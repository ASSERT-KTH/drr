import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 1, 0.0f, textAnchor4, (double) '4', textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            stackedAreaRenderer1.setSeriesOutlinePaint((-1), paint5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font2, paint7, rectangleEdge9, horizontalAlignment10, verticalAlignment11, rectangleInsets12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.geom.Point2D point2D8 = null;
        try {
            xYPlot7.setQuadrantOrigin(point2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = java.awt.Color.black;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) 100, 12.0d, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ThreadContext", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        try {
            dateAxis1.setAutoRangeMinimumSize((-8.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint2 = boxAndWhiskerRenderer0.lookupSeriesFillPaint(1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = boxAndWhiskerRenderer0.initialise(graphics2D3, rectangle2D4, categoryPlot5, 15, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Paint paint9 = null;
        try {
            xYPlot7.setDomainCrosshairPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot7.getDomainAxisForDataset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("{0}");
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.removeFragment(textFragment2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ThreadContext");
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ThreadContext", graphics2D1, (float) '#', (float) (short) 0, textAnchor4, 2.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            stackedAreaRenderer1.drawDomainMarker(graphics2D4, categoryPlot5, categoryAxis6, categoryMarker7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean17 = dateAxis11.isInverted();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        try {
            jFreeChart2.draw(graphics2D3, rectangle2D4, point2D5, chartRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.resizeRange(0.0d, 100.0d);
        java.awt.Stroke stroke9 = null;
        try {
            dateAxis1.setAxisLineStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { (byte) 100, 12.0d, 100, (-1.0f), 11 };
        java.lang.String[] strArray6 = org.jfree.data.time.SerialDate.getMonths();
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, (java.lang.Comparable[]) strArray6, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of column keys does not match the number of columns in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            waferMapPlot2.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            stackedAreaRenderer1.drawOutline(graphics2D4, categoryPlot5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Date date0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(date1, date2);
        try {
            org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date0, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = stackedBarRenderer3D2.initialise(graphics2D3, rectangle2D4, categoryPlot5, (int) (short) 100, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        try {
            jFreeChart2.draw(graphics2D4, rectangle2D5, point2D6, chartRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        java.awt.Color color7 = java.awt.Color.pink;
        stackedAreaRenderer1.setBaseItemLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = stackedAreaRenderer1.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean22 = numberAxis3D21.getAutoRangeIncludesZero();
        try {
            xYPlot7.setDomainAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        java.awt.Paint paint10 = stackedAreaRenderer1.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        try {
            org.jfree.data.Range range12 = stackedAreaRenderer1.findRangeBounds(categoryDataset11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        try {
            org.jfree.chart.plot.XYPlot xYPlot4 = jFreeChart2.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        dateAxis3.setNegativeArrowVisible(false);
        float float7 = dateAxis3.getTickMarkInsideLength();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(date8, date9);
        dateAxis3.setRange((org.jfree.data.Range) dateRange10);
        numberAxis3D1.setRange((org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range15 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, 0.0d, (double) (-1L));
        org.jfree.data.Range range17 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange10, 0.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        xYPlot7.mapDatasetToDomainAxis((int) (byte) 100, 15);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            xYPlot7.drawOutline(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        boolean boolean4 = jFreeChart2.isNotify();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        numberAxis3D1.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        try {
            java.lang.String str7 = standardCategoryURLGenerator3.generateURL(categoryDataset4, 15, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        try {
            java.lang.String str3 = standardCategoryToolTipGenerator0.generateRowLabel(categoryDataset1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint9 = stackedAreaRenderer7.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer7.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedAreaRenderer7.getBaseItemLabelGenerator();
        double double13 = stackedAreaRenderer7.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer7.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis1.setAxisLinePaint(paint16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        float float22 = dateAxis21.getTickMarkOutsideLength();
        dateAxis21.setNegativeArrowVisible(false);
        float float25 = dateAxis21.getTickMarkInsideLength();
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange(date26, date27);
        dateAxis21.setRange((org.jfree.data.Range) dateRange28);
        numberAxis3D19.setRange((org.jfree.data.Range) dateRange28);
        dateAxis1.setRange((org.jfree.data.Range) dateRange28);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge34);
        try {
            double double36 = dateAxis1.valueToJava2D((double) (-1.0f), rectangle2D33, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            xYPlot7.addAnnotation(xYAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemURLGenerator();
        org.jfree.chart.LegendItem legendItem8 = stackedAreaRenderer1.getLegendItem(1, (int) ' ');
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        try {
            jFreeChart2.addSubtitle((int) (byte) -1, (org.jfree.chart.title.Title) textTitle5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        xYPlot7.setBackgroundAlpha((float) 1L);
        xYPlot7.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (double) (-1L), 4.0d, (double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '#');
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        java.awt.Graphics2D graphics2D9 = null;
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date10, date11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        dateAxis16.setNegativeArrowVisible(false);
        float float20 = dateAxis16.getTickMarkInsideLength();
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        dateAxis16.setRange((org.jfree.data.Range) dateRange23);
        numberAxis3D14.setRange((org.jfree.data.Range) dateRange23);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange12, (org.jfree.data.Range) dateRange23);
        double double27 = rectangleConstraint26.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = rectangleConstraint26.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D29 = labelBlock3.arrange(graphics2D9, rectangleConstraint26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10L, (double) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            labelBlock3.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = numberAxis3D1.draw(graphics2D3, 0.0d, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setVisible(false);
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        boolean boolean5 = numberAxis3D1.getAutoRangeIncludesZero();
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0, (int) '4', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(date1, date2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        dateAxis7.setNegativeArrowVisible(false);
        float float11 = dateAxis7.getTickMarkInsideLength();
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(date12, date13);
        dateAxis7.setRange((org.jfree.data.Range) dateRange14);
        numberAxis3D5.setRange((org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange14);
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange(date18, date19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        float float25 = dateAxis24.getTickMarkOutsideLength();
        dateAxis24.setNegativeArrowVisible(false);
        float float28 = dateAxis24.getTickMarkInsideLength();
        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange(date29, date30);
        dateAxis24.setRange((org.jfree.data.Range) dateRange31);
        numberAxis3D22.setRange((org.jfree.data.Range) dateRange31);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange20, (org.jfree.data.Range) dateRange31);
        double double35 = rectangleConstraint34.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = rectangleConstraint34.getWidthConstraintType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        float float42 = dateAxis41.getTickMarkOutsideLength();
        dateAxis41.setNegativeArrowVisible(false);
        float float45 = dateAxis41.getTickMarkInsideLength();
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date47 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange48 = new org.jfree.data.time.DateRange(date46, date47);
        dateAxis41.setRange((org.jfree.data.Range) dateRange48);
        numberAxis3D39.setRange((org.jfree.data.Range) dateRange48);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType51 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint((double) 0L, (org.jfree.data.Range) dateRange14, lengthConstraintType36, (double) (short) 10, (org.jfree.data.Range) dateRange48, lengthConstraintType51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date47);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot7.getAxisOffset();
        double double14 = rectangleInsets12.trimWidth(100.0d);
        double double16 = rectangleInsets12.calculateTopOutset((double) 0.0f);
        double double18 = rectangleInsets12.calculateLeftInset((double) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot7.setFixedDomainAxisSpace(axisSpace17);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        java.util.List list4 = null;
        try {
            jFreeChart2.setSubtitles(list4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = stackedBarRenderer3D2.getItemLabelPaint((int) (byte) -1, 9999);
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint8, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot7.setOrientation(plotOrientation11);
        boolean boolean13 = xYPlot7.isRangeCrosshairVisible();
        java.awt.Paint paint14 = null;
        try {
            xYPlot7.setRangeGridlinePaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double9 = dateAxis1.lengthToJava2D((double) 2, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot0.setLabelOutlinePaint(paint2);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        dateAxis7.setNegativeArrowVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        try {
            boxAndWhiskerRenderer0.drawHorizontalItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryDataset11, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries1.removeAll();
        taskSeries1.setNotify(false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = rendererChangeEvent1.getType();
        org.jfree.chart.JFreeChart jFreeChart3 = rendererChangeEvent1.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        try {
            double double2 = piePlot3D1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Last", "{0}");
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        dateAxis11.resizeRange(0.0d, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        try {
            stackedBarRenderer3D2.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryDataset19, (int) 'a', (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font6, (org.jfree.chart.plot.Plot) piePlot9, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState14 = piePlot0.initialise(graphics2D2, rectangle2D3, piePlot9, (java.lang.Integer) 0, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
        double double3 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Object obj1 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.dateToJava2D(date8, rectangle2D10, rectangleEdge11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets13.trimHeight(0.0d);
        boolean boolean16 = dateAxis2.equals((java.lang.Object) double15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-8.0d) + "'", double15 == (-8.0d));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '#');
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis3D1.draw(graphics2D2, 0.0d, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        try {
            piePlot0.setLegendLabelGenerator(pieSectionLabelGenerator2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color1 = java.awt.Color.getColor("HorizontalAlignment.RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = rectangleAnchor0.equals(obj2);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedAreaRenderer1.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 1, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = stackedAreaRenderer1.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        double double2 = piePlot0.getInteriorGap();
        piePlot0.setStartAngle((double) 0.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        dateAxis3.setNegativeArrowVisible(false);
        float float7 = dateAxis3.getTickMarkInsideLength();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(date8, date9);
        dateAxis3.setRange((org.jfree.data.Range) dateRange10);
        numberAxis3D1.setRange((org.jfree.data.Range) dateRange10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = null;
        try {
            numberAxis3D1.setTickUnit(numberTickUnit13, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) '4', (double) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        try {
            xYPlot7.setRenderer((int) (byte) -1, xYItemRenderer32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint2 = boxAndWhiskerRenderer0.lookupSeriesFillPaint(1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean7 = numberAxis3D6.getAutoRangeIncludesZero();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            boxAndWhiskerRenderer0.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.plot.Marker) valueMarker9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        double double5 = dateAxis1.getFixedDimension();
        dateAxis1.resizeRange(4.0d, 0.0d);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer15);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis11.dateToJava2D(date17, rectangle2D19, rectangleEdge20);
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange(date22, date23);
        try {
            dateAxis1.setRange(date17, date23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) '#', (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10, 0.0d);
        columnArrangement4.clear();
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = null;
//        projectInfo0.setLogo(image1);
//        projectInfo0.setLicenceText("hi!");
//        java.lang.String str5 = projectInfo0.getName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart" + "'", str5.equals("JFreeChart"));
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = null;
        try {
            valueMarker1.setPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLegendLabelToolTipGenerator();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            piePlot3D1.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        java.awt.Shape shape8 = legendGraphic7.getLine();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            legendGraphic7.draw(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Color color8 = java.awt.Color.CYAN;
        piePlot5.setBaseSectionOutlinePaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = null;
        try {
            piePlot5.setBaseSectionPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis3D1.getTickUnit();
        numberAxis3D1.setAutoRangeMinimumSize(0.4d, true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean10 = numberAxis3D9.getAutoRangeIncludesZero();
        boolean boolean11 = multiplePiePlot7.equals((java.lang.Object) boolean10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        multiplePiePlot7.setDrawingSupplier(drawingSupplier12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot7);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 10, (double) 9999);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        xYPlot7.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        java.awt.Paint paint23 = xYPlot10.getBackgroundPaint();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot10.setDataset(xYDataset24);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot7.getAxisOffset();
        double double14 = rectangleInsets12.trimWidth(100.0d);
        double double16 = rectangleInsets12.calculateTopOutset((double) 0.0f);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D19.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedBarRenderer3D19.getPositiveItemLabelPositionFallback();
        boolean boolean23 = rectangleInsets12.equals((java.lang.Object) itemLabelPosition22);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(itemLabelPosition22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot7.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot18.getPieChart();
        java.awt.Image image20 = jFreeChart19.getBackgroundImage();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            jFreeChart19.draw(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNull(image20);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateLeftInset((-8.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendGraphic7.getFillPaintTransformer();
        double double9 = legendGraphic7.getContentYOffset();
        boolean boolean10 = legendGraphic7.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.resizeRange(0.0d, 100.0d);
        dateAxis1.resizeRange(8.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '#', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        float float16 = dateAxis15.getTickMarkOutsideLength();
        dateAxis15.setNegativeArrowVisible(false);
        float float19 = dateAxis15.getTickMarkInsideLength();
        xYPlot11.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot11.getDomainMarkers(layer21);
        boolean boolean23 = simpleTimePeriod3.equals((java.lang.Object) xYPlot11);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("ThreadContext", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot7.getAxisOffset();
        float float13 = xYPlot7.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setLowerMargin((double) 100);
        java.text.DateFormat dateFormat4 = null;
        dateAxis1.setDateFormatOverride(dateFormat4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator9 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        lineAndShapeRenderer0.setSeriesURLGenerator(9999, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D11, categoryPlot12, categoryAxis13, categoryMarker14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker1.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint7 = stackedAreaRenderer5.getSeriesItemLabelPaint(100);
        stackedAreaRenderer5.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer5.setSeriesStroke(100, stroke11);
        valueMarker1.setStroke(stroke11);
        java.lang.Class class14 = null;
        try {
            java.util.EventListener[] eventListenerArray15 = valueMarker1.getListeners(class14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("cyan", "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = xYPlot9.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        dateAxis13.setNegativeArrowVisible(false);
        float float17 = dateAxis13.getTickMarkInsideLength();
        xYPlot9.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot9.getDomainMarkers(layer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot9.setRangeAxisLocation((int) (short) 100, axisLocation22, true);
        boolean boolean25 = year1.equals((java.lang.Object) (short) 100);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year1.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setForegroundAlpha(0.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        dateAxis5.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot9 = dateAxis5.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint13 = stackedAreaRenderer11.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = stackedAreaRenderer11.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = stackedAreaRenderer11.getBaseItemLabelGenerator();
        double double17 = stackedAreaRenderer11.getItemLabelAnchorOffset();
        java.awt.Paint paint20 = stackedAreaRenderer11.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis5.setAxisLinePaint(paint20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        float float26 = dateAxis25.getTickMarkOutsideLength();
        dateAxis25.setNegativeArrowVisible(false);
        float float29 = dateAxis25.getTickMarkInsideLength();
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date31 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange(date30, date31);
        dateAxis25.setRange((org.jfree.data.Range) dateRange32);
        numberAxis3D23.setRange((org.jfree.data.Range) dateRange32);
        dateAxis5.setRange((org.jfree.data.Range) dateRange32);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, (org.jfree.data.Range) dateRange32);
        try {
            int int37 = simpleTimePeriod2.compareTo((java.lang.Object) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setRangeAxisLocation((int) (short) 100, axisLocation20, true);
        int int23 = xYPlot7.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Last");
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1L), (double) (-1), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.LegendItemCollection legendItemCollection2 = piePlot3D1.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        xYPlot7.setBackgroundAlpha((float) 1L);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        xYPlot7.datasetChanged(datasetChangeEvent13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot7.setDataset(xYDataset15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setLowerMargin((double) 15);
        double double7 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        float float9 = dateAxis8.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        org.jfree.data.Range range14 = dateAxis8.getRange();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        try {
            boxAndWhiskerRenderer0.drawVerticalItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryDataset15, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset4 = piePlot2.getDataset();
        piePlot2.setMinimumArcAngleToDraw(12.0d);
        boolean boolean7 = textTitle1.equals((java.lang.Object) piePlot2);
        boolean boolean8 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setLowerMargin((double) 100);
        boolean boolean4 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        java.lang.Object obj7 = textTitle5.clone();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis3D1.getTickUnit();
        numberAxis3D1.setAutoRangeMinimumSize(0.4d, true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = numberAxis3D1.draw(graphics2D6, (double) (byte) 10, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = xYPlot9.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        dateAxis13.setNegativeArrowVisible(false);
        float float17 = dateAxis13.getTickMarkInsideLength();
        xYPlot9.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot9.getDomainMarkers(layer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot9.setRangeAxisLocation((int) (short) 100, axisLocation22, true);
        boolean boolean25 = year1.equals((java.lang.Object) (short) 100);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year1.getMiddleMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity3 = new org.jfree.chart.entity.TickLabelEntity(shape0, "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!", "{0}");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot10.setNoDataMessagePaint((java.awt.Paint) color12);
        xYPlot10.clearRangeAxes();
        xYPlot10.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot10.getRangeAxisLocation((int) (short) 1);
        java.awt.Paint paint19 = xYPlot10.getDomainCrosshairPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape2, paint19);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, 2.0d, (float) 1, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator(10, categoryItemLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint11 = stackedAreaRenderer9.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedAreaRenderer9.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = stackedAreaRenderer9.getBaseItemLabelGenerator();
        double double15 = stackedAreaRenderer9.getItemLabelAnchorOffset();
        java.lang.Boolean boolean17 = stackedAreaRenderer9.getSeriesItemLabelsVisible((-1));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = stackedAreaRenderer9.getLegendItemLabelGenerator();
        stackedAreaRenderer1.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection3 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color8 = java.awt.Color.CYAN;
        stackedAreaRenderer6.setSeriesFillPaint(2, (java.awt.Paint) color8, true);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        double double19 = stackedAreaRenderer13.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedAreaRenderer13.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint24 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        stackedAreaRenderer13.setSeriesPaint(2, paint24);
        java.awt.Stroke stroke26 = null;
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("hi!", font28, paint29);
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "", shape4, paint24, stroke26, paint29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        java.awt.Paint paint13 = xYPlot12.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        xYPlot12.setDrawingSupplier(drawingSupplier14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = xYPlot12.getDatasetRenderingOrder();
        boolean boolean17 = textAnchor4.equals((java.lang.Object) datasetRenderingOrder16);
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.text.TextUtilities.drawAlignedString("JFreeChart", graphics2D1, (float) 100L, (float) (byte) -1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer2 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer2.setItemMargin(100.0d);
        int int5 = numberTickUnit1.compareTo((java.lang.Object) 100.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Stroke stroke8 = jFreeChart7.getBorderStroke();
        org.jfree.chart.title.LegendTitle legendTitle9 = null;
        try {
            jFreeChart7.addLegend(legendTitle9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedAreaRenderer1.lookupSeriesFillPaint((int) ' ');
        java.awt.Paint paint8 = stackedAreaRenderer1.getBaseOutlinePaint();
        java.awt.Paint paint10 = stackedAreaRenderer1.getSeriesItemLabelPaint((int) (byte) 100);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Locale locale1 = dataPackageResources0.getLocale();
        java.util.Set<java.lang.String> strSet2 = dataPackageResources0.keySet();
        boolean boolean4 = dataPackageResources0.containsKey("Last");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Locale locale1 = dataPackageResources0.getLocale();
        java.util.Set<java.lang.String> strSet2 = dataPackageResources0.keySet();
        boolean boolean4 = dataPackageResources0.containsKey("ThreadContext");
        try {
            java.lang.String str6 = dataPackageResources0.getString("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) 100L, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(8.0d, (double) (byte) 10, (double) 100L, (double) (short) 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 0L;
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D2.setVisible(false);
        org.jfree.chart.plot.Plot plot5 = numberAxis3D2.getPlot();
        java.awt.Shape shape6 = numberAxis3D2.getLeftArrow();
        boolean boolean7 = borderArrangement0.equals((java.lang.Object) shape6);
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 2);
        boolean boolean11 = blockContainer8.equals((java.lang.Object) 2);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean4 = numberAxis3D3.getAutoRangeIncludesZero();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) boolean4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            multiplePiePlot1.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot7.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot18.getPieChart();
        java.awt.Image image20 = jFreeChart19.getBackgroundImage();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot7.setAxisOffset(rectangleInsets22);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker26.setLabel("");
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot7.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker26, layer29);
        try {
            valueMarker26.setAlpha((float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(layer29);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        dateAxis4.setNegativeArrowVisible(false);
        float float8 = dateAxis4.getTickMarkInsideLength();
        dateAxis4.resizeRange(0.0d, 100.0d);
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) dateAxis4);
        java.lang.Class class13 = null;
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(date16, date17);
        org.jfree.data.gantt.Task task19 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date15, date16);
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date16, timeZone20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double24 = dateAxis4.dateToJava2D(date16, rectangle2D22, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        java.awt.Paint paint16 = xYPlot7.getDomainCrosshairPaint();
        xYPlot7.setForegroundAlpha((float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke5 = piePlot4.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset6 = piePlot4.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot0.initialise(graphics2D2, rectangle2D3, piePlot4, (java.lang.Integer) (-1), plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieDataset6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot10.getDomainAxisLocation(0);
        int int25 = xYPlot10.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        double double5 = stackedBarRenderer3D2.getMinimumBarLength();
        java.awt.Paint paint6 = stackedBarRenderer3D2.getWallPaint();
        boolean boolean7 = stackedBarRenderer3D2.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot7.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot18.getPieChart();
        java.awt.Image image20 = jFreeChart19.getBackgroundImage();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot7.setAxisOffset(rectangleInsets22);
        double double25 = rectangleInsets22.calculateTopInset((double) 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.calculateTopInset((double) 15);
        double double6 = rectangleInsets0.calculateTopInset(90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.0d) + "'", double2 == (-8.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot7.getRangeAxisEdge(15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot7.handleClick((int) (short) 0, 10, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("Last", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        try {
            org.jfree.data.gantt.Task task6 = task4.getSubtask(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D6.setVisible(false);
        org.jfree.chart.plot.Plot plot9 = numberAxis3D6.getPlot();
        java.awt.Shape shape10 = numberAxis3D6.getLeftArrow();
        boolean boolean11 = borderArrangement4.equals((java.lang.Object) shape10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint16 = stackedAreaRenderer14.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer14.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = stackedAreaRenderer14.getBaseItemLabelGenerator();
        double double20 = stackedAreaRenderer14.getItemLabelAnchorOffset();
        java.awt.Paint paint23 = stackedAreaRenderer14.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker26.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer30 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint32 = stackedAreaRenderer30.getSeriesItemLabelPaint(100);
        stackedAreaRenderer30.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer30.setSeriesStroke(100, stroke36);
        valueMarker26.setStroke(stroke36);
        stackedAreaRenderer14.setSeriesStroke(11, stroke36);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        float float43 = dateAxis42.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer46);
        java.awt.Paint paint48 = xYPlot47.getRangeTickBandPaint();
        java.awt.Color color49 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot47.setNoDataMessagePaint((java.awt.Paint) color49);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor51 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean52 = xYPlot47.equals((java.lang.Object) itemLabelAnchor51);
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke54 = piePlot53.getBaseSectionOutlineStroke();
        java.awt.Color color55 = java.awt.Color.CYAN;
        piePlot53.setShadowPaint((java.awt.Paint) color55);
        java.lang.String str57 = org.jfree.chart.util.PaintUtilities.colorToString(color55);
        xYPlot47.setOutlinePaint((java.awt.Paint) color55);
        try {
            org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "", "JFreeChart", shape10, paint12, stroke36, (java.awt.Paint) color55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 2.0f + "'", float43 == 2.0f);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(itemLabelAnchor51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "cyan" + "'", str57.equals("cyan"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "cyan", "{0}", "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, (double) (-1L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot7.getAxisOffset();
        double double10 = rectangleInsets8.calculateLeftOutset((double) 11);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets8.createInsetRectangle(rectangle2D11, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = null;
//        projectInfo0.setLogo(image1);
//        projectInfo0.setLicenceText("hi!");
//        java.lang.String str5 = projectInfo0.toString();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!" + "'", str5.equals("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!"));
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        dateAxis2.setNegativeArrowVisible(false);
        float float6 = dateAxis2.getTickMarkInsideLength();
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(date7, date8);
        dateAxis2.setRange((org.jfree.data.Range) dateRange9);
        double double11 = dateAxis2.getFixedAutoRange();
        boolean boolean13 = dateAxis2.isHiddenValue((-1L));
        java.awt.Color color17 = java.awt.Color.getHSBColor(100.0f, (float) (short) 1, (float) (short) 0);
        dateAxis2.setLabelPaint((java.awt.Paint) color17);
        java.awt.Color color19 = java.awt.Color.getColor("HorizontalAlignment.RIGHT", color17);
        int int20 = color19.getGreen();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendGraphic7.getFillPaintTransformer();
        double double9 = legendGraphic7.getContentYOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendGraphic7.getShapeAnchor();
        double double11 = legendGraphic7.getHeight();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        xYPlot10.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot10.setDomainAxisLocation(axisLocation14, false);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.chart.plot.Plot plot18 = dateAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(plot18);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("hi!", font2, paint3);
        boolean boolean5 = ringPlot0.equals((java.lang.Object) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D6, rectangle2D7, piePlot8, (java.lang.Integer) 100, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("GradientPaintTransformType.HORIZONTAL", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        try {
            java.lang.Comparable comparable9 = defaultIntervalCategoryDataset7.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisible(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = xYPlot9.getRangeTickBandPaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint14 = stackedAreaRenderer12.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = stackedAreaRenderer12.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer12.getBaseItemLabelGenerator();
        double double18 = stackedAreaRenderer12.getItemLabelAnchorOffset();
        java.awt.Paint paint21 = stackedAreaRenderer12.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker24.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint30 = stackedAreaRenderer28.getSeriesItemLabelPaint(100);
        stackedAreaRenderer28.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer28.setSeriesStroke(100, stroke34);
        valueMarker24.setStroke(stroke34);
        stackedAreaRenderer12.setSeriesStroke(11, stroke34);
        xYPlot9.setRangeCrosshairStroke(stroke34);
        strokeList0.setStroke(2, stroke34);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean11 = stackedAreaRenderer9.getSeriesVisibleInLegend(10);
        boolean boolean12 = stackedAreaRenderer9.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer9.getLegendItemURLGenerator();
        java.awt.Paint paint15 = stackedAreaRenderer9.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer1.setSeriesPaint(1, paint15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font20 = textTitle19.getFont();
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font20, paint21);
        stackedAreaRenderer1.setBaseItemLabelPaint(paint21, false);
        stackedAreaRenderer1.setBaseItemLabelsVisible(false);
        java.awt.Paint paint27 = null;
        stackedAreaRenderer1.setBasePaint(paint27);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '#');
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date1, date2);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("Last", (org.jfree.data.time.TimePeriod) simpleTimePeriod9);
        task5.addSubtask(task10);
        boolean boolean13 = task5.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot7.getDomainAxisLocation();
        xYPlot7.clearRangeMarkers(100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ThreadContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D5.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D5.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint11 = stackedBarRenderer3D5.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D2.setBaseOutlinePaint(paint11);
        boolean boolean13 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = xYPlot10.getFixedRangeAxisSpace();
        xYPlot10.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(axisSpace25);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        try {
            java.lang.Comparable comparable9 = defaultIntervalCategoryDataset7.getRowKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues0.getKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(15);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        labelBlock3.setToolTipText("hi!");
        java.lang.Object obj11 = labelBlock3.clone();
        java.awt.Graphics2D graphics2D12 = null;
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(date13, date14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        float float20 = dateAxis19.getTickMarkOutsideLength();
        dateAxis19.setNegativeArrowVisible(false);
        float float23 = dateAxis19.getTickMarkInsideLength();
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange(date24, date25);
        dateAxis19.setRange((org.jfree.data.Range) dateRange26);
        numberAxis3D17.setRange((org.jfree.data.Range) dateRange26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange26);
        double double30 = rectangleConstraint29.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D31 = labelBlock3.arrange(graphics2D12, rectangleConstraint29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ThreadContext", font1, paint2, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font6, (org.jfree.chart.plot.Plot) piePlot9, false);
        stackedBarRenderer3D2.setSeriesItemLabelFont((int) '4', font6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        int int14 = stackedBarRenderer3D2.getPassCount();
        org.jfree.chart.LegendItem legendItem17 = stackedBarRenderer3D2.getLegendItem((int) (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(legendItem17);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setVisible(false);
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState((double) 2);
        axisState7.cursorDown((double) 15);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer17);
        java.awt.Paint paint19 = xYPlot18.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        xYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot18.setDomainAxisLocation(axisLocation22, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = null;
        xYPlot18.notifyListeners(plotChangeEvent25);
        java.awt.Stroke stroke27 = xYPlot18.getDomainZeroBaselineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot18.getRangeAxisEdge();
        try {
            java.util.List list29 = numberAxis3D1.refreshTicks(graphics2D5, axisState7, rectangle2D10, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Stroke stroke4 = stackedBarRenderer3D2.lookupSeriesStroke((int) 'a');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint8 = stackedAreaRenderer6.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedAreaRenderer6.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer6.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedAreaRenderer6.getLegendItemToolTipGenerator();
        stackedAreaRenderer6.setSeriesCreateEntities(2, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator17 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (byte) 10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator17);
        stackedBarRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator17);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray23, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        float float30 = dateAxis29.getTickMarkOutsideLength();
        dateAxis29.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot33 = dateAxis29.getPlot();
        double double34 = dateAxis29.getUpperBound();
        java.awt.Shape shape35 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint39 = stackedAreaRenderer37.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = stackedAreaRenderer37.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator42 = stackedAreaRenderer37.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer45 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean47 = stackedAreaRenderer45.getSeriesVisibleInLegend(10);
        boolean boolean48 = stackedAreaRenderer45.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = stackedAreaRenderer45.getLegendItemURLGenerator();
        java.awt.Paint paint51 = stackedAreaRenderer45.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer37.setSeriesPaint(1, paint51);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font56 = textTitle55.getFont();
        java.awt.Paint paint57 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine58 = new org.jfree.chart.text.TextLine("", font56, paint57);
        stackedAreaRenderer37.setBaseItemLabelPaint(paint57, false);
        stackedAreaRenderer37.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer37);
        try {
            java.lang.String str65 = standardCategoryToolTipGenerator17.generateColumnLabel(categoryDataset26, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(categoryItemLabelGenerator41);
        org.junit.Assert.assertNull(categoryItemLabelGenerator42);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setLowerMargin(3.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator4 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean5 = lineAndShapeRenderer0.equals((java.lang.Object) "");
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(date3, date4);
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date2, date3);
        java.util.TimeZone timeZone7 = null;
        try {
            java.util.Date date8 = dateTickUnit0.addToDate(date3, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean12 = xYPlot7.equals((java.lang.Object) itemLabelAnchor11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke14 = piePlot13.getBaseSectionOutlineStroke();
        java.awt.Color color15 = java.awt.Color.CYAN;
        piePlot13.setShadowPaint((java.awt.Paint) color15);
        java.lang.String str17 = org.jfree.chart.util.PaintUtilities.colorToString(color15);
        xYPlot7.setOutlinePaint((java.awt.Paint) color15);
        java.awt.Paint paint19 = xYPlot7.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "cyan" + "'", str17.equals("cyan"));
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8);
        double double10 = dateAxis1.getFixedAutoRange();
        boolean boolean12 = dateAxis1.isHiddenValue((-1L));
        java.awt.Color color16 = java.awt.Color.getHSBColor(100.0f, (float) (short) 1, (float) (short) 0);
        dateAxis1.setLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = dateAxis1.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot3D9.setLegendLabelURLGenerator(pieURLGenerator11);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D2.setVisible(false);
        org.jfree.chart.plot.Plot plot5 = numberAxis3D2.getPlot();
        java.awt.Shape shape6 = numberAxis3D2.getLeftArrow();
        boolean boolean7 = borderArrangement0.equals((java.lang.Object) shape6);
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = blockContainer8.arrange(graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        try {
            java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = null;
        projectInfo2.setLogo(image3);
        projectInfo2.setLicenceText("hi!");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo2.setLicenceText("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(projectInfo2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        boolean boolean3 = org.jfree.chart.util.ShapeUtilities.equal(shape0, shape2);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape2, "", "ThreadContext");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator7 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator8 = null;
        try {
            java.lang.String str9 = tickLabelEntity6.getImageMapAreaTag(toolTipTagFragmentGenerator7, uRLTagFragmentGenerator8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot2.getPieChart();
        java.awt.Paint paint4 = jFreeChart3.getBorderPaint();
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape0, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.resizeRange(0.0d, 100.0d);
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date9, date10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        float float16 = dateAxis15.getTickMarkOutsideLength();
        dateAxis15.setNegativeArrowVisible(false);
        float float19 = dateAxis15.getTickMarkInsideLength();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(date20, date21);
        dateAxis15.setRange((org.jfree.data.Range) dateRange22);
        numberAxis3D13.setRange((org.jfree.data.Range) dateRange22);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange11, (org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange11, (double) 86400000L, (double) 1);
        dateAxis1.setRange(range28, true, false);
        org.jfree.data.Range range34 = org.jfree.data.Range.expand(range28, 4.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Stroke stroke4 = stackedBarRenderer3D2.lookupSeriesStroke((int) 'a');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint8 = stackedAreaRenderer6.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedAreaRenderer6.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer6.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedAreaRenderer6.getLegendItemToolTipGenerator();
        stackedAreaRenderer6.setSeriesCreateEntities(2, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator17 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (byte) 10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator17);
        stackedBarRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator17);
        stackedBarRenderer3D2.setMaximumBarWidth((double) 1L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset2 = piePlot0.getDataset();
        piePlot0.setMinimumArcAngleToDraw(12.0d);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint8 = stackedAreaRenderer6.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedAreaRenderer6.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer6.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean16 = stackedAreaRenderer14.getSeriesVisibleInLegend(10);
        boolean boolean17 = stackedAreaRenderer14.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = stackedAreaRenderer14.getLegendItemURLGenerator();
        java.awt.Paint paint20 = stackedAreaRenderer14.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer6.setSeriesPaint(1, paint20);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font25 = textTitle24.getFont();
        java.awt.Paint paint26 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("", font25, paint26);
        stackedAreaRenderer6.setBaseItemLabelPaint(paint26, false);
        piePlot0.setLabelPaint(paint26);
        org.jfree.chart.util.Rotation rotation31 = null;
        try {
            piePlot0.setDirection(rotation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(pieDataset2);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color5 = java.awt.Color.CYAN;
        stackedAreaRenderer3.setSeriesFillPaint(2, (java.awt.Paint) color5, true);
        piePlot0.setLabelShadowPaint((java.awt.Paint) color5);
        piePlot0.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset6, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(range45);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        boolean boolean3 = org.jfree.chart.util.ShapeUtilities.equal(shape0, shape2);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape2, "", "ThreadContext");
        tickLabelEntity6.setToolTipText("");
        tickLabelEntity6.setURLText("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("cyan", font3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D10.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D10.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint16 = stackedBarRenderer3D10.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D7.setBaseOutlinePaint(paint16);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("{0}", font3, paint16, (float) 2);
        java.awt.Color color20 = java.awt.Color.orange;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.text.TextMeasurer textMeasurer24 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("GradientPaintTransformType.HORIZONTAL", font3, (java.awt.Paint) color20, 2.0f, 31, textMeasurer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font2 = textTitle1.getFont();
        java.awt.Color color3 = java.awt.Color.RED;
        textTitle1.setPaint((java.awt.Paint) color3);
        textTitle1.setText("HorizontalAlignment.RIGHT");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.insertValue((int) '#', (java.lang.Comparable) 100.0f, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.JFreeChart jFreeChart29 = multiplePiePlot28.getPieChart();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot7.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        try {
            xYPlot7.zoomDomainAxes((double) (short) 10, 3.0d, plotRenderingInfo34, point2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jFreeChart29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot7.getAxisOffset();
        xYPlot7.setRangeCrosshairValue((double) (-1.0f), true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        boolean boolean7 = textTitle5.getExpandToFitSpace();
        double double8 = textTitle5.getHeight();
        textTitle5.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator9 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        lineAndShapeRenderer0.setSeriesURLGenerator(9999, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator9);
        boolean boolean13 = lineAndShapeRenderer0.getItemShapeFilled(15, (int) 'a');
        boolean boolean14 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset2 = piePlot0.getDataset();
        piePlot0.setMinimumArcAngleToDraw(12.0d);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint8 = stackedAreaRenderer6.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedAreaRenderer6.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer6.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean16 = stackedAreaRenderer14.getSeriesVisibleInLegend(10);
        boolean boolean17 = stackedAreaRenderer14.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = stackedAreaRenderer14.getLegendItemURLGenerator();
        java.awt.Paint paint20 = stackedAreaRenderer14.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer6.setSeriesPaint(1, paint20);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font25 = textTitle24.getFont();
        java.awt.Paint paint26 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("", font25, paint26);
        stackedAreaRenderer6.setBaseItemLabelPaint(paint26, false);
        piePlot0.setLabelPaint(paint26);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator31 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator31);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(pieDataset2);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange13);
        double double17 = rectangleConstraint16.getHeight();
        org.jfree.data.Range range18 = rectangleConstraint16.getHeightRange();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        java.lang.String str2 = projectInfo0.toString();
//        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getOptionalLibraries();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code." + "'", str2.equals("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code."));
//        org.junit.Assert.assertNotNull(libraryArray3);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color5 = java.awt.Color.CYAN;
        stackedAreaRenderer3.setSeriesFillPaint(2, (java.awt.Paint) color5, true);
        piePlot0.setLabelShadowPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = null;
        try {
            piePlot0.setLegendLabelGenerator(pieSectionLabelGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = null;
        piePlot3D1.setToolTipGenerator(pieToolTipGenerator3);
        piePlot3D1.setDepthFactor((double) 1.0f);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        java.awt.Paint paint11 = piePlot3D9.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        float float47 = dateAxis46.getTickMarkOutsideLength();
        dateAxis46.setNegativeArrowVisible(false);
        dateAxis46.setLowerMargin((double) 15);
        dateAxis46.setLowerMargin(0.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator58 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean59 = lineAndShapeRenderer54.equals((java.lang.Object) "");
        boolean boolean61 = lineAndShapeRenderer54.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer54);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset6);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(range63);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = xYPlot9.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        dateAxis13.setNegativeArrowVisible(false);
        float float17 = dateAxis13.getTickMarkInsideLength();
        xYPlot9.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot9.getDomainMarkers(layer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot9.setRangeAxisLocation((int) (short) 100, axisLocation22, true);
        boolean boolean25 = year1.equals((java.lang.Object) (short) 100);
        java.util.Date date26 = year1.getEnd();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.TickLabelEntity tickLabelEntity3 = new org.jfree.chart.entity.TickLabelEntity(shape0, "RectangleAnchor.BOTTOM_RIGHT", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer7);
        java.awt.Paint paint9 = xYPlot8.getRangeTickBandPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot8.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("cyan", (org.jfree.chart.plot.Plot) xYPlot8);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot7.getRangeMarkers(9999, layer10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        xYPlot7.datasetChanged(datasetChangeEvent12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        double double2 = piePlot0.getShadowXOffset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Shape shape4 = lineAndShapeRenderer0.getItemShape(6, 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = lineAndShapeRenderer0.getBaseURLGenerator();
        boolean boolean6 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        xYPlot7.notifyListeners(plotChangeEvent14);
        java.awt.Paint paint16 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke17 = xYPlot7.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot7.setRangeAxisLocation(axisLocation18, true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 2);
        axisState1.setCursor(0.2d);
        axisState1.cursorRight(0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(31, (int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) lengthAdjustmentType0);
        java.lang.String str2 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EXPAND" + "'", str2.equals("EXPAND"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedAreaRenderer1.getBaseNegativeItemLabelPosition();
        stackedAreaRenderer1.setAutoPopulateSeriesPaint(true);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.util.List list8 = jFreeChart7.getSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart7.getLegend(10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendTitle10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Stroke stroke17 = xYPlot7.getDomainGridlineStroke();
        java.awt.Stroke stroke18 = xYPlot7.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot7.addChangeListener(plotChangeListener27);
        xYPlot7.setNoDataMessage("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        try {
            java.lang.Comparable comparable12 = defaultIntervalCategoryDataset7.getSeriesKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such series : 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            xYPlot7.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Stroke stroke2 = stackedAreaRenderer1.getBaseStroke();
        int int3 = stackedAreaRenderer1.getPassCount();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        stackedBarRenderer3D2.setMaximumBarWidth(0.0d);
        org.junit.Assert.assertNull(itemLabelPosition5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Stroke stroke4 = stackedBarRenderer3D2.lookupSeriesStroke((int) 'a');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint8 = stackedAreaRenderer6.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedAreaRenderer6.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer6.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedAreaRenderer6.getLegendItemToolTipGenerator();
        stackedAreaRenderer6.setSeriesCreateEntities(2, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator17 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (byte) 10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator17);
        stackedBarRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator17);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray23, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        float float30 = dateAxis29.getTickMarkOutsideLength();
        dateAxis29.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot33 = dateAxis29.getPlot();
        double double34 = dateAxis29.getUpperBound();
        java.awt.Shape shape35 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint39 = stackedAreaRenderer37.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = stackedAreaRenderer37.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator42 = stackedAreaRenderer37.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer45 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean47 = stackedAreaRenderer45.getSeriesVisibleInLegend(10);
        boolean boolean48 = stackedAreaRenderer45.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = stackedAreaRenderer45.getLegendItemURLGenerator();
        java.awt.Paint paint51 = stackedAreaRenderer45.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer37.setSeriesPaint(1, paint51);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font56 = textTitle55.getFont();
        java.awt.Paint paint57 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine58 = new org.jfree.chart.text.TextLine("", font56, paint57);
        stackedAreaRenderer37.setBaseItemLabelPaint(paint57, false);
        stackedAreaRenderer37.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer37);
        try {
            java.lang.String str65 = standardCategoryToolTipGenerator17.generateColumnLabel(categoryDataset26, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(categoryItemLabelGenerator41);
        org.junit.Assert.assertNull(categoryItemLabelGenerator42);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 86400000L);
        java.awt.Color color6 = java.awt.Color.RED;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem(attributedString0, "ChartEntity: tooltip = {0}", "EXPAND", "", shape5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        labelBlock3.setToolTipText("hi!");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = xYPlot21.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        xYPlot21.setDrawingSupplier(drawingSupplier23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(axisLocation25, false);
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = labelBlock3.equals((java.lang.Object) xYPlot21);
        double double30 = xYPlot21.getRangeCrosshairValue();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        xYPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.4d, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator4 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean5 = lineAndShapeRenderer0.equals((java.lang.Object) "");
        boolean boolean7 = lineAndShapeRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        java.awt.Stroke stroke9 = lineAndShapeRenderer0.getSeriesOutlineStroke(10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        dateAxis12.setNegativeArrowVisible(false);
        double double16 = dateAxis12.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        float float19 = dateAxis18.getTickMarkOutsideLength();
        dateAxis18.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot22 = dateAxis18.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint26 = stackedAreaRenderer24.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = stackedAreaRenderer24.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer24.getBaseItemLabelGenerator();
        double double30 = stackedAreaRenderer24.getItemLabelAnchorOffset();
        java.awt.Paint paint33 = stackedAreaRenderer24.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis18.setAxisLinePaint(paint33);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        float float39 = dateAxis38.getTickMarkOutsideLength();
        dateAxis38.setNegativeArrowVisible(false);
        float float42 = dateAxis38.getTickMarkInsideLength();
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date44 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange(date43, date44);
        dateAxis38.setRange((org.jfree.data.Range) dateRange45);
        numberAxis3D36.setRange((org.jfree.data.Range) dateRange45);
        dateAxis18.setRange((org.jfree.data.Range) dateRange45);
        boolean boolean49 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int51 = dateTickUnit50.getCount();
        dateAxis18.setTickUnit(dateTickUnit50, false, false);
        dateAxis12.setTickUnit(dateTickUnit50);
        try {
            java.lang.Number number57 = defaultIntervalCategoryDataset7.getStartValue((java.lang.Comparable) dateTickUnit50, (java.lang.Comparable) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dateTickUnit50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.JFreeChart jFreeChart29 = multiplePiePlot28.getPieChart();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        xYPlot7.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jFreeChart29);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("JFreeChart", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "GradientPaintTransformType.HORIZONTAL", "AxisLocation.BOTTOM_OR_LEFT");
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray27 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer26 };
        xYPlot10.setRenderers(xYItemRendererArray27);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(xYItemRendererArray27);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean4 = numberAxis3D3.getAutoRangeIncludesZero();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) boolean4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        multiplePiePlot1.setDrawingSupplier(drawingSupplier6);
        multiplePiePlot1.setLimit((double) 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.RenderingHints renderingHints8 = jFreeChart7.getRenderingHints();
        org.jfree.chart.plot.Plot plot9 = jFreeChart7.getPlot();
        org.jfree.chart.axis.AxisCollection axisCollection10 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list11 = axisCollection10.getAxesAtBottom();
        jFreeChart7.setSubtitles(list11);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(renderingHints8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getColorComponents(floatArray2);
        float[] floatArray4 = color0.getRGBComponents(floatArray2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis3D1.getTickUnit();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D4.setVisible(false);
        org.jfree.chart.plot.Plot plot7 = numberAxis3D4.getPlot();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer8 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint10 = boxAndWhiskerRenderer8.lookupSeriesFillPaint(1);
        numberAxis3D4.setAxisLinePaint(paint10);
        double double12 = numberAxis3D4.getLowerBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D18.setVisible(false);
        java.awt.Font font22 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("cyan", font22);
        numberAxis3D18.setTickLabelFont(font22);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D4, (double) (byte) 1, (double) (-1), (double) 1, (double) 100.0f, font22);
        numberAxis3D1.setMarkerBand(markerAxisBand25);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        try {
            org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate6.getNearestDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.resizeRange(0.0d, 100.0d);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis1.valueToJava2D((double) 10L, rectangle2D10, rectangleEdge11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        double double6 = dateAxis1.getUpperBound();
        java.awt.Shape shape7 = dateAxis1.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape7, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        stackedAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.data.Range range8 = dateAxis2.getRange();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot15 = dateAxis11.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        double double23 = stackedAreaRenderer17.getItemLabelAnchorOffset();
        java.awt.Paint paint26 = stackedAreaRenderer17.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis11.setAxisLinePaint(paint26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        float float32 = dateAxis31.getTickMarkOutsideLength();
        dateAxis31.setNegativeArrowVisible(false);
        float float35 = dateAxis31.getTickMarkInsideLength();
        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange(date36, date37);
        dateAxis31.setRange((org.jfree.data.Range) dateRange38);
        numberAxis3D29.setRange((org.jfree.data.Range) dateRange38);
        dateAxis11.setRange((org.jfree.data.Range) dateRange38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, (org.jfree.data.Range) dateRange38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint(range8, (org.jfree.data.Range) dateRange38);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        double double5 = dateAxis1.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        dateAxis7.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot11 = dateAxis7.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        double double19 = stackedAreaRenderer13.getItemLabelAnchorOffset();
        java.awt.Paint paint22 = stackedAreaRenderer13.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis7.setAxisLinePaint(paint22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        float float28 = dateAxis27.getTickMarkOutsideLength();
        dateAxis27.setNegativeArrowVisible(false);
        float float31 = dateAxis27.getTickMarkInsideLength();
        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange(date32, date33);
        dateAxis27.setRange((org.jfree.data.Range) dateRange34);
        numberAxis3D25.setRange((org.jfree.data.Range) dateRange34);
        dateAxis7.setRange((org.jfree.data.Range) dateRange34);
        boolean boolean38 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int40 = dateTickUnit39.getCount();
        dateAxis7.setTickUnit(dateTickUnit39, false, false);
        dateAxis1.setTickUnit(dateTickUnit39);
        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int48 = dateTickUnit47.getCount();
        java.util.Date date49 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date50 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange51 = new org.jfree.data.time.DateRange(date49, date50);
        java.util.Date date52 = dateTickUnit47.rollDate(date49);
        org.jfree.data.time.DateRange dateRange53 = new org.jfree.data.time.DateRange(date45, date49);
        java.util.TimeZone timeZone54 = null;
        try {
            java.util.Date date55 = dateTickUnit39.addToDate(date49, timeZone54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(dateTickUnit47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray11, doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        float float18 = dateAxis17.getTickMarkOutsideLength();
        dateAxis17.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot21 = dateAxis17.getPlot();
        double double22 = dateAxis17.getUpperBound();
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint27 = stackedAreaRenderer25.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer25.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer25.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean35 = stackedAreaRenderer33.getSeriesVisibleInLegend(10);
        boolean boolean36 = stackedAreaRenderer33.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedAreaRenderer33.getLegendItemURLGenerator();
        java.awt.Paint paint39 = stackedAreaRenderer33.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer25.setSeriesPaint(1, paint39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font44 = textTitle43.getFont();
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("", font44, paint45);
        stackedAreaRenderer25.setBaseItemLabelPaint(paint45, false);
        stackedAreaRenderer25.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("");
        float float55 = dateAxis54.getTickMarkOutsideLength();
        dateAxis54.setNegativeArrowVisible(false);
        dateAxis54.setLowerMargin((double) 15);
        dateAxis54.setLowerMargin(0.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer62 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator66 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean67 = lineAndShapeRenderer62.equals((java.lang.Object) "");
        boolean boolean69 = lineAndShapeRenderer62.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer62);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot70);
        try {
            int int72 = defaultIntervalCategoryDataset7.getRowCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 2.0f + "'", float55 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = stackedAreaRenderer1.getLegendItemToolTipGenerator();
        stackedAreaRenderer1.setSeriesCreateEntities(2, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator12 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (byte) 10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator12);
        java.text.DateFormat dateFormat14 = standardCategoryToolTipGenerator12.getDateFormat();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNull(dateFormat14);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        jFreeChart2.clearSubtitles();
        org.jfree.chart.event.ChartChangeListener chartChangeListener5 = null;
        try {
            jFreeChart2.removeChangeListener(chartChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint1 = boxAndWhiskerRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = null;
//        projectInfo0.setLogo(image1);
//        java.lang.String str3 = projectInfo0.toString();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code." + "'", str3.equals("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code."));
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
//        float float7 = dateAxis6.getTickMarkOutsideLength();
//        dateAxis6.setNegativeArrowVisible(false);
//        float float10 = dateAxis6.getTickMarkInsideLength();
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
//        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
//        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
//        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange13);
//        double double17 = dateRange13.getLowerBound();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.560181216381E12d + "'", double17 == 1.560181216381E12d);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        try {
            java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset4 = piePlot2.getDataset();
        piePlot2.setMinimumArcAngleToDraw(12.0d);
        boolean boolean7 = textTitle1.equals((java.lang.Object) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray13 = null;
        float[] floatArray14 = color12.getColorComponents(floatArray13);
        float[] floatArray15 = java.awt.Color.RGBtoHSB(10, 2, 0, floatArray13);
        float[] floatArray16 = color8.getRGBColorComponents(floatArray15);
        textTitle1.setPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot7.setOrientation(plotOrientation11);
        boolean boolean13 = xYPlot7.isRangeCrosshairVisible();
        xYPlot7.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date1, date2);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("Last", (org.jfree.data.time.TimePeriod) simpleTimePeriod9);
        task5.addSubtask(task10);
        java.lang.String str12 = task10.getDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Last" + "'", str12.equals("Last"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        boolean boolean24 = simpleTimePeriod2.equals((java.lang.Object) 9999);
        java.util.Date date25 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange13);
        double double17 = rectangleConstraint16.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint16.getWidthConstraintType();
        java.lang.String str19 = rectangleConstraint16.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint16.toFixedWidth((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedHeight((double) 10.0f);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str19.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Locale locale1 = dataPackageResources0.getLocale();
        java.lang.Object obj3 = dataPackageResources0.handleGetObject("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer1.getBaseLinesVisible();
        boolean boolean3 = lineAndShapeRenderer1.getBaseCreateEntities();
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer1.setSeriesOutlineStroke((int) (short) 10, stroke5, false);
        boolean boolean8 = standardGradientPaintTransformer0.equals((java.lang.Object) stroke5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        java.awt.Paint paint23 = xYPlot10.getBackgroundPaint();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo26 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image27 = null;
        projectInfo26.setLogo(image27);
        org.jfree.data.gantt.TaskSeries taskSeries30 = new org.jfree.data.gantt.TaskSeries("{0}");
        java.util.List list31 = taskSeries30.getTasks();
        projectInfo26.setContributors(list31);
        xYPlot10.drawDomainTickBands(graphics2D24, rectangle2D25, list31);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(projectInfo26);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint paint2 = null;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, (java.awt.Paint) color1, paint2, paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'negativeBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        ganttRenderer0.setIncompletePaint(paint3);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint9 = stackedAreaRenderer7.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer7.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedAreaRenderer7.getBaseItemLabelGenerator();
        double double13 = stackedAreaRenderer7.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer7.getItemPaint((int) '#', (int) (byte) 0);
        ganttRenderer0.setIncompletePaint(paint16);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 2);
        axisState1.setCursor((double) 86400000L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        xYPlot7.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.awt.Paint paint2 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        jFreeChart2.setBackgroundImageAlpha((float) 'a');
        jFreeChart2.setNotify(false);
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer7);
        java.awt.Paint paint9 = xYPlot8.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        xYPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot8.setDomainAxisLocation(axisLocation12, false);
        categoryPlot0.setDomainAxisLocation(axisLocation12);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Comparable comparable2 = null;
        java.awt.Paint paint3 = null;
        try {
            piePlot3D1.setSectionOutlinePaint(comparable2, paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot7.getRangeMarkers(9999, layer10);
        java.awt.Paint paint12 = xYPlot7.getRangeTickBandPaint();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        float float20 = dateAxis19.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer23);
        java.awt.Paint paint25 = xYPlot24.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        float float29 = dateAxis28.getTickMarkOutsideLength();
        dateAxis28.setNegativeArrowVisible(false);
        float float32 = dateAxis28.getTickMarkInsideLength();
        xYPlot24.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis28);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot24.getDomainMarkers(layer34);
        boolean boolean36 = simpleTimePeriod16.equals((java.lang.Object) xYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot24.getDomainAxisLocation(0);
        xYPlot7.setRangeAxisLocation((int) (byte) 10, axisLocation38, false);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray41 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot7.setRenderers(xYItemRendererArray41);
        boolean boolean43 = xYPlot7.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(xYItemRendererArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) 0, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint6 = stackedBarRenderer3D2.getBasePaint();
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator4 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean5 = lineAndShapeRenderer0.equals((java.lang.Object) "");
        boolean boolean7 = lineAndShapeRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        lineAndShapeRenderer0.setBaseShapesFilled(false);
        try {
            lineAndShapeRenderer0.setSeriesCreateEntities((int) (byte) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = null;
        projectInfo2.setLogo(image3);
        projectInfo2.setLicenceText("hi!");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo2.getOptionalLibraries();
        projectInfo2.addOptionalLibrary("Last");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        try {
            textTitle5.setVerticalAlignment(verticalAlignment7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        float float47 = dateAxis46.getTickMarkOutsideLength();
        dateAxis46.setNegativeArrowVisible(false);
        dateAxis46.setLowerMargin((double) 15);
        dateAxis46.setLowerMargin(0.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator58 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean59 = lineAndShapeRenderer54.equals((java.lang.Object) "");
        boolean boolean61 = lineAndShapeRenderer54.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer54);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        try {
            categoryPlot62.setDomainAxis((int) (byte) -1, categoryAxis64, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Paint paint0 = null;
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setVisible(false);
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint7 = boxAndWhiskerRenderer5.lookupSeriesFillPaint(1);
        numberAxis3D1.setAxisLinePaint(paint7);
        boolean boolean9 = numberAxis3D1.isVisible();
        java.awt.Paint paint10 = null;
        try {
            numberAxis3D1.setTickLabelPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setItemMargin(100.0d);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot10.setNoDataMessagePaint((java.awt.Paint) color12);
        xYPlot10.clearRangeAxes();
        xYPlot10.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot10.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup19 = xYPlot10.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset20);
        org.jfree.chart.JFreeChart jFreeChart22 = multiplePiePlot21.getPieChart();
        java.awt.Image image23 = jFreeChart22.getBackgroundImage();
        xYPlot10.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        boolean boolean25 = boxAndWhiskerRenderer0.equals((java.lang.Object) xYPlot10);
        float float26 = xYPlot10.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(datasetGroup19);
        org.junit.Assert.assertNotNull(jFreeChart22);
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(1.560181216381E12d, 1.0E-5d, (double) 6, (double) (byte) 100);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        float float2 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double7 = categoryAxis3D0.getCategoryMiddle((int) '4', 4, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot7.getRangeAxisEdge(4);
        java.awt.Stroke stroke33 = xYPlot7.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj7 = categoryAxis3D6.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        float float13 = dateAxis9.getTickMarkInsideLength();
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange(date14, date15);
        dateAxis9.setRange((org.jfree.data.Range) dateRange16);
        java.lang.String[] strArray18 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray19 = null;
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray21, numberArray23 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset25 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray18, numberArray19, numberArray24);
        try {
            boxAndWhiskerRenderer0.drawItem(graphics2D1, categoryItemRendererState3, rectangle2D4, categoryPlot5, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset25, (int) (short) 1, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: BoxAndWhiskerRenderer.drawItem() : the data should be of type BoxAndWhiskerCategoryDataset only.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) 0L, 0.2d, (double) (short) 1, (double) 10L, font5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        markerAxisBand6.draw(graphics2D7, rectangle2D8, rectangle2D9, (double) (byte) 0, (double) (short) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = null;
        markerAxisBand6.addMarker(intervalMarker13);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = null;
        markerAxisBand6.addMarker(intervalMarker15);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset4 = piePlot2.getDataset();
        piePlot2.setMinimumArcAngleToDraw(12.0d);
        boolean boolean7 = textTitle1.equals((java.lang.Object) piePlot2);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer17);
        java.awt.Paint paint19 = xYPlot18.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        float float23 = dateAxis22.getTickMarkOutsideLength();
        dateAxis22.setNegativeArrowVisible(false);
        float float26 = dateAxis22.getTickMarkInsideLength();
        xYPlot18.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = xYPlot18.getDomainMarkers(layer28);
        boolean boolean30 = simpleTimePeriod10.equals((java.lang.Object) xYPlot18);
        java.awt.Stroke stroke31 = piePlot2.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod10);
        double double32 = piePlot2.getStartAngle();
        piePlot2.setMaximumLabelWidth((double) 10);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(stroke31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 90.0d + "'", double32 == 90.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendGraphic7.getFillPaintTransformer();
        double double9 = legendGraphic7.getContentYOffset();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        dateAxis13.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot17 = dateAxis13.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint21 = stackedAreaRenderer19.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedAreaRenderer19.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = stackedAreaRenderer19.getBaseItemLabelGenerator();
        double double25 = stackedAreaRenderer19.getItemLabelAnchorOffset();
        java.awt.Paint paint28 = stackedAreaRenderer19.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis13.setAxisLinePaint(paint28);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        float float34 = dateAxis33.getTickMarkOutsideLength();
        dateAxis33.setNegativeArrowVisible(false);
        float float37 = dateAxis33.getTickMarkInsideLength();
        java.util.Date date38 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange(date38, date39);
        dateAxis33.setRange((org.jfree.data.Range) dateRange40);
        numberAxis3D31.setRange((org.jfree.data.Range) dateRange40);
        dateAxis13.setRange((org.jfree.data.Range) dateRange40);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, (org.jfree.data.Range) dateRange40);
        try {
            org.jfree.chart.util.Size2D size2D45 = legendGraphic7.arrange(graphics2D10, rectangleConstraint44);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 2.0f + "'", float34 == 2.0f);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.0f + "'", float37 == 0.0f);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean11 = stackedAreaRenderer9.getSeriesVisibleInLegend(10);
        boolean boolean12 = stackedAreaRenderer9.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer9.getLegendItemURLGenerator();
        java.awt.Paint paint15 = stackedAreaRenderer9.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer1.setSeriesPaint(1, paint15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = stackedAreaRenderer1.getPlot();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryPlot17);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.data.Range range18 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange13, 0.0d, (double) (-1L));
        numberAxis3D1.setRange(range18);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean23 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge22);
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge22);
        try {
            double double25 = numberAxis3D1.valueToJava2D((double) 0L, rectangle2D21, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str7 = ringPlot6.getNoDataMessage();
        java.awt.Paint paint8 = ringPlot6.getBaseSectionOutlinePaint();
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "RectangleAnchor.BOTTOM_RIGHT", "", "GradientPaintTransformType.HORIZONTAL", shape4, stroke5, paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition();
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition(15, itemLabelPosition3, true);
        java.awt.Stroke stroke6 = stackedAreaRenderer1.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition();
        stackedAreaRenderer9.setSeriesNegativeItemLabelPosition(15, itemLabelPosition11, true);
        stackedAreaRenderer1.setSeriesPositiveItemLabelPosition(0, itemLabelPosition11, false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setVisible(false);
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        java.awt.Shape shape5 = numberAxis3D1.getLeftArrow();
        org.jfree.data.Range range6 = numberAxis3D1.getRange();
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean11 = stackedAreaRenderer9.getSeriesVisibleInLegend(10);
        boolean boolean12 = stackedAreaRenderer9.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer9.getLegendItemURLGenerator();
        java.awt.Paint paint15 = stackedAreaRenderer9.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer1.setSeriesPaint(1, paint15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font20 = textTitle19.getFont();
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font20, paint21);
        stackedAreaRenderer1.setBaseItemLabelPaint(paint21, false);
        java.awt.Paint paint25 = stackedAreaRenderer1.getBasePaint();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.JFreeChart jFreeChart29 = multiplePiePlot28.getPieChart();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            xYPlot7.drawBackground(graphics2D31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jFreeChart29);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
        double double4 = rectangleInsets0.calculateTopOutset((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset4 = piePlot2.getDataset();
        piePlot2.setMinimumArcAngleToDraw(12.0d);
        boolean boolean7 = textTitle1.equals((java.lang.Object) piePlot2);
        textTitle1.setText("GradientPaintTransformType.HORIZONTAL");
        java.lang.String str10 = textTitle1.getURLText();
        double double11 = textTitle1.getWidth();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Color color2 = java.awt.Color.GRAY;
        intervalBarRenderer0.setSeriesItemLabelPaint((int) (byte) 100, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = stackedAreaRenderer1.getURLGenerator((int) '4', 0);
        stackedAreaRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot43.getRowRenderingOrder();
        categoryPlot43.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        float float51 = dateAxis50.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis53, xYItemRenderer54);
        java.awt.Paint paint56 = xYPlot55.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = null;
        xYPlot55.setDrawingSupplier(drawingSupplier57);
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot55.setDomainAxisLocation(axisLocation59, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent62 = null;
        xYPlot55.notifyListeners(plotChangeEvent62);
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getBaseSectionOutlineStroke();
        java.awt.Color color66 = java.awt.Color.CYAN;
        piePlot64.setShadowPaint((java.awt.Paint) color66);
        java.awt.Color color69 = java.awt.Color.white;
        piePlot64.setSectionPaint((java.lang.Comparable) 12.0d, (java.awt.Paint) color69);
        xYPlot55.setRangeCrosshairPaint((java.awt.Paint) color69);
        java.awt.Color color72 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        xYPlot55.setRangeCrosshairPaint((java.awt.Paint) color72);
        categoryPlot43.setRangeGridlinePaint((java.awt.Paint) color72);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 2.0f + "'", float51 == 2.0f);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(color72);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font6, (org.jfree.chart.plot.Plot) piePlot9, false);
        stackedBarRenderer3D2.setSeriesItemLabelFont((int) '4', font6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        int int14 = stackedBarRenderer3D2.getPassCount();
        java.awt.Paint paint16 = null;
        stackedBarRenderer3D2.setSeriesItemLabelPaint(3, paint16, true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("1.0.6", "", "ThreadContext", "RectangleAnchor.BOTTOM_RIGHT");
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("XY Plot");
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot7.setOrientation(plotOrientation11);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot7.getRangeAxisForDataset((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean2 = dataPackageResources0.containsKey("");
        java.util.Locale locale3 = dataPackageResources0.getLocale();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer10);
        org.jfree.data.Range range12 = dateAxis6.getRange();
        dateAxis2.setRange(range12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean16 = numberAxis3D15.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer17);
        java.awt.Paint paint19 = xYPlot18.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.data.Range range8 = dateAxis2.getRange();
        double double9 = range8.getUpperBound();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range8, (double) 0L, (-1.0d));
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range12, 8.0d, false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 2);
        org.jfree.chart.JFreeChart jFreeChart2 = rendererChangeEvent1.getChart();
        java.lang.Object obj3 = rendererChangeEvent1.getSource();
        org.junit.Assert.assertNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 2 + "'", obj3.equals(2));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean1 = boxAndWhiskerRenderer0.getFillBox();
        org.jfree.chart.LegendItem legendItem4 = boxAndWhiskerRenderer0.getLegendItem(0, 9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(legendItem4);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font2 = textTitle1.getFont();
        java.awt.Color color3 = java.awt.Color.RED;
        textTitle1.setPaint((java.awt.Paint) color3);
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        try {
            int int20 = defaultIntervalCategoryDataset7.getRowCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D2.setVisible(false);
        org.jfree.chart.plot.Plot plot5 = numberAxis3D2.getPlot();
        java.awt.Shape shape6 = numberAxis3D2.getLeftArrow();
        boolean boolean7 = borderArrangement0.equals((java.lang.Object) shape6);
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        java.util.List list9 = blockContainer8.getBlocks();
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getDownArrow();
        org.jfree.data.RangeType rangeType2 = org.jfree.data.RangeType.FULL;
        numberAxis0.setRangeType(rangeType2);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = null;
        projectInfo2.setLogo(image3);
        projectInfo2.setLicenceText("hi!");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray11, doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        float float18 = dateAxis17.getTickMarkOutsideLength();
        dateAxis17.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot21 = dateAxis17.getPlot();
        double double22 = dateAxis17.getUpperBound();
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint27 = stackedAreaRenderer25.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer25.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer25.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean35 = stackedAreaRenderer33.getSeriesVisibleInLegend(10);
        boolean boolean36 = stackedAreaRenderer33.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedAreaRenderer33.getLegendItemURLGenerator();
        java.awt.Paint paint39 = stackedAreaRenderer33.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer25.setSeriesPaint(1, paint39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font44 = textTitle43.getFont();
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("", font44, paint45);
        stackedAreaRenderer25.setBaseItemLabelPaint(paint45, false);
        stackedAreaRenderer25.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer25);
        boolean boolean52 = projectInfo2.equals((java.lang.Object) dateAxis17);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = dateAxis17.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("");
        float float56 = dateAxis55.getTickMarkOutsideLength();
        dateAxis55.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot59 = dateAxis55.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer61 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint63 = stackedAreaRenderer61.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator65 = stackedAreaRenderer61.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator66 = stackedAreaRenderer61.getBaseItemLabelGenerator();
        double double67 = stackedAreaRenderer61.getItemLabelAnchorOffset();
        java.awt.Paint paint70 = stackedAreaRenderer61.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis55.setAxisLinePaint(paint70);
        org.jfree.chart.plot.Plot plot72 = dateAxis55.getPlot();
        org.jfree.chart.axis.Timeline timeline73 = dateAxis55.getTimeline();
        dateAxis17.setTimeline(timeline73);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 2.0f + "'", float56 == 2.0f);
        org.junit.Assert.assertNull(plot59);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertNull(categoryItemLabelGenerator65);
        org.junit.Assert.assertNull(categoryItemLabelGenerator66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNull(plot72);
        org.junit.Assert.assertNotNull(timeline73);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        xYPlot7.notifyListeners(plotChangeEvent14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke17 = piePlot16.getBaseSectionOutlineStroke();
        java.awt.Color color18 = java.awt.Color.CYAN;
        piePlot16.setShadowPaint((java.awt.Paint) color18);
        java.awt.Color color21 = java.awt.Color.white;
        piePlot16.setSectionPaint((java.lang.Comparable) 12.0d, (java.awt.Paint) color21);
        xYPlot7.setRangeCrosshairPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot7.zoomRangeAxes(0.0d, (double) '4', plotRenderingInfo26, point2D27);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries1.removeAll();
        java.lang.String str3 = taskSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color3 = java.awt.Color.CYAN;
        stackedAreaRenderer1.setSeriesFillPaint(2, (java.awt.Paint) color3, true);
        java.awt.Paint paint7 = stackedAreaRenderer1.lookupSeriesFillPaint((int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedAreaRenderer1.getBasePositiveItemLabelPosition();
        stackedAreaRenderer1.setSeriesVisible(4, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis3D1.getTickUnit();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        xYPlot10.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace15);
        int int17 = numberTickUnit2.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            xYPlot10.draw(graphics2D18, rectangle2D19, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset9 = piePlot7.getDataset();
        piePlot7.setMinimumArcAngleToDraw(12.0d);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace16 = dateAxis1.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) piePlot7, rectangle2D12, rectangleEdge13, axisSpace15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean11 = stackedAreaRenderer9.getSeriesVisibleInLegend(10);
        boolean boolean12 = stackedAreaRenderer9.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer9.getLegendItemURLGenerator();
        java.awt.Paint paint15 = stackedAreaRenderer9.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer1.setSeriesPaint(1, paint15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font20 = textTitle19.getFont();
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font20, paint21);
        stackedAreaRenderer1.setBaseItemLabelPaint(paint21, false);
        java.awt.Font font25 = stackedAreaRenderer1.getBaseItemLabelFont();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
        java.lang.String str2 = year1.toString();
        java.lang.String str3 = year1.toString();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
        java.lang.Comparable comparable2 = null;
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, paint6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font5, (org.jfree.chart.plot.Plot) piePlot8, false);
        try {
            categoryAxis3D0.setTickLabelFont(comparable2, font5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape1, "{0}", "");
        java.lang.Object obj5 = tickLabelEntity4.clone();
        tickLabelEntity4.setURLText("{0}");
        java.lang.String str8 = tickLabelEntity4.getShapeCoords();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0,-1,-1,1,1,1,1,1" + "'", str8.equals("0,-1,-1,1,1,1,1,1"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Stroke stroke4 = stackedBarRenderer3D2.lookupSeriesStroke((int) 'a');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint8 = stackedAreaRenderer6.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedAreaRenderer6.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer6.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedAreaRenderer6.getLegendItemToolTipGenerator();
        stackedAreaRenderer6.setSeriesCreateEntities(2, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator17 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (byte) 10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator17);
        stackedBarRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator17);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[][] doubleArray27 = new double[][] { doubleArray24, doubleArray25, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        float float32 = dateAxis31.getTickMarkOutsideLength();
        dateAxis31.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot35 = dateAxis31.getPlot();
        double double36 = dateAxis31.getUpperBound();
        java.awt.Shape shape37 = dateAxis31.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer39 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint41 = stackedAreaRenderer39.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator43 = stackedAreaRenderer39.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator44 = stackedAreaRenderer39.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer47 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean49 = stackedAreaRenderer47.getSeriesVisibleInLegend(10);
        boolean boolean50 = stackedAreaRenderer47.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator51 = stackedAreaRenderer47.getLegendItemURLGenerator();
        java.awt.Paint paint53 = stackedAreaRenderer47.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer39.setSeriesPaint(1, paint53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font58 = textTitle57.getFont();
        java.awt.Paint paint59 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine60 = new org.jfree.chart.text.TextLine("", font58, paint59);
        stackedAreaRenderer39.setBaseItemLabelPaint(paint59, false);
        stackedAreaRenderer39.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer39);
        categoryPlot65.setRangeCrosshairValue((double) 6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState70 = stackedBarRenderer3D2.initialise(graphics2D20, rectangle2D21, categoryPlot65, 15, plotRenderingInfo69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNull(categoryItemLabelGenerator43);
        org.junit.Assert.assertNull(categoryItemLabelGenerator44);
        org.junit.Assert.assertNull(boolean49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.Object obj1 = standardCategoryToolTipGenerator0.clone();
        java.lang.String[] strArray2 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray3 = null;
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray5, numberArray7 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray3, numberArray8);
        java.lang.String[] strArray10 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray11 = null;
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray13, numberArray15 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset17 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray10, numberArray11, numberArray16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D(pieDataset18);
        defaultIntervalCategoryDataset17.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D19);
        defaultIntervalCategoryDataset9.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D19);
        try {
            java.lang.String str23 = standardCategoryToolTipGenerator0.generateRowLabel((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset9, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        projectInfo0.setLicenceText("hi!");
        java.awt.Image image5 = null;
        projectInfo0.setLogo(image5);
        java.lang.String str7 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str7.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        categoryPlot43.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj46 = categoryAxis3D45.clone();
        float float47 = categoryAxis3D45.getMaximumCategoryLabelWidthRatio();
        int int48 = categoryPlot43.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D45);
        int int49 = categoryAxis3D45.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = null;
        projectInfo2.setLogo(image3);
        projectInfo2.setLicenceText("hi!");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray11, doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        float float18 = dateAxis17.getTickMarkOutsideLength();
        dateAxis17.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot21 = dateAxis17.getPlot();
        double double22 = dateAxis17.getUpperBound();
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint27 = stackedAreaRenderer25.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer25.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer25.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean35 = stackedAreaRenderer33.getSeriesVisibleInLegend(10);
        boolean boolean36 = stackedAreaRenderer33.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedAreaRenderer33.getLegendItemURLGenerator();
        java.awt.Paint paint39 = stackedAreaRenderer33.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer25.setSeriesPaint(1, paint39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font44 = textTitle43.getFont();
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("", font44, paint45);
        stackedAreaRenderer25.setBaseItemLabelPaint(paint45, false);
        stackedAreaRenderer25.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer25);
        boolean boolean52 = projectInfo2.equals((java.lang.Object) dateAxis17);
        projectInfo2.setInfo("HorizontalAlignment.RIGHT");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = lineAndShapeRenderer0.getToolTipGenerator(9, 9);
        boolean boolean10 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        boolean boolean7 = textTitle5.getExpandToFitSpace();
        double double8 = textTitle5.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets9.calculateLeftInset((double) 11);
        textTitle5.setPadding(rectangleInsets9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle5.getMargin();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

