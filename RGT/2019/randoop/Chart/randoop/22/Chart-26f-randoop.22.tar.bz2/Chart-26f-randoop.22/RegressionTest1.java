import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        xYPlot7.notifyListeners(plotChangeEvent14);
        java.awt.Stroke stroke16 = xYPlot7.getDomainZeroBaselineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot7.getRangeAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer24);
        java.awt.Paint paint26 = xYPlot25.getRangeTickBandPaint();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot25.setNoDataMessagePaint((java.awt.Paint) color27);
        xYPlot25.clearRangeAxes();
        xYPlot25.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot25.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup34 = xYPlot25.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot36 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset35);
        org.jfree.chart.JFreeChart jFreeChart37 = multiplePiePlot36.getPieChart();
        java.awt.Image image38 = jFreeChart37.getBackgroundImage();
        xYPlot25.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart37);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot25.setAxisOffset(rectangleInsets40);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker44.setLabel("");
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot25.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker44, layer47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = valueMarker44.getLabelAnchor();
        java.awt.Paint paint50 = valueMarker44.getOutlinePaint();
        xYPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNull(datasetGroup34);
        org.junit.Assert.assertNotNull(jFreeChart37);
        org.junit.Assert.assertNull(image38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date1, date2);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray13 = null;
        float[] floatArray14 = color12.getColorComponents(floatArray13);
        float[] floatArray15 = java.awt.Color.RGBtoHSB(10, 2, 0, floatArray13);
        float[] floatArray16 = color8.getRGBColorComponents(floatArray15);
        boolean boolean17 = month7.equals((java.lang.Object) floatArray16);
        java.util.Calendar calendar18 = null;
        try {
            month7.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.data.Range range18 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange13, 0.0d, (double) (-1L));
        numberAxis3D1.setRange(range18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        float float23 = dateAxis22.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer26);
        java.awt.Paint paint28 = xYPlot27.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = null;
        xYPlot27.setDrawingSupplier(drawingSupplier29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot27.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint35 = stackedAreaRenderer33.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = stackedAreaRenderer33.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator38 = stackedAreaRenderer33.getBaseItemLabelGenerator();
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date42 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange(date41, date42);
        org.jfree.data.gantt.Task task44 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date40, date41);
        boolean boolean45 = stackedAreaRenderer33.equals((java.lang.Object) task44);
        boolean boolean46 = xYPlot27.equals((java.lang.Object) boolean45);
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        xYPlot27.addChangeListener(plotChangeListener47);
        java.awt.Stroke stroke49 = xYPlot27.getDomainCrosshairStroke();
        boolean boolean50 = numberAxis3D1.equals((java.lang.Object) stroke49);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categoryItemLabelGenerator37);
        org.junit.Assert.assertNull(categoryItemLabelGenerator38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        double double5 = stackedBarRenderer3D2.getMinimumBarLength();
        java.awt.Stroke stroke6 = stackedBarRenderer3D2.getBaseOutlineStroke();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("Layer.FOREGROUND");
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setVisible(false);
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint7 = boxAndWhiskerRenderer5.lookupSeriesFillPaint(1);
        numberAxis3D1.setAxisLinePaint(paint7);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint12 = stackedAreaRenderer10.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = stackedAreaRenderer10.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = stackedAreaRenderer10.getBaseItemLabelGenerator();
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange(date18, date19);
        org.jfree.data.gantt.Task task21 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date17, date18);
        boolean boolean22 = stackedAreaRenderer10.equals((java.lang.Object) task21);
        org.jfree.chart.LegendItem legendItem25 = stackedAreaRenderer10.getLegendItem((int) '#', 0);
        java.awt.Paint paint27 = stackedAreaRenderer10.lookupSeriesOutlinePaint((int) '4');
        numberAxis3D1.setTickMarkPaint(paint27);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.data.Range range18 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange13, 0.0d, (double) (-1L));
        numberAxis3D1.setRange(range18);
        numberAxis3D1.setLabel("1.0.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries1.removeAll();
        java.lang.String str3 = taskSeries1.getDescription();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer4.getBaseLinesVisible();
        lineAndShapeRenderer4.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        boolean boolean9 = taskSeries1.equals((java.lang.Object) lineAndShapeRenderer4);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        double double6 = dateAxis1.getUpperBound();
        java.awt.Shape shape7 = dateAxis1.getDownArrow();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape7, shape8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot15 = dateAxis11.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        double double23 = stackedAreaRenderer17.getItemLabelAnchorOffset();
        java.awt.Paint paint26 = stackedAreaRenderer17.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis11.setAxisLinePaint(paint26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape7, paint26);
        java.lang.Object obj29 = legendGraphic28.clone();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = null;
        projectInfo2.setLogo(image3);
        projectInfo2.setLicenceText("hi!");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo2.getOptionalLibraries();
        org.jfree.chart.ui.Library library9 = null;
        try {
            projectInfo2.addLibrary(library9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        xYPlot7.notifyListeners(plotChangeEvent14);
        java.awt.Stroke stroke16 = xYPlot7.getDomainZeroBaselineStroke();
        boolean boolean17 = xYPlot7.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        try {
            java.lang.Comparable comparable21 = defaultIntervalCategoryDataset7.getColumnKey(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        xYPlot7.mapDatasetToDomainAxis((int) (byte) 100, 15);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot7.getSeriesRenderingOrder();
        java.lang.String str20 = xYPlot7.getPlotType();
        java.awt.Paint paint21 = xYPlot7.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        java.lang.Object obj4 = standardCategoryURLGenerator3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate48.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean52 = spreadsheetDate46.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate48.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean59 = categoryAnchor44.equals((java.lang.Object) spreadsheetDate54);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedAreaRenderer1.lookupSeriesFillPaint((int) ' ');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator(255, categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = xYPlot9.getRangeTickBandPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot9.setNoDataMessagePaint((java.awt.Paint) color11);
        xYPlot9.clearRangeAxes();
        xYPlot9.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot9.getRangeAxisLocation((int) (short) 1);
        java.awt.Paint paint18 = xYPlot9.getDomainCrosshairPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape1, paint18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendGraphic19.setShapeLocation(rectangleAnchor20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke25 = piePlot24.getBaseSectionOutlineStroke();
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        piePlot24.setLabelFont(font26);
        piePlot24.setLabelLinkMargin((double) 100L);
        try {
            java.lang.Object obj30 = legendGraphic19.draw(graphics2D22, rectangle2D23, (java.lang.Object) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        double double6 = dateAxis1.getUpperBound();
        dateAxis1.setLabel("Last");
        dateAxis1.setLabelAngle((double) 2);
        java.awt.Shape shape11 = dateAxis1.getUpArrow();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        boolean boolean24 = simpleTimePeriod2.equals((java.lang.Object) 9999);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint28 = stackedAreaRenderer26.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer26.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator31 = stackedAreaRenderer26.getBaseItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = stackedAreaRenderer26.getBaseNegativeItemLabelPosition();
        try {
            int int33 = simpleTimePeriod2.compareTo((java.lang.Object) stackedAreaRenderer26);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.renderer.category.StackedAreaRenderer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(categoryItemLabelGenerator31);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        double double6 = dateAxis1.getUpperBound();
        java.awt.Shape shape7 = dateAxis1.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape7, "{0}");
        java.lang.String str10 = chartEntity9.toString();
        chartEntity9.setToolTipText("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str13 = chartEntity9.getURLText();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartEntity: tooltip = {0}" + "'", str10.equals("ChartEntity: tooltip = {0}"));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 6, (double) (byte) 100, 116.0d);
        double double6 = rectangleInsets5.getTop();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.dateToJava2D(date8, rectangle2D10, rectangleEdge11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis2);
        org.jfree.chart.axis.Axis axis14 = axisChangeEvent13.getAxis();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(axis14);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        piePlot3D9.setForegroundAlpha((float) (byte) 10);
        boolean boolean13 = piePlot3D9.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint9 = stackedAreaRenderer7.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer7.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedAreaRenderer7.getBaseItemLabelGenerator();
        double double13 = stackedAreaRenderer7.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer7.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis1.setAxisLinePaint(paint16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        float float22 = dateAxis21.getTickMarkOutsideLength();
        dateAxis21.setNegativeArrowVisible(false);
        float float25 = dateAxis21.getTickMarkInsideLength();
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange(date26, date27);
        dateAxis21.setRange((org.jfree.data.Range) dateRange28);
        numberAxis3D19.setRange((org.jfree.data.Range) dateRange28);
        dateAxis1.setRange((org.jfree.data.Range) dateRange28);
        dateAxis1.setFixedAutoRange((double) 1);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange(date34, date35);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        float float41 = dateAxis40.getTickMarkOutsideLength();
        dateAxis40.setNegativeArrowVisible(false);
        float float44 = dateAxis40.getTickMarkInsideLength();
        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange47 = new org.jfree.data.time.DateRange(date45, date46);
        dateAxis40.setRange((org.jfree.data.Range) dateRange47);
        numberAxis3D38.setRange((org.jfree.data.Range) dateRange47);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, (org.jfree.data.Range) dateRange47);
        org.jfree.data.Range range53 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange36, (double) 86400000L, (double) 1);
        dateAxis1.setDefaultAutoRange(range53);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 2.0f + "'", float41 == 2.0f);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(range53);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        textBlock0.draw(graphics2D1, (float) (short) 0, 100.0f, textBlockAnchor4, (float) 15, (float) 0L, (double) (byte) 0);
        org.jfree.chart.text.TextLine textLine9 = textBlock0.getLastLine();
        org.junit.Assert.assertNull(textLine9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("Last", "1.0.6", "[Jun 10, 2019 8:40:16 AM --> Jun 10, 2019 8:40:16 AM]", image3, "1.0.6", "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code.", "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
        boolean boolean3 = year1.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0 == 0L);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot7.getDatasetGroup();
        int int17 = xYPlot7.getSeriesCount();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            xYPlot7.handleClick(100, (int) (short) 0, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        try {
            java.lang.Number number5 = defaultKeyedValues0.getValue((java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 100");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset2 = piePlot0.getDataset();
        piePlot0.setMinimumArcAngleToDraw(12.0d);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint8 = stackedAreaRenderer6.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedAreaRenderer6.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer6.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean16 = stackedAreaRenderer14.getSeriesVisibleInLegend(10);
        boolean boolean17 = stackedAreaRenderer14.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = stackedAreaRenderer14.getLegendItemURLGenerator();
        java.awt.Paint paint20 = stackedAreaRenderer14.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer6.setSeriesPaint(1, paint20);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font25 = textTitle24.getFont();
        java.awt.Paint paint26 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("", font25, paint26);
        stackedAreaRenderer6.setBaseItemLabelPaint(paint26, false);
        piePlot0.setLabelPaint(paint26);
        piePlot0.setMaximumLabelWidth(0.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(pieDataset2);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font47 = textTitle46.getFont();
        java.awt.Paint paint48 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine49 = new org.jfree.chart.text.TextLine("", font47, paint48);
        categoryPlot43.setDomainGridlinePaint(paint48);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues51 = new org.jfree.data.DefaultKeyedValues();
        double[] doubleArray54 = new double[] {};
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[][] doubleArray57 = new double[][] { doubleArray54, doubleArray55, doubleArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray57);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("");
        float float62 = dateAxis61.getTickMarkOutsideLength();
        dateAxis61.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot65 = dateAxis61.getPlot();
        double double66 = dateAxis61.getUpperBound();
        java.awt.Shape shape67 = dateAxis61.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer69 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint71 = stackedAreaRenderer69.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator73 = stackedAreaRenderer69.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator74 = stackedAreaRenderer69.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer77 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean79 = stackedAreaRenderer77.getSeriesVisibleInLegend(10);
        boolean boolean80 = stackedAreaRenderer77.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator81 = stackedAreaRenderer77.getLegendItemURLGenerator();
        java.awt.Paint paint83 = stackedAreaRenderer77.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer69.setSeriesPaint(1, paint83);
        org.jfree.chart.title.TextTitle textTitle87 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font88 = textTitle87.getFont();
        java.awt.Paint paint89 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine90 = new org.jfree.chart.text.TextLine("", font88, paint89);
        stackedAreaRenderer69.setBaseItemLabelPaint(paint89, false);
        stackedAreaRenderer69.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot95 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, (org.jfree.chart.axis.ValueAxis) dateAxis61, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer69);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor96 = categoryPlot95.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder97 = categoryPlot95.getRowRenderingOrder();
        defaultKeyedValues51.sortByValues(sortOrder97);
        categoryPlot43.setRowRenderingOrder(sortOrder97);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 2.0f + "'", float62 == 2.0f);
        org.junit.Assert.assertNull(plot65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNull(paint71);
        org.junit.Assert.assertNull(categoryItemLabelGenerator73);
        org.junit.Assert.assertNull(categoryItemLabelGenerator74);
        org.junit.Assert.assertNull(boolean79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(font88);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(categoryAnchor96);
        org.junit.Assert.assertNotNull(sortOrder97);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        dateAxis3.setNegativeArrowVisible(false);
        float float7 = dateAxis3.getTickMarkInsideLength();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(date8, date9);
        dateAxis3.setRange((org.jfree.data.Range) dateRange10);
        boolean boolean12 = taskSeries1.equals((java.lang.Object) dateRange10);
        taskSeries1.setDescription("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedAreaRenderer1.getBasePositiveItemLabelPosition();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        boolean boolean10 = stackedAreaRenderer1.equals((java.lang.Object) multiplePiePlot8);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange13);
        double double17 = rectangleConstraint16.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint16.getWidthConstraintType();
        java.lang.String str19 = rectangleConstraint16.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint16.toFixedWidth((double) (short) 1);
        org.jfree.data.Range range22 = rectangleConstraint21.getWidthRange();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str19.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle7);
        boolean boolean9 = textTitle7.getExpandToFitSpace();
        boolean boolean10 = gradientPaintTransformType0.equals((java.lang.Object) textTitle7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNull(legendTitle5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font6, (org.jfree.chart.plot.Plot) piePlot9, false);
        stackedBarRenderer3D2.setSeriesItemLabelFont((int) '4', font6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        stackedBarRenderer3D2.setMinimumBarLength((double) 4);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray23, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        float float30 = dateAxis29.getTickMarkOutsideLength();
        dateAxis29.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot33 = dateAxis29.getPlot();
        double double34 = dateAxis29.getUpperBound();
        java.awt.Shape shape35 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint39 = stackedAreaRenderer37.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = stackedAreaRenderer37.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator42 = stackedAreaRenderer37.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer45 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean47 = stackedAreaRenderer45.getSeriesVisibleInLegend(10);
        boolean boolean48 = stackedAreaRenderer45.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = stackedAreaRenderer45.getLegendItemURLGenerator();
        java.awt.Paint paint51 = stackedAreaRenderer45.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer37.setSeriesPaint(1, paint51);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font56 = textTitle55.getFont();
        java.awt.Paint paint57 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine58 = new org.jfree.chart.text.TextLine("", font56, paint57);
        stackedAreaRenderer37.setBaseItemLabelPaint(paint57, false);
        stackedAreaRenderer37.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer37);
        categoryPlot63.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D65 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj66 = categoryAxis3D65.clone();
        float float67 = categoryAxis3D65.getMaximumCategoryLabelWidthRatio();
        int int68 = categoryPlot63.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D65);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        java.lang.String[] strArray71 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray72 = null;
        java.lang.Number[] numberArray74 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray77 = new java.lang.Number[][] { numberArray74, numberArray76 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset78 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray71, numberArray72, numberArray77);
        org.jfree.data.general.PieDataset pieDataset79 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D80 = new org.jfree.chart.plot.PiePlot3D(pieDataset79);
        defaultIntervalCategoryDataset78.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D80);
        int int82 = defaultIntervalCategoryDataset78.getSeriesCount();
        try {
            stackedBarRenderer3D2.drawItem(graphics2D16, categoryItemRendererState18, rectangle2D19, categoryPlot63, categoryAxis69, valueAxis70, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset78, (int) (byte) 10, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(categoryItemLabelGenerator41);
        org.junit.Assert.assertNull(categoryItemLabelGenerator42);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(obj66);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 0.0f + "'", float67 == 0.0f);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(strArray71);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray77);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8);
        double double10 = dateAxis1.getFixedAutoRange();
        boolean boolean12 = dateAxis1.isHiddenValue((-1L));
        dateAxis1.setLabel("{0}");
        dateAxis1.setRangeAboutValue((double) 255, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator4 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean5 = lineAndShapeRenderer0.equals((java.lang.Object) "");
        lineAndShapeRenderer0.setDrawOutlines(false);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries1.removeAll();
        org.jfree.data.gantt.Task task4 = taskSeries1.get("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.util.List list5 = taskSeries1.getTasks();
        java.lang.Comparable comparable6 = null;
        try {
            taskSeries1.setKey(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(task4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        xYPlot7.mapDatasetToDomainAxis((int) (byte) 100, 15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot7.getDomainAxisEdge();
        xYPlot7.zoom(4.0d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("cyan", font2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D9.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = stackedBarRenderer3D9.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint15 = stackedBarRenderer3D9.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D6.setBaseOutlinePaint(paint15);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("{0}", font2, paint15, (float) 2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D21.setMaximumBarWidth((double) (short) 0);
        double double24 = stackedBarRenderer3D21.getMinimumBarLength();
        java.awt.Paint paint25 = stackedBarRenderer3D21.getWallPaint();
        boolean boolean26 = org.jfree.chart.util.PaintUtilities.equal(paint15, paint25);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        java.awt.Paint paint3 = dateAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "Last", "XY Plot");
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        float float34 = dateAxis33.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer37);
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = dateAxis33.dateToJava2D(date39, rectangle2D41, rectangleEdge42);
        int int44 = xYPlot7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        float float48 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer51);
        java.awt.Paint paint53 = xYPlot52.getRangeTickBandPaint();
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot52.setNoDataMessagePaint((java.awt.Paint) color54);
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot52.setOrientation(plotOrientation56);
        xYPlot7.setOrientation(plotOrientation56);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = xYPlot7.getDomainAxisEdge(9999);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke62 = piePlot61.getBaseSectionOutlineStroke();
        java.awt.Font font63 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        piePlot61.setLabelFont(font63);
        xYPlot7.setNoDataMessageFont(font63);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 2.0f + "'", float34 == 2.0f);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(font63);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        double double1 = dateRange0.getLowerBound();
        java.lang.String str2 = dateRange0.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str2.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        piePlot0.zoom(0.0d);
        piePlot0.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer2.getSeriesShapesVisible(0);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 2);
        axisState1.setCursor(0.2d);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        java.awt.Paint paint13 = xYPlot12.getRangeTickBandPaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot12.setNoDataMessagePaint((java.awt.Paint) color14);
        xYPlot12.clearRangeAxes();
        xYPlot12.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot12.getRangeAxisLocation((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot12.getRangeAxisEdge(15);
        axisState1.moveCursor((double) 100L, rectangleEdge22);
        double double24 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        double double1 = dateRange0.getLowerBound();
        double double3 = dateRange0.constrain(0.0d);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean4 = numberAxis3D3.getAutoRangeIncludesZero();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) boolean4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        multiplePiePlot1.setDrawingSupplier(drawingSupplier6);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 100.0d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = plotChangeEvent10.getType();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer7);
        dateAxis6.setRangeWithMargins((double) 10L, (double) 100L);
        boolean boolean12 = gradientPaintTransformType0.equals((java.lang.Object) dateAxis6);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState((double) 2);
        axisState18.setCursor(0.2d);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        float float25 = dateAxis24.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer28);
        java.awt.Paint paint30 = xYPlot29.getRangeTickBandPaint();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot29.setNoDataMessagePaint((java.awt.Paint) color31);
        xYPlot29.clearRangeAxes();
        xYPlot29.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot29.getRangeAxisLocation((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot29.getRangeAxisEdge(15);
        axisState18.moveCursor((double) 100L, rectangleEdge39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        try {
            org.jfree.chart.axis.AxisState axisState42 = dateAxis6.draw(graphics2D13, (double) 86400000L, rectangle2D15, rectangle2D16, rectangleEdge39, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint5 = stackedAreaRenderer3.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = stackedAreaRenderer3.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = stackedAreaRenderer3.getBaseItemLabelGenerator();
        double double9 = stackedAreaRenderer3.getItemLabelAnchorOffset();
        java.awt.Paint paint12 = stackedAreaRenderer3.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker15.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint21 = stackedAreaRenderer19.getSeriesItemLabelPaint(100);
        stackedAreaRenderer19.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer19.setSeriesStroke(100, stroke25);
        valueMarker15.setStroke(stroke25);
        stackedAreaRenderer3.setSeriesStroke(11, stroke25);
        stackedBarRenderer0.setSeriesStroke(0, stroke25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(itemLabelPosition30);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.gantt.TaskSeries taskSeries26 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries26.removeAll();
        org.jfree.data.gantt.Task task29 = taskSeries26.get("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.util.List list30 = taskSeries26.getTasks();
        xYPlot10.drawRangeTickBands(graphics2D23, rectangle2D24, list30);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(task29);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot7.getRangeMarkers(9999, layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        xYPlot7.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = stackedAreaRenderer1.getLegendItemToolTipGenerator();
        stackedAreaRenderer1.setSeriesCreateEntities(2, (java.lang.Boolean) false);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke13 = piePlot12.getBaseSectionOutlineStroke();
        java.awt.Color color14 = java.awt.Color.CYAN;
        piePlot12.setShadowPaint((java.awt.Paint) color14);
        java.lang.String str16 = org.jfree.chart.util.PaintUtilities.colorToString(color14);
        try {
            stackedAreaRenderer1.setSeriesPaint((int) (byte) -1, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "cyan" + "'", str16.equals("cyan"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries1.removeAll();
        java.lang.String str3 = taskSeries1.getDescription();
        boolean boolean4 = taskSeries1.getNotify();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, 0.2d, 0.0d, (double) 4);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setRangeAxisLocation((int) (short) 100, axisLocation20, true);
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(date23, date24);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        float float30 = dateAxis29.getTickMarkOutsideLength();
        dateAxis29.setNegativeArrowVisible(false);
        float float33 = dateAxis29.getTickMarkInsideLength();
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange(date34, date35);
        dateAxis29.setRange((org.jfree.data.Range) dateRange36);
        numberAxis3D27.setRange((org.jfree.data.Range) dateRange36);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange25, (org.jfree.data.Range) dateRange36);
        double double40 = rectangleConstraint39.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType41 = rectangleConstraint39.getWidthConstraintType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean43 = lengthConstraintType41.equals((java.lang.Object) rectangleAnchor42);
        boolean boolean44 = axisLocation20.equals((java.lang.Object) lengthConstraintType41);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Friday" + "'", str1.equals("Friday"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        xYPlot7.setBackgroundAlpha((float) 1L);
        java.awt.Color color13 = java.awt.Color.ORANGE;
        xYPlot7.setDomainCrosshairPaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font2 = textTitle1.getFont();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle1.getVerticalAlignment();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font7 = textTitle6.getFont();
        java.awt.Color color8 = java.awt.Color.RED;
        textTitle6.setPaint((java.awt.Paint) color8);
        boolean boolean10 = verticalAlignment4.equals((java.lang.Object) textTitle6);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image4 = null;
        projectInfo3.setLogo(image4);
        org.jfree.data.gantt.TaskSeries taskSeries7 = new org.jfree.data.gantt.TaskSeries("{0}");
        java.util.List list8 = taskSeries7.getTasks();
        projectInfo3.setContributors(list8);
        projectInfo0.setContributors(list8);
        java.lang.String str11 = projectInfo0.getVersion();
        java.lang.String str12 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0.6" + "'", str11.equals("1.0.6"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "JFreeChart" + "'", str12.equals("JFreeChart"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("JFreeChart");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getRed();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray6 = new float[] { 128, 'a', (-1) };
        try {
            float[] floatArray7 = color0.getColorComponents(colorSpace2, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        xYPlot7.notifyListeners(plotChangeEvent14);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer16 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint21 = stackedAreaRenderer19.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedAreaRenderer19.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = stackedAreaRenderer19.getBaseItemLabelGenerator();
        double double25 = stackedAreaRenderer19.getItemLabelAnchorOffset();
        java.awt.Paint paint28 = stackedAreaRenderer19.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker31.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer35 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint37 = stackedAreaRenderer35.getSeriesItemLabelPaint(100);
        stackedAreaRenderer35.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer35.setSeriesStroke(100, stroke41);
        valueMarker31.setStroke(stroke41);
        stackedAreaRenderer19.setSeriesStroke(11, stroke41);
        stackedBarRenderer16.setSeriesStroke(0, stroke41);
        xYPlot7.setDomainCrosshairStroke(stroke41);
        try {
            java.lang.Object obj47 = xYPlot7.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.RenderingHints renderingHints8 = jFreeChart7.getRenderingHints();
        org.jfree.chart.plot.Plot plot9 = jFreeChart7.getPlot();
        boolean boolean10 = jFreeChart7.isNotify();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(renderingHints8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setVisible(false);
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        numberAxis3D1.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        try {
            double double11 = numberAxis3D1.valueToJava2D((-8.0d), rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        labelBlock3.setToolTipText("hi!");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = xYPlot21.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        xYPlot21.setDrawingSupplier(drawingSupplier23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(axisLocation25, false);
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = labelBlock3.equals((java.lang.Object) xYPlot21);
        double double30 = xYPlot21.getRangeCrosshairValue();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.Point2D point2D33 = null;
        org.jfree.chart.plot.PlotState plotState34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            xYPlot21.draw(graphics2D31, rectangle2D32, point2D33, plotState34, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        java.awt.image.BufferedImage bufferedImage9 = jFreeChart4.createBufferedImage(100, (int) ' ', chartRenderingInfo8);
        projectInfo0.setLogo((java.awt.Image) bufferedImage9);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNull(legendTitle5);
        org.junit.Assert.assertNotNull(bufferedImage9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        java.lang.String[] strArray4 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray5 = null;
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray7, numberArray9 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset11 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray4, numberArray5, numberArray10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D(pieDataset12);
        defaultIntervalCategoryDataset11.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D13);
        int int15 = defaultIntervalCategoryDataset11.getSeriesCount();
        try {
            java.lang.String str18 = standardCategoryURLGenerator3.generateURL((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset11, 9999, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.getBaseFillPaint();
        lineAndShapeRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.LegendItem legendItem11 = lineAndShapeRenderer0.getLegendItem((int) '#', 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(legendItem11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        float float2 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray6, doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        dateAxis12.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot16 = dateAxis12.getPlot();
        double double17 = dateAxis12.getUpperBound();
        java.awt.Shape shape18 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint22 = stackedAreaRenderer20.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = stackedAreaRenderer20.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = stackedAreaRenderer20.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean30 = stackedAreaRenderer28.getSeriesVisibleInLegend(10);
        boolean boolean31 = stackedAreaRenderer28.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator32 = stackedAreaRenderer28.getLegendItemURLGenerator();
        java.awt.Paint paint34 = stackedAreaRenderer28.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer20.setSeriesPaint(1, paint34);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font39 = textTitle38.getFont();
        java.awt.Paint paint40 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("", font39, paint40);
        stackedAreaRenderer20.setBaseItemLabelPaint(paint40, false);
        stackedAreaRenderer20.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer20);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.axis.AxisCollection axisCollection51 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list52 = axisCollection51.getAxesAtBottom();
        java.util.List list53 = axisCollection51.getAxesAtLeft();
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("");
        float float56 = dateAxis55.getTickMarkOutsideLength();
        dateAxis55.setNegativeArrowVisible(false);
        double double59 = dateAxis55.getFixedDimension();
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("");
        float float63 = dateAxis62.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) dateAxis62, (org.jfree.chart.axis.ValueAxis) dateAxis65, xYItemRenderer66);
        java.awt.Paint paint68 = xYPlot67.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis("");
        float float72 = dateAxis71.getTickMarkOutsideLength();
        dateAxis71.setNegativeArrowVisible(false);
        float float75 = dateAxis71.getTickMarkInsideLength();
        xYPlot67.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis71);
        org.jfree.chart.util.Layer layer77 = null;
        java.util.Collection collection78 = xYPlot67.getDomainMarkers(layer77);
        org.jfree.chart.axis.DateAxis dateAxis80 = new org.jfree.chart.axis.DateAxis("");
        float float81 = dateAxis80.getTickMarkOutsideLength();
        dateAxis80.setNegativeArrowVisible(false);
        float float84 = dateAxis80.getTickMarkInsideLength();
        java.util.Date date85 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date86 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange87 = new org.jfree.data.time.DateRange(date85, date86);
        dateAxis80.setRange((org.jfree.data.Range) dateRange87);
        double double89 = dateAxis80.getFixedAutoRange();
        xYPlot67.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis80);
        org.jfree.chart.util.RectangleEdge rectangleEdge92 = xYPlot67.getRangeAxisEdge(4);
        axisCollection51.add((org.jfree.chart.axis.Axis) dateAxis55, rectangleEdge92);
        try {
            double double94 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor47, (int) (short) 0, 11, rectangle2D50, rectangleEdge92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
        org.junit.Assert.assertNull(categoryItemLabelGenerator25);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 2.0f + "'", float56 == 2.0f);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 2.0f + "'", float63 == 2.0f);
        org.junit.Assert.assertNull(paint68);
        org.junit.Assert.assertTrue("'" + float72 + "' != '" + 2.0f + "'", float72 == 2.0f);
        org.junit.Assert.assertTrue("'" + float75 + "' != '" + 0.0f + "'", float75 == 0.0f);
        org.junit.Assert.assertNull(collection78);
        org.junit.Assert.assertTrue("'" + float81 + "' != '" + 2.0f + "'", float81 == 2.0f);
        org.junit.Assert.assertTrue("'" + float84 + "' != '" + 0.0f + "'", float84 == 0.0f);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge92);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer0.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        boolean boolean4 = blockContainer3.isEmpty();
        org.jfree.chart.block.Arrangement arrangement5 = blockContainer3.getArrangement();
        blockContainer0.setArrangement(arrangement5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(arrangement5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.zoom(8.0d);
        int int13 = xYPlot7.getWeight();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedAreaRenderer1.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint11 = null;
        stackedAreaRenderer1.setBasePaint(paint11, false);
        boolean boolean14 = stackedAreaRenderer1.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke16 = piePlot15.getBaseSectionOutlineStroke();
        java.awt.Color color17 = java.awt.Color.CYAN;
        piePlot15.setShadowPaint((java.awt.Paint) color17);
        stackedAreaRenderer1.setBaseItemLabelPaint((java.awt.Paint) color17);
        java.lang.Object obj20 = stackedAreaRenderer1.clone();
        java.awt.Stroke stroke22 = stackedAreaRenderer1.getSeriesStroke(11);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(stroke22);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "{0}", "");
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape8 = numberAxis7.getDownArrow();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape3, shape8);
        shapeList0.setShape((int) (short) 100, shape8);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        float float48 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer51);
        java.util.Date date53 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = dateAxis47.dateToJava2D(date53, rectangle2D55, rectangleEdge56);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent58 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis47);
        categoryPlot43.axisChanged(axisChangeEvent58);
        org.jfree.chart.JFreeChart jFreeChart60 = axisChangeEvent58.getChart();
        org.jfree.chart.JFreeChart jFreeChart61 = axisChangeEvent58.getChart();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNull(jFreeChart60);
        org.junit.Assert.assertNull(jFreeChart61);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor1 = itemLabelPosition0.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker5.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint11 = stackedAreaRenderer9.getSeriesItemLabelPaint(100);
        stackedAreaRenderer9.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer9.setSeriesStroke(100, stroke15);
        valueMarker5.setStroke(stroke15);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer24);
        java.awt.Paint paint26 = xYPlot25.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        float float30 = dateAxis29.getTickMarkOutsideLength();
        dateAxis29.setNegativeArrowVisible(false);
        float float33 = dateAxis29.getTickMarkInsideLength();
        xYPlot25.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot25.getDomainMarkers(layer35);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        float float39 = dateAxis38.getTickMarkOutsideLength();
        dateAxis38.setNegativeArrowVisible(false);
        float float42 = dateAxis38.getTickMarkInsideLength();
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date44 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange(date43, date44);
        dateAxis38.setRange((org.jfree.data.Range) dateRange45);
        double double47 = dateAxis38.getFixedAutoRange();
        xYPlot25.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis38);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        float float52 = dateAxis51.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer55);
        java.util.Date date57 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis51.dateToJava2D(date57, rectangle2D59, rectangleEdge60);
        int int62 = xYPlot25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis51);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("");
        float float66 = dateAxis65.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset63, (org.jfree.chart.axis.ValueAxis) dateAxis65, (org.jfree.chart.axis.ValueAxis) dateAxis68, xYItemRenderer69);
        java.awt.Paint paint71 = xYPlot70.getRangeTickBandPaint();
        java.awt.Color color72 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot70.setNoDataMessagePaint((java.awt.Paint) color72);
        org.jfree.chart.plot.PlotOrientation plotOrientation74 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot70.setOrientation(plotOrientation74);
        xYPlot25.setOrientation(plotOrientation74);
        java.awt.Paint paint77 = xYPlot25.getBackgroundPaint();
        java.awt.Stroke stroke78 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker80 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) simpleTimePeriod2, (java.awt.Paint) color3, stroke15, paint77, stroke78, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 2.0f + "'", float52 == 2.0f);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 2.0f + "'", float66 == 2.0f);
        org.junit.Assert.assertNull(paint71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(plotOrientation74);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("Friday");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getCount();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        java.util.Date date5 = dateTickUnit0.rollDate(date2);
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Date date10 = dateTickUnit0.rollDate(date6, timeZone9);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset4);
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot5.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart6.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        java.awt.image.BufferedImage bufferedImage11 = jFreeChart6.createBufferedImage(100, (int) ' ', chartRenderingInfo10);
        jFreeChart2.setBackgroundImage((java.awt.Image) bufferedImage11);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNotNull(bufferedImage11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean13 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, year2);
        java.util.Date date5 = month4.getStart();
        long long6 = month4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1572591599999L + "'", long6 == 1572591599999L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = piePlot3D1.clone();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, paint5);
        piePlot3D1.setLabelFont(font4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot3D1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        xYPlot7.notifyListeners(plotChangeEvent14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke17 = piePlot16.getBaseSectionOutlineStroke();
        java.awt.Color color18 = java.awt.Color.CYAN;
        piePlot16.setShadowPaint((java.awt.Paint) color18);
        java.awt.Color color21 = java.awt.Color.white;
        piePlot16.setSectionPaint((java.lang.Comparable) 12.0d, (java.awt.Paint) color21);
        xYPlot7.setRangeCrosshairPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Plot plot24 = xYPlot7.getParent();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(plot24);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        float float2 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis3D0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setPositiveArrowVisible(true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer2.getSeriesCreateEntities((int) (byte) -1);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator8 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.Object obj9 = standardCategoryToolTipGenerator8.clone();
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (byte) 0, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator8);
        java.lang.String[] strArray11 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray12 = null;
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray14, numberArray16 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray11, numberArray12, numberArray17);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray21, doubleArray22, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        float float29 = dateAxis28.getTickMarkOutsideLength();
        dateAxis28.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot32 = dateAxis28.getPlot();
        double double33 = dateAxis28.getUpperBound();
        java.awt.Shape shape34 = dateAxis28.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer36 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint38 = stackedAreaRenderer36.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator40 = stackedAreaRenderer36.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = stackedAreaRenderer36.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean46 = stackedAreaRenderer44.getSeriesVisibleInLegend(10);
        boolean boolean47 = stackedAreaRenderer44.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator48 = stackedAreaRenderer44.getLegendItemURLGenerator();
        java.awt.Paint paint50 = stackedAreaRenderer44.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer36.setSeriesPaint(1, paint50);
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font55 = textTitle54.getFont();
        java.awt.Paint paint56 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine57 = new org.jfree.chart.text.TextLine("", font55, paint56);
        stackedAreaRenderer36.setBaseItemLabelPaint(paint56, false);
        stackedAreaRenderer36.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer36);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("");
        float float66 = dateAxis65.getTickMarkOutsideLength();
        dateAxis65.setNegativeArrowVisible(false);
        dateAxis65.setLowerMargin((double) 15);
        dateAxis65.setLowerMargin(0.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer73 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator77 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean78 = lineAndShapeRenderer73.equals((java.lang.Object) "");
        boolean boolean80 = lineAndShapeRenderer73.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot81 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis65, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer73);
        defaultIntervalCategoryDataset18.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot81);
        try {
            java.lang.String str84 = standardCategoryToolTipGenerator8.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset18, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNull(categoryItemLabelGenerator40);
        org.junit.Assert.assertNull(categoryItemLabelGenerator41);
        org.junit.Assert.assertNull(boolean46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 2.0f + "'", float66 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint9 = stackedAreaRenderer7.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer7.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedAreaRenderer7.getBaseItemLabelGenerator();
        double double13 = stackedAreaRenderer7.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer7.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis1.setAxisLinePaint(paint16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        float float22 = dateAxis21.getTickMarkOutsideLength();
        dateAxis21.setNegativeArrowVisible(false);
        float float25 = dateAxis21.getTickMarkInsideLength();
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange(date26, date27);
        dateAxis21.setRange((org.jfree.data.Range) dateRange28);
        numberAxis3D19.setRange((org.jfree.data.Range) dateRange28);
        dateAxis1.setRange((org.jfree.data.Range) dateRange28);
        boolean boolean32 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int34 = dateTickUnit33.getCount();
        dateAxis1.setTickUnit(dateTickUnit33, false, false);
        boolean boolean39 = dateTickUnit33.equals((java.lang.Object) (byte) 1);
        java.util.Date date40 = null;
        try {
            java.util.Date date41 = dateTickUnit33.addToDate(date40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font4 = textTitle3.getFont();
        java.awt.Paint paint5 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font4, paint5);
        textBlock0.addLine(textLine6);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font9, paint10);
        textBlock0.addLine(textLine11);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLegendLabelToolTipGenerator();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getColorComponents(floatArray5);
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font13, paint14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font13, (org.jfree.chart.plot.Plot) piePlot16, false);
        java.awt.RenderingHints renderingHints19 = jFreeChart18.getRenderingHints();
        java.awt.PaintContext paintContext20 = color4.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints19);
        piePlot3D1.setSectionPaint((java.lang.Comparable) (byte) 10, (java.awt.Paint) color4);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(renderingHints19);
        org.junit.Assert.assertNotNull(paintContext20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date1, date2);
        task5.setPercentComplete(3.0d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color8 = java.awt.Color.CYAN;
        stackedAreaRenderer6.setSeriesFillPaint(2, (java.awt.Paint) color8, true);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color8);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity12 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean14 = lineAndShapeRenderer13.getBaseLinesVisible();
        boolean boolean15 = lineAndShapeRenderer13.getBaseCreateEntities();
        lineAndShapeRenderer13.setUseOutlinePaint(false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer13.lookupSeriesOutlineStroke(100);
        java.awt.Color color20 = java.awt.Color.CYAN;
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "cyan", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code.", shape4, stroke19, (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("CategoryLabelWidthType.CATEGORY", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "Friday", "JFreeChart");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        dateAxis2.setNegativeArrowVisible(false);
        float float6 = dateAxis2.getTickMarkInsideLength();
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(date7, date8);
        dateAxis2.setRange((org.jfree.data.Range) dateRange9);
        double double11 = dateAxis2.getFixedAutoRange();
        boolean boolean12 = chartChangeEventType0.equals((java.lang.Object) dateAxis2);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 100);
        java.util.List list2 = keyToGroupMap1.getGroups();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        int int21 = defaultIntervalCategoryDataset7.indexOf((java.lang.Comparable) 9);
        try {
            int int22 = defaultIntervalCategoryDataset7.getRowCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setNegativeArrowVisible(false);
        float float18 = dateAxis14.getTickMarkInsideLength();
        xYPlot10.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getDomainMarkers(layer20);
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) xYPlot10);
        java.awt.Paint paint23 = xYPlot10.getBackgroundPaint();
        xYPlot10.zoom((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        piePlot3D9.setForegroundAlpha((float) (byte) 10);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            piePlot3D9.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.JFreeChart jFreeChart29 = multiplePiePlot28.getPieChart();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        jFreeChart29.clearSubtitles();
        jFreeChart29.setNotify(false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jFreeChart29);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        boolean boolean7 = textTitle5.getExpandToFitSpace();
        double double8 = textTitle5.getHeight();
        textTitle5.setPadding((double) (byte) 1, 0.0d, (double) (byte) -1, 100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle5.getMargin();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Paint paint11 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        xYPlot10.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot10.setDomainAxisLocation(axisLocation14, false);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        boolean boolean18 = dateAxis1.isAutoRange();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 100);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        dateAxis5.setNegativeArrowVisible(false);
        float float9 = dateAxis5.getTickMarkInsideLength();
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date10, date11);
        dateAxis5.setRange((org.jfree.data.Range) dateRange12);
        numberAxis3D3.setRange((org.jfree.data.Range) dateRange12);
        java.util.Date date15 = dateRange12.getUpperDate();
        int int16 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) date15);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        try {
            double double7 = dateAxis0.java2DToValue((double) 1546329600000L, rectangle2D2, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean12 = xYPlot7.equals((java.lang.Object) itemLabelAnchor11);
        boolean boolean13 = xYPlot7.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font6, (org.jfree.chart.plot.Plot) piePlot9, false);
        stackedBarRenderer3D2.setSeriesItemLabelFont((int) '4', font6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = stackedBarRenderer3D2.getSeriesNegativeItemLabelPosition(11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            stackedBarRenderer3D2.drawRangeGridline(graphics2D16, categoryPlot17, valueAxis18, rectangle2D19, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockBorder2.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot7.getRangeMarkers(9999, layer10);
        java.awt.Paint paint12 = xYPlot7.getRangeTickBandPaint();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        float float20 = dateAxis19.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer23);
        java.awt.Paint paint25 = xYPlot24.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        float float29 = dateAxis28.getTickMarkOutsideLength();
        dateAxis28.setNegativeArrowVisible(false);
        float float32 = dateAxis28.getTickMarkInsideLength();
        xYPlot24.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis28);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot24.getDomainMarkers(layer34);
        boolean boolean36 = simpleTimePeriod16.equals((java.lang.Object) xYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot24.getDomainAxisLocation(0);
        xYPlot7.setRangeAxisLocation((int) (byte) 10, axisLocation38, false);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape43 = numberAxis42.getDownArrow();
        xYPlot7.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis42);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(shape43);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setLabelLinksVisible(true);
        java.awt.Color color4 = java.awt.Color.ORANGE;
        piePlot3D1.setBaseSectionPaint((java.awt.Paint) color4);
        piePlot3D1.setStartAngle(1.560181216381E12d);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        int int5 = lineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset6, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D5.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D5.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint11 = stackedBarRenderer3D5.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D2.setBaseOutlinePaint(paint11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            stackedBarRenderer3D2.drawDomainGridline(graphics2D13, categoryPlot14, rectangle2D15, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot7.addChangeListener(plotChangeListener27);
        java.awt.Paint paint29 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot7.setRangeTickBandPaint(paint29);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint12 = stackedAreaRenderer10.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = stackedAreaRenderer10.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = stackedAreaRenderer10.getBaseItemLabelGenerator();
        double double16 = stackedAreaRenderer10.getItemLabelAnchorOffset();
        java.awt.Paint paint19 = stackedAreaRenderer10.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker22.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint28 = stackedAreaRenderer26.getSeriesItemLabelPaint(100);
        stackedAreaRenderer26.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer26.setSeriesStroke(100, stroke32);
        valueMarker22.setStroke(stroke32);
        stackedAreaRenderer10.setSeriesStroke(11, stroke32);
        xYPlot7.setRangeCrosshairStroke(stroke32);
        int int37 = xYPlot7.getSeriesCount();
        double double38 = xYPlot7.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setTickLabelsVisible(true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis3D9.getTickUnit();
        try {
            int int11 = defaultIntervalCategoryDataset7.getColumnIndex((java.lang.Comparable) numberTickUnit10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberTickUnit10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        categoryPlot43.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj46 = categoryAxis3D45.clone();
        float float47 = categoryAxis3D45.getMaximumCategoryLabelWidthRatio();
        int int48 = categoryPlot43.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D45);
        int int49 = categoryPlot43.getRangeAxisCount();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("");
        float float56 = dateAxis55.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis58, xYItemRenderer59);
        java.awt.Paint paint61 = xYPlot60.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis("");
        float float65 = dateAxis64.getTickMarkOutsideLength();
        dateAxis64.setNegativeArrowVisible(false);
        float float68 = dateAxis64.getTickMarkInsideLength();
        xYPlot60.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis64);
        org.jfree.chart.util.Layer layer70 = null;
        java.util.Collection collection71 = xYPlot60.getDomainMarkers(layer70);
        boolean boolean72 = simpleTimePeriod52.equals((java.lang.Object) xYPlot60);
        org.jfree.chart.axis.AxisLocation axisLocation74 = xYPlot60.getDomainAxisLocation(0);
        java.lang.String str75 = axisLocation74.toString();
        categoryPlot43.setRangeAxisLocation(axisLocation74);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 2.0f + "'", float56 == 2.0f);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertTrue("'" + float65 + "' != '" + 2.0f + "'", float65 == 2.0f);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 0.0f + "'", float68 == 0.0f);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str75.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        categoryPlot43.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj46 = categoryAxis3D45.clone();
        float float47 = categoryAxis3D45.getMaximumCategoryLabelWidthRatio();
        int int48 = categoryPlot43.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D45);
        categoryPlot43.setRangeCrosshairValue((double) 5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot7.getRangeMarkers(9999, layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            xYPlot7.handleClick((int) (byte) 0, 0, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedAreaRenderer1.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 1, (java.lang.Boolean) false, true);
        boolean boolean13 = stackedAreaRenderer1.isSeriesItemLabelsVisible((int) '4');
        boolean boolean14 = stackedAreaRenderer1.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.String str4 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("Last", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        task4.setDescription("Last");
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) task4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 3.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedAreaRenderer1.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        stackedAreaRenderer1.setSeriesPaint(2, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray17, doubleArray18, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        float float25 = dateAxis24.getTickMarkOutsideLength();
        dateAxis24.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot28 = dateAxis24.getPlot();
        double double29 = dateAxis24.getUpperBound();
        java.awt.Shape shape30 = dateAxis24.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer32 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint34 = stackedAreaRenderer32.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator36 = stackedAreaRenderer32.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = stackedAreaRenderer32.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer40 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean42 = stackedAreaRenderer40.getSeriesVisibleInLegend(10);
        boolean boolean43 = stackedAreaRenderer40.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = stackedAreaRenderer40.getLegendItemURLGenerator();
        java.awt.Paint paint46 = stackedAreaRenderer40.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer32.setSeriesPaint(1, paint46);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font51 = textTitle50.getFont();
        java.awt.Paint paint52 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine53 = new org.jfree.chart.text.TextLine("", font51, paint52);
        stackedAreaRenderer32.setBaseItemLabelPaint(paint52, false);
        stackedAreaRenderer32.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer32);
        org.jfree.chart.LegendItemCollection legendItemCollection59 = categoryPlot58.getLegendItems();
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        try {
            stackedAreaRenderer1.drawDomainGridline(graphics2D14, categoryPlot58, rectangle2D60, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNull(categoryItemLabelGenerator36);
        org.junit.Assert.assertNull(categoryItemLabelGenerator37);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(legendItemCollection59);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        try {
            int int10 = spreadsheetDate3.compareTo((java.lang.Object) numberAxis3D9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.axis.NumberAxis3D cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        double double6 = dateAxis1.getUpperBound();
        java.awt.Shape shape7 = dateAxis1.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape7, "{0}");
        java.lang.String str10 = chartEntity9.toString();
        java.lang.String str11 = chartEntity9.getToolTipText();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartEntity: tooltip = {0}" + "'", str10.equals("ChartEntity: tooltip = {0}"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{0}" + "'", str11.equals("{0}"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        org.jfree.data.general.DatasetGroup datasetGroup20 = defaultIntervalCategoryDataset7.getGroup();
        try {
            int int21 = defaultIntervalCategoryDataset7.getRowCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(datasetGroup20);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot43.getDomainAxis(9999);
        java.awt.Stroke stroke46 = categoryPlot43.getOutlineStroke();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, year2);
        java.util.Date date5 = month4.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer15);
        java.awt.Paint paint17 = xYPlot16.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        xYPlot16.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot16.getDomainMarkers(layer26);
        boolean boolean28 = simpleTimePeriod8.equals((java.lang.Object) xYPlot16);
        java.awt.Paint paint29 = xYPlot16.getBackgroundPaint();
        boolean boolean30 = month4.equals((java.lang.Object) xYPlot16);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D36.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = stackedBarRenderer3D36.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint42 = stackedBarRenderer3D36.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D33.setBaseOutlinePaint(paint42);
        stackedBarRenderer3D33.setItemLabelAnchorOffset((double) 1.0f);
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str47 = ringPlot46.getNoDataMessage();
        double double48 = ringPlot46.getInnerSeparatorExtension();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer50 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint52 = stackedAreaRenderer50.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator54 = stackedAreaRenderer50.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator55 = stackedAreaRenderer50.getBaseItemLabelGenerator();
        double double56 = stackedAreaRenderer50.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = stackedAreaRenderer50.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint60 = null;
        stackedAreaRenderer50.setBasePaint(paint60, false);
        boolean boolean63 = stackedAreaRenderer50.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getBaseSectionOutlineStroke();
        java.awt.Color color66 = java.awt.Color.CYAN;
        piePlot64.setShadowPaint((java.awt.Paint) color66);
        stackedAreaRenderer50.setBaseItemLabelPaint((java.awt.Paint) color66);
        ringPlot46.setSeparatorPaint((java.awt.Paint) color66);
        stackedBarRenderer3D33.setWallPaint((java.awt.Paint) color66);
        java.awt.Paint paint71 = stackedBarRenderer3D33.getWallPaint();
        xYPlot16.setRangeCrosshairPaint(paint71);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertNull(categoryItemLabelGenerator54);
        org.junit.Assert.assertNull(categoryItemLabelGenerator55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 2.0d + "'", double56 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer5.getBaseLinesVisible();
        boolean boolean7 = lineAndShapeRenderer5.getBaseCreateEntities();
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer5.setSeriesOutlineStroke((int) (short) 10, stroke9, false);
        stackedBarRenderer3D2.setBaseStroke(stroke9, false);
        java.io.ObjectOutputStream objectOutputStream14 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke9, objectOutputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = stackedAreaRenderer1.getLegendItemToolTipGenerator();
        java.lang.Boolean boolean9 = stackedAreaRenderer1.getSeriesCreateEntities((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean12 = lineAndShapeRenderer11.getBaseLinesVisible();
        lineAndShapeRenderer11.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator20 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        lineAndShapeRenderer11.setSeriesURLGenerator(9999, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator20);
        stackedAreaRenderer1.setSeriesURLGenerator((int) (byte) 100, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator20, false);
        java.lang.Object obj24 = standardCategoryURLGenerator20.clone();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer15);
        java.awt.Paint paint17 = xYPlot16.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        xYPlot16.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        xYPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        float float30 = dateAxis29.getTickMarkOutsideLength();
        dateAxis29.setNegativeArrowVisible(false);
        dateAxis29.setLowerMargin((double) 15);
        dateAxis29.setFixedAutoRange((double) 1);
        xYPlot7.setRangeAxis(9, (org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot43.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        int int47 = categoryPlot43.getDomainAxisIndex(categoryAxis46);
        int int48 = categoryPlot43.getDomainAxisCount();
        categoryPlot43.zoom((double) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot43.getDomainAxis();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNull(categoryAxis51);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date9, date10);
        org.jfree.data.gantt.Task task12 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date8, date9);
        boolean boolean13 = stackedAreaRenderer1.equals((java.lang.Object) task12);
        boolean boolean16 = stackedAreaRenderer1.getItemVisible(4, 3);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        multiplePiePlot1.setDataset(categoryDataset3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D10.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D10.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint16 = stackedBarRenderer3D10.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D7.setBaseOutlinePaint(paint16);
        boolean boolean18 = multiplePiePlot1.equals((java.lang.Object) paint16);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot1.getPieChart();
        java.util.List list20 = jFreeChart19.getSubtitles();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("hi!", font2, paint3);
        boolean boolean5 = ringPlot0.equals((java.lang.Object) "hi!");
        ringPlot0.setInnerSeparatorExtension((double) 86400000L);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        multiplePiePlot1.setDataset(categoryDataset3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D10.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D10.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint16 = stackedBarRenderer3D10.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D7.setBaseOutlinePaint(paint16);
        boolean boolean18 = multiplePiePlot1.equals((java.lang.Object) paint16);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.Title title20 = null;
        try {
            jFreeChart19.addSubtitle(title20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jFreeChart19);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = xYPlot17.getRangeTickBandPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot17.setNoDataMessagePaint((java.awt.Paint) color19);
        xYPlot17.clearRangeAxes();
        xYPlot17.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot17.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup26 = xYPlot17.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.JFreeChart jFreeChart29 = multiplePiePlot28.getPieChart();
        java.awt.Image image30 = jFreeChart29.getBackgroundImage();
        xYPlot17.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot17.setAxisOffset(rectangleInsets32);
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker36.setLabel("");
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot17.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker36, layer39);
        java.util.Collection collection41 = xYPlot7.getDomainMarkers(1, layer39);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(jFreeChart29);
        org.junit.Assert.assertNull(image30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNull(collection41);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange13);
        double double17 = rectangleConstraint16.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint16.getWidthConstraintType();
        java.lang.String str19 = rectangleConstraint16.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint16.toUnconstrainedWidth();
        org.jfree.data.Range range21 = rectangleConstraint20.getWidthRange();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str19.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        java.awt.Paint paint10 = stackedAreaRenderer1.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D14.setMaximumBarWidth((double) (short) 0);
        stackedBarRenderer3D14.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint24 = stackedAreaRenderer22.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = stackedAreaRenderer22.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = stackedAreaRenderer22.getBaseItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer22.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D14.setSeriesNegativeItemLabelPosition(9999, itemLabelPosition28, false);
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition(11, itemLabelPosition28);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = stackedAreaRenderer1.getLegendItems();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator27);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(legendItemCollection32);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        categoryPlot43.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj46 = categoryAxis3D45.clone();
        float float47 = categoryAxis3D45.getMaximumCategoryLabelWidthRatio();
        int int48 = categoryPlot43.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D45);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        float float52 = dateAxis51.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer55);
        java.awt.Paint paint57 = xYPlot56.getRangeTickBandPaint();
        java.awt.Color color58 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot56.setNoDataMessagePaint((java.awt.Paint) color58);
        xYPlot56.clearRangeAxes();
        xYPlot56.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation64 = xYPlot56.getRangeAxisLocation((int) (short) 1);
        xYPlot56.mapDatasetToDomainAxis((int) (byte) 100, 15);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder68 = xYPlot56.getSeriesRenderingOrder();
        categoryAxis3D45.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot56);
        try {
            xYPlot56.setBackgroundImageAlpha((float) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 2.0f + "'", float52 == 2.0f);
        org.junit.Assert.assertNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(axisLocation64);
        org.junit.Assert.assertNotNull(seriesRenderingOrder68);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot7.getRangeMarkers(9999, layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot7.getSeriesRenderingOrder();
        boolean boolean17 = xYPlot7.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setName("EXPAND");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedAreaRenderer1.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        stackedAreaRenderer1.setSeriesPaint(2, paint12);
        org.jfree.chart.block.BorderArrangement borderArrangement14 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D16.setVisible(false);
        org.jfree.chart.plot.Plot plot19 = numberAxis3D16.getPlot();
        java.awt.Shape shape20 = numberAxis3D16.getLeftArrow();
        boolean boolean21 = borderArrangement14.equals((java.lang.Object) shape20);
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, (double) 15, (double) 10);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer1, (org.jfree.chart.block.Arrangement) borderArrangement14, (org.jfree.chart.block.Arrangement) columnArrangement27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer30 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean31 = rectangleInsets29.equals((java.lang.Object) ganttRenderer30);
        legendTitle28.setLegendItemGraphicPadding(rectangleInsets29);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        java.awt.Image image2 = piePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot0.setDataset(pieDataset3);
        piePlot0.setCircular(true, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Shape shape4 = lineAndShapeRenderer0.getItemShape(6, 1);
        boolean boolean7 = lineAndShapeRenderer0.isItemLabelVisible((int) (byte) 10, 4);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray11, doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        float float18 = dateAxis17.getTickMarkOutsideLength();
        dateAxis17.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot21 = dateAxis17.getPlot();
        double double22 = dateAxis17.getUpperBound();
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint27 = stackedAreaRenderer25.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer25.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer25.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean35 = stackedAreaRenderer33.getSeriesVisibleInLegend(10);
        boolean boolean36 = stackedAreaRenderer33.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedAreaRenderer33.getLegendItemURLGenerator();
        java.awt.Paint paint39 = stackedAreaRenderer33.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer25.setSeriesPaint(1, paint39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font44 = textTitle43.getFont();
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("", font44, paint45);
        stackedAreaRenderer25.setBaseItemLabelPaint(paint45, false);
        stackedAreaRenderer25.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer25);
        org.jfree.data.Range range52 = lineAndShapeRenderer0.findRangeBounds(categoryDataset14);
        java.lang.Number number53 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNull(number53);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset4 = piePlot2.getDataset();
        piePlot2.setMinimumArcAngleToDraw(12.0d);
        boolean boolean7 = textTitle1.equals((java.lang.Object) piePlot2);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer17);
        java.awt.Paint paint19 = xYPlot18.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        float float23 = dateAxis22.getTickMarkOutsideLength();
        dateAxis22.setNegativeArrowVisible(false);
        float float26 = dateAxis22.getTickMarkInsideLength();
        xYPlot18.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = xYPlot18.getDomainMarkers(layer28);
        boolean boolean30 = simpleTimePeriod10.equals((java.lang.Object) xYPlot18);
        java.awt.Stroke stroke31 = piePlot2.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod10);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            piePlot2.drawBackground(graphics2D32, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(stroke31);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        categoryPlot43.setRangeCrosshairValue((double) 6);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        float float48 = dateAxis47.getTickMarkOutsideLength();
        dateAxis47.setNegativeArrowVisible(false);
        double double51 = dateAxis47.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("");
        float float54 = dateAxis53.getTickMarkOutsideLength();
        dateAxis53.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot57 = dateAxis53.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint61 = stackedAreaRenderer59.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator63 = stackedAreaRenderer59.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator64 = stackedAreaRenderer59.getBaseItemLabelGenerator();
        double double65 = stackedAreaRenderer59.getItemLabelAnchorOffset();
        java.awt.Paint paint68 = stackedAreaRenderer59.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis53.setAxisLinePaint(paint68);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D71 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("");
        float float74 = dateAxis73.getTickMarkOutsideLength();
        dateAxis73.setNegativeArrowVisible(false);
        float float77 = dateAxis73.getTickMarkInsideLength();
        java.util.Date date78 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date79 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange80 = new org.jfree.data.time.DateRange(date78, date79);
        dateAxis73.setRange((org.jfree.data.Range) dateRange80);
        numberAxis3D71.setRange((org.jfree.data.Range) dateRange80);
        dateAxis53.setRange((org.jfree.data.Range) dateRange80);
        boolean boolean84 = dateAxis53.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit85 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int86 = dateTickUnit85.getCount();
        dateAxis53.setTickUnit(dateTickUnit85, false, false);
        dateAxis47.setTickUnit(dateTickUnit85);
        org.jfree.data.Range range91 = categoryPlot43.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis47);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 2.0f + "'", float54 == 2.0f);
        org.junit.Assert.assertNull(plot57);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNull(categoryItemLabelGenerator63);
        org.junit.Assert.assertNull(categoryItemLabelGenerator64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 2.0d + "'", double65 == 2.0d);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 2.0f + "'", float74 == 2.0f);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.0f + "'", float77 == 0.0f);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(dateTickUnit85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNull(range91);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape1, "{0}", "");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape1);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint7 = stackedAreaRenderer1.getItemPaint(255, 255);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = stackedAreaRenderer1.getLegendItemLabelGenerator();
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Class class0 = null;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(date3, date4);
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date2, date3);
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone7);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.DateTick dateTick13 = new org.jfree.chart.axis.DateTick(date3, "", textAnchor10, textAnchor11, (double) 2);
        java.util.Date date14 = dateTick13.getDate();
        double double15 = dateTick13.getAngle();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        numberAxis3D1.setRange((double) 100, 100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCount();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date9, date10);
        org.jfree.data.gantt.Task task12 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date8, date9);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date9, timeZone13);
        java.util.Date date15 = dateTickUnit4.addToDate(date6, timeZone13);
        try {
            org.jfree.data.xy.XYDataset xYDataset16 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 1, 0.0d, 0, (java.lang.Comparable) dateTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.JFreeChart jFreeChart29 = multiplePiePlot28.getPieChart();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        try {
            org.jfree.chart.title.Title title32 = jFreeChart29.getSubtitle((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jFreeChart29);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setBackgroundImageAlignment((int) (short) 1);
        boolean boolean34 = xYPlot7.isRangeZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean39 = lineAndShapeRenderer38.getBaseLinesVisible();
        boolean boolean40 = lineAndShapeRenderer38.getBaseCreateEntities();
        java.awt.Stroke stroke42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer38.setSeriesOutlineStroke((int) (short) 10, stroke42, false);
        valueMarker37.setStroke(stroke42);
        org.jfree.chart.util.Layer layer46 = null;
        xYPlot7.addRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker37, layer46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double50 = rectangleInsets48.calculateLeftInset((double) 11);
        valueMarker37.setLabelOffset(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 8.0d + "'", double50 == 8.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        int int7 = jFreeChart2.getBackgroundImageAlignment();
        float float8 = jFreeChart2.getBackgroundImageAlpha();
        jFreeChart2.setTitle("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (-1L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int2 = defaultCategoryDataset0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        piePlot3D9.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj14 = categoryAxis3D13.clone();
        float float15 = categoryAxis3D13.getMaximumCategoryLabelWidthRatio();
        float float16 = categoryAxis3D13.getMaximumCategoryLabelWidthRatio();
        java.lang.Object obj17 = categoryAxis3D13.clone();
        java.awt.Font font19 = categoryAxis3D13.getTickLabelFont((java.lang.Comparable) true);
        piePlot3D9.setLabelFont(font19);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", 90.0d);
        java.lang.Number number6 = null;
        try {
            defaultKeyedValues0.insertValue((int) (byte) 100, (java.lang.Comparable) 9999, number6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getNoDataMessage();
        java.awt.Stroke stroke2 = ringPlot0.getLabelLinkStroke();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        stackedBarRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = stackedBarRenderer3D2.getURLGenerator(5, 3);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 0, 12.0d, 0.25d, (double) (-1));
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        boolean boolean31 = dateAxis20.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        stackedAreaRenderer1.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer1.setSeriesStroke(100, stroke7);
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke7, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            textTitle1.setBounds(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedAreaRenderer1.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint11 = null;
        stackedAreaRenderer1.setBasePaint(paint11, false);
        boolean boolean14 = stackedAreaRenderer1.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke16 = piePlot15.getBaseSectionOutlineStroke();
        java.awt.Color color17 = java.awt.Color.CYAN;
        piePlot15.setShadowPaint((java.awt.Paint) color17);
        stackedAreaRenderer1.setBaseItemLabelPaint((java.awt.Paint) color17);
        stackedAreaRenderer1.setBaseCreateEntities(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedAreaRenderer1.getSeriesItemLabelGenerator((int) '#');
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font4 = textTitle3.getFont();
        java.awt.Paint paint5 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font4, paint5);
        textBlock0.addLine(textLine6);
        org.jfree.chart.text.TextFragment textFragment8 = textLine6.getLastTextFragment();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = textAnchor12.equals((java.lang.Object) spreadsheetDate16);
        try {
            textLine6.draw(graphics2D9, 0.0f, (float) 10L, textAnchor12, (float) 6, (float) 9999, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textFragment8);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean27 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean28 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        double double6 = dateAxis1.getUpperBound();
        java.awt.Shape shape7 = dateAxis1.getDownArrow();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape7, shape8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = xYPlot17.getRangeTickBandPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot17.setNoDataMessagePaint((java.awt.Paint) color19);
        xYPlot17.clearRangeAxes();
        xYPlot17.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot17.getRangeAxisLocation((int) (short) 1);
        java.awt.Paint paint26 = xYPlot17.getDomainCrosshairPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape7, paint26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        float float32 = dateAxis31.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis34, valueAxis37, xYItemRenderer38);
        java.awt.Stroke stroke40 = xYPlot39.getRangeZeroBaselineStroke();
        legendGraphic27.setLineStroke(stroke40);
        java.awt.Stroke stroke42 = legendGraphic27.getOutlineStroke();
        legendGraphic27.setShapeOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(stroke42);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8);
        double double10 = dateAxis1.getFixedAutoRange();
        boolean boolean12 = dateAxis1.isHiddenValue((long) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean4 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setSeriesOutlineStroke((int) (short) 10, stroke6, false);
        valueMarker1.setStroke(stroke6);
        java.awt.Paint paint10 = valueMarker1.getPaint();
        java.awt.Stroke stroke11 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        double double2 = blockContainer0.getHeight();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            blockContainer0.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.clearCache(classLoader3);
        java.util.ResourceBundle.clearCache(classLoader3);
        java.util.ResourceBundle.Control control6 = null;
        try {
            java.util.ResourceBundle resourceBundle7 = java.util.ResourceBundle.getBundle("AxisLocation.BOTTOM_OR_LEFT", locale1, classLoader3, control6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setRangeAxisLocation((int) (short) 100, axisLocation20, true);
        java.awt.Paint paint23 = xYPlot7.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        dateAxis2.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot6 = dateAxis2.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint10 = stackedAreaRenderer8.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedAreaRenderer8.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedAreaRenderer8.getBaseItemLabelGenerator();
        double double14 = stackedAreaRenderer8.getItemLabelAnchorOffset();
        java.awt.Paint paint17 = stackedAreaRenderer8.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis2.setAxisLinePaint(paint17);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        float float23 = dateAxis22.getTickMarkOutsideLength();
        dateAxis22.setNegativeArrowVisible(false);
        float float26 = dateAxis22.getTickMarkInsideLength();
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange(date27, date28);
        dateAxis22.setRange((org.jfree.data.Range) dateRange29);
        numberAxis3D20.setRange((org.jfree.data.Range) dateRange29);
        dateAxis2.setRange((org.jfree.data.Range) dateRange29);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, (org.jfree.data.Range) dateRange29);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange(date34, date35);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        float float41 = dateAxis40.getTickMarkOutsideLength();
        dateAxis40.setNegativeArrowVisible(false);
        float float44 = dateAxis40.getTickMarkInsideLength();
        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange47 = new org.jfree.data.time.DateRange(date45, date46);
        dateAxis40.setRange((org.jfree.data.Range) dateRange47);
        numberAxis3D38.setRange((org.jfree.data.Range) dateRange47);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, (org.jfree.data.Range) dateRange47);
        org.jfree.data.Range range53 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange36, (double) 86400000L, (double) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = rectangleConstraint33.toRangeHeight((org.jfree.data.Range) dateRange36);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 2.0f + "'", float41 == 2.0f);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rectangleConstraint54);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        double double2 = blockContainer0.getHeight();
        boolean boolean3 = blockContainer0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot7.getRangeAxisEdge(15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        float float20 = dateAxis19.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        float float24 = dateAxis23.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer27);
        org.jfree.data.Range range29 = dateAxis23.getRange();
        dateAxis19.setRange(range29);
        java.lang.String str31 = range29.toString();
        boolean boolean32 = rectangleEdge17.equals((java.lang.Object) range29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str31.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getNoDataMessage();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator2);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        boolean boolean9 = xYPlot7.isOutlineVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot15 = dateAxis11.getPlot();
        double double16 = dateAxis11.getUpperBound();
        java.awt.Shape shape17 = dateAxis11.getDownArrow();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal(shape17, shape18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        float float23 = dateAxis22.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer26);
        java.awt.Paint paint28 = xYPlot27.getRangeTickBandPaint();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot27.setNoDataMessagePaint((java.awt.Paint) color29);
        xYPlot27.clearRangeAxes();
        xYPlot27.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot27.getRangeAxisLocation((int) (short) 1);
        java.awt.Paint paint36 = xYPlot27.getDomainCrosshairPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape17, paint36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        float float42 = dateAxis41.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis44, valueAxis47, xYItemRenderer48);
        java.awt.Stroke stroke50 = xYPlot49.getRangeZeroBaselineStroke();
        legendGraphic37.setLineStroke(stroke50);
        xYPlot7.setOutlineStroke(stroke50);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.getBaseFillPaint();
        lineAndShapeRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        double double5 = stackedBarRenderer3D2.getMinimumBarLength();
        double double6 = stackedBarRenderer3D2.getLowerClip();
        double double7 = stackedBarRenderer3D2.getUpperClip();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset2 = piePlot0.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(pieDataset2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        categoryPlot43.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj46 = categoryAxis3D45.clone();
        float float47 = categoryAxis3D45.getMaximumCategoryLabelWidthRatio();
        int int48 = categoryPlot43.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D45);
        int int49 = categoryPlot43.getRangeAxisCount();
        double double50 = categoryPlot43.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        try {
            org.jfree.data.Range range2 = stackedBarRenderer0.findRangeBounds(categoryDataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int11 = spreadsheetDate6.getDayOfWeek();
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) int11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setVisible(false);
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint7 = boxAndWhiskerRenderer5.lookupSeriesFillPaint(1);
        numberAxis3D1.setAxisLinePaint(paint7);
        boolean boolean9 = numberAxis3D1.isVisible();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState((double) 2);
        axisState15.setCursor(0.2d);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        float float22 = dateAxis21.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer25);
        java.awt.Paint paint27 = xYPlot26.getRangeTickBandPaint();
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot26.setNoDataMessagePaint((java.awt.Paint) color28);
        xYPlot26.clearRangeAxes();
        xYPlot26.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot26.getRangeAxisLocation((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot26.getRangeAxisEdge(15);
        axisState15.moveCursor((double) 100L, rectangleEdge36);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        try {
            org.jfree.chart.axis.AxisState axisState40 = numberAxis3D1.draw(graphics2D10, (double) 8, rectangle2D12, rectangle2D13, rectangleEdge36, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Shape shape4 = lineAndShapeRenderer0.getItemShape(6, 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = lineAndShapeRenderer0.getBaseURLGenerator();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator7 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        lineAndShapeRenderer0.setSeriesURLGenerator(0, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator7, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        ganttRenderer0.setIncompletePaint(paint3);
        double double6 = ganttRenderer0.getStartPercent();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.35d + "'", double6 == 0.35d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.calculateTopOutset((double) 0L);
        java.lang.String str5 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.0d) + "'", double2 == (-8.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str5.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        org.jfree.chart.JFreeChart jFreeChart8 = multiplePiePlot7.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart8.getLegend();
        boolean boolean10 = spreadsheetDate4.equals((java.lang.Object) jFreeChart8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean20 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate24.compare((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean28 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        int int33 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean35 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(jFreeChart8);
        org.junit.Assert.assertNull(legendTitle9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(255, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        int int31 = xYPlot7.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, year2);
        java.util.Date date5 = month4.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer15);
        java.awt.Paint paint17 = xYPlot16.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        xYPlot16.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot16.getDomainMarkers(layer26);
        boolean boolean28 = simpleTimePeriod8.equals((java.lang.Object) xYPlot16);
        java.awt.Paint paint29 = xYPlot16.getBackgroundPaint();
        boolean boolean30 = month4.equals((java.lang.Object) xYPlot16);
        org.jfree.data.time.Year year31 = month4.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(year31);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        areaRenderer0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.lang.Object obj7 = piePlot3D6.clone();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("hi!", font9, paint10);
        piePlot3D6.setLabelFont(font9);
        try {
            areaRenderer0.setSeriesItemLabelFont((int) (short) -1, font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot7.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot18.getPieChart();
        java.awt.Image image20 = jFreeChart19.getBackgroundImage();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot7.setAxisOffset(rectangleInsets22);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker26.setLabel("");
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot7.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker26, layer29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = valueMarker26.getLabelAnchor();
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray36 = null;
        float[] floatArray37 = color35.getColorComponents(floatArray36);
        float[] floatArray38 = java.awt.Color.RGBtoHSB(10, 2, 0, floatArray36);
        boolean boolean39 = valueMarker26.equals((java.lang.Object) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        valueMarker26.notifyListeners(markerChangeEvent40);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint9 = stackedAreaRenderer7.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer7.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedAreaRenderer7.getBaseItemLabelGenerator();
        double double13 = stackedAreaRenderer7.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer7.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis1.setAxisLinePaint(paint16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        float float22 = dateAxis21.getTickMarkOutsideLength();
        dateAxis21.setNegativeArrowVisible(false);
        float float25 = dateAxis21.getTickMarkInsideLength();
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange(date26, date27);
        dateAxis21.setRange((org.jfree.data.Range) dateRange28);
        numberAxis3D19.setRange((org.jfree.data.Range) dateRange28);
        dateAxis1.setRange((org.jfree.data.Range) dateRange28);
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis1.getStandardTickUnits();
        try {
            dateAxis1.setRangeWithMargins((double) 2958465, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2958465.0) <= upper (255.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        jFreeChart2.setBorderVisible(false);
        int int6 = jFreeChart2.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener20 = null;
        defaultIntervalCategoryDataset7.removeChangeListener(datasetChangeListener20);
        try {
            int int23 = defaultIntervalCategoryDataset7.getCategoryIndex((java.lang.Comparable) "ChartEntity: tooltip = {0}");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), 15, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("CategoryLabelWidthType.CATEGORY");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int2 = dateTickUnit1.getCount();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date5, date6);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date6, timeZone10);
        java.util.Date date12 = dateTickUnit1.addToDate(date3, timeZone10);
        try {
            org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) dateTickUnit1, (double) 5, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("XY Plot", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        float float9 = dateAxis8.getTickMarkOutsideLength();
        dateAxis8.setNegativeArrowVisible(false);
        float float12 = dateAxis8.getTickMarkInsideLength();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(date13, date14);
        dateAxis8.setRange((org.jfree.data.Range) dateRange15);
        numberAxis3D6.setRange((org.jfree.data.Range) dateRange15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange15);
        double double19 = rectangleConstraint18.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.chart.util.Size2D size2D21 = blockContainer0.arrange(graphics2D1, rectangleConstraint18);
        size2D21.setWidth((double) 7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(size2D21);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) '#');
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean4 = numberAxis3D3.getAutoRangeIncludesZero();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) boolean4);
        int int6 = multiplePiePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        java.awt.Shape shape8 = legendGraphic7.getLine();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = legendGraphic7.getFillPaintTransformer();
        legendGraphic7.setWidth((double) (byte) 0);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 8, (double) (short) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        float float34 = dateAxis33.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer37);
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = dateAxis33.dateToJava2D(date39, rectangle2D41, rectangleEdge42);
        int int44 = xYPlot7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        float float48 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer51);
        java.awt.Paint paint53 = xYPlot52.getRangeTickBandPaint();
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot52.setNoDataMessagePaint((java.awt.Paint) color54);
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot52.setOrientation(plotOrientation56);
        xYPlot7.setOrientation(plotOrientation56);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = xYPlot7.getDomainAxisEdge(9999);
        xYPlot7.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 2.0f + "'", float34 == 2.0f);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean11 = stackedAreaRenderer9.getSeriesVisibleInLegend(10);
        boolean boolean12 = stackedAreaRenderer9.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer9.getLegendItemURLGenerator();
        java.awt.Paint paint15 = stackedAreaRenderer9.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer1.setSeriesPaint(1, paint15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font20 = textTitle19.getFont();
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font20, paint21);
        stackedAreaRenderer1.setBaseItemLabelPaint(paint21, false);
        stackedAreaRenderer1.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = stackedAreaRenderer1.getSeriesToolTipGenerator(6);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot7.getFixedDomainAxisSpace();
        boolean boolean10 = xYPlot7.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer7);
        dateAxis6.setRangeWithMargins((double) 10L, (double) 100L);
        boolean boolean12 = gradientPaintTransformType0.equals((java.lang.Object) dateAxis6);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = xYPlot21.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        xYPlot21.setDrawingSupplier(drawingSupplier23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(axisLocation25, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = null;
        xYPlot21.notifyListeners(plotChangeEvent28);
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke31 = piePlot30.getBaseSectionOutlineStroke();
        java.awt.Color color32 = java.awt.Color.CYAN;
        piePlot30.setShadowPaint((java.awt.Paint) color32);
        java.awt.Color color35 = java.awt.Color.white;
        piePlot30.setSectionPaint((java.lang.Comparable) 12.0d, (java.awt.Paint) color35);
        xYPlot21.setRangeCrosshairPaint((java.awt.Paint) color35);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        float float40 = dateAxis39.getTickMarkOutsideLength();
        dateAxis39.setNegativeArrowVisible(false);
        float float43 = dateAxis39.getTickMarkInsideLength();
        java.util.Date date44 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange(date44, date45);
        dateAxis39.setRange((org.jfree.data.Range) dateRange46);
        double double48 = dateAxis39.getFixedAutoRange();
        boolean boolean50 = dateAxis39.isHiddenValue((-1L));
        java.awt.Color color54 = java.awt.Color.getHSBColor(100.0f, (float) (short) 1, (float) (short) 0);
        dateAxis39.setLabelPaint((java.awt.Paint) color54);
        xYPlot21.setRangeZeroBaselinePaint((java.awt.Paint) color54);
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean59 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge58);
        boolean boolean60 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge58);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge58);
        org.jfree.chart.axis.AxisSpace axisSpace62 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace63 = dateAxis6.reserveSpace(graphics2D13, (org.jfree.chart.plot.Plot) xYPlot21, rectangle2D57, rectangleEdge61, axisSpace62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 2.0f + "'", float40 == 2.0f);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean4 = numberAxis3D3.getAutoRangeIncludesZero();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) boolean4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        try {
            multiplePiePlot1.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        java.lang.Class class11 = null;
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange(date14, date15);
        org.jfree.data.gantt.Task task17 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date13, date14);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone18);
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.DateTick dateTick24 = new org.jfree.chart.axis.DateTick(date14, "", textAnchor21, textAnchor22, (double) 2);
        try {
            int int25 = defaultIntervalCategoryDataset7.getCategoryIndex((java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer2.getSeriesCreateEntities((int) (byte) -1);
        java.awt.Paint paint9 = lineAndShapeRenderer2.getItemOutlinePaint(8, 8);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = numberAxis3D3.getTickUnit();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer7);
        numberAxis3D3.setLabelAngle(100.0d);
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        float float34 = dateAxis33.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer37);
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = dateAxis33.dateToJava2D(date39, rectangle2D41, rectangleEdge42);
        int int44 = xYPlot7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        float float48 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer51);
        java.awt.Paint paint53 = xYPlot52.getRangeTickBandPaint();
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot52.setNoDataMessagePaint((java.awt.Paint) color54);
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot52.setOrientation(plotOrientation56);
        xYPlot7.setOrientation(plotOrientation56);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = xYPlot7.getDomainAxisEdge(9999);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot7.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 2.0f + "'", float34 == 2.0f);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot43.getRowRenderingOrder();
        int int46 = categoryPlot43.getDatasetCount();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Shape shape4 = lineAndShapeRenderer0.getItemShape(6, 1);
        boolean boolean5 = lineAndShapeRenderer0.getDrawOutlines();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        double double5 = dateAxis1.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        dateAxis7.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot11 = dateAxis7.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        double double19 = stackedAreaRenderer13.getItemLabelAnchorOffset();
        java.awt.Paint paint22 = stackedAreaRenderer13.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis7.setAxisLinePaint(paint22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        float float28 = dateAxis27.getTickMarkOutsideLength();
        dateAxis27.setNegativeArrowVisible(false);
        float float31 = dateAxis27.getTickMarkInsideLength();
        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange(date32, date33);
        dateAxis27.setRange((org.jfree.data.Range) dateRange34);
        numberAxis3D25.setRange((org.jfree.data.Range) dateRange34);
        dateAxis7.setRange((org.jfree.data.Range) dateRange34);
        boolean boolean38 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int40 = dateTickUnit39.getCount();
        dateAxis7.setTickUnit(dateTickUnit39, false, false);
        dateAxis1.setTickUnit(dateTickUnit39);
        boolean boolean46 = dateAxis1.isHiddenValue((long) 128);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean9 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int16 = spreadsheetDate11.getDayOfWeek();
        defaultKeyedValues0.insertValue(0, (java.lang.Comparable) spreadsheetDate11, (java.lang.Number) 100L);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Stroke stroke23 = stackedBarRenderer3D21.lookupSeriesStroke((int) 'a');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint27 = stackedAreaRenderer25.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer25.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer25.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = stackedAreaRenderer25.getLegendItemToolTipGenerator();
        stackedAreaRenderer25.setSeriesCreateEntities(2, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator36 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (byte) 10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator36);
        stackedBarRenderer3D21.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator36);
        boolean boolean39 = spreadsheetDate11.equals((java.lang.Object) standardCategoryToolTipGenerator36);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator31);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot43.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        int int47 = categoryPlot43.getDomainAxisIndex(categoryAxis46);
        java.lang.String str48 = categoryPlot43.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot43.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker50, layer51);
        categoryPlot43.clearRangeMarkers();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Category Plot" + "'", str48.equals("Category Plot"));
        org.junit.Assert.assertNotNull(layer51);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Graphics2D graphics2D1 = null;
        java.lang.Class class4 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(date7, date8);
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date6, date7);
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date7, timeZone11);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.DateTick dateTick17 = new org.jfree.chart.axis.DateTick(date7, "", textAnchor14, textAnchor15, (double) 2);
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Friday", graphics2D1, (float) 7, 1.0f, textAnchor15, (double) 1L, textAnchor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        multiplePiePlot1.setDataset(categoryDataset3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D10.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D10.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint16 = stackedBarRenderer3D10.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D7.setBaseOutlinePaint(paint16);
        boolean boolean18 = multiplePiePlot1.equals((java.lang.Object) paint16);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot1.getPieChart();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNotNull(legendItemCollection20);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, valueAxis9, xYItemRenderer10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        dateAxis13.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot17 = dateAxis13.getPlot();
        double double18 = dateAxis13.getUpperBound();
        java.awt.Shape shape19 = dateAxis13.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape19, "{0}");
        dateAxis6.setRightArrow(shape19);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        org.jfree.data.general.DatasetGroup datasetGroup20 = defaultIntervalCategoryDataset7.getGroup();
        java.lang.String[] strArray21 = org.jfree.data.time.SerialDate.getMonths();
        try {
            defaultIntervalCategoryDataset7.setSeriesKeys((java.lang.Comparable[]) strArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(datasetGroup20);
        org.junit.Assert.assertNotNull(strArray21);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot7.addChangeListener(plotChangeListener27);
        java.awt.Paint paint29 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot7.setRangeTickBandPaint(paint29);
        java.awt.Paint paint31 = xYPlot7.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getNoDataMessage();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        ringPlot0.setDataset(pieDataset3);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
        java.lang.Comparable comparable2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str4 = ringPlot3.getNoDataMessage();
        java.awt.Paint paint5 = ringPlot3.getBaseSectionOutlinePaint();
        ringPlot3.setShadowXOffset((double) 4);
        boolean boolean8 = ringPlot3.getIgnoreNullValues();
        java.awt.Font font9 = ringPlot3.getNoDataMessageFont();
        try {
            categoryAxis3D0.setTickLabelFont(comparable2, font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        double double8 = stackedBarRenderer3D2.getXOffset();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray7 = null;
        float[] floatArray8 = color6.getColorComponents(floatArray7);
        float[] floatArray9 = java.awt.Color.RGBtoHSB(10, 2, 0, floatArray7);
        float[] floatArray10 = color2.getRGBColorComponents(floatArray9);
        try {
            float[] floatArray11 = color0.getColorComponents(colorSpace1, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        boolean boolean4 = org.jfree.chart.util.ShapeUtilities.equal(shape1, shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) 255, 90.0d);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = textAnchor9.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean16 = rectangleAnchor5.equals((java.lang.Object) boolean15);
        try {
            java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        org.jfree.data.gantt.TaskSeries taskSeries4 = new org.jfree.data.gantt.TaskSeries("{0}");
        java.util.List list5 = taskSeries4.getTasks();
        projectInfo0.setContributors(list5);
        projectInfo0.setVersion("GradientPaintTransformType.HORIZONTAL");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, paint3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint12 = stackedAreaRenderer10.getSeriesItemLabelPaint(100);
        stackedAreaRenderer10.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer10.setSeriesStroke(100, stroke16);
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) 100.0f, stroke16);
        piePlot5.setIgnoreNullValues(false);
        piePlot5.setLabelGap(0.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        try {
            java.lang.Number number22 = defaultIntervalCategoryDataset7.getValue((int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        dateAxis1.setLowerBound(8.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D5.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Stroke stroke12 = stackedBarRenderer3D10.lookupSeriesStroke((int) 'a');
        stackedBarRenderer3D5.setBaseOutlineStroke(stroke12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker(1.560181216381E12d, (double) 0.0f, paint2, stroke12, (java.awt.Paint) color14, stroke15, (float) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedAreaRenderer1.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        stackedAreaRenderer1.setSeriesPaint(2, paint12);
        org.jfree.chart.block.BorderArrangement borderArrangement14 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D16.setVisible(false);
        org.jfree.chart.plot.Plot plot19 = numberAxis3D16.getPlot();
        java.awt.Shape shape20 = numberAxis3D16.getLeftArrow();
        boolean boolean21 = borderArrangement14.equals((java.lang.Object) shape20);
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, (double) 15, (double) 10);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer1, (org.jfree.chart.block.Arrangement) borderArrangement14, (org.jfree.chart.block.Arrangement) columnArrangement27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D30.setVisible(false);
        org.jfree.chart.plot.Plot plot33 = numberAxis3D30.getPlot();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer34 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint36 = boxAndWhiskerRenderer34.lookupSeriesFillPaint(1);
        numberAxis3D30.setAxisLinePaint(paint36);
        double double38 = numberAxis3D30.getLowerBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D44.setVisible(false);
        java.awt.Font font48 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment49 = new org.jfree.chart.text.TextFragment("cyan", font48);
        numberAxis3D44.setTickLabelFont(font48);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D30, (double) (byte) 1, (double) (-1), (double) 1, (double) 100.0f, font48);
        legendTitle28.setItemFont(font48);
        java.awt.Color color53 = java.awt.Color.BLUE;
        legendTitle28.setBackgroundPaint((java.awt.Paint) color53);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getBarWidth();
        double double3 = categoryItemRendererState1.getBarWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = xYPlot9.getRangeTickBandPaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint14 = stackedAreaRenderer12.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = stackedAreaRenderer12.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer12.getBaseItemLabelGenerator();
        double double18 = stackedAreaRenderer12.getItemLabelAnchorOffset();
        java.awt.Paint paint21 = stackedAreaRenderer12.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker24.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint30 = stackedAreaRenderer28.getSeriesItemLabelPaint(100);
        stackedAreaRenderer28.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer28.setSeriesStroke(100, stroke34);
        valueMarker24.setStroke(stroke34);
        stackedAreaRenderer12.setSeriesStroke(11, stroke34);
        xYPlot9.setRangeCrosshairStroke(stroke34);
        strokeList0.setStroke(31, stroke34);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean1 = boxAndWhiskerRenderer0.getFillBox();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint5 = stackedAreaRenderer3.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = stackedAreaRenderer3.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = stackedAreaRenderer3.getBaseItemLabelGenerator();
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        org.jfree.data.gantt.Task task14 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date10, date11);
        boolean boolean15 = stackedAreaRenderer3.equals((java.lang.Object) task14);
        org.jfree.chart.LegendItem legendItem18 = stackedAreaRenderer3.getLegendItem((int) '#', 0);
        java.awt.Paint paint20 = stackedAreaRenderer3.lookupSeriesOutlinePaint((int) '4');
        boxAndWhiskerRenderer0.setArtifactPaint(paint20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(legendItem18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer2.getSeriesShapesVisible((-1));
        boolean boolean7 = lineAndShapeRenderer2.getBaseCreateEntities();
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint9 = stackedAreaRenderer7.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = stackedAreaRenderer7.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedAreaRenderer7.getBaseItemLabelGenerator();
        double double13 = stackedAreaRenderer7.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer7.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis1.setAxisLinePaint(paint16);
        org.jfree.chart.plot.Plot plot18 = dateAxis1.getPlot();
        java.util.Date date19 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("EXPAND", graphics2D1, (-1.0f), (float) (byte) -1, (double) 2.0f, (float) (short) 100, (float) 1572591599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedAreaRenderer1.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 1, (java.lang.Boolean) false, true);
        java.awt.Color color13 = java.awt.Color.GRAY;
        try {
            stackedAreaRenderer1.setSeriesFillPaint((int) (short) -1, (java.awt.Paint) color13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot7.getDomainAxis(9);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        float float14 = dateAxis13.getTickMarkOutsideLength();
        dateAxis13.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot17 = dateAxis13.getPlot();
        double double18 = dateAxis13.getUpperBound();
        java.awt.Shape shape19 = dateAxis13.getDownArrow();
        dateAxis13.setLabelURL("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        double double22 = dateAxis13.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        float float25 = dateAxis24.getTickMarkOutsideLength();
        dateAxis24.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot28 = dateAxis24.getPlot();
        double double29 = dateAxis24.getUpperBound();
        java.awt.Shape shape30 = dateAxis24.getDownArrow();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean32 = org.jfree.chart.util.ShapeUtilities.equal(shape30, shape31);
        dateAxis13.setUpArrow(shape31);
        xYPlot7.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getNoDataMessage();
        java.awt.Paint paint2 = ringPlot0.getBaseSectionOutlinePaint();
        ringPlot0.setShadowXOffset((double) 4);
        boolean boolean5 = ringPlot0.getIgnoreNullValues();
        double double6 = ringPlot0.getSectionDepth();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean8 = ringPlot0.equals((java.lang.Object) lengthAdjustmentType7);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis3D1.getTickUnit();
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = textAnchor0.equals((java.lang.Object) spreadsheetDate4);
        java.lang.String str7 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str7.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        java.lang.Object obj3 = numberAxis3D1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font4 = textTitle3.getFont();
        java.awt.Paint paint5 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font4, paint5);
        textBlock0.addLine(textLine6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            textLine6.draw(graphics2D8, (float) (short) 1, (float) 31, textAnchor11, (float) 7, (float) 31, (double) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker1.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint7 = stackedAreaRenderer5.getSeriesItemLabelPaint(100);
        stackedAreaRenderer5.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer5.setSeriesStroke(100, stroke11);
        valueMarker1.setStroke(stroke11);
        java.awt.Stroke stroke14 = valueMarker1.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(5.0d, (double) 4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font6, (org.jfree.chart.plot.Plot) piePlot9, false);
        stackedBarRenderer3D2.setSeriesItemLabelFont((int) '4', font6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        java.lang.Boolean boolean15 = stackedBarRenderer3D2.getSeriesItemLabelsVisible((int) (byte) 10);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        xYPlot7.notifyListeners(plotChangeEvent14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke17 = piePlot16.getBaseSectionOutlineStroke();
        java.awt.Color color18 = java.awt.Color.CYAN;
        piePlot16.setShadowPaint((java.awt.Paint) color18);
        java.awt.Color color21 = java.awt.Color.white;
        piePlot16.setSectionPaint((java.lang.Comparable) 12.0d, (java.awt.Paint) color21);
        xYPlot7.setRangeCrosshairPaint((java.awt.Paint) color21);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        float float26 = dateAxis25.getTickMarkOutsideLength();
        dateAxis25.setNegativeArrowVisible(false);
        float float29 = dateAxis25.getTickMarkInsideLength();
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date31 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange(date30, date31);
        dateAxis25.setRange((org.jfree.data.Range) dateRange32);
        double double34 = dateAxis25.getFixedAutoRange();
        boolean boolean36 = dateAxis25.isHiddenValue((-1L));
        java.awt.Color color40 = java.awt.Color.getHSBColor(100.0f, (float) (short) 1, (float) (short) 0);
        dateAxis25.setLabelPaint((java.awt.Paint) color40);
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) color40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = xYPlot7.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        double double5 = stackedBarRenderer3D2.getMinimumBarLength();
        double double6 = stackedBarRenderer3D2.getMinimumBarLength();
        double double7 = stackedBarRenderer3D2.getMaximumBarWidth();
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray11, doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        float float18 = dateAxis17.getTickMarkOutsideLength();
        dateAxis17.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot21 = dateAxis17.getPlot();
        double double22 = dateAxis17.getUpperBound();
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint27 = stackedAreaRenderer25.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer25.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer25.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean35 = stackedAreaRenderer33.getSeriesVisibleInLegend(10);
        boolean boolean36 = stackedAreaRenderer33.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedAreaRenderer33.getLegendItemURLGenerator();
        java.awt.Paint paint39 = stackedAreaRenderer33.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer25.setSeriesPaint(1, paint39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font44 = textTitle43.getFont();
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("", font44, paint45);
        stackedAreaRenderer25.setBaseItemLabelPaint(paint45, false);
        stackedAreaRenderer25.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer25);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("");
        float float54 = dateAxis53.getTickMarkOutsideLength();
        org.jfree.data.Range range55 = categoryPlot51.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis53);
        stackedBarRenderer3D2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot51);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("");
        float float60 = dateAxis59.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) dateAxis59, (org.jfree.chart.axis.ValueAxis) dateAxis62, xYItemRenderer63);
        java.awt.Paint paint65 = xYPlot64.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier66 = null;
        xYPlot64.setDrawingSupplier(drawingSupplier66);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder68 = xYPlot64.getDatasetRenderingOrder();
        categoryPlot51.setDatasetRenderingOrder(datasetRenderingOrder68);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder70 = categoryPlot51.getDatasetRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder71 = categoryPlot51.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 2.0f + "'", float54 == 2.0f);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 2.0f + "'", float60 == 2.0f);
        org.junit.Assert.assertNull(paint65);
        org.junit.Assert.assertNotNull(datasetRenderingOrder68);
        org.junit.Assert.assertNotNull(datasetRenderingOrder70);
        org.junit.Assert.assertNotNull(datasetRenderingOrder71);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Locale locale1 = dataPackageResources0.getLocale();
        java.util.Set<java.lang.String> strSet2 = dataPackageResources0.keySet();
        boolean boolean4 = dataPackageResources0.containsKey("ThreadContext");
        java.util.Enumeration<java.lang.String> strEnumeration5 = dataPackageResources0.getKeys();
        java.util.Locale locale6 = dataPackageResources0.getLocale();
        java.lang.Object[][] objArray7 = dataPackageResources0.getContents();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strEnumeration5);
        org.junit.Assert.assertNull(locale6);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        labelBlock3.setToolTipText("hi!");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = xYPlot21.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        xYPlot21.setDrawingSupplier(drawingSupplier23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(axisLocation25, false);
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = labelBlock3.equals((java.lang.Object) xYPlot21);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot21.getDomainAxis();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(valueAxis30);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = stackedAreaRenderer1.getBaseFillPaint();
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible(31);
        int int5 = lineAndShapeRenderer2.getPassCount();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (short) -1, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.calculateTopOutset((double) 0L);
        java.lang.String str5 = rectangleInsets0.toString();
        double double7 = rectangleInsets0.calculateRightOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.0d) + "'", double2 == (-8.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str5.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        java.awt.Shape shape3 = null;
        try {
            stackedBarRenderer3D2.setBaseShape(shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean4 = numberAxis3D3.getAutoRangeIncludesZero();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) boolean4);
        multiplePiePlot1.setLimit(2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        dateAxis2.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot6 = dateAxis2.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint10 = stackedAreaRenderer8.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedAreaRenderer8.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedAreaRenderer8.getBaseItemLabelGenerator();
        double double14 = stackedAreaRenderer8.getItemLabelAnchorOffset();
        java.awt.Paint paint17 = stackedAreaRenderer8.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis2.setAxisLinePaint(paint17);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        float float23 = dateAxis22.getTickMarkOutsideLength();
        dateAxis22.setNegativeArrowVisible(false);
        float float26 = dateAxis22.getTickMarkInsideLength();
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange(date27, date28);
        dateAxis22.setRange((org.jfree.data.Range) dateRange29);
        numberAxis3D20.setRange((org.jfree.data.Range) dateRange29);
        dateAxis2.setRange((org.jfree.data.Range) dateRange29);
        boolean boolean33 = defaultKeyedValues0.equals((java.lang.Object) dateRange29);
        java.lang.Comparable comparable34 = null;
        try {
            defaultKeyedValues0.setValue(comparable34, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8);
        double double10 = dateAxis1.getFixedAutoRange();
        boolean boolean12 = dateAxis1.isHiddenValue((-1L));
        dateAxis1.setLabel("{0}");
        dateAxis1.configure();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int17 = dateTickUnit16.getCount();
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date21, timeZone25);
        java.util.Date date27 = dateTickUnit16.addToDate(date18, timeZone25);
        dateAxis1.setTimeZone(timeZone25);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("cyan", font2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D9.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = stackedBarRenderer3D9.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint15 = stackedBarRenderer3D9.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D6.setBaseOutlinePaint(paint15);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("{0}", font2, paint15, (float) 2);
        java.awt.Paint paint19 = textFragment18.getPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean22 = textFragment18.equals((java.lang.Object) "{0}");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Shape shape5 = stackedBarRenderer3D2.getItemShape((-1), 15);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemURLGenerator();
        stackedAreaRenderer1.setBaseCreateEntities(true, true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        org.jfree.data.general.DatasetGroup datasetGroup20 = defaultIntervalCategoryDataset7.getGroup();
        try {
            java.lang.Number number23 = defaultIntervalCategoryDataset7.getEndValue((java.lang.Comparable) "cyan", (java.lang.Comparable) "HorizontalAlignment.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(datasetGroup20);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str2 = ringPlot1.getNoDataMessage();
        java.awt.Paint paint3 = ringPlot1.getBaseSectionOutlinePaint();
        ringPlot1.setShadowXOffset((double) 4);
        boolean boolean6 = ringPlot1.getIgnoreNullValues();
        java.awt.Font font7 = ringPlot1.getNoDataMessageFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer11 = new org.jfree.chart.text.G2TextMeasurer(graphics2D10);
        try {
            org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color8, (float) 3, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot43.getLegendItems();
        int int45 = legendItemCollection44.getItemCount();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries1.removeAll();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener3);
        java.lang.Comparable comparable5 = taskSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "{0}" + "'", comparable5.equals("{0}"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = lineAndShapeRenderer0.getToolTipGenerator(9, 9);
        boolean boolean11 = lineAndShapeRenderer0.equals((java.lang.Object) "({0}, {1}) = {2}");
        boolean boolean12 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = stackedBarRenderer3D2.getItemLabelPaint((int) (byte) -1, 9999);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        stackedBarRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator9, true);
        stackedBarRenderer3D2.setSeriesCreateEntities(100, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        xYPlot7.mapDatasetToDomainAxis((int) (byte) 100, 15);
        java.awt.Font font19 = xYPlot7.getNoDataMessageFont();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        float float24 = dateAxis23.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer27);
        java.awt.Paint paint29 = xYPlot28.getRangeTickBandPaint();
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot28.setNoDataMessagePaint((java.awt.Paint) color30);
        xYPlot28.clearRangeAxes();
        xYPlot28.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot28.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup37 = xYPlot28.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot39 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset38);
        org.jfree.chart.JFreeChart jFreeChart40 = multiplePiePlot39.getPieChart();
        java.awt.Image image41 = jFreeChart40.getBackgroundImage();
        xYPlot28.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart40);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot28.setAxisOffset(rectangleInsets43);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer46 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint48 = stackedAreaRenderer46.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator50 = stackedAreaRenderer46.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator51 = stackedAreaRenderer46.getBaseItemLabelGenerator();
        double double52 = stackedAreaRenderer46.getItemLabelAnchorOffset();
        java.awt.Paint paint55 = stackedAreaRenderer46.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker58.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer62 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint64 = stackedAreaRenderer62.getSeriesItemLabelPaint(100);
        stackedAreaRenderer62.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke68 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer62.setSeriesStroke(100, stroke68);
        valueMarker58.setStroke(stroke68);
        stackedAreaRenderer46.setSeriesStroke(11, stroke68);
        xYPlot28.setDomainGridlineStroke(stroke68);
        org.jfree.data.xy.XYDataset xYDataset74 = null;
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis("");
        float float77 = dateAxis76.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset74, (org.jfree.chart.axis.ValueAxis) dateAxis76, (org.jfree.chart.axis.ValueAxis) dateAxis79, xYItemRenderer80);
        java.awt.Paint paint82 = xYPlot81.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis("");
        float float86 = dateAxis85.getTickMarkOutsideLength();
        dateAxis85.setNegativeArrowVisible(false);
        float float89 = dateAxis85.getTickMarkInsideLength();
        xYPlot81.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis85);
        org.jfree.chart.util.Layer layer91 = null;
        java.util.Collection collection92 = xYPlot81.getDomainMarkers(layer91);
        org.jfree.chart.axis.AxisLocation axisLocation93 = xYPlot81.getDomainAxisLocation();
        xYPlot28.setDomainAxisLocation(3, axisLocation93, true);
        try {
            xYPlot7.setDomainAxisLocation((int) (short) -1, axisLocation93);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNull(datasetGroup37);
        org.junit.Assert.assertNotNull(jFreeChart40);
        org.junit.Assert.assertNull(image41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNull(categoryItemLabelGenerator50);
        org.junit.Assert.assertNull(categoryItemLabelGenerator51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 2.0d + "'", double52 == 2.0d);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNull(paint64);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 2.0f + "'", float77 == 2.0f);
        org.junit.Assert.assertNull(paint82);
        org.junit.Assert.assertTrue("'" + float86 + "' != '" + 2.0f + "'", float86 == 2.0f);
        org.junit.Assert.assertTrue("'" + float89 + "' != '" + 0.0f + "'", float89 == 0.0f);
        org.junit.Assert.assertNull(collection92);
        org.junit.Assert.assertNotNull(axisLocation93);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        java.awt.Shape shape8 = legendGraphic7.getLine();
        java.awt.Stroke stroke9 = legendGraphic7.getLineStroke();
        java.awt.Shape shape10 = legendGraphic7.getLine();
        java.awt.Paint paint11 = legendGraphic7.getLinePaint();
        java.awt.Paint paint12 = legendGraphic7.getFillPaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        double double3 = numberAxis3D1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        boolean boolean3 = org.jfree.chart.util.ShapeUtilities.equal(shape0, shape2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor4, (double) 255, 90.0d);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity(shape2, "Last", "Last");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener20 = null;
        defaultIntervalCategoryDataset7.removeChangeListener(datasetChangeListener20);
        java.lang.Comparable comparable22 = null;
        try {
            int int23 = defaultIntervalCategoryDataset7.getRowIndex(comparable22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.dateToJava2D(date8, rectangle2D10, rectangleEdge11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis2);
        org.jfree.chart.block.BorderArrangement borderArrangement14 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D16.setVisible(false);
        org.jfree.chart.plot.Plot plot19 = numberAxis3D16.getPlot();
        java.awt.Shape shape20 = numberAxis3D16.getLeftArrow();
        boolean boolean21 = borderArrangement14.equals((java.lang.Object) shape20);
        dateAxis2.setRightArrow(shape20);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        float float30 = dateAxis29.getTickMarkOutsideLength();
        dateAxis29.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot33 = dateAxis29.getPlot();
        double double34 = dateAxis29.getUpperBound();
        java.awt.Shape shape35 = dateAxis29.getDownArrow();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean37 = org.jfree.chart.util.ShapeUtilities.equal(shape35, shape36);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        float float40 = dateAxis39.getTickMarkOutsideLength();
        dateAxis39.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot43 = dateAxis39.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer45 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint47 = stackedAreaRenderer45.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator49 = stackedAreaRenderer45.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator50 = stackedAreaRenderer45.getBaseItemLabelGenerator();
        double double51 = stackedAreaRenderer45.getItemLabelAnchorOffset();
        java.awt.Paint paint54 = stackedAreaRenderer45.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis39.setAxisLinePaint(paint54);
        org.jfree.chart.title.LegendGraphic legendGraphic56 = new org.jfree.chart.title.LegendGraphic(shape35, paint54);
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font61 = textTitle60.getFont();
        java.awt.Paint paint62 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine63 = new org.jfree.chart.text.TextLine("", font61, paint62);
        java.awt.Paint paint65 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Font font68 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine70 = new org.jfree.chart.text.TextLine("", font68, paint69);
        org.jfree.chart.plot.PiePlot piePlot71 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart73 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font68, (org.jfree.chart.plot.Plot) piePlot71, false);
        java.awt.Stroke stroke74 = jFreeChart73.getBorderStroke();
        java.awt.Shape shape76 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D80 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D80.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition83 = stackedBarRenderer3D80.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint86 = stackedBarRenderer3D80.getItemLabelPaint((int) (byte) -1, 9999);
        org.jfree.chart.LegendItem legendItem87 = new org.jfree.chart.LegendItem("", "Category Plot", "Nearest", "CategoryLabelWidthType.CATEGORY", false, shape35, true, paint62, true, paint65, stroke74, true, shape76, stroke77, paint86);
        dateAxis2.setTickMarkStroke(stroke74);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 2.0f + "'", float40 == 2.0f);
        org.junit.Assert.assertNull(plot43);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNull(categoryItemLabelGenerator49);
        org.junit.Assert.assertNull(categoryItemLabelGenerator50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 2.0d + "'", double51 == 2.0d);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNull(itemLabelPosition83);
        org.junit.Assert.assertNotNull(paint86);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        java.lang.String str45 = categoryAnchor44.toString();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str45.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
        double double4 = rectangleInsets0.extendWidth((-1.0d));
        double double5 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer7);
        java.awt.Paint paint9 = xYPlot8.getRangeTickBandPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot8.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean13 = xYPlot8.equals((java.lang.Object) itemLabelAnchor12);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke15 = piePlot14.getBaseSectionOutlineStroke();
        java.awt.Color color16 = java.awt.Color.CYAN;
        piePlot14.setShadowPaint((java.awt.Paint) color16);
        java.lang.String str18 = org.jfree.chart.util.PaintUtilities.colorToString(color16);
        xYPlot8.setOutlinePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot8.getDomainAxisEdge((int) (short) 1);
        boolean boolean22 = defaultCategoryDataset0.equals((java.lang.Object) rectangleEdge21);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "cyan" + "'", str18.equals("cyan"));
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) 1, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = lineAndShapeRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = lineAndShapeRenderer0.getPlot();
        int int6 = lineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(categoryPlot5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray5, doubleArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot15 = dateAxis11.getPlot();
        double double16 = dateAxis11.getUpperBound();
        java.awt.Shape shape17 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint21 = stackedAreaRenderer19.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedAreaRenderer19.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = stackedAreaRenderer19.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer27 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean29 = stackedAreaRenderer27.getSeriesVisibleInLegend(10);
        boolean boolean30 = stackedAreaRenderer27.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = stackedAreaRenderer27.getLegendItemURLGenerator();
        java.awt.Paint paint33 = stackedAreaRenderer27.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer19.setSeriesPaint(1, paint33);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font38 = textTitle37.getFont();
        java.awt.Paint paint39 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine("", font38, paint39);
        stackedAreaRenderer19.setBaseItemLabelPaint(paint39, false);
        stackedAreaRenderer19.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer19);
        categoryPlot45.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj48 = categoryAxis3D47.clone();
        float float49 = categoryAxis3D47.getMaximumCategoryLabelWidthRatio();
        int int50 = categoryPlot45.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray51 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D47 };
        categoryPlot0.setDomainAxes(categoryAxisArray51);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(categoryAxisArray51);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean3 = stackedAreaRenderer1.getSeriesVisibleInLegend(10);
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedAreaRenderer1.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedAreaRenderer1.lookupSeriesFillPaint((int) ' ');
        java.awt.Paint paint8 = stackedAreaRenderer1.getBaseOutlinePaint();
        stackedAreaRenderer1.setRenderAsPercentages(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer14.setBaseLinesVisible(true);
        java.lang.Boolean boolean18 = lineAndShapeRenderer14.getSeriesCreateEntities((int) (byte) -1);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.Object obj21 = standardCategoryToolTipGenerator20.clone();
        lineAndShapeRenderer14.setSeriesToolTipGenerator((int) (byte) 0, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20);
        java.lang.String str23 = standardCategoryToolTipGenerator20.getLabelFormat();
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "({0}, {1}) = {2}" + "'", str23.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font13, paint14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font13, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint23 = stackedAreaRenderer21.getSeriesItemLabelPaint(100);
        stackedAreaRenderer21.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer21.setSeriesStroke(100, stroke27);
        piePlot16.setSectionOutlineStroke((java.lang.Comparable) 100.0f, stroke27);
        xYPlot7.setRangeZeroBaselineStroke(stroke27);
        java.awt.Paint paint31 = xYPlot7.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        boolean boolean9 = xYPlot7.isOutlineVisible();
        java.lang.String str10 = xYPlot7.getPlotType();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot7.getOrientation();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int14 = dateTickUnit13.getCount();
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(date15, date16);
        java.util.Date date18 = dateTickUnit13.rollDate(date15);
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange(date11, date15);
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange(date22, date23);
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date21, date22);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date22, timeZone26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date15, timeZone26);
        defaultCategoryDataset9.addValue((java.lang.Number) 31, (java.lang.Comparable) month28, (java.lang.Comparable) 0.35d);
        legendItemEntity8.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        org.jfree.data.general.Dataset dataset32 = legendItemEntity8.getDataset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(dataset32);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        boolean boolean6 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("XY Plot");
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        float float48 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer51);
        java.util.Date date53 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = dateAxis47.dateToJava2D(date53, rectangle2D55, rectangleEdge56);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent58 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis47);
        categoryPlot43.axisChanged(axisChangeEvent58);
        java.lang.Object obj60 = axisChangeEvent58.getSource();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(obj60);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        labelBlock3.setToolTipText("hi!");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = xYPlot21.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        xYPlot21.setDrawingSupplier(drawingSupplier23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(axisLocation25, false);
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = labelBlock3.equals((java.lang.Object) xYPlot21);
        double double30 = xYPlot21.getRangeCrosshairValue();
        xYPlot21.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        java.lang.Object obj9 = labelBlock3.clone();
        java.awt.Paint paint10 = labelBlock3.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        double double6 = categoryItemRendererState5.getBarWidth();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray11, doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        float float18 = dateAxis17.getTickMarkOutsideLength();
        dateAxis17.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot21 = dateAxis17.getPlot();
        double double22 = dateAxis17.getUpperBound();
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint27 = stackedAreaRenderer25.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer25.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer25.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean35 = stackedAreaRenderer33.getSeriesVisibleInLegend(10);
        boolean boolean36 = stackedAreaRenderer33.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedAreaRenderer33.getLegendItemURLGenerator();
        java.awt.Paint paint39 = stackedAreaRenderer33.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer25.setSeriesPaint(1, paint39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font44 = textTitle43.getFont();
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("", font44, paint45);
        stackedAreaRenderer25.setBaseItemLabelPaint(paint45, false);
        stackedAreaRenderer25.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer25);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor52 = categoryPlot51.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot51.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        int int55 = categoryPlot51.getDomainAxisIndex(categoryAxis54);
        java.lang.String str56 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot51.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker58, layer59);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D61 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj62 = categoryAxis3D61.clone();
        float float63 = categoryAxis3D61.getMaximumCategoryLabelWidthRatio();
        categoryAxis3D61.setMaximumCategoryLabelLines((int) '#');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D67 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D67.setVisible(false);
        org.jfree.chart.plot.Plot plot70 = numberAxis3D67.getPlot();
        java.awt.Shape shape71 = numberAxis3D67.getLeftArrow();
        java.awt.Shape shape73 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 86400000L);
        numberAxis3D67.setRightArrow(shape73);
        double[] doubleArray77 = new double[] {};
        double[] doubleArray78 = new double[] {};
        double[] doubleArray79 = new double[] {};
        double[][] doubleArray80 = new double[][] { doubleArray77, doubleArray78, doubleArray79 };
        org.jfree.data.category.CategoryDataset categoryDataset81 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray80);
        try {
            lineAndShapeRenderer2.drawItem(graphics2D3, categoryItemRendererState5, rectangle2D7, categoryPlot51, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D61, (org.jfree.chart.axis.ValueAxis) numberAxis3D67, categoryDataset81, 6, 9, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(categoryAnchor52);
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Category Plot" + "'", str56.equals("Category Plot"));
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 0.0f + "'", float63 == 0.0f);
        org.junit.Assert.assertNull(plot70);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(categoryDataset81);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        java.lang.Boolean boolean9 = stackedAreaRenderer1.getSeriesItemLabelsVisible((-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedAreaRenderer1.getSeriesPositiveItemLabelPosition(7);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("1.0.6");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.configure();
        boolean boolean4 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) categoryAxis3D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer10);
        org.jfree.data.Range range12 = dateAxis6.getRange();
        dateAxis2.setRange(range12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean16 = numberAxis3D15.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer17);
        java.text.NumberFormat numberFormat19 = numberAxis3D15.getNumberFormatOverride();
        java.awt.Font font24 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D15, (double) 128, (double) 31, 1.0d, 90.0d, font24);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(numberFormat19);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot7.getAxisOffset();
        java.lang.String str9 = rectangleInsets8.toString();
        double double11 = rectangleInsets8.calculateRightOutset((double) 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
//        float float4 = dateAxis3.getTickMarkOutsideLength();
//        dateAxis3.setNegativeArrowVisible(false);
//        float float7 = dateAxis3.getTickMarkInsideLength();
//        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(date8, date9);
//        dateAxis3.setRange((org.jfree.data.Range) dateRange10);
//        numberAxis3D1.setRange((org.jfree.data.Range) dateRange10);
//        org.jfree.data.xy.XYDataset xYDataset13 = null;
//        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
//        float float16 = dateAxis15.getTickMarkOutsideLength();
//        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
//        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer19);
//        org.jfree.data.Range range21 = dateAxis15.getRange();
//        org.jfree.data.Range range22 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange10, range21);
//        java.lang.String str23 = dateRange10.toString();
//        org.jfree.data.Range range26 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange10, (double) (byte) 1, false);
//        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
//        org.junit.Assert.assertNotNull(range21);
//        org.junit.Assert.assertNotNull(range22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[Jun 10, 2019 8:40:16 AM --> Jun 10, 2019 8:40:16 AM]" + "'", str23.equals("[Jun 10, 2019 8:40:16 AM --> Jun 10, 2019 8:40:16 AM]"));
//        org.junit.Assert.assertNotNull(range26);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        categoryPlot43.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj46 = categoryAxis3D45.clone();
        float float47 = categoryAxis3D45.getMaximumCategoryLabelWidthRatio();
        int int48 = categoryPlot43.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D45);
        categoryAxis3D45.removeCategoryLabelToolTip((java.lang.Comparable) 0.4d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.String str2 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str2.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.dateToJava2D(date8, rectangle2D10, rectangleEdge11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis2);
        boolean boolean14 = dateAxis2.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        int int7 = jFreeChart2.getBackgroundImageAlignment();
        float float8 = jFreeChart2.getBackgroundImageAlpha();
        boolean boolean10 = jFreeChart2.equals((java.lang.Object) 9999);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean15 = numberAxis3D14.getAutoRangeIncludesZero();
        boolean boolean16 = multiplePiePlot12.equals((java.lang.Object) boolean15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        multiplePiePlot12.setDrawingSupplier(drawingSupplier17);
        multiplePiePlot12.setAggregatedItemsKey((java.lang.Comparable) 100.0d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot12);
        jFreeChart2.plotChanged(plotChangeEvent21);
        org.jfree.chart.plot.Plot plot23 = jFreeChart2.getPlot();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset24);
        org.jfree.chart.JFreeChart jFreeChart26 = multiplePiePlot25.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle27 = jFreeChart26.getLegend();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        jFreeChart26.addSubtitle((org.jfree.chart.title.Title) textTitle29);
        boolean boolean31 = textTitle29.getExpandToFitSpace();
        double double32 = textTitle29.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double35 = rectangleInsets33.calculateLeftInset((double) 11);
        textTitle29.setPadding(rectangleInsets33);
        jFreeChart2.removeSubtitle((org.jfree.chart.title.Title) textTitle29);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(plot23);
        org.junit.Assert.assertNotNull(jFreeChart26);
        org.junit.Assert.assertNull(legendTitle27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 8.0d + "'", double35 == 8.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        defaultIntervalCategoryDataset15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D17);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener20 = null;
        defaultIntervalCategoryDataset7.removeChangeListener(datasetChangeListener20);
        int int22 = defaultIntervalCategoryDataset7.getCategoryCount();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer0.getArrangement();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, paint5);
        labelBlock6.setToolTipText("{0}");
        labelBlock6.setToolTipText("hi!");
        java.lang.String str11 = labelBlock6.getToolTipText();
        labelBlock6.setToolTipText("hi!");
        java.lang.Object obj14 = labelBlock6.clone();
        blockContainer0.add((org.jfree.chart.block.Block) labelBlock6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        int int7 = jFreeChart2.getBackgroundImageAlignment();
        float float8 = jFreeChart2.getBackgroundImageAlpha();
        boolean boolean10 = jFreeChart2.equals((java.lang.Object) 9999);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean15 = numberAxis3D14.getAutoRangeIncludesZero();
        boolean boolean16 = multiplePiePlot12.equals((java.lang.Object) boolean15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        multiplePiePlot12.setDrawingSupplier(drawingSupplier17);
        multiplePiePlot12.setAggregatedItemsKey((java.lang.Comparable) 100.0d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot12);
        jFreeChart2.plotChanged(plotChangeEvent21);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = plotChangeEvent21.getType();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        xYPlot7.setBackgroundAlpha((float) 1L);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        xYPlot7.datasetChanged(datasetChangeEvent13);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot7.getDomainAxisForDataset(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8);
        java.util.Date date10 = dateAxis1.getMinimumDate();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart13 = multiplePiePlot12.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        jFreeChart13.addSubtitle((org.jfree.chart.title.Title) textTitle16);
        boolean boolean18 = textTitle16.getExpandToFitSpace();
        double double19 = textTitle16.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets20.calculateLeftInset((double) 11);
        textTitle16.setPadding(rectangleInsets20);
        dateAxis1.setTickLabelInsets(rectangleInsets20);
        double double26 = rectangleInsets20.calculateBottomOutset((double) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        java.awt.Color color2 = java.awt.Color.CYAN;
        piePlot0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) 0);
        double double6 = piePlot0.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedAreaRenderer1.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        stackedAreaRenderer1.setSeriesPaint(2, paint12);
        org.jfree.chart.block.BorderArrangement borderArrangement14 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D16.setVisible(false);
        org.jfree.chart.plot.Plot plot19 = numberAxis3D16.getPlot();
        java.awt.Shape shape20 = numberAxis3D16.getLeftArrow();
        boolean boolean21 = borderArrangement14.equals((java.lang.Object) shape20);
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, (double) 15, (double) 10);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer1, (org.jfree.chart.block.Arrangement) borderArrangement14, (org.jfree.chart.block.Arrangement) columnArrangement27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D30.setVisible(false);
        org.jfree.chart.plot.Plot plot33 = numberAxis3D30.getPlot();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer34 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint36 = boxAndWhiskerRenderer34.lookupSeriesFillPaint(1);
        numberAxis3D30.setAxisLinePaint(paint36);
        double double38 = numberAxis3D30.getLowerBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D44.setVisible(false);
        java.awt.Font font48 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment49 = new org.jfree.chart.text.TextFragment("cyan", font48);
        numberAxis3D44.setTickLabelFont(font48);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D30, (double) (byte) 1, (double) (-1), (double) 1, (double) 100.0f, font48);
        legendTitle28.setItemFont(font48);
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot54 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset53);
        org.jfree.chart.JFreeChart jFreeChart55 = multiplePiePlot54.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle56 = jFreeChart55.getLegend();
        org.jfree.chart.title.TextTitle textTitle58 = new org.jfree.chart.title.TextTitle("");
        jFreeChart55.addSubtitle((org.jfree.chart.title.Title) textTitle58);
        boolean boolean60 = textTitle58.getExpandToFitSpace();
        double double61 = textTitle58.getHeight();
        java.awt.Paint paint62 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        textTitle58.setBackgroundPaint(paint62);
        legendTitle28.setItemPaint(paint62);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(jFreeChart55);
        org.junit.Assert.assertNull(legendTitle56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        piePlot3D9.setCircular(false, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        piePlot3D9.setInsets(rectangleInsets14);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font2 = textTitle1.getFont();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.JFreeChart jFreeChart4 = titleChangeEvent3.getChart();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        float float5 = dateAxis1.getTickMarkInsideLength();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8);
        double double10 = dateAxis1.getFixedAutoRange();
        boolean boolean12 = dateAxis1.isHiddenValue((-1L));
        dateAxis1.setLabel("{0}");
        dateAxis1.configure();
        java.lang.Class class16 = null;
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange(date19, date20);
        org.jfree.data.gantt.Task task22 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date18, date19);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date19, timeZone23);
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.DateTick dateTick29 = new org.jfree.chart.axis.DateTick(date19, "", textAnchor26, textAnchor27, (double) 2);
        java.util.Date date30 = dateTick29.getDate();
        java.lang.Class class31 = null;
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange(date34, date35);
        org.jfree.data.gantt.Task task37 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date33, date34);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date34, timeZone38);
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.DateTick dateTick44 = new org.jfree.chart.axis.DateTick(date34, "", textAnchor41, textAnchor42, (double) 2);
        try {
            dateAxis1.setRange(date30, date34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        xYPlot7.setBackgroundAlpha((float) 1L);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        xYPlot7.datasetChanged(datasetChangeEvent13);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot7.markerChanged(markerChangeEvent15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = xYPlot7.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(axisSpace17);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        int int7 = jFreeChart2.getBackgroundImageAlignment();
        float float8 = jFreeChart2.getBackgroundImageAlpha();
        boolean boolean10 = jFreeChart2.equals((java.lang.Object) 9999);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean15 = numberAxis3D14.getAutoRangeIncludesZero();
        boolean boolean16 = multiplePiePlot12.equals((java.lang.Object) boolean15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        multiplePiePlot12.setDrawingSupplier(drawingSupplier17);
        multiplePiePlot12.setAggregatedItemsKey((java.lang.Comparable) 100.0d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot12);
        jFreeChart2.plotChanged(plotChangeEvent21);
        org.jfree.chart.plot.Plot plot23 = plotChangeEvent21.getPlot();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(plot23);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        boolean boolean7 = textTitle5.getExpandToFitSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getPadding();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        boolean boolean7 = textTitle5.getExpandToFitSpace();
        double double8 = textTitle5.getHeight();
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint9);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        dateAxis12.setNegativeArrowVisible(false);
        float float16 = dateAxis12.getTickMarkInsideLength();
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange(date17, date18);
        dateAxis12.setRange((org.jfree.data.Range) dateRange19);
        java.util.Date date21 = dateAxis12.getMinimumDate();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset22);
        org.jfree.chart.JFreeChart jFreeChart24 = multiplePiePlot23.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart24.getLegend();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        jFreeChart24.addSubtitle((org.jfree.chart.title.Title) textTitle27);
        boolean boolean29 = textTitle27.getExpandToFitSpace();
        double double30 = textTitle27.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double33 = rectangleInsets31.calculateLeftInset((double) 11);
        textTitle27.setPadding(rectangleInsets31);
        dateAxis12.setTickLabelInsets(rectangleInsets31);
        textTitle5.setPadding(rectangleInsets31);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(jFreeChart24);
        org.junit.Assert.assertNull(legendTitle25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("hi!", font2, paint3);
        boolean boolean5 = ringPlot0.equals((java.lang.Object) "hi!");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        ringPlot0.markerChanged(markerChangeEvent6);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        float float11 = dateAxis10.getTickMarkOutsideLength();
        dateAxis10.setNegativeArrowVisible(false);
        float float14 = dateAxis10.getTickMarkInsideLength();
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(date15, date16);
        dateAxis10.setRange((org.jfree.data.Range) dateRange17);
        double double19 = dateAxis10.getFixedAutoRange();
        boolean boolean21 = dateAxis10.isHiddenValue((-1L));
        java.awt.Color color25 = java.awt.Color.getHSBColor(100.0f, (float) (short) 1, (float) (short) 0);
        dateAxis10.setLabelPaint((java.awt.Paint) color25);
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) (-1), (java.awt.Paint) color25);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = ringPlot0.getLegendItems();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setSeparatorStroke(stroke29);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        dateAxis3.setNegativeArrowVisible(false);
        float float7 = dateAxis3.getTickMarkInsideLength();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(date8, date9);
        dateAxis3.setRange((org.jfree.data.Range) dateRange10);
        boolean boolean12 = taskSeries1.equals((java.lang.Object) dateRange10);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedAreaRenderer1.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        stackedAreaRenderer1.setSeriesPaint(2, paint12);
        org.jfree.chart.block.BorderArrangement borderArrangement14 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D16.setVisible(false);
        org.jfree.chart.plot.Plot plot19 = numberAxis3D16.getPlot();
        java.awt.Shape shape20 = numberAxis3D16.getLeftArrow();
        boolean boolean21 = borderArrangement14.equals((java.lang.Object) shape20);
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, (double) 15, (double) 10);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer1, (org.jfree.chart.block.Arrangement) borderArrangement14, (org.jfree.chart.block.Arrangement) columnArrangement27);
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray32, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        float float39 = dateAxis38.getTickMarkOutsideLength();
        dateAxis38.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot42 = dateAxis38.getPlot();
        double double43 = dateAxis38.getUpperBound();
        java.awt.Shape shape44 = dateAxis38.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer46 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint48 = stackedAreaRenderer46.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator50 = stackedAreaRenderer46.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator51 = stackedAreaRenderer46.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer54 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean56 = stackedAreaRenderer54.getSeriesVisibleInLegend(10);
        boolean boolean57 = stackedAreaRenderer54.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator58 = stackedAreaRenderer54.getLegendItemURLGenerator();
        java.awt.Paint paint60 = stackedAreaRenderer54.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer46.setSeriesPaint(1, paint60);
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font65 = textTitle64.getFont();
        java.awt.Paint paint66 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine67 = new org.jfree.chart.text.TextLine("", font65, paint66);
        stackedAreaRenderer46.setBaseItemLabelPaint(paint66, false);
        stackedAreaRenderer46.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer46);
        org.jfree.chart.title.TextTitle textTitle75 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font76 = textTitle75.getFont();
        java.awt.Paint paint77 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine78 = new org.jfree.chart.text.TextLine("", font76, paint77);
        categoryPlot72.setDomainGridlinePaint(paint77);
        categoryPlot72.setRangeCrosshairValue(0.25d);
        stackedAreaRenderer1.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot72);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNull(categoryItemLabelGenerator50);
        org.junit.Assert.assertNull(categoryItemLabelGenerator51);
        org.junit.Assert.assertNull(boolean56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator58);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(font76);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        float float9 = dateAxis8.getTickMarkOutsideLength();
        dateAxis8.setNegativeArrowVisible(false);
        float float12 = dateAxis8.getTickMarkInsideLength();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(date13, date14);
        dateAxis8.setRange((org.jfree.data.Range) dateRange15);
        numberAxis3D6.setRange((org.jfree.data.Range) dateRange15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange15);
        double double19 = rectangleConstraint18.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.chart.util.Size2D size2D21 = blockContainer0.arrange(graphics2D1, rectangleConstraint18);
        java.lang.String str22 = size2D21.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str22.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean1 = boxAndWhiskerRenderer0.getFillBox();
        java.awt.Paint paint4 = boxAndWhiskerRenderer0.getItemPaint((int) (byte) 1, 0);
        boxAndWhiskerRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray13, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        float float20 = dateAxis19.getTickMarkOutsideLength();
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot23 = dateAxis19.getPlot();
        double double24 = dateAxis19.getUpperBound();
        java.awt.Shape shape25 = dateAxis19.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer27 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint29 = stackedAreaRenderer27.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator31 = stackedAreaRenderer27.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator32 = stackedAreaRenderer27.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer35 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean37 = stackedAreaRenderer35.getSeriesVisibleInLegend(10);
        boolean boolean38 = stackedAreaRenderer35.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = stackedAreaRenderer35.getLegendItemURLGenerator();
        java.awt.Paint paint41 = stackedAreaRenderer35.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer27.setSeriesPaint(1, paint41);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font46 = textTitle45.getFont();
        java.awt.Paint paint47 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine48 = new org.jfree.chart.text.TextLine("", font46, paint47);
        stackedAreaRenderer27.setBaseItemLabelPaint(paint47, false);
        stackedAreaRenderer27.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer27);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor54 = categoryPlot53.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder55 = categoryPlot53.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        int int57 = categoryPlot53.getDomainAxisIndex(categoryAxis56);
        int int58 = categoryPlot53.getDomainAxisCount();
        categoryPlot53.zoom((double) (short) 10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState64 = boxAndWhiskerRenderer0.initialise(graphics2D8, rectangle2D9, categoryPlot53, 0, plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator31);
        org.junit.Assert.assertNull(categoryItemLabelGenerator32);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(categoryAnchor54);
        org.junit.Assert.assertNotNull(sortOrder55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot43.getDomainAxis(1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertNull(categoryAxis46);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getCount();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange(date5, date6);
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date4, date5);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date5, timeZone9);
        java.util.Date date11 = dateTickUnit0.addToDate(date2, timeZone9);
        org.jfree.data.KeyToGroupMap keyToGroupMap12 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) dateTickUnit0);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
        categoryAxis3D0.setUpperMargin(0.0d);
        double double4 = categoryAxis3D0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Stroke stroke4 = stackedBarRenderer3D2.lookupSeriesStroke((int) 'a');
        java.lang.String[] strArray5 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray6 = null;
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray8, numberArray10 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset12 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray5, numberArray6, numberArray11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        defaultIntervalCategoryDataset12.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D14);
        try {
            org.jfree.data.Range range16 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        float float48 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer51);
        java.util.Date date53 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = dateAxis47.dateToJava2D(date53, rectangle2D55, rectangleEdge56);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent58 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis47);
        categoryPlot43.axisChanged(axisChangeEvent58);
        categoryPlot43.clearDomainAxes();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot7.getRangeMarkers(9999, layer10);
        java.awt.Paint paint12 = xYPlot7.getRangeTickBandPaint();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        float float20 = dateAxis19.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer23);
        java.awt.Paint paint25 = xYPlot24.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        float float29 = dateAxis28.getTickMarkOutsideLength();
        dateAxis28.setNegativeArrowVisible(false);
        float float32 = dateAxis28.getTickMarkInsideLength();
        xYPlot24.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis28);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot24.getDomainMarkers(layer34);
        boolean boolean36 = simpleTimePeriod16.equals((java.lang.Object) xYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot24.getDomainAxisLocation(0);
        xYPlot7.setRangeAxisLocation((int) (byte) 10, axisLocation38, false);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray41 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot7.setRenderers(xYItemRendererArray41);
        xYPlot7.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        float float49 = dateAxis48.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis51, xYItemRenderer52);
        java.awt.Paint paint54 = xYPlot53.getRangeTickBandPaint();
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot53.setNoDataMessagePaint((java.awt.Paint) color55);
        xYPlot53.clearRangeAxes();
        xYPlot53.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot53.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup62 = xYPlot53.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot64 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset63);
        org.jfree.chart.JFreeChart jFreeChart65 = multiplePiePlot64.getPieChart();
        java.awt.Image image66 = jFreeChart65.getBackgroundImage();
        xYPlot53.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart65);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot53.setAxisOffset(rectangleInsets68);
        org.jfree.chart.plot.ValueMarker valueMarker72 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker72.setLabel("");
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot53.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker72, layer75);
        java.util.Collection collection77 = xYPlot7.getDomainMarkers(9, layer75);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(xYItemRendererArray41);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 2.0f + "'", float49 == 2.0f);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNull(datasetGroup62);
        org.junit.Assert.assertNotNull(jFreeChart65);
        org.junit.Assert.assertNull(image66);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertNull(collection77);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        double double5 = stackedBarRenderer3D2.getMinimumBarLength();
        java.awt.Paint paint6 = stackedBarRenderer3D2.getWallPaint();
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke4, false);
        lineAndShapeRenderer0.setSeriesLinesVisible(31, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        java.awt.Paint paint16 = xYPlot7.getDomainCrosshairPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.plot.Plot plot18 = xYPlot7.getParent();
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker20.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint26 = stackedAreaRenderer24.getSeriesItemLabelPaint(100);
        stackedAreaRenderer24.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer24.setSeriesStroke(100, stroke30);
        valueMarker20.setStroke(stroke30);
        java.awt.Stroke stroke33 = valueMarker20.getStroke();
        xYPlot7.setRangeCrosshairStroke(stroke33);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        double double5 = dateAxis1.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        dateAxis7.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot11 = dateAxis7.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        double double19 = stackedAreaRenderer13.getItemLabelAnchorOffset();
        java.awt.Paint paint22 = stackedAreaRenderer13.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis7.setAxisLinePaint(paint22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        float float28 = dateAxis27.getTickMarkOutsideLength();
        dateAxis27.setNegativeArrowVisible(false);
        float float31 = dateAxis27.getTickMarkInsideLength();
        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange(date32, date33);
        dateAxis27.setRange((org.jfree.data.Range) dateRange34);
        numberAxis3D25.setRange((org.jfree.data.Range) dateRange34);
        dateAxis7.setRange((org.jfree.data.Range) dateRange34);
        boolean boolean38 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int40 = dateTickUnit39.getCount();
        dateAxis7.setTickUnit(dateTickUnit39, false, false);
        dateAxis1.setTickUnit(dateTickUnit39);
        try {
            dateAxis1.zoomRange((double) '#', 8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (8.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot7.getAxisOffset();
        org.jfree.data.general.DatasetGroup datasetGroup9 = xYPlot7.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(datasetGroup9);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        double double6 = dateAxis1.getUpperBound();
        java.awt.Shape shape7 = dateAxis1.getDownArrow();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape7, shape8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = xYPlot17.getRangeTickBandPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot17.setNoDataMessagePaint((java.awt.Paint) color19);
        xYPlot17.clearRangeAxes();
        xYPlot17.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot17.getRangeAxisLocation((int) (short) 1);
        java.awt.Paint paint26 = xYPlot17.getDomainCrosshairPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape7, paint26);
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        boolean boolean31 = org.jfree.chart.util.ShapeUtilities.equal(shape28, shape30);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity34 = new org.jfree.chart.entity.TickLabelEntity(shape30, "", "ThreadContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str36 = rectangleAnchor35.toString();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape30, rectangleAnchor35, (double) '4', 10.0d);
        legendGraphic27.setShapeLocation(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str36.equals("RectangleAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font2 = textTitle1.getFont();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle1.getVerticalAlignment();
        java.lang.String str5 = textTitle1.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        double double5 = dateAxis1.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        dateAxis7.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot11 = dateAxis7.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        double double19 = stackedAreaRenderer13.getItemLabelAnchorOffset();
        java.awt.Paint paint22 = stackedAreaRenderer13.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis7.setAxisLinePaint(paint22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        float float28 = dateAxis27.getTickMarkOutsideLength();
        dateAxis27.setNegativeArrowVisible(false);
        float float31 = dateAxis27.getTickMarkInsideLength();
        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange(date32, date33);
        dateAxis27.setRange((org.jfree.data.Range) dateRange34);
        numberAxis3D25.setRange((org.jfree.data.Range) dateRange34);
        dateAxis7.setRange((org.jfree.data.Range) dateRange34);
        boolean boolean38 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int40 = dateTickUnit39.getCount();
        dateAxis7.setTickUnit(dateTickUnit39, false, false);
        dateAxis1.setTickUnit(dateTickUnit39);
        int int45 = dateTickUnit39.getCount();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        categoryPlot43.setDrawSharedDomainAxis(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot43.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = null;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker4.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint10 = stackedAreaRenderer8.getSeriesItemLabelPaint(100);
        stackedAreaRenderer8.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer8.setSeriesStroke(100, stroke14);
        valueMarker4.setStroke(stroke14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        float float20 = dateAxis19.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer23);
        java.awt.Paint paint25 = xYPlot24.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        xYPlot24.setDrawingSupplier(drawingSupplier26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot24.setDomainAxisLocation(axisLocation28, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = null;
        xYPlot24.notifyListeners(plotChangeEvent31);
        java.awt.Stroke stroke33 = xYPlot24.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean35 = lineAndShapeRenderer34.getBaseLinesVisible();
        boolean boolean36 = lineAndShapeRenderer34.getBaseCreateEntities();
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer34.setSeriesOutlineStroke((int) (short) 10, stroke38, false);
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] { stroke14, stroke33, stroke38 };
        java.awt.Shape[] shapeArray42 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray41, shapeArray42);
        java.lang.Object obj44 = defaultDrawingSupplier43.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("({0}, {1}) = {2}");
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = xYPlot9.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        xYPlot9.setDrawingSupplier(drawingSupplier11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot9.setDomainAxisLocation(axisLocation13, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot9.notifyListeners(plotChangeEvent16);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer18 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint23 = stackedAreaRenderer21.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = stackedAreaRenderer21.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = stackedAreaRenderer21.getBaseItemLabelGenerator();
        double double27 = stackedAreaRenderer21.getItemLabelAnchorOffset();
        java.awt.Paint paint30 = stackedAreaRenderer21.getItemPaint((int) '#', (int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker33.setLabel("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint39 = stackedAreaRenderer37.getSeriesItemLabelPaint(100);
        stackedAreaRenderer37.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer37.setSeriesStroke(100, stroke43);
        valueMarker33.setStroke(stroke43);
        stackedAreaRenderer21.setSeriesStroke(11, stroke43);
        stackedBarRenderer18.setSeriesStroke(0, stroke43);
        xYPlot9.setDomainCrosshairStroke(stroke43);
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) false, paint1, stroke43);
        java.awt.Paint paint50 = categoryMarker49.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator25);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange13);
        double double17 = rectangleConstraint16.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = numberAxis3D3.getTickUnit();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        float float11 = dateAxis10.getTickMarkOutsideLength();
        dateAxis10.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot14 = dateAxis10.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint18 = stackedAreaRenderer16.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = stackedAreaRenderer16.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer16.getBaseItemLabelGenerator();
        double double22 = stackedAreaRenderer16.getItemLabelAnchorOffset();
        java.awt.Paint paint25 = stackedAreaRenderer16.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis10.setAxisLinePaint(paint25);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        float float31 = dateAxis30.getTickMarkOutsideLength();
        dateAxis30.setNegativeArrowVisible(false);
        float float34 = dateAxis30.getTickMarkInsideLength();
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange(date35, date36);
        dateAxis30.setRange((org.jfree.data.Range) dateRange37);
        numberAxis3D28.setRange((org.jfree.data.Range) dateRange37);
        dateAxis10.setRange((org.jfree.data.Range) dateRange37);
        numberAxis3D3.setRangeWithMargins((org.jfree.data.Range) dateRange37);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(categoryItemLabelGenerator20);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 2.0f + "'", float31 == 2.0f);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint3 = stackedAreaRenderer1.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedAreaRenderer1.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer1.getBaseItemLabelGenerator();
        double double7 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedAreaRenderer1.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        boolean boolean12 = stackedAreaRenderer1.isSeriesVisibleInLegend(31);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle3 = jFreeChart2.getLegend();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) textTitle5);
        int int7 = jFreeChart2.getBackgroundImageAlignment();
        java.util.List list8 = jFreeChart2.getSubtitles();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(legendTitle3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        int int11 = defaultIntervalCategoryDataset7.getSeriesCount();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        org.jfree.chart.JFreeChart jFreeChart14 = multiplePiePlot13.getPieChart();
        defaultIntervalCategoryDataset7.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot13);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(jFreeChart14);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCount();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date6, date7);
        java.util.Date date9 = dateTickUnit4.rollDate(date6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(date2, date6);
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(date13, date14);
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date12, date13);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date13, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date6, timeZone17);
        defaultCategoryDataset0.addValue((java.lang.Number) 31, (java.lang.Comparable) month19, (java.lang.Comparable) 0.35d);
        java.util.List list22 = defaultCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean1 = minMaxCategoryRenderer0.isDrawLines();
        minMaxCategoryRenderer0.setDrawLines(true);
        javax.swing.Icon icon4 = minMaxCategoryRenderer0.getMaxIcon();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(icon4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries1.removeAll();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener3);
        taskSeries1.setNotify(false);
        java.lang.Object obj7 = taskSeries1.clone();
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        piePlot0.setLabelFont(font2);
        boolean boolean4 = piePlot0.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean2 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        java.awt.Stroke stroke6 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("cyan");
        lineAndShapeRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date1, date2);
        java.lang.Object obj6 = task5.clone();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj8 = categoryAxis3D7.clone();
        float float9 = categoryAxis3D7.getMaximumCategoryLabelWidthRatio();
        float float10 = categoryAxis3D7.getMaximumCategoryLabelWidthRatio();
        categoryAxis3D7.addCategoryLabelToolTip((java.lang.Comparable) "HorizontalAlignment.RIGHT", "CategoryLabelWidthType.CATEGORY");
        boolean boolean14 = task5.equals((java.lang.Object) categoryAxis3D7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D5.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D5.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint11 = stackedBarRenderer3D5.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D2.setBaseOutlinePaint(paint11);
        stackedBarRenderer3D2.setItemLabelAnchorOffset((double) 1.0f);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str16 = ringPlot15.getNoDataMessage();
        double double17 = ringPlot15.getInnerSeparatorExtension();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint21 = stackedAreaRenderer19.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedAreaRenderer19.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = stackedAreaRenderer19.getBaseItemLabelGenerator();
        double double25 = stackedAreaRenderer19.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer19.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint29 = null;
        stackedAreaRenderer19.setBasePaint(paint29, false);
        boolean boolean32 = stackedAreaRenderer19.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke34 = piePlot33.getBaseSectionOutlineStroke();
        java.awt.Color color35 = java.awt.Color.CYAN;
        piePlot33.setShadowPaint((java.awt.Paint) color35);
        stackedAreaRenderer19.setBaseItemLabelPaint((java.awt.Paint) color35);
        ringPlot15.setSeparatorPaint((java.awt.Paint) color35);
        stackedBarRenderer3D2.setWallPaint((java.awt.Paint) color35);
        boolean boolean42 = stackedBarRenderer3D2.getItemVisible(0, (int) (short) 100);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean8 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) spreadsheetDate2, 0.0d, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        float float47 = dateAxis46.getTickMarkOutsideLength();
        dateAxis46.setNegativeArrowVisible(false);
        float float50 = dateAxis46.getTickMarkInsideLength();
        java.util.Date date51 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange53 = new org.jfree.data.time.DateRange(date51, date52);
        dateAxis46.setRange((org.jfree.data.Range) dateRange53);
        double double55 = dateAxis46.getFixedAutoRange();
        boolean boolean57 = dateAxis46.isHiddenValue((-1L));
        java.awt.Shape shape58 = dateAxis46.getDownArrow();
        categoryPlot43.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis46);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition60 = dateAxis46.getTickMarkPosition();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.0f + "'", float50 == 0.0f);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(dateTickMarkPosition60);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Image image8 = xYPlot7.getBackgroundImage();
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font11, paint12);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font11, (org.jfree.chart.plot.Plot) piePlot14, false);
        java.awt.RenderingHints renderingHints17 = jFreeChart16.getRenderingHints();
        org.jfree.chart.plot.Plot plot18 = jFreeChart16.getPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot7, jFreeChart16);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(renderingHints17);
        org.junit.Assert.assertNotNull(plot18);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getBaseSectionOutlineStroke();
        java.awt.Paint paint2 = piePlot0.getLabelLinkPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot0.setLabelGenerator(pieSectionLabelGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer13);
        java.awt.Paint paint15 = xYPlot14.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        float float19 = dateAxis18.getTickMarkOutsideLength();
        dateAxis18.setNegativeArrowVisible(false);
        float float22 = dateAxis18.getTickMarkInsideLength();
        xYPlot14.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot14.getDomainMarkers(layer24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        float float28 = dateAxis27.getTickMarkOutsideLength();
        dateAxis27.setNegativeArrowVisible(false);
        float float31 = dateAxis27.getTickMarkInsideLength();
        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange(date32, date33);
        dateAxis27.setRange((org.jfree.data.Range) dateRange34);
        double double36 = dateAxis27.getFixedAutoRange();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        xYPlot14.zoomDomainAxes((double) 1L, (double) 1.0f, plotRenderingInfo41, point2D42);
        float float44 = xYPlot14.getBackgroundImageAlpha();
        java.awt.geom.Point2D point2D45 = xYPlot14.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo47);
        try {
            piePlot0.draw(graphics2D5, rectangle2D6, point2D45, plotState46, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.5f + "'", float44 == 0.5f);
        org.junit.Assert.assertNotNull(point2D45);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot10 = dateAxis6.getPlot();
        double double11 = dateAxis6.getUpperBound();
        java.awt.Shape shape12 = dateAxis6.getDownArrow();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape12, shape13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        dateAxis16.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot20 = dateAxis16.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint24 = stackedAreaRenderer22.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = stackedAreaRenderer22.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = stackedAreaRenderer22.getBaseItemLabelGenerator();
        double double28 = stackedAreaRenderer22.getItemLabelAnchorOffset();
        java.awt.Paint paint31 = stackedAreaRenderer22.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis16.setAxisLinePaint(paint31);
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape12, paint31);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font38 = textTitle37.getFont();
        java.awt.Paint paint39 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine("", font38, paint39);
        java.awt.Paint paint42 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Font font45 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine47 = new org.jfree.chart.text.TextLine("", font45, paint46);
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font45, (org.jfree.chart.plot.Plot) piePlot48, false);
        java.awt.Stroke stroke51 = jFreeChart50.getBorderStroke();
        java.awt.Shape shape53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D57 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D57.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = stackedBarRenderer3D57.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint63 = stackedBarRenderer3D57.getItemLabelPaint((int) (byte) -1, 9999);
        org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem("", "Category Plot", "Nearest", "CategoryLabelWidthType.CATEGORY", false, shape12, true, paint39, true, paint42, stroke51, true, shape53, stroke54, paint63);
        legendItem64.setSeriesKey((java.lang.Comparable) 5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNull(itemLabelPosition60);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setVisible(false);
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint7 = boxAndWhiskerRenderer5.lookupSeriesFillPaint(1);
        numberAxis3D1.setAxisLinePaint(paint7);
        double double9 = numberAxis3D1.getLowerBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D15.setVisible(false);
        java.awt.Font font19 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("cyan", font19);
        numberAxis3D15.setTickLabelFont(font19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) (byte) 1, (double) (-1), (double) 1, (double) 100.0f, font19);
        numberAxis3D1.resizeRange((double) 2.0f);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 2);
        org.jfree.chart.JFreeChart jFreeChart2 = rendererChangeEvent1.getChart();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        rendererChangeEvent1.setChart(jFreeChart3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot6.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart7.getLegend();
        rendererChangeEvent1.setChart(jFreeChart7);
        org.junit.Assert.assertNull(jFreeChart2);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNull(legendTitle8);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalLineAndShapeRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        dateAxis2.zoomRange(0.0d, 0.0d);
        java.awt.Shape shape11 = null;
        try {
            dateAxis2.setDownArrow(shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 128);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = categoryLabelPositions1.getLabelPosition(rectangleEdge2);
        org.jfree.chart.text.TextAnchor textAnchor4 = categoryLabelPosition3.getRotationAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(categoryLabelPosition3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        spreadsheetDate9.setDescription("EXPAND");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        boolean boolean17 = spreadsheetDate9.equals((java.lang.Object) itemLabelAnchor16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.lang.Object obj2 = plotRenderingInfo1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        xYPlot7.notifyListeners(plotChangeEvent14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke17 = piePlot16.getBaseSectionOutlineStroke();
        java.awt.Color color18 = java.awt.Color.CYAN;
        piePlot16.setShadowPaint((java.awt.Paint) color18);
        java.awt.Color color21 = java.awt.Color.white;
        piePlot16.setSectionPaint((java.lang.Comparable) 12.0d, (java.awt.Paint) color21);
        xYPlot7.setRangeCrosshairPaint((java.awt.Paint) color21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        float float27 = dateAxis26.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer30);
        java.awt.Paint paint32 = xYPlot31.getRangeTickBandPaint();
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot31.setNoDataMessagePaint((java.awt.Paint) color33);
        xYPlot31.clearRangeAxes();
        xYPlot31.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot31.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup40 = xYPlot31.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot42 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset41);
        org.jfree.chart.JFreeChart jFreeChart43 = multiplePiePlot42.getPieChart();
        java.awt.Image image44 = jFreeChart43.getBackgroundImage();
        xYPlot31.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart43);
        xYPlot7.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart43);
        boolean boolean47 = xYPlot7.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = xYPlot7.getAxisOffset();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNull(datasetGroup40);
        org.junit.Assert.assertNotNull(jFreeChart43);
        org.junit.Assert.assertNull(image44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(rectangleInsets48);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean2 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        float float10 = dateAxis6.getTickMarkInsideLength();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date11, date12);
        dateAxis6.setRange((org.jfree.data.Range) dateRange13);
        numberAxis3D4.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange13);
        double double17 = rectangleConstraint16.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint16.getWidthConstraintType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean20 = lengthConstraintType18.equals((java.lang.Object) rectangleAnchor19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj22 = categoryAxis3D21.clone();
        float float23 = categoryAxis3D21.getMaximumCategoryLabelWidthRatio();
        float float24 = categoryAxis3D21.getMaximumCategoryLabelWidthRatio();
        java.lang.Object obj25 = categoryAxis3D21.clone();
        java.awt.Font font27 = categoryAxis3D21.getTickLabelFont((java.lang.Comparable) true);
        boolean boolean28 = rectangleAnchor19.equals((java.lang.Object) font27);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker1.setLabel("");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        float float9 = dateAxis8.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        java.awt.Paint paint14 = xYPlot13.getRangeTickBandPaint();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot13.setNoDataMessagePaint((java.awt.Paint) color15);
        xYPlot13.clearRangeAxes();
        xYPlot13.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup22 = xYPlot13.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot24.getPieChart();
        java.awt.Image image26 = jFreeChart25.getBackgroundImage();
        xYPlot13.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot13.setAxisOffset(rectangleInsets28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker32.setLabel("");
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot13.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker32, layer35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = valueMarker32.getLabelAnchor();
        java.awt.Paint paint38 = valueMarker32.getOutlinePaint();
        valueMarker1.setPaint(paint38);
        double double40 = valueMarker1.getValue();
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.lang.Class class2 = null;
        try {
            java.util.EventListener[] eventListenerArray3 = valueMarker1.getListeners(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible(31);
        java.awt.Paint paint7 = lineAndShapeRenderer2.getItemPaint(6, 8);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getCategoryLabelPositionOffset();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color3 = java.awt.Color.CYAN;
        stackedAreaRenderer1.setSeriesFillPaint(2, (java.awt.Paint) color3, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator7, false);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("", font12, paint13);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font12, (org.jfree.chart.plot.Plot) piePlot15, false);
        java.awt.RenderingHints renderingHints18 = jFreeChart17.getRenderingHints();
        org.jfree.chart.plot.Plot plot19 = jFreeChart17.getPlot();
        java.awt.Font font22 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("cyan", font22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D29.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = stackedBarRenderer3D29.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint35 = stackedBarRenderer3D29.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D26.setBaseOutlinePaint(paint35);
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("{0}", font22, paint35, (float) 2);
        java.awt.Paint paint39 = textFragment38.getPaint();
        jFreeChart17.setBackgroundPaint(paint39);
        boolean boolean41 = stackedAreaRenderer1.equals((java.lang.Object) jFreeChart17);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(renderingHints18);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        float float7 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot10 = dateAxis6.getPlot();
        double double11 = dateAxis6.getUpperBound();
        java.awt.Shape shape12 = dateAxis6.getDownArrow();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape12, shape13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        dateAxis16.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot20 = dateAxis16.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint24 = stackedAreaRenderer22.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = stackedAreaRenderer22.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = stackedAreaRenderer22.getBaseItemLabelGenerator();
        double double28 = stackedAreaRenderer22.getItemLabelAnchorOffset();
        java.awt.Paint paint31 = stackedAreaRenderer22.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis16.setAxisLinePaint(paint31);
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape12, paint31);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font38 = textTitle37.getFont();
        java.awt.Paint paint39 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine("", font38, paint39);
        java.awt.Paint paint42 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Font font45 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine47 = new org.jfree.chart.text.TextLine("", font45, paint46);
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font45, (org.jfree.chart.plot.Plot) piePlot48, false);
        java.awt.Stroke stroke51 = jFreeChart50.getBorderStroke();
        java.awt.Shape shape53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D57 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D57.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = stackedBarRenderer3D57.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint63 = stackedBarRenderer3D57.getItemLabelPaint((int) (byte) -1, 9999);
        org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem("", "Category Plot", "Nearest", "CategoryLabelWidthType.CATEGORY", false, shape12, true, paint39, true, paint42, stroke51, true, shape53, stroke54, paint63);
        java.lang.String str65 = legendItem64.getToolTipText();
        java.awt.Stroke stroke66 = legendItem64.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNull(itemLabelPosition60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Nearest" + "'", str65.equals("Nearest"));
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Stroke stroke9 = stackedBarRenderer3D7.lookupSeriesStroke((int) 'a');
        stackedBarRenderer3D2.setBaseOutlineStroke(stroke9);
        java.awt.Paint paint11 = stackedBarRenderer3D2.getWallPaint();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Stroke stroke17 = xYPlot7.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot7.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        textBlock0.draw(graphics2D1, (float) (short) 0, 100.0f, textBlockAnchor4, (float) 15, (float) 0L, (double) (byte) 0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock0.draw(graphics2D9, 0.0f, (float) (short) 0, textBlockAnchor12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape21 = textBlock0.calculateBounds(graphics2D14, (float) 4, (float) 86400000L, textBlockAnchor17, 0.0f, (float) 9999, (double) 100L);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = stackedBarRenderer3D4.getBaseItemLabelGenerator();
        categoryPlot0.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font6, (org.jfree.chart.plot.Plot) piePlot9, false);
        stackedBarRenderer3D2.setSeriesItemLabelFont((int) '4', font6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        int int14 = stackedBarRenderer3D2.getPassCount();
        double double15 = stackedBarRenderer3D2.getLowerClip();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date2, date3);
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date1, date2);
        java.lang.Object obj6 = task5.clone();
        try {
            org.jfree.data.gantt.Task task8 = task5.getSubtask((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setLowerMargin((double) 15);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(tickUnitSource7);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        dateAxis4.setNegativeArrowVisible(false);
        float float8 = dateAxis4.getTickMarkInsideLength();
        dateAxis4.resizeRange(0.0d, 100.0d);
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) dateAxis4);
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.lang.String str16 = year15.toString();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(10, year15);
        java.util.Date date18 = month17.getStart();
        dateAxis4.setMaximumDate(date18);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getCount();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange(date5, date6);
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date4, date5);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date5, timeZone9);
        java.util.Date date11 = dateTickUnit0.addToDate(date2, timeZone9);
        java.lang.String str13 = dateTickUnit0.valueToString((double) 255);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12/31/69 4:00 PM" + "'", str13.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        java.awt.Shape shape8 = legendGraphic7.getLine();
        java.awt.Stroke stroke9 = legendGraphic7.getLineStroke();
        java.awt.Paint paint10 = legendGraphic7.getFillPaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        double double5 = stackedBarRenderer3D2.getMinimumBarLength();
        double double6 = stackedBarRenderer3D2.getMinimumBarLength();
        double double7 = stackedBarRenderer3D2.getMaximumBarWidth();
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray11, doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        float float18 = dateAxis17.getTickMarkOutsideLength();
        dateAxis17.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot21 = dateAxis17.getPlot();
        double double22 = dateAxis17.getUpperBound();
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint27 = stackedAreaRenderer25.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer25.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = stackedAreaRenderer25.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean35 = stackedAreaRenderer33.getSeriesVisibleInLegend(10);
        boolean boolean36 = stackedAreaRenderer33.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedAreaRenderer33.getLegendItemURLGenerator();
        java.awt.Paint paint39 = stackedAreaRenderer33.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer25.setSeriesPaint(1, paint39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font44 = textTitle43.getFont();
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("", font44, paint45);
        stackedAreaRenderer25.setBaseItemLabelPaint(paint45, false);
        stackedAreaRenderer25.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer25);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("");
        float float54 = dateAxis53.getTickMarkOutsideLength();
        org.jfree.data.Range range55 = categoryPlot51.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis53);
        stackedBarRenderer3D2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot51);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = stackedBarRenderer3D2.getNegativeItemLabelPosition(100, 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 2.0f + "'", float54 == 2.0f);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertNotNull(itemLabelPosition59);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot7.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot18.getPieChart();
        java.awt.Image image20 = jFreeChart19.getBackgroundImage();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        float float24 = dateAxis23.getTickMarkOutsideLength();
        dateAxis23.setNegativeArrowVisible(false);
        dateAxis23.setLowerMargin((double) 15);
        dateAxis23.setFixedAutoRange((double) 1);
        int int31 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D5.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D5.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint11 = stackedBarRenderer3D5.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D2.setBaseOutlinePaint(paint11);
        stackedBarRenderer3D2.setItemLabelAnchorOffset((double) 1.0f);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str16 = ringPlot15.getNoDataMessage();
        double double17 = ringPlot15.getInnerSeparatorExtension();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint21 = stackedAreaRenderer19.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedAreaRenderer19.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = stackedAreaRenderer19.getBaseItemLabelGenerator();
        double double25 = stackedAreaRenderer19.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer19.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint29 = null;
        stackedAreaRenderer19.setBasePaint(paint29, false);
        boolean boolean32 = stackedAreaRenderer19.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke34 = piePlot33.getBaseSectionOutlineStroke();
        java.awt.Color color35 = java.awt.Color.CYAN;
        piePlot33.setShadowPaint((java.awt.Paint) color35);
        stackedAreaRenderer19.setBaseItemLabelPaint((java.awt.Paint) color35);
        ringPlot15.setSeparatorPaint((java.awt.Paint) color35);
        stackedBarRenderer3D2.setWallPaint((java.awt.Paint) color35);
        java.awt.Color color40 = color35.darker();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot42 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset41);
        org.jfree.chart.JFreeChart jFreeChart43 = multiplePiePlot42.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        multiplePiePlot42.setDataset(categoryDataset44);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D51.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = stackedBarRenderer3D51.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint57 = stackedBarRenderer3D51.getItemLabelPaint((int) (byte) -1, 9999);
        stackedBarRenderer3D48.setBaseOutlinePaint(paint57);
        boolean boolean59 = multiplePiePlot42.equals((java.lang.Object) paint57);
        org.jfree.chart.JFreeChart jFreeChart60 = multiplePiePlot42.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot62 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset61);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean65 = numberAxis3D64.getAutoRangeIncludesZero();
        boolean boolean66 = multiplePiePlot62.equals((java.lang.Object) boolean65);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier67 = null;
        multiplePiePlot62.setDrawingSupplier(drawingSupplier67);
        multiplePiePlot62.setAggregatedItemsKey((java.lang.Comparable) 100.0d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent71 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot62);
        jFreeChart60.plotChanged(plotChangeEvent71);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent73 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color35, jFreeChart60);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(jFreeChart43);
        org.junit.Assert.assertNull(itemLabelPosition54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(jFreeChart60);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset4 = piePlot2.getDataset();
        piePlot2.setMinimumArcAngleToDraw(12.0d);
        boolean boolean7 = textTitle1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle1.getVerticalAlignment();
        java.lang.String str9 = verticalAlignment8.toString();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "VerticalAlignment.CENTER" + "'", str9.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        labelBlock3.setToolTipText("hi!");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        float float13 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        float float17 = dateAxis16.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = xYPlot21.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        xYPlot21.setDrawingSupplier(drawingSupplier23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(axisLocation25, false);
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = labelBlock3.equals((java.lang.Object) xYPlot21);
        double double30 = xYPlot21.getRangeCrosshairValue();
        xYPlot21.clearDomainMarkers(0);
        java.lang.String str33 = xYPlot21.getPlotType();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "XY Plot" + "'", str33.equals("XY Plot"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        stackedAreaRenderer13.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer13.setSeriesStroke(100, stroke19);
        xYPlot11.setRangeZeroBaselineStroke(stroke19);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        float float25 = dateAxis24.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer28);
        java.awt.Paint paint30 = xYPlot29.getRangeTickBandPaint();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot29.setNoDataMessagePaint((java.awt.Paint) color31);
        xYPlot29.clearRangeAxes();
        xYPlot29.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot29.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup38 = xYPlot29.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot40 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset39);
        org.jfree.chart.JFreeChart jFreeChart41 = multiplePiePlot40.getPieChart();
        java.awt.Image image42 = jFreeChart41.getBackgroundImage();
        xYPlot29.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart41);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot29.setAxisOffset(rectangleInsets44);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker48.setLabel("");
        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot29.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker48, layer51);
        java.util.Collection collection53 = xYPlot11.getDomainMarkers(layer51);
        boolean boolean54 = xYPlot11.isDomainZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = xYPlot11.getRenderer();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(datasetGroup38);
        org.junit.Assert.assertNotNull(jFreeChart41);
        org.junit.Assert.assertNull(image42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(layer51);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(xYItemRenderer55);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        java.lang.String[] strArray5 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray6 = null;
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray8, numberArray10 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset12 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray5, numberArray6, numberArray11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        defaultIntervalCategoryDataset12.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D14);
        int int16 = defaultIntervalCategoryDataset12.getSeriesCount();
        try {
            org.jfree.data.Range range17 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        float float47 = dateAxis46.getTickMarkOutsideLength();
        dateAxis46.setNegativeArrowVisible(false);
        dateAxis46.setLowerMargin((double) 15);
        dateAxis46.setLowerMargin(0.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator58 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        boolean boolean59 = lineAndShapeRenderer54.equals((java.lang.Object) "");
        boolean boolean61 = lineAndShapeRenderer54.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer54);
        org.jfree.chart.axis.ValueAxis valueAxis63 = categoryPlot62.getRangeAxis();
        categoryPlot62.mapDatasetToDomainAxis((int) (byte) 1, 8);
        org.jfree.chart.axis.AxisLocation axisLocation68 = categoryPlot62.getDomainAxisLocation(100);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNotNull(axisLocation68);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Stroke stroke17 = xYPlot7.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset3 = piePlot1.getDataset();
        piePlot1.setMinimumArcAngleToDraw(12.0d);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        piePlot1.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font2 = textTitle1.getFont();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle1.draw(graphics2D5, rectangle2D6);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean4 = lineAndShapeRenderer3.getBaseLinesVisible();
        lineAndShapeRenderer3.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator12 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        lineAndShapeRenderer3.setSeriesURLGenerator(9999, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator12);
        stackedBarRenderer3D2.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator12);
        double double15 = stackedBarRenderer3D2.getXOffset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        piePlot0.zoom(0.0d);
        boolean boolean4 = piePlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint2 = boxAndWhiskerRenderer0.lookupSeriesFillPaint(1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot4.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle6 = jFreeChart5.getLegend();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        jFreeChart5.addSubtitle((org.jfree.chart.title.Title) textTitle8);
        boolean boolean10 = textTitle8.getExpandToFitSpace();
        java.awt.Shape shape11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color15 = java.awt.Color.CYAN;
        stackedAreaRenderer13.setSeriesFillPaint(2, (java.awt.Paint) color15, true);
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color15);
        textTitle8.setPaint((java.awt.Paint) color15);
        boolean boolean20 = boxAndWhiskerRenderer0.equals((java.lang.Object) textTitle8);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertNull(legendTitle6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
        labelBlock3.setToolTipText("{0}");
        labelBlock3.setToolTipText("hi!");
        java.lang.String str8 = labelBlock3.getToolTipText();
        labelBlock3.setToolTipText("hi!");
        java.lang.Object obj11 = labelBlock3.clone();
        labelBlock3.setMargin(100.0d, (double) 10, (double) 11, (double) 4);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        defaultIntervalCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D9);
        try {
            org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100, 0.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        java.lang.Number number4 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        categoryPlot43.clearAnnotations();
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot43.getRangeMarkers(128, layer46);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        float float51 = dateAxis50.getTickMarkOutsideLength();
        dateAxis50.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot54 = dateAxis50.getPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer56 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint58 = stackedAreaRenderer56.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator60 = stackedAreaRenderer56.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator61 = stackedAreaRenderer56.getBaseItemLabelGenerator();
        double double62 = stackedAreaRenderer56.getItemLabelAnchorOffset();
        java.awt.Paint paint65 = stackedAreaRenderer56.getItemPaint((int) '#', (int) (byte) 0);
        dateAxis50.setAxisLinePaint(paint65);
        org.jfree.chart.plot.Plot plot67 = dateAxis50.getPlot();
        categoryPlot43.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis50, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 2.0f + "'", float51 == 2.0f);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNull(categoryItemLabelGenerator60);
        org.junit.Assert.assertNull(categoryItemLabelGenerator61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.0d + "'", double62 == 2.0d);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(plot67);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.junit.Assert.assertNull(waferMapDataset2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        java.util.List list2 = taskSeries1.getTasks();
        taskSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        double double6 = stackedBarRenderer3D2.getXOffset();
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        jFreeChart2.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.event.ChartChangeListener chartChangeListener5 = null;
        try {
            jFreeChart2.removeChangeListener(chartChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
    }
}

