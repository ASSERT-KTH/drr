import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
//        int int15 = day11.getYear();
//        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
//        java.lang.String str20 = timePeriodValues5.getDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timePeriodValues5.addChangeListener(seriesChangeListener23);
//        java.lang.Object obj25 = timePeriodValues5.clone();
//        timePeriodValues5.setDomainDescription("Time");
//        java.lang.Object obj28 = timePeriodValues5.clone();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        long long33 = day29.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) (-1L));
//        int int36 = day29.getYear();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day29, (double) 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560452399999L + "'", long33 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
//        int int15 = day11.getYear();
//        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day11.previous();
//        int int22 = day11.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (double) (byte) 0);
//        long long25 = day11.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560495599999L + "'", long25 == 1560495599999L);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,97]");
        int int5 = year0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.lang.Object obj6 = null;
        boolean boolean7 = year0.equals(obj6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getMonth();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day11, 0.0d);
        int int18 = timePeriodValues10.getMinStartIndex();
        int int19 = timePeriodValues10.getMinEndIndex();
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues10.getTimePeriod(0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(timePeriod21);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.util.Date date7 = year0.getEnd();
        long long8 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=12-June-2019]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getYear();
        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
        java.lang.String str20 = timePeriodValues5.getDescription();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        timePeriodValues5.setKey((java.lang.Comparable) day21);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day21.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(str20);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int9 = day0.compareTo((java.lang.Object) simpleTimePeriod8);
//        java.lang.Class<?> wildcardClass10 = day0.getClass();
//        java.util.Date date11 = day0.getEnd();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019L);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        java.lang.Number number6 = timePeriodValue4.getValue();
//        java.lang.Object obj7 = timePeriodValue4.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        boolean boolean13 = timePeriodValue11.equals((java.lang.Object) 11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, 1.0d);
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int23 = day14.compareTo((java.lang.Object) simpleTimePeriod22);
//        boolean boolean24 = timePeriodValue11.equals((java.lang.Object) day14);
//        long long25 = day14.getSerialIndex();
//        java.util.Date date26 = day14.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long30 = simpleTimePeriod29.getEndMillis();
//        long long31 = simpleTimePeriod29.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long31);
//        timePeriodValues32.setKey((java.lang.Comparable) 1L);
//        java.lang.String str35 = timePeriodValues32.getDomainDescription();
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        int int37 = timePeriodValues32.getMaxEndIndex();
//        timePeriodValues32.setDomainDescription("");
//        int int40 = day14.compareTo((java.lang.Object) timePeriodValues32);
//        boolean boolean41 = timePeriodValue4.equals((java.lang.Object) timePeriodValues32);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day42, 1.0d);
//        long long46 = day42.getMiddleMillisecond();
//        int int47 = day42.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int51 = day42.compareTo((java.lang.Object) simpleTimePeriod50);
//        java.lang.Class<?> wildcardClass52 = day42.getClass();
//        boolean boolean53 = timePeriodValue4.equals((java.lang.Object) wildcardClass52);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2019L + "'", number5.equals(2019L));
//        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2019L + "'", number6.equals(2019L));
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560452399999L + "'", long46 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 13 + "'", int47 == 13);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setNotify(false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long18 = simpleTimePeriod17.getEndMillis();
        long long19 = simpleTimePeriod17.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long19);
        int int21 = timePeriodValues20.getMinEndIndex();
        boolean boolean22 = timePeriodValues20.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues20.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 1.0d);
        int int30 = day26.getYear();
        int int32 = day26.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (byte) -1);
        java.lang.String str35 = timePeriodValues20.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timePeriodValues20.removeChangeListener(seriesChangeListener36);
        boolean boolean38 = timePeriodValues5.equals((java.lang.Object) seriesChangeListener36);
        java.lang.String str39 = timePeriodValues5.getDomainDescription();
        int int40 = timePeriodValues5.getMinMiddleIndex();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        java.util.Date date42 = day41.getEnd();
        java.lang.Number number43 = null;
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day41, number43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day45.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day45, (java.lang.Number) 100L);
        timePeriodValues5.add(timePeriodValue49);
        timePeriodValue49.setValue((java.lang.Number) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Time" + "'", str39.equals("Time"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        timePeriodValues5.setRangeDescription("Value");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener8);
        timePeriodValues5.setRangeDescription("Value");
        boolean boolean12 = timePeriodValues5.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int9 = day0.compareTo((java.lang.Object) simpleTimePeriod8);
//        boolean boolean11 = simpleTimePeriod8.equals((java.lang.Object) 1577865599999L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        java.lang.String str14 = day12.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 10L);
//        int int17 = simpleTimePeriod8.compareTo((java.lang.Object) day12);
//        long long18 = simpleTimePeriod8.getStartMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 0);
//        java.util.Date date21 = simpleTimePeriod8.getStart();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(date21);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.general.SeriesChangeEvent[source=12-June-2019]", "13-June-2019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "13-June-2019");
//        boolean boolean6 = timePeriodValues5.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues5.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timePeriodValues5.getDescription();
//        java.lang.String str10 = timePeriodValues5.getDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNull(str10);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getMonth();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day11, 0.0d);
        int int18 = timePeriodValues10.getMinEndIndex();
        timePeriodValues10.delete(10, (int) (short) 1);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue23 = timePeriodValues10.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getDayOfMonth();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day2.equals(obj5);
//        java.lang.String str7 = day2.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        timePeriodValues5.setKey((java.lang.Comparable) 1L);
        java.lang.String str8 = timePeriodValues5.getDomainDescription();
        java.lang.String str9 = timePeriodValues5.getDomainDescription();
        timePeriodValues5.setDescription("hi!");
        timePeriodValues5.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int9 = day0.compareTo((java.lang.Object) simpleTimePeriod8);
//        boolean boolean11 = simpleTimePeriod8.equals((java.lang.Object) 1577865599999L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        java.lang.String str14 = day12.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 10L);
//        int int17 = simpleTimePeriod8.compareTo((java.lang.Object) day12);
//        long long18 = simpleTimePeriod8.getStartMillis();
//        java.util.Date date19 = simpleTimePeriod8.getStart();
//        long long20 = simpleTimePeriod8.getStartMillis();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("hi!");
        seriesException8.addSuppressed((java.lang.Throwable) seriesException10);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        int int13 = year0.compareTo((java.lang.Object) seriesException8);
        java.lang.String str14 = seriesException8.toString();
        java.lang.Throwable[] throwableArray15 = seriesException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str14.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setDomainDescription("");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        boolean boolean18 = timePeriodValues5.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener19);
        java.lang.String str21 = timePeriodValues5.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues5.createCopy(0, (int) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener25);
        java.lang.String str27 = timePeriodValues5.getDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues24);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long7 = simpleTimePeriod6.getEndMillis();
        long long8 = simpleTimePeriod6.getStartMillis();
        long long9 = simpleTimePeriod6.getStartMillis();
        java.util.Date date10 = simpleTimePeriod6.getStart();
        java.util.Date date11 = simpleTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date3, date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
        java.lang.Number number17 = timePeriodValue16.getValue();
        java.lang.Object obj18 = null;
        boolean boolean19 = timePeriodValue16.equals(obj18);
        boolean boolean20 = simpleTimePeriod12.equals((java.lang.Object) boolean19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) 2019L);
        java.lang.Number number26 = timePeriodValue25.getValue();
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValue25.getPeriod();
        int int28 = simpleTimePeriod12.compareTo((java.lang.Object) timePeriod27);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 2019L + "'", number26.equals(2019L));
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = day8.toString();
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        java.util.Date date13 = day8.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date13, timeZone14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date5, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,97]");
//        boolean boolean20 = year17.equals((java.lang.Object) timePeriodFormatException19);
//        java.util.Calendar calendar21 = null;
//        try {
//            year17.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setDomainDescription("");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        boolean boolean18 = timePeriodValues5.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener19);
        java.lang.Object obj21 = timePeriodValues5.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues5.createCopy((int) (byte) 10, 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues24.addChangeListener(seriesChangeListener25);
        int int27 = timePeriodValues24.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(timePeriodValues24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int9 = day0.compareTo((java.lang.Object) simpleTimePeriod8);
//        java.lang.Class<?> wildcardClass10 = day0.getClass();
//        java.lang.String str11 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
//        int int13 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        timePeriodValues5.setRangeDescription("Value");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener8);
        timePeriodValues5.setRangeDescription("Value");
        java.lang.Object obj12 = null;
        boolean boolean13 = timePeriodValues5.equals(obj12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 1);
        long long10 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.next();
        long long12 = year7.getFirstMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long16 = simpleTimePeriod15.getEndMillis();
        long long17 = simpleTimePeriod15.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long17);
        int int19 = timePeriodValues18.getMinEndIndex();
        boolean boolean20 = timePeriodValues18.isEmpty();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day21, (double) 10.0f);
        timePeriodValues18.setNotify(false);
        timePeriodValues18.setRangeDescription("Time");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener30);
        boolean boolean32 = year7.equals((java.lang.Object) propertyChangeListener30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year7.next();
        java.lang.String str34 = year7.toString();
        java.util.Calendar calendar35 = null;
        try {
            year7.peg(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long4 = simpleTimePeriod3.getEndMillis();
//        long long5 = simpleTimePeriod3.getStartMillis();
//        java.util.Date date6 = simpleTimePeriod3.getStart();
//        java.util.Date date7 = simpleTimePeriod3.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        long long12 = day8.getMiddleMillisecond();
//        java.util.Date date13 = day8.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        java.lang.String str18 = day16.toString();
//        long long19 = day16.getFirstMillisecond();
//        int int20 = day16.getYear();
//        java.util.Date date21 = day16.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date13, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone22);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("Time");
//        int int29 = year26.compareTo((java.lang.Object) "Time");
//        long long30 = year26.getFirstMillisecond();
//        long long31 = year26.getLastMillisecond();
//        long long32 = year26.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-31507200000L) + "'", long30 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28799999L + "'", long31 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1969L + "'", long32 == 1969L);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (double) 8);
//        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue5.getPeriod();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod6, "org.jfree.data.general.SeriesChangeEvent[source=12-June-2019]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.removePropertyChangeListener(propertyChangeListener10);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(timePeriod6);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getMiddleMillisecond();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
        java.lang.Number number4 = timePeriodValue3.getValue();
        java.lang.Object obj5 = null;
        boolean boolean6 = timePeriodValue3.equals(obj5);
        timePeriodValue3.setValue((java.lang.Number) (short) -1);
        java.lang.Number number9 = timePeriodValue3.getValue();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) -1 + "'", number9.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriod10);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 11);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, 1.0d);
//        long long10 = day6.getMiddleMillisecond();
//        int int11 = day6.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int15 = day6.compareTo((java.lang.Object) simpleTimePeriod14);
//        boolean boolean16 = timePeriodValue3.equals((java.lang.Object) day6);
//        java.lang.Number number17 = timePeriodValue3.getValue();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long21 = simpleTimePeriod20.getEndMillis();
//        long long22 = simpleTimePeriod20.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long22);
//        int int24 = timePeriodValues23.getMinEndIndex();
//        boolean boolean25 = timePeriodValues23.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues23.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        int int33 = day29.getYear();
//        int int35 = day29.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) (byte) -1);
//        boolean boolean38 = timePeriodValue3.equals((java.lang.Object) day29);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,100]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.lang.Class<?> wildcardClass6 = simpleTimePeriod2.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        java.lang.Number number4 = timePeriodValue3.getValue();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) (short) 100);
//        long long11 = day6.getLastMillisecond();
//        long long12 = day6.getLastMillisecond();
//        java.lang.Object obj13 = null;
//        boolean boolean14 = day6.equals(obj13);
//        boolean boolean15 = timePeriodValue3.equals(obj13);
//        java.lang.String str16 = timePeriodValue3.toString();
//        java.lang.Object obj17 = timePeriodValue3.clone();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str16.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertNotNull(obj17);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (-31507200000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        java.lang.Object obj11 = timePeriodValues5.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues5.createCopy(7, (-1));
        boolean boolean15 = timePeriodValues14.getNotify();
        int int16 = timePeriodValues14.getMinStartIndex();
        timePeriodValues14.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("hi!");
        seriesException8.addSuppressed((java.lang.Throwable) seriesException10);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        int int13 = year0.compareTo((java.lang.Object) seriesException8);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        seriesException15.addSuppressed((java.lang.Throwable) seriesException17);
        java.lang.Throwable[] throwableArray19 = seriesException15.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.String str21 = seriesException15.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str21.equals("org.jfree.data.general.SeriesException: hi!"));
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int9 = day0.compareTo((java.lang.Object) simpleTimePeriod8);
//        long long10 = simpleTimePeriod8.getStartMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 13);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
//        long long17 = day13.getMiddleMillisecond();
//        java.util.Date date18 = day13.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        boolean boolean20 = timePeriodValue12.equals((java.lang.Object) day19);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = day19.getFirstMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560452399999L + "'", long17 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
//        timePeriodValues5.setNotify(false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long18 = simpleTimePeriod17.getEndMillis();
//        long long19 = simpleTimePeriod17.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long19);
//        int int21 = timePeriodValues20.getMinEndIndex();
//        boolean boolean22 = timePeriodValues20.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues20.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 1.0d);
//        int int30 = day26.getYear();
//        int int32 = day26.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (byte) -1);
//        java.lang.String str35 = timePeriodValues20.getDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timePeriodValues20.removeChangeListener(seriesChangeListener36);
//        boolean boolean38 = timePeriodValues5.equals((java.lang.Object) seriesChangeListener36);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        long long40 = day39.getFirstMillisecond();
//        java.lang.String str41 = day39.toString();
//        int int42 = day39.getMonth();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day39, (double) 2019);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        long long46 = year45.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.previous();
//        boolean boolean48 = day39.equals((java.lang.Object) regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNull(str35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "13-June-2019" + "'", str41.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getYear();
        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
        java.lang.String str20 = timePeriodValues5.getDescription();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        timePeriodValues5.setKey((java.lang.Comparable) day21);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (double) (byte) 0);
        java.util.Date date25 = day21.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day21.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (-1L));
//        int int7 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.next();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019L);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        java.lang.Number number6 = timePeriodValue4.getValue();
//        java.lang.Object obj7 = timePeriodValue4.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        boolean boolean13 = timePeriodValue11.equals((java.lang.Object) 11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, 1.0d);
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int23 = day14.compareTo((java.lang.Object) simpleTimePeriod22);
//        boolean boolean24 = timePeriodValue11.equals((java.lang.Object) day14);
//        long long25 = day14.getSerialIndex();
//        java.util.Date date26 = day14.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long30 = simpleTimePeriod29.getEndMillis();
//        long long31 = simpleTimePeriod29.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long31);
//        timePeriodValues32.setKey((java.lang.Comparable) 1L);
//        java.lang.String str35 = timePeriodValues32.getDomainDescription();
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        int int37 = timePeriodValues32.getMaxEndIndex();
//        timePeriodValues32.setDomainDescription("");
//        int int40 = day14.compareTo((java.lang.Object) timePeriodValues32);
//        boolean boolean41 = timePeriodValue4.equals((java.lang.Object) timePeriodValues32);
//        java.lang.Number number42 = timePeriodValue4.getValue();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2019L + "'", number5.equals(2019L));
//        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2019L + "'", number6.equals(2019L));
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 2019L + "'", number42.equals(2019L));
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        java.lang.Number number4 = timePeriodValue3.getValue();
//        timePeriodValue3.setValue((java.lang.Number) 97L);
//        java.lang.String str7 = timePeriodValue3.toString();
//        java.lang.Number number8 = timePeriodValue3.getValue();
//        timePeriodValue3.setValue((java.lang.Number) (-1.0d));
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[13-June-2019,97]" + "'", str7.equals("TimePeriodValue[13-June-2019,97]"));
//        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 97L + "'", number8.equals(97L));
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,3.0]");
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 11);
        java.lang.Number number6 = timePeriodValue3.getValue();
        java.lang.Number number7 = timePeriodValue3.getValue();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0d + "'", number7.equals(1.0d));
        org.junit.Assert.assertNotNull(timePeriod8);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        int int8 = day0.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date9 = day0.getEnd();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,97]");
        int int5 = year0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long7 = simpleTimePeriod6.getEndMillis();
        long long8 = simpleTimePeriod6.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long8);
        int int10 = timePeriodValues9.getMinEndIndex();
        boolean boolean11 = timePeriodValues9.isEmpty();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day12, (double) 10.0f);
        timePeriodValues9.setNotify(false);
        timePeriodValues9.setRangeDescription("Time");
        java.lang.String str21 = timePeriodValues9.getDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long25 = simpleTimePeriod24.getEndMillis();
        long long26 = simpleTimePeriod24.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long26);
        int int28 = timePeriodValues27.getMinEndIndex();
        boolean boolean29 = timePeriodValues27.isEmpty();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.next();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day30, (double) 10.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, 0.0d);
        org.jfree.data.time.TimePeriod timePeriod37 = timePeriodValue36.getPeriod();
        timePeriodValues9.add(timePeriodValue36);
        int int39 = day3.compareTo((java.lang.Object) timePeriodValue36);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timePeriod37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.general.SeriesChangeEvent[source=12-June-2019]", "13-June-2019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "13-June-2019");
//        boolean boolean6 = timePeriodValues5.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues5.addPropertyChangeListener(propertyChangeListener7);
//        boolean boolean9 = timePeriodValues5.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues5.addChangeListener(seriesChangeListener10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        java.lang.String str4 = day2.toString();
//        long long5 = day2.getFirstMillisecond();
//        int int6 = day2.getYear();
//        java.util.Date date7 = day2.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date7);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        java.lang.String str15 = day13.toString();
//        long long16 = day13.getFirstMillisecond();
//        int int17 = day13.getYear();
//        java.util.Date date18 = day13.getEnd();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date12, date18);
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date10, date21);
//        java.util.Date date23 = simpleTimePeriod22.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.util.Date date7 = year0.getEnd();
        java.util.Date date8 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("hi!");
        seriesException8.addSuppressed((java.lang.Throwable) seriesException10);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        int int13 = year0.compareTo((java.lang.Object) seriesException8);
        long long14 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,97]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setNotify(false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long18 = simpleTimePeriod17.getEndMillis();
        long long19 = simpleTimePeriod17.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long19);
        int int21 = timePeriodValues20.getMinEndIndex();
        boolean boolean22 = timePeriodValues20.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues20.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 1.0d);
        int int30 = day26.getYear();
        int int32 = day26.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (byte) -1);
        java.lang.String str35 = timePeriodValues20.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timePeriodValues20.removeChangeListener(seriesChangeListener36);
        boolean boolean38 = timePeriodValues5.equals((java.lang.Object) seriesChangeListener36);
        java.lang.String str39 = timePeriodValues5.getDomainDescription();
        int int40 = timePeriodValues5.getMinMiddleIndex();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        java.util.Date date42 = day41.getEnd();
        java.lang.Number number43 = null;
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day41, number43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day45.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day45, (java.lang.Number) 100L);
        timePeriodValues5.add(timePeriodValue49);
        java.lang.String str51 = timePeriodValues5.getDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Time" + "'", str39.equals("Time"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNull(str51);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 13-June-2019");
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int9 = day0.compareTo((java.lang.Object) simpleTimePeriod8);
//        boolean boolean11 = simpleTimePeriod8.equals((java.lang.Object) 1577865599999L);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
//        int int14 = simpleTimePeriod8.compareTo((java.lang.Object) regularTimePeriod13);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getYear();
        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
        java.lang.String str20 = timePeriodValues5.getDescription();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        timePeriodValues5.setKey((java.lang.Comparable) day21);
        int int23 = timePeriodValues5.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener24);
        int int26 = timePeriodValues5.getItemCount();
        boolean boolean27 = timePeriodValues5.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "2019", "Time");
        int int9 = timePeriodValues8.getMinEndIndex();
        java.lang.Object obj10 = timePeriodValues8.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener5);
        boolean boolean7 = timePeriodValues4.getNotify();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 1);
//        int int10 = timePeriodValues5.getMinMiddleIndex();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
//        int int14 = day11.getMonth();
//        long long15 = day11.getLastMillisecond();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = day11.equals(obj16);
//        int int19 = day11.compareTo((java.lang.Object) 1.0d);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long23 = simpleTimePeriod22.getEndMillis();
//        long long24 = simpleTimePeriod22.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long24);
//        int int26 = timePeriodValues25.getMinEndIndex();
//        boolean boolean27 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day28, (double) 10.0f);
//        timePeriodValues25.setDomainDescription("");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate36 = day35.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day35.next();
//        boolean boolean38 = timePeriodValues25.equals((java.lang.Object) day35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timePeriodValues25.addChangeListener(seriesChangeListener39);
//        java.lang.Object obj41 = timePeriodValues25.clone();
//        int int42 = day11.compareTo(obj41);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "Value", "org.jfree.data.general.SeriesChangeEvent[source=12-June-2019]");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        timePeriodValues10.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=12-June-2019]");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues5.createCopy((int) 'a', (int) (byte) 0);
        try {
            java.lang.Number number15 = timePeriodValues13.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setNotify(false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long18 = simpleTimePeriod17.getEndMillis();
        long long19 = simpleTimePeriod17.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long19);
        int int21 = timePeriodValues20.getMinEndIndex();
        boolean boolean22 = timePeriodValues20.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues20.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 1.0d);
        int int30 = day26.getYear();
        int int32 = day26.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (byte) -1);
        java.lang.String str35 = timePeriodValues20.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timePeriodValues20.removeChangeListener(seriesChangeListener36);
        boolean boolean38 = timePeriodValues5.equals((java.lang.Object) seriesChangeListener36);
        java.lang.String str39 = timePeriodValues5.getDomainDescription();
        int int40 = timePeriodValues5.getMinMiddleIndex();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        java.util.Date date42 = day41.getEnd();
        java.lang.Number number43 = null;
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day41, number43);
        timePeriodValues5.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        int int47 = timePeriodValues5.getItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Time" + "'", str39.equals("Time"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int9 = day0.compareTo((java.lang.Object) simpleTimePeriod8);
//        boolean boolean11 = simpleTimePeriod8.equals((java.lang.Object) 1577865599999L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        java.lang.String str14 = day12.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 10L);
//        int int17 = simpleTimePeriod8.compareTo((java.lang.Object) day12);
//        long long18 = day12.getSerialIndex();
//        int int19 = day12.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.previous();
//        java.util.Date date10 = day0.getEnd();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setDomainDescription("");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        boolean boolean18 = timePeriodValues5.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener19);
        java.lang.Object obj21 = timePeriodValues5.clone();
        java.lang.Comparable comparable22 = timePeriodValues5.getKey();
        timePeriodValues5.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1L) + "'", comparable22.equals((-1L)));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) 100);
        java.lang.Object obj5 = timePeriodValue4.clone();
        java.lang.Number number6 = timePeriodValue4.getValue();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues5.getMaxStartIndex();
        java.lang.String str14 = timePeriodValues5.getRangeDescription();
        int int15 = timePeriodValues5.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        java.lang.Object obj11 = timePeriodValues5.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues5.createCopy(7, (-1));
        boolean boolean15 = timePeriodValues14.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues14.removeChangeListener(seriesChangeListener16);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues14.createCopy((int) (byte) 10, 4);
        timePeriodValues14.setRangeDescription("Time");
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues14.createCopy((int) (short) 0, (int) (byte) 100);
        boolean boolean26 = timePeriodValues14.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.util.Date date7 = year0.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        java.lang.String str10 = year8.toString();
        java.lang.String str11 = year8.toString();
        java.lang.String str12 = year8.toString();
        long long13 = year8.getFirstMillisecond();
        int int14 = year0.compareTo((java.lang.Object) long13);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year0.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) 0);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue6);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, 1560365999999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getYear();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        java.lang.String str9 = day7.toString();
//        long long10 = day7.getFirstMillisecond();
//        int int11 = day7.getYear();
//        java.util.Date date12 = day7.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        java.util.Date date14 = regularTimePeriod13.getEnd();
//        boolean boolean15 = day0.equals((java.lang.Object) regularTimePeriod13);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, 1.0d);
//        java.lang.Object obj20 = timePeriodValue19.clone();
//        timePeriodValue19.setValue((java.lang.Number) (byte) 0);
//        boolean boolean23 = day0.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day0.previous();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        timePeriodValues10.setDomainDescription("13-June-2019");
        timePeriodValues10.fireSeriesChanged();
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        int int15 = timePeriodValues10.getMaxEndIndex();
        timePeriodValues10.setDescription("Value");
        int int18 = timePeriodValues10.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019L);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long4 = simpleTimePeriod3.getEndMillis();
//        long long5 = simpleTimePeriod3.getStartMillis();
//        java.util.Date date6 = simpleTimePeriod3.getStart();
//        java.util.Date date7 = simpleTimePeriod3.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        long long12 = day8.getMiddleMillisecond();
//        java.util.Date date13 = day8.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        java.lang.String str18 = day16.toString();
//        long long19 = day16.getFirstMillisecond();
//        int int20 = day16.getYear();
//        java.util.Date date21 = day16.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date13, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone22);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("Time");
//        int int29 = year26.compareTo((java.lang.Object) "Time");
//        long long30 = year26.getFirstMillisecond();
//        long long31 = year26.getLastMillisecond();
//        java.lang.String str32 = year26.toString();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-31507200000L) + "'", long30 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28799999L + "'", long31 == 28799999L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1969" + "'", str32.equals("1969"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        timePeriodValues10.setDomainDescription("13-June-2019");
        timePeriodValues10.fireSeriesChanged();
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        int int15 = timePeriodValues10.getMaxEndIndex();
        int int16 = timePeriodValues10.getItemCount();
        boolean boolean17 = timePeriodValues10.getNotify();
        int int18 = timePeriodValues10.getMinEndIndex();
        java.lang.Comparable comparable19 = timePeriodValues10.getKey();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
        seriesException21.addSuppressed((java.lang.Throwable) seriesException23);
        java.lang.Throwable[] throwableArray25 = seriesException21.getSuppressed();
        java.lang.String str26 = seriesException21.toString();
        java.lang.Throwable[] throwableArray27 = seriesException21.getSuppressed();
        boolean boolean28 = timePeriodValues10.equals((java.lang.Object) throwableArray27);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1L) + "'", comparable19.equals((-1L)));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str26.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getMonth();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) -1);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 4);
        java.lang.Comparable comparable2 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 4 + "'", comparable2.equals(4));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener15);
        java.lang.Comparable comparable17 = timePeriodValues5.getKey();
        int int18 = timePeriodValues5.getMaxStartIndex();
        try {
            timePeriodValues5.delete(0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (-1L) + "'", comparable17.equals((-1L)));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int9 = day0.compareTo((java.lang.Object) simpleTimePeriod8);
//        java.lang.Class<?> wildcardClass10 = day0.getClass();
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        timePeriodValues5.setKey((java.lang.Comparable) 1L);
//        timePeriodValues5.setNotify(false);
//        int int10 = timePeriodValues5.getItemCount();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
//        boolean boolean16 = timePeriodValue14.equals((java.lang.Object) 11);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate18 = day17.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, 1.0d);
//        long long21 = day17.getMiddleMillisecond();
//        int int22 = day17.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int26 = day17.compareTo((java.lang.Object) simpleTimePeriod25);
//        boolean boolean27 = timePeriodValue14.equals((java.lang.Object) day17);
//        long long28 = day17.getSerialIndex();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        java.lang.Number number33 = timePeriodValue32.getValue();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = timePeriodValue32.equals(obj34);
//        timePeriodValue32.setValue((java.lang.Number) (short) -1);
//        int int38 = day17.compareTo((java.lang.Object) (short) -1);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1577865599999L);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day41, (double) (short) 100);
//        long long46 = day41.getLastMillisecond();
//        long long47 = day41.getLastMillisecond();
//        java.util.Date date48 = day41.getStart();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day41.previous();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.0d + "'", number33.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560495599999L + "'", long46 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560495599999L + "'", long47 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
//        int int15 = day11.getYear();
//        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
//        java.lang.String str20 = timePeriodValues5.getDescription();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = day21.toString();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day21, (double) 1577865599999L);
//        java.lang.String str26 = timePeriodValues5.getRangeDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long30 = simpleTimePeriod29.getEndMillis();
//        long long31 = simpleTimePeriod29.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long31);
//        int int33 = timePeriodValues32.getMinEndIndex();
//        boolean boolean34 = timePeriodValues32.isEmpty();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate36 = day35.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day35.next();
//        timePeriodValues32.add((org.jfree.data.time.TimePeriod) day35, (double) 10.0f);
//        timePeriodValues32.setDomainDescription("");
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
//        boolean boolean45 = timePeriodValues32.equals((java.lang.Object) day42);
//        java.util.Date date46 = day42.getStart();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
//        long long48 = year47.getFirstMillisecond();
//        long long49 = year47.getLastMillisecond();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year47, (double) (-1.0f));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1546329600000L + "'", long48 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
//        timePeriodValues5.setNotify(false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long18 = simpleTimePeriod17.getEndMillis();
//        long long19 = simpleTimePeriod17.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long19);
//        int int21 = timePeriodValues20.getMinEndIndex();
//        boolean boolean22 = timePeriodValues20.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues20.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 1.0d);
//        int int30 = day26.getYear();
//        int int32 = day26.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (byte) -1);
//        java.lang.String str35 = timePeriodValues20.getDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timePeriodValues20.removeChangeListener(seriesChangeListener36);
//        boolean boolean38 = timePeriodValues5.equals((java.lang.Object) seriesChangeListener36);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        long long40 = day39.getFirstMillisecond();
//        java.lang.String str41 = day39.toString();
//        int int42 = day39.getMonth();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day39, (double) 2019);
//        int int45 = timePeriodValues5.getItemCount();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNull(str35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "13-June-2019" + "'", str41.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        java.lang.String str4 = day2.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        java.lang.String str4 = day2.toString();
//        long long5 = day2.getFirstMillisecond();
//        int int6 = day2.getYear();
//        java.util.Date date7 = day2.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date7);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        java.lang.String str15 = day13.toString();
//        long long16 = day13.getFirstMillisecond();
//        int int17 = day13.getYear();
//        java.util.Date date18 = day13.getEnd();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date12, date18);
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date10, date21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date10);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
//        java.lang.String str27 = day25.toString();
//        long long28 = day25.getFirstMillisecond();
//        int int29 = day25.getYear();
//        java.util.Date date30 = day25.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, 1.0d);
//        long long37 = day33.getMiddleMillisecond();
//        java.util.Date date38 = day33.getEnd();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        java.lang.String str43 = day41.toString();
//        long long44 = day41.getFirstMillisecond();
//        int int45 = day41.getYear();
//        java.util.Date date46 = day41.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date46, timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date38, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date30, timeZone47);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date10, timeZone47);
//        int int52 = year51.getYear();
//        long long53 = year51.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560409200000L + "'", long28 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560452399999L + "'", long37 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560409200000L + "'", long44 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2019L + "'", long53 == 2019L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        int int11 = timePeriodValues10.getMaxStartIndex();
        timePeriodValues10.setDescription("Time");
        int int14 = timePeriodValues10.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(97L, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getYear();
        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
        org.jfree.data.time.SerialDate serialDate20 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(serialDate20);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019L);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        java.lang.Number number6 = timePeriodValue4.getValue();
//        java.lang.Object obj7 = timePeriodValue4.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        boolean boolean13 = timePeriodValue11.equals((java.lang.Object) 11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, 1.0d);
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int23 = day14.compareTo((java.lang.Object) simpleTimePeriod22);
//        boolean boolean24 = timePeriodValue11.equals((java.lang.Object) day14);
//        long long25 = day14.getSerialIndex();
//        java.util.Date date26 = day14.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long30 = simpleTimePeriod29.getEndMillis();
//        long long31 = simpleTimePeriod29.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long31);
//        timePeriodValues32.setKey((java.lang.Comparable) 1L);
//        java.lang.String str35 = timePeriodValues32.getDomainDescription();
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        int int37 = timePeriodValues32.getMaxEndIndex();
//        timePeriodValues32.setDomainDescription("");
//        int int40 = day14.compareTo((java.lang.Object) timePeriodValues32);
//        boolean boolean41 = timePeriodValue4.equals((java.lang.Object) timePeriodValues32);
//        java.lang.String str42 = timePeriodValues32.getDomainDescription();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2019L + "'", number5.equals(2019L));
//        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2019L + "'", number6.equals(2019L));
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 0.0d);
//        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
//        java.lang.String str16 = timePeriodValue14.toString();
//        java.lang.Class<?> wildcardClass17 = timePeriodValue14.getClass();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(timePeriod15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,0.0]" + "'", str16.equals("TimePeriodValue[13-June-2019,0.0]"));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long7 = simpleTimePeriod6.getEndMillis();
//        long long8 = simpleTimePeriod6.getStartMillis();
//        java.util.Date date9 = simpleTimePeriod6.getStart();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getStartMillis();
//        java.util.Date date16 = simpleTimePeriod13.getStart();
//        java.util.Date date17 = simpleTimePeriod13.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, 1.0d);
//        long long22 = day18.getMiddleMillisecond();
//        java.util.Date date23 = day18.getEnd();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
//        java.lang.String str28 = day26.toString();
//        long long29 = day26.getFirstMillisecond();
//        int int30 = day26.getYear();
//        java.util.Date date31 = day26.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date31, timeZone32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date23, timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date17, timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone32);
//        java.util.Date date37 = regularTimePeriod36.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod36);
//        java.lang.String str39 = seriesChangeEvent38.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560452399999L + "'", long22 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=31-December-1969]" + "'", str39.equals("org.jfree.data.general.SeriesChangeEvent[source=31-December-1969]"));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(97L, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        long long8 = day7.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 1);
        long long10 = year7.getFirstMillisecond();
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
        long long13 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long10 = simpleTimePeriod9.getEndMillis();
        long long11 = simpleTimePeriod9.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long11);
        int int13 = timePeriodValues12.getMinEndIndex();
        boolean boolean14 = timePeriodValues12.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues12.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, 1.0d);
        int int22 = day18.getYear();
        int int24 = day18.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day18.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod27);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) 0);
        java.lang.Comparable comparable31 = timePeriodValues5.getKey();
        timePeriodValues5.delete(100, 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (-1L) + "'", comparable31.equals((-1L)));
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        java.lang.String str6 = day4.toString();
//        long long7 = day4.getFirstMillisecond();
//        int int8 = day4.getYear();
//        java.util.Date date9 = day4.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
//        long long15 = day11.getMiddleMillisecond();
//        java.util.Date date16 = day11.getEnd();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        java.lang.String str21 = day19.toString();
//        long long22 = day19.getFirstMillisecond();
//        int int23 = day19.getYear();
//        java.util.Date date24 = day19.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date24, timeZone25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date16, timeZone25);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date9, timeZone25);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
//        java.lang.String str33 = day31.toString();
//        long long34 = day31.getFirstMillisecond();
//        int int35 = day31.getYear();
//        int int36 = day31.getMonth();
//        boolean boolean37 = year30.equals((java.lang.Object) day31);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560409200000L + "'", long34 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, 100L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
//        int int15 = day11.getYear();
//        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
//        java.lang.String str20 = timePeriodValues5.getDescription();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = day21.toString();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day21, (double) 1577865599999L);
//        java.lang.String str26 = timePeriodValues5.getRangeDescription();
//        timePeriodValues5.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        java.lang.Object obj33 = timePeriodValue32.clone();
//        timePeriodValue32.setValue((java.lang.Number) 12);
//        timePeriodValue32.setValue((java.lang.Number) 1.0f);
//        timePeriodValues5.add(timePeriodValue32);
//        org.jfree.data.time.TimePeriod timePeriod39 = timePeriodValue32.getPeriod();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertNotNull(timePeriod39);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
//        java.lang.Object obj11 = timePeriodValues5.clone();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        int int15 = day12.getMonth();
//        long long16 = day12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day12, "", "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day12.previous();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day12, (double) (-31507200000L));
//        int int24 = timePeriodValues5.getMinStartIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 12, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) 100);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getLastMillisecond();
//        java.util.Date date7 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1562097599999L);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 11);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, 1.0d);
//        long long10 = day6.getMiddleMillisecond();
//        int int11 = day6.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int15 = day6.compareTo((java.lang.Object) simpleTimePeriod14);
//        boolean boolean16 = timePeriodValue3.equals((java.lang.Object) day6);
//        long long17 = day6.getSerialIndex();
//        java.util.Date date18 = day6.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long22 = simpleTimePeriod21.getEndMillis();
//        long long23 = simpleTimePeriod21.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long23);
//        timePeriodValues24.setKey((java.lang.Comparable) 1L);
//        java.lang.String str27 = timePeriodValues24.getDomainDescription();
//        java.lang.String str28 = timePeriodValues24.getDomainDescription();
//        int int29 = timePeriodValues24.getMaxEndIndex();
//        timePeriodValues24.setDomainDescription("");
//        int int32 = day6.compareTo((java.lang.Object) timePeriodValues24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day6.next();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
//        java.lang.String str13 = day8.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getYear();
        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
        java.lang.String str20 = timePeriodValues5.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener21);
        boolean boolean23 = timePeriodValues5.isEmpty();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue25 = timePeriodValues5.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long4 = simpleTimePeriod3.getEndMillis();
//        long long5 = simpleTimePeriod3.getStartMillis();
//        java.util.Date date6 = simpleTimePeriod3.getStart();
//        java.util.Date date7 = simpleTimePeriod3.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        long long12 = day8.getMiddleMillisecond();
//        java.util.Date date13 = day8.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        java.lang.String str18 = day16.toString();
//        long long19 = day16.getFirstMillisecond();
//        int int20 = day16.getYear();
//        java.util.Date date21 = day16.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date13, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        java.util.Date date29 = simpleTimePeriod28.getEnd();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date7, date29);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate33 = day32.getSerialDate();
//        java.lang.String str34 = day32.toString();
//        long long35 = day32.getFirstMillisecond();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate37 = day36.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day36.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day36, (double) (short) 100);
//        long long41 = day36.getLastMillisecond();
//        long long42 = day36.getLastMillisecond();
//        long long43 = day36.getLastMillisecond();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long47 = simpleTimePeriod46.getEndMillis();
//        long long48 = simpleTimePeriod46.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long48);
//        int int50 = timePeriodValues49.getMinEndIndex();
//        boolean boolean51 = timePeriodValues49.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = timePeriodValues49.createCopy((-1), (int) (short) -1);
//        boolean boolean55 = day36.equals((java.lang.Object) timePeriodValues49);
//        int int56 = day32.compareTo((java.lang.Object) day36);
//        int int57 = simpleTimePeriod31.compareTo((java.lang.Object) day36);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560495599999L + "'", long41 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560495599999L + "'", long42 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560495599999L + "'", long43 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 97L + "'", long47 == 97L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-1L) + "'", long48 == (-1L));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setDomainDescription("");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        boolean boolean18 = timePeriodValues5.equals((java.lang.Object) day15);
        java.util.Date date19 = day15.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getFirstMillisecond();
        long long22 = year20.getLastMillisecond();
        long long23 = year20.getLastMillisecond();
        java.lang.String str24 = year20.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long5 = simpleTimePeriod4.getEndMillis();
//        long long6 = simpleTimePeriod4.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long6);
//        int int8 = timePeriodValues7.getMinEndIndex();
//        boolean boolean9 = timePeriodValues7.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues7.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
//        int int17 = day13.getYear();
//        int int19 = day13.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) (byte) -1);
//        java.lang.String str22 = timePeriodValues7.getDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
//        java.lang.String str25 = day23.toString();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day23, (double) 1577865599999L);
//        int int28 = timePeriodValues7.getMaxStartIndex();
//        boolean boolean29 = year0.equals((java.lang.Object) timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        long long4 = day0.getMiddleMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        java.lang.Class<?> wildcardClass6 = day0.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
//        java.lang.String str11 = day9.toString();
//        long long12 = day9.getFirstMillisecond();
//        int int13 = day9.getYear();
//        java.util.Date date14 = day9.getEnd();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date8, date14);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
//        java.lang.String str20 = day18.toString();
//        long long21 = day18.getFirstMillisecond();
//        int int22 = day18.getYear();
//        java.util.Date date23 = day18.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date8, timeZone24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getEnd();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        java.lang.String str32 = day30.toString();
//        long long33 = day30.getFirstMillisecond();
//        int int34 = day30.getYear();
//        java.util.Date date35 = day30.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day30.next();
//        java.util.Date date37 = regularTimePeriod36.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long41 = simpleTimePeriod40.getStartMillis();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day42, 1.0d);
//        long long46 = day42.getMiddleMillisecond();
//        java.util.Date date47 = day42.getEnd();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
//        java.lang.Class class49 = null;
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate51 = day50.getSerialDate();
//        java.lang.String str52 = day50.toString();
//        long long53 = day50.getFirstMillisecond();
//        int int54 = day50.getYear();
//        java.util.Date date55 = day50.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date55, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date47, timeZone56);
//        boolean boolean59 = simpleTimePeriod40.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date37, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date28, timeZone56);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date28);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560452399999L + "'", long46 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "13-June-2019" + "'", str52.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560409200000L + "'", long53 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long4 = simpleTimePeriod3.getEndMillis();
//        long long5 = simpleTimePeriod3.getStartMillis();
//        java.util.Date date6 = simpleTimePeriod3.getStart();
//        java.util.Date date7 = simpleTimePeriod3.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        long long12 = day8.getMiddleMillisecond();
//        java.util.Date date13 = day8.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        java.lang.String str18 = day16.toString();
//        long long19 = day16.getFirstMillisecond();
//        int int20 = day16.getYear();
//        java.util.Date date21 = day16.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date13, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        java.util.Date date29 = simpleTimePeriod28.getEnd();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date7, date29);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod2);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 1);
        long long10 = year7.getFirstMillisecond();
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year7.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 11);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, 1.0d);
//        long long10 = day6.getMiddleMillisecond();
//        int int11 = day6.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int15 = day6.compareTo((java.lang.Object) simpleTimePeriod14);
//        boolean boolean16 = timePeriodValue3.equals((java.lang.Object) day6);
//        int int17 = day6.getMonth();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day6.equals(obj18);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 3);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getEnd();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        java.lang.String str5 = day3.toString();
//        long long6 = day3.getFirstMillisecond();
//        int int7 = day3.getYear();
//        java.util.Date date8 = day3.getEnd();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date2, date8);
//        java.util.Date date11 = simpleTimePeriod10.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getSerialIndex();
//        long long17 = year15.getFirstMillisecond();
//        long long18 = year15.getMiddleMillisecond();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
//        java.lang.String str22 = day20.toString();
//        long long23 = day20.getFirstMillisecond();
//        int int24 = day20.getYear();
//        java.util.Date date25 = day20.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date25, timeZone26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, 1.0d);
//        long long32 = day28.getMiddleMillisecond();
//        java.util.Date date33 = day28.getEnd();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate37 = day36.getSerialDate();
//        java.lang.String str38 = day36.toString();
//        long long39 = day36.getFirstMillisecond();
//        int int40 = day36.getYear();
//        java.util.Date date41 = day36.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date41, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date33, timeZone42);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date25, timeZone42);
//        boolean boolean46 = year15.equals((java.lang.Object) timeZone42);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date13, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date11, timeZone42);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560452399999L + "'", long32 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-June-2019" + "'", str38.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560409200000L + "'", long39 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
//        int int15 = day11.getYear();
//        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day11.previous();
//        int int22 = day11.compareTo((java.lang.Object) 0L);
//        java.util.Date date23 = day11.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day11);
//        java.lang.String str25 = seriesChangeEvent24.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str25.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.general.SeriesChangeEvent[source=12-June-2019]", "13-June-2019");
//        long long5 = day0.getFirstMillisecond();
//        int int6 = day0.getMonth();
//        long long7 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        int int11 = timePeriodValues10.getMaxStartIndex();
        int int12 = timePeriodValues10.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getMonth();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day11, 0.0d);
        int int18 = timePeriodValues10.getMinEndIndex();
        timePeriodValues10.fireSeriesChanged();
        timePeriodValues10.setNotify(false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        int int11 = timePeriodValues10.getMaxMiddleIndex();
        boolean boolean12 = timePeriodValues10.isEmpty();
        int int13 = timePeriodValues10.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        java.lang.Object obj11 = timePeriodValues5.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues5.createCopy(7, (-1));
        int int15 = timePeriodValues14.getItemCount();
        int int16 = timePeriodValues14.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 11);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, 1.0d);
//        long long10 = day6.getMiddleMillisecond();
//        int int11 = day6.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        int int15 = day6.compareTo((java.lang.Object) simpleTimePeriod14);
//        boolean boolean16 = timePeriodValue3.equals((java.lang.Object) day6);
//        java.lang.Number number17 = timePeriodValue3.getValue();
//        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue3.getPeriod();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue(timePeriod18, (java.lang.Number) 1.0d);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod18);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        java.lang.String str4 = day2.toString();
//        long long5 = day2.getFirstMillisecond();
//        int int6 = day2.getYear();
//        java.util.Date date7 = day2.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date7);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        java.lang.String str15 = day13.toString();
//        long long16 = day13.getFirstMillisecond();
//        int int17 = day13.getYear();
//        java.util.Date date18 = day13.getEnd();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date12, date18);
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date10, date21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date10);
//        java.util.Calendar calendar24 = null;
//        try {
//            year23.peg(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(97L, (long) 'a');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 100);
        java.lang.Object obj5 = null;
        boolean boolean6 = simpleTimePeriod2.equals(obj5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long10 = simpleTimePeriod9.getEndMillis();
        long long11 = simpleTimePeriod9.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long11);
        int int13 = timePeriodValues12.getMinEndIndex();
        boolean boolean14 = timePeriodValues12.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues12.createCopy((-1), (int) (short) -1);
        int int18 = timePeriodValues17.getMaxMiddleIndex();
        int int19 = timePeriodValues17.getMaxEndIndex();
        timePeriodValues17.setRangeDescription("TimePeriodValue[13-June-2019,97]");
        try {
            int int22 = simpleTimePeriod2.compareTo((java.lang.Object) "TimePeriodValue[13-June-2019,97]");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        boolean boolean8 = timePeriodValues5.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues5.createCopy((int) (short) 0, (int) '4');
        int int12 = timePeriodValues11.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 1);
        int int10 = timePeriodValues5.getMinMiddleIndex();
        timePeriodValues5.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener13);
        java.lang.Object obj15 = timePeriodValues5.clone();
        java.lang.Comparable comparable16 = timePeriodValues5.getKey();
        int int17 = timePeriodValues5.getMaxMiddleIndex();
        java.lang.String str18 = timePeriodValues5.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (-1L) + "'", comparable16.equals((-1L)));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
        java.lang.Number number4 = timePeriodValue3.getValue();
        java.lang.Object obj5 = null;
        boolean boolean6 = timePeriodValue3.equals(obj5);
        timePeriodValue3.setValue((java.lang.Number) (short) -1);
        java.lang.Number number9 = timePeriodValue3.getValue();
        timePeriodValue3.setValue((java.lang.Number) 3);
        java.lang.Object obj12 = timePeriodValue3.clone();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) -1 + "'", number9.equals((short) -1));
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        java.lang.String str4 = day2.toString();
//        long long5 = day2.getFirstMillisecond();
//        int int6 = day2.getYear();
//        java.util.Date date7 = day2.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long14 = simpleTimePeriod13.getEndMillis();
//        java.util.Date date15 = simpleTimePeriod13.getEnd();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date1, date15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
        int int15 = day11.getYear();
        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
        java.lang.String str20 = timePeriodValues5.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long26 = simpleTimePeriod25.getEndMillis();
        long long27 = simpleTimePeriod25.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long27);
        int int29 = timePeriodValues28.getMinEndIndex();
        boolean boolean30 = timePeriodValues28.isEmpty();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day31, (double) 10.0f);
        timePeriodValues28.setDomainDescription("");
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day38.next();
        boolean boolean41 = timePeriodValues28.equals((java.lang.Object) day38);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day38, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener44);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener46);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues8.addChangeListener(seriesChangeListener9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getSerialIndex();
//        long long13 = year11.getFirstMillisecond();
//        java.lang.String str14 = year11.toString();
//        java.util.Date date15 = year11.getEnd();
//        java.lang.String str16 = year11.toString();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year11, (double) 1577865599999L);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = year11.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        timePeriodValues5.setKey((java.lang.Comparable) 1L);
        java.lang.String str8 = timePeriodValues5.getDomainDescription();
        java.lang.String str9 = timePeriodValues5.getDomainDescription();
        int int10 = timePeriodValues5.getMaxEndIndex();
        try {
            timePeriodValues5.delete((int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setDomainDescription("");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        boolean boolean18 = timePeriodValues5.equals((java.lang.Object) day15);
        boolean boolean19 = timePeriodValues5.getNotify();
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues5.equals(obj20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        java.lang.String str5 = day3.toString();
//        long long6 = day3.getFirstMillisecond();
//        int int7 = day3.getYear();
//        java.util.Date date8 = day3.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long13 = simpleTimePeriod12.getEndMillis();
//        long long14 = simpleTimePeriod12.getStartMillis();
//        java.util.Date date15 = simpleTimePeriod12.getStart();
//        java.util.Date date16 = simpleTimePeriod12.getStart();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
//        java.lang.String str24 = day22.toString();
//        long long25 = day22.getFirstMillisecond();
//        int int26 = day22.getYear();
//        java.util.Date date27 = day22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date21, date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        long long33 = day29.getMiddleMillisecond();
//        java.util.Date date34 = day29.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
//        java.lang.String str39 = day37.toString();
//        long long40 = day37.getFirstMillisecond();
//        int int41 = day37.getYear();
//        java.util.Date date42 = day37.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date42, timeZone43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date34, timeZone43);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date27, timeZone43);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate48 = day47.getSerialDate();
//        java.lang.Class<?> wildcardClass49 = day47.getClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.util.Date date52 = day51.getEnd();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
//        java.lang.String str55 = day53.toString();
//        long long56 = day53.getFirstMillisecond();
//        int int57 = day53.getYear();
//        java.util.Date date58 = day53.getEnd();
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date52, date58);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        java.util.Date date64 = simpleTimePeriod63.getEnd();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate66 = day65.getSerialDate();
//        java.lang.String str67 = day65.toString();
//        long long68 = day65.getFirstMillisecond();
//        int int69 = day65.getYear();
//        java.util.Date date70 = day65.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod(date64, date70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate73 = day72.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue75 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day72, 1.0d);
//        long long76 = day72.getMiddleMillisecond();
//        java.util.Date date77 = day72.getEnd();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date77);
//        java.lang.Class class79 = null;
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate81 = day80.getSerialDate();
//        java.lang.String str82 = day80.toString();
//        long long83 = day80.getFirstMillisecond();
//        int int84 = day80.getYear();
//        java.util.Date date85 = day80.getEnd();
//        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class79, date85, timeZone86);
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date77, timeZone86);
//        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date70, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date52, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date27, timeZone86);
//        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date16, timeZone86);
//        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date8, timeZone86);
//        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date8);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560452399999L + "'", long33 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "13-June-2019" + "'", str55.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560409200000L + "'", long56 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "13-June-2019" + "'", str67.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560409200000L + "'", long68 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560452399999L + "'", long76 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "13-June-2019" + "'", str82.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560409200000L + "'", long83 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 2019 + "'", int84 == 2019);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(timeZone86);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        timePeriodValues5.setKey((java.lang.Comparable) 1L);
        timePeriodValues5.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues5.createCopy((-1), (int) (short) 10);
        int int13 = timePeriodValues5.getMinMiddleIndex();
        try {
            java.lang.Number number15 = timePeriodValues5.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(97L, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        java.lang.String str8 = day6.toString();
//        long long9 = day6.getFirstMillisecond();
//        int int10 = day6.getYear();
//        java.util.Date date11 = day6.getEnd();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date5, date11);
//        java.util.Date date14 = simpleTimePeriod13.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
//        java.lang.Class<?> wildcardClass17 = day15.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = day21.toString();
//        long long24 = day21.getFirstMillisecond();
//        int int25 = day21.getYear();
//        java.util.Date date26 = day21.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date20, date26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        java.util.Date date32 = simpleTimePeriod31.getEnd();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
//        java.lang.String str35 = day33.toString();
//        long long36 = day33.getFirstMillisecond();
//        int int37 = day33.getYear();
//        java.util.Date date38 = day33.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date32, date38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day40, 1.0d);
//        long long44 = day40.getMiddleMillisecond();
//        java.util.Date date45 = day40.getEnd();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
//        java.lang.String str50 = day48.toString();
//        long long51 = day48.getFirstMillisecond();
//        int int52 = day48.getYear();
//        java.util.Date date53 = day48.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date53, timeZone54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date45, timeZone54);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date38, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone54);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date14, timeZone54);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date3, timeZone54);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560452399999L + "'", long44 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "13-June-2019" + "'", str50.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560409200000L + "'", long51 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long6 = simpleTimePeriod5.getEndMillis();
        long long7 = simpleTimePeriod5.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long7);
        int int9 = timePeriodValues8.getMinEndIndex();
        boolean boolean10 = timePeriodValues8.isEmpty();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day11, (double) 10.0f);
        timePeriodValues8.setNotify(false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long21 = simpleTimePeriod20.getEndMillis();
        long long22 = simpleTimePeriod20.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long22);
        int int24 = timePeriodValues23.getMinEndIndex();
        boolean boolean25 = timePeriodValues23.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues23.createCopy((-1), (int) (short) -1);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
        int int33 = day29.getYear();
        int int35 = day29.compareTo((java.lang.Object) 1577865599999L);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) (byte) -1);
        java.lang.String str38 = timePeriodValues23.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
        timePeriodValues23.removeChangeListener(seriesChangeListener39);
        boolean boolean41 = timePeriodValues8.equals((java.lang.Object) seriesChangeListener39);
        java.lang.String str42 = timePeriodValues8.getDomainDescription();
        int int43 = timePeriodValues8.getMinMiddleIndex();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        java.util.Date date45 = day44.getEnd();
        java.lang.Number number46 = null;
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day44, number46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day48.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 100L);
        timePeriodValues8.add(timePeriodValue52);
        boolean boolean54 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues8);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(timePeriodValues28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        boolean boolean7 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy((-1), (int) (short) -1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 1.0d);
//        int int15 = day11.getYear();
//        int int17 = day11.compareTo((java.lang.Object) 1577865599999L);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) -1);
//        java.lang.String str20 = timePeriodValues5.getDescription();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = day21.toString();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day21, (double) 1577865599999L);
//        java.lang.String str26 = timePeriodValues5.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues5.addPropertyChangeListener(propertyChangeListener27);
//        int int29 = timePeriodValues5.getMaxMiddleIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getMonth();
//        java.lang.Object obj4 = null;
//        int int5 = day0.compareTo(obj4);
//        int int6 = day0.getDayOfMonth();
//        long long7 = day0.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            day0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 'a');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
        int int6 = timePeriodValues5.getMinEndIndex();
        boolean boolean7 = timePeriodValues5.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (double) 10.0f);
        timePeriodValues5.setNotify(false);
        boolean boolean15 = timePeriodValues5.getNotify();
        java.lang.Comparable comparable16 = null;
        try {
            timePeriodValues5.setKey(comparable16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }
}

