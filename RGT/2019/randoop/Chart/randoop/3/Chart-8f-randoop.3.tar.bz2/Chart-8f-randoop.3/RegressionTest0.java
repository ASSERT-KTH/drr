import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test010");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test013");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            week0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week2.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.Locale locale12 = null;
//        try {
//            org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date3, timeZone10, locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.util.TimeZone timeZone6 = null;
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(year2);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            week0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week5.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date0, timeZone5, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        int int7 = week5.getYearValue();
//        java.util.Calendar calendar8 = null;
//        try {
//            week5.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2020 + "'", int7 == 2020);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week5.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2020 + "'", int7 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        int int2 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        java.lang.String str14 = week0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 2020");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week0.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, (int) (short) 1);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone16);
//        long long19 = regularTimePeriod18.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577908799999L + "'", long19 == 1577908799999L);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = week5.getEnd();
//        long long9 = week5.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577908799999L + "'", long9 == 1577908799999L);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week5.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.Throwable throwable7 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        boolean boolean8 = week6.equals((java.lang.Object) 10.0d);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        java.util.TimeZone timeZone6 = null;
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass7 = week5.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Date date7 = week5.getStart();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week5.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        long long21 = week19.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass22 = week19.getClass();
//        java.lang.String str23 = week19.toString();
//        java.util.Date date24 = week19.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int27 = week26.getWeek();
//        long long28 = week26.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass29 = week26.getClass();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        int int31 = week30.getWeek();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        java.util.Date date33 = year32.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
//        long long36 = week35.getMiddleMillisecond();
//        java.util.Date date37 = week35.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        int int39 = week38.getWeek();
//        org.jfree.data.time.Year year40 = week38.getYear();
//        java.util.Date date41 = year40.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date37, timeZone42);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date24, timeZone42);
//        java.lang.Class<?> wildcardClass46 = date24.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        int int48 = week47.getWeek();
//        org.jfree.data.time.Year year49 = week47.getYear();
//        java.util.Date date50 = year49.getEnd();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date50);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date50, timeZone52);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        int int55 = week54.getWeek();
//        long long56 = week54.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass57 = week54.getClass();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        int int59 = week58.getWeek();
//        org.jfree.data.time.Year year60 = week58.getYear();
//        java.util.Date date61 = year60.getEnd();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date61, timeZone62);
//        long long64 = week63.getMiddleMillisecond();
//        java.util.Date date65 = week63.getStart();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        int int67 = week66.getWeek();
//        org.jfree.data.time.Year year68 = week66.getYear();
//        java.util.Date date69 = year68.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date69, timeZone70);
//        java.lang.Class<?> wildcardClass72 = week71.getClass();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        int int74 = week73.getWeek();
//        org.jfree.data.time.Year year75 = week73.getYear();
//        java.util.Date date76 = year75.getEnd();
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week();
//        int int78 = week77.getWeek();
//        long long79 = week77.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass80 = week77.getClass();
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week();
//        int int82 = week81.getWeek();
//        org.jfree.data.time.Year year83 = week81.getYear();
//        java.util.Date date84 = year83.getEnd();
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date84, timeZone85);
//        long long87 = week86.getMiddleMillisecond();
//        java.util.Date date88 = week86.getStart();
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week();
//        int int90 = week89.getWeek();
//        org.jfree.data.time.Year year91 = week89.getYear();
//        java.util.Date date92 = year91.getEnd();
//        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date92, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date88, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date76, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date65, timeZone93);
//        org.jfree.data.time.Week week98 = new org.jfree.data.time.Week(date50, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod99 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date24, timeZone93);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577908799999L + "'", long36 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 24 + "'", int39 == 24);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 24 + "'", int55 == 24);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560063600000L + "'", long56 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 24 + "'", int59 == 24);
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577908799999L + "'", long64 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 24 + "'", int67 == 24);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 24 + "'", int74 == 24);
//        org.junit.Assert.assertNotNull(year75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 24 + "'", int78 == 24);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560063600000L + "'", long79 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass80);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 24 + "'", int82 == 24);
//        org.junit.Assert.assertNotNull(year83);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1577908799999L + "'", long87 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 24 + "'", int90 == 24);
//        org.junit.Assert.assertNotNull(year91);
//        org.junit.Assert.assertNotNull(date92);
//        org.junit.Assert.assertNotNull(timeZone93);
//        org.junit.Assert.assertNotNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//        org.junit.Assert.assertNotNull(regularTimePeriod97);
//        org.junit.Assert.assertNotNull(regularTimePeriod99);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = week17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        long long25 = week23.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        long long33 = week32.getMiddleMillisecond();
//        java.util.Date date34 = week32.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone39);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        int int46 = week45.getWeek();
//        org.jfree.data.time.Year year47 = week45.getYear();
//        java.util.Date date48 = year47.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date48);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        int int51 = week50.getWeek();
//        long long52 = week50.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass53 = week50.getClass();
//        java.lang.String str54 = week50.toString();
//        java.util.Date date55 = week50.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        int int58 = week57.getWeek();
//        long long59 = week57.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass60 = week57.getClass();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        int int62 = week61.getWeek();
//        org.jfree.data.time.Year year63 = week61.getYear();
//        java.util.Date date64 = year63.getEnd();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date64, timeZone65);
//        long long67 = week66.getMiddleMillisecond();
//        java.util.Date date68 = week66.getStart();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        int int70 = week69.getWeek();
//        org.jfree.data.time.Year year71 = week69.getYear();
//        java.util.Date date72 = year71.getEnd();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date72, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date68, timeZone73);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date55, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date48, timeZone73);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577908799999L + "'", long33 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 24 + "'", int51 == 24);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560063600000L + "'", long52 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Week 24, 2019" + "'", str54.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 24 + "'", int58 == 24);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560063600000L + "'", long59 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 24 + "'", int62 == 24);
//        org.junit.Assert.assertNotNull(year63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1577908799999L + "'", long67 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 24 + "'", int70 == 24);
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        int int6 = week1.compareTo((java.lang.Object) week3);
//        boolean boolean7 = week0.equals((java.lang.Object) week3);
//        java.lang.String str8 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        java.util.Calendar calendar15 = null;
//        try {
//            week5.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week13.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = week13.getFirstMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        java.util.Date date8 = week6.getEnd();
//        long long9 = week6.getLastMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            week6.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        long long7 = week6.getSerialIndex();
//        int int8 = week6.getYearValue();
//        long long9 = week6.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107016L + "'", long7 == 107016L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1551599999999L + "'", long9 == 1551599999999L);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        int int6 = week1.compareTo((java.lang.Object) week3);
//        boolean boolean7 = week0.equals((java.lang.Object) week3);
//        java.util.Date date8 = week3.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12, timeZone13);
//        java.util.Locale locale15 = null;
//        try {
//            org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date8, timeZone13, locale15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        long long6 = week2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 1, 2020");
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week7.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        int int8 = week7.getWeek();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week7.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        long long9 = week6.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week6.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1550995200000L + "'", long9 == 1550995200000L);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        int int9 = week5.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 10);
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getSerialIndex();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        int int9 = week4.compareTo((java.lang.Object) week6);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = week6.equals(obj10);
//        int int12 = week0.compareTo(obj10);
//        int int13 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) 10);
        java.util.Calendar calendar3 = null;
        try {
            week0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        org.jfree.data.time.Year year3 = week0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(year3);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        long long9 = week7.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        long long17 = week16.getMiddleMillisecond();
//        java.util.Date date18 = week16.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date5, timeZone23);
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = week26.getLastMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577908799999L + "'", long17 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        java.lang.Class<?> wildcardClass7 = week6.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getFirstMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week6.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1550995200000L + "'", long10 == 1550995200000L);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        long long9 = week5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107061L + "'", long9 == 107061L);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 2);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Date date7 = week5.getEnd();
//        java.util.Calendar calendar8 = null;
//        try {
//            week5.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week5.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        boolean boolean6 = week0.equals((java.lang.Object) 1551599999999L);
//        long long7 = week0.getSerialIndex();
//        java.util.Date date8 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        boolean boolean6 = week0.equals((java.lang.Object) 1551599999999L);
//        long long7 = week0.getSerialIndex();
//        boolean boolean9 = week0.equals((java.lang.Object) 24);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.util.Date date14 = week12.getStart();
//        int int15 = week5.compareTo((java.lang.Object) date14);
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date14, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date14);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = week18.getFirstMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(timeZone16);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) -1, year8);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577606400000L + "'", long7 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str16 = timePeriodFormatException15.toString();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str21 = timePeriodFormatException5.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 10, year8);
//        java.lang.String str10 = week9.toString();
//        long long11 = week9.getMiddleMillisecond();
//        java.lang.String str12 = week9.toString();
//        boolean boolean14 = week9.equals((java.lang.Object) 7);
//        java.util.Calendar calendar15 = null;
//        try {
//            week9.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577606400000L + "'", long7 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 10, 2020" + "'", str10.equals("Week 10, 2020"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1583351999999L + "'", long11 == 1583351999999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 10, 2020" + "'", str12.equals("Week 10, 2020"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week2.equals(obj6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
//        long long9 = week2.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        long long9 = week5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107061L + "'", long9 == 107061L);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = week9.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int16 = week15.getWeek();
//        long long17 = week15.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        long long25 = week24.getMiddleMillisecond();
//        java.util.Date date26 = week24.getStart();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date26, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        long long41 = week40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        int int43 = week42.getWeek();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        long long48 = week47.getMiddleMillisecond();
//        java.util.Date date49 = week47.getStart();
//        int int50 = week40.compareTo((java.lang.Object) date49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        int int53 = week51.compareTo((java.lang.Object) 10);
//        java.util.Date date54 = week51.getStart();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date49, timeZone55);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date3, timeZone55);
//        java.util.Calendar calendar59 = null;
//        try {
//            long long60 = week58.getFirstMillisecond(calendar59);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577908799999L + "'", long25 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577908799999L + "'", long41 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577908799999L + "'", long48 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) 10);
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 10);
//        java.util.Date date3 = week0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.util.Date date6 = week5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        long long8 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        int int6 = week1.compareTo((java.lang.Object) week3);
//        boolean boolean7 = week0.equals((java.lang.Object) week3);
//        java.util.Date date8 = week3.getStart();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week3.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week5.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        long long9 = week7.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        long long17 = week16.getMiddleMillisecond();
//        java.util.Date date18 = week16.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date5, timeZone23);
//        long long27 = week26.getMiddleMillisecond();
//        long long28 = week26.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577908799999L + "'", long17 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560365999999L + "'", long27 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 107031L + "'", long28 == 107031L);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        boolean boolean7 = week0.equals((java.lang.Object) "Week 10, 2020");
//        java.lang.String str8 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        long long17 = week13.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1578211199999L + "'", long17 == 1578211199999L);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        long long14 = week11.getLastMillisecond();
//        java.util.Date date15 = week11.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1551599999999L + "'", long14 == 1551599999999L);
//        org.junit.Assert.assertNotNull(date15);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date12, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int17 = week16.getWeek();
//        long long18 = week16.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass19 = week16.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        int int21 = week20.getWeek();
//        org.jfree.data.time.Year year22 = week20.getYear();
//        java.util.Date date23 = year22.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23, timeZone24);
//        long long26 = week25.getMiddleMillisecond();
//        java.util.Date date27 = week25.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getWeek();
//        org.jfree.data.time.Year year30 = week28.getYear();
//        java.util.Date date31 = year30.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date31, timeZone32);
//        java.lang.Class<?> wildcardClass34 = week33.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        int int40 = week39.getWeek();
//        long long41 = week39.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass42 = week39.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        int int44 = week43.getWeek();
//        org.jfree.data.time.Year year45 = week43.getYear();
//        java.util.Date date46 = year45.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date46, timeZone47);
//        long long49 = week48.getMiddleMillisecond();
//        java.util.Date date50 = week48.getStart();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        int int52 = week51.getWeek();
//        org.jfree.data.time.Year year53 = week51.getYear();
//        java.util.Date date54 = year53.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date50, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date27, timeZone55);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date12, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone55);
//        java.util.Date date62 = regularTimePeriod61.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577908799999L + "'", long26 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560063600000L + "'", long41 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 24 + "'", int44 == 24);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577908799999L + "'", long49 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 24 + "'", int52 == 24);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date62);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 10);
//        java.util.Date date3 = week0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.util.Date date6 = week5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int9 = week8.getWeek();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        java.util.Date date11 = year10.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = week17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        long long25 = week23.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        long long33 = week32.getMiddleMillisecond();
//        java.util.Date date34 = week32.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        int int44 = week43.getWeek();
//        org.jfree.data.time.Year year45 = week43.getYear();
//        java.util.Date date46 = year45.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date46, timeZone47);
//        long long49 = week48.getMiddleMillisecond();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        int int51 = week50.getWeek();
//        org.jfree.data.time.Year year52 = week50.getYear();
//        java.util.Date date53 = year52.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date53, timeZone54);
//        long long56 = week55.getMiddleMillisecond();
//        java.util.Date date57 = week55.getStart();
//        int int58 = week48.compareTo((java.lang.Object) date57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        int int61 = week59.compareTo((java.lang.Object) 10);
//        java.util.Date date62 = week59.getStart();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date62, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date57, timeZone63);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date11, timeZone63);
//        java.util.Locale locale67 = null;
//        try {
//            org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date6, timeZone63, locale67);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577908799999L + "'", long33 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 24 + "'", int44 == 24);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577908799999L + "'", long49 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 24 + "'", int51 == 24);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577908799999L + "'", long56 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        java.lang.String str5 = week1.toString();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        long long9 = week7.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.Year year11 = week7.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(9, year11);
//        long long13 = week12.getSerialIndex();
//        int int14 = week1.compareTo((java.lang.Object) week12);
//        org.jfree.data.time.Year year15 = week12.getYear();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, year15);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107016L + "'", long13 == 107016L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertNotNull(year15);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) 10);
        int int3 = week0.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        long long9 = week7.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        long long17 = week16.getMiddleMillisecond();
//        java.util.Date date18 = week16.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date5, timeZone23);
//        long long27 = week26.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577908799999L + "'", long17 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        long long13 = week11.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int16 = week15.getWeek();
//        org.jfree.data.time.Year year17 = week15.getYear();
//        java.util.Date date18 = year17.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        long long21 = week20.getMiddleMillisecond();
//        java.util.Date date22 = week20.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        org.jfree.data.time.Year year25 = week23.getYear();
//        java.util.Date date26 = year25.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date22, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone27);
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = regularTimePeriod30.getMiddleMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577908799999L + "'", long21 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week5.previous();
//        int int17 = week5.compareTo((java.lang.Object) "Week 24, 2019");
//        java.lang.Class<?> wildcardClass18 = week5.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        long long7 = week6.getSerialIndex();
//        int int8 = week6.getYearValue();
//        long long9 = week6.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107016L + "'", long7 == 107016L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1551297599999L + "'", long9 == 1551297599999L);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week5.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        long long4 = week2.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        java.lang.String str6 = week2.toString();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int9 = week8.getWeek();
//        long long10 = week8.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Year year12 = week8.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(9, year12);
//        long long14 = week13.getSerialIndex();
//        int int15 = week2.compareTo((java.lang.Object) week13);
//        org.jfree.data.time.Year year16 = week13.getYear();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) 'a', year16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(12, year16);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107016L + "'", long14 == 107016L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(year16);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week2.equals(obj6);
//        java.lang.String str8 = week2.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '4', (int) (byte) 10);
//        long long12 = week11.getFirstMillisecond();
//        int int13 = week2.compareTo((java.lang.Object) long12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61821158400000L) + "'", long12 == (-61821158400000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        java.util.Date date8 = week6.getEnd();
//        long long9 = week6.getLastMillisecond();
//        java.lang.Object obj10 = null;
//        int int11 = week6.compareTo(obj10);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week6.getMiddleMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = week9.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int16 = week15.getWeek();
//        long long17 = week15.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        long long25 = week24.getMiddleMillisecond();
//        java.util.Date date26 = week24.getStart();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date26, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        long long41 = week40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        int int43 = week42.getWeek();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        long long48 = week47.getMiddleMillisecond();
//        java.util.Date date49 = week47.getStart();
//        int int50 = week40.compareTo((java.lang.Object) date49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        int int53 = week51.compareTo((java.lang.Object) 10);
//        java.util.Date date54 = week51.getStart();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date49, timeZone55);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date3, timeZone55);
//        long long59 = week58.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577908799999L + "'", long25 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577908799999L + "'", long41 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577908799999L + "'", long48 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577606400000L + "'", long59 == 1577606400000L);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        boolean boolean6 = week0.equals((java.lang.Object) 1551599999999L);
//        long long7 = week0.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2020");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        boolean boolean6 = week0.equals((java.lang.Object) 1551599999999L);
//        int int7 = week0.getYearValue();
//        long long8 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        long long9 = week7.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        long long17 = week16.getMiddleMillisecond();
//        java.util.Date date18 = week16.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date5, timeZone23);
//        java.lang.Class<?> wildcardClass27 = date5.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577908799999L + "'", long17 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        int int14 = week0.getWeek();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week0.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        java.util.Date date8 = week6.getEnd();
//        long long9 = week6.getLastMillisecond();
//        java.lang.Object obj10 = null;
//        int int11 = week6.compareTo(obj10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        long long18 = week17.getMiddleMillisecond();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22);
//        int int26 = week17.compareTo((java.lang.Object) week25);
//        int int27 = week25.getYearValue();
//        org.jfree.data.time.Year year28 = week25.getYear();
//        int int29 = week6.compareTo((java.lang.Object) year28);
//        java.util.Calendar calendar30 = null;
//        try {
//            week6.peg(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577908799999L + "'", long18 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2020 + "'", int27 == 2020);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2020");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        java.lang.Object obj9 = null;
//        int int10 = week6.compareTo(obj9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        java.lang.String str10 = week6.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 9, 2019" + "'", str10.equals("Week 9, 2019"));
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 10, year8);
//        java.lang.String str10 = week9.toString();
//        long long11 = week9.getMiddleMillisecond();
//        java.lang.String str12 = week9.toString();
//        java.lang.Class<?> wildcardClass13 = week9.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577606400000L + "'", long7 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 10, 2020" + "'", str10.equals("Week 10, 2020"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1583351999999L + "'", long11 == 1583351999999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 10, 2020" + "'", str12.equals("Week 10, 2020"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 10);
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        long long7 = week6.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week6.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107016L + "'", long7 == 107016L);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getWeek();
//        long long7 = week5.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12, timeZone13);
//        long long15 = week14.getMiddleMillisecond();
//        java.util.Date date16 = week14.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        java.lang.Class<?> wildcardClass23 = week22.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        int int25 = week24.getWeek();
//        org.jfree.data.time.Year year26 = week24.getYear();
//        java.util.Date date27 = year26.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getWeek();
//        long long30 = week28.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        int int33 = week32.getWeek();
//        org.jfree.data.time.Year year34 = week32.getYear();
//        java.util.Date date35 = year34.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
//        long long38 = week37.getMiddleMillisecond();
//        java.util.Date date39 = week37.getStart();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int41 = week40.getWeek();
//        org.jfree.data.time.Year year42 = week40.getYear();
//        java.util.Date date43 = year42.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date39, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone44);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date16);
//        int int50 = week0.compareTo((java.lang.Object) week49);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577908799999L + "'", long15 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577908799999L + "'", long38 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        int int4 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        java.util.Calendar calendar6 = null;
//        try {
//            week5.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.util.Date date14 = week12.getStart();
//        int int15 = week5.compareTo((java.lang.Object) date14);
//        long long16 = week5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1578211199999L + "'", long16 == 1578211199999L);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        long long16 = week13.getLastMillisecond();
//        java.util.Calendar calendar17 = null;
//        try {
//            week13.peg(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1578211199999L + "'", long16 == 1578211199999L);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        long long7 = week6.getSerialIndex();
//        long long8 = week6.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getMiddleMillisecond();
//        java.lang.String str8 = week6.toString();
//        long long9 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(7, year10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577908799999L + "'", long7 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 1, 2020" + "'", str8.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577606400000L + "'", long9 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year10);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getFirstMillisecond();
//        int int11 = week6.getYearValue();
//        long long12 = week6.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1550995200000L + "'", long10 == 1550995200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        int int15 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        long long6 = week2.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week5.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2020 + "'", int7 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        int int15 = week0.getWeek();
//        java.util.Date date16 = week0.getEnd();
//        int int17 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = week5.getEnd();
//        org.jfree.data.time.Year year9 = week5.getYear();
//        boolean boolean11 = week5.equals((java.lang.Object) 10L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 10, year8);
//        java.lang.String str10 = week9.toString();
//        int int11 = week9.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577606400000L + "'", long7 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 10, 2020" + "'", str10.equals("Week 10, 2020"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = week5.getEnd();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week5.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 1, 2020");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (byte) 1);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        java.util.Calendar calendar14 = null;
//        try {
//            week0.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        long long8 = week7.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        try {
//            week7.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107107L + "'", long8 == 107107L);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        int int15 = week0.getWeek();
//        long long16 = week0.getLastMillisecond();
//        int int17 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        int int15 = week0.getWeek();
//        java.util.Date date16 = week0.getEnd();
//        java.util.Date date17 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        long long7 = week5.getMiddleMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week5.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577908799999L + "'", long7 == 1577908799999L);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str10 = timePeriodFormatException6.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str12 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.util.Date date4 = week0.getEnd();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 10);
//        java.util.Date date3 = week0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.util.Date date6 = week5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        int int8 = week7.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        java.lang.String str9 = week5.toString();
//        long long10 = week5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 1, 2020" + "'", str9.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1578211199999L + "'", long10 == 1578211199999L);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        java.util.Date date10 = week5.getStart();
//        java.util.TimeZone timeZone11 = null;
//        try {
//            org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getSerialIndex();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12, timeZone13);
//        long long15 = week14.getMiddleMillisecond();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int17 = week16.getWeek();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        java.util.Date date19 = year18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        long long22 = week21.getMiddleMillisecond();
//        java.util.Date date23 = week21.getStart();
//        int int24 = week14.compareTo((java.lang.Object) date23);
//        java.util.Date date25 = week14.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int27 = week26.getWeek();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        java.util.Date date29 = year28.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date29, timeZone31);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        int int34 = week33.getWeek();
//        long long35 = week33.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        int int38 = week37.getWeek();
//        org.jfree.data.time.Year year39 = week37.getYear();
//        java.util.Date date40 = year39.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date40, timeZone41);
//        long long43 = week42.getMiddleMillisecond();
//        java.util.Date date44 = week42.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        int int46 = week45.getWeek();
//        org.jfree.data.time.Year year47 = week45.getYear();
//        java.util.Date date48 = year47.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date48, timeZone49);
//        java.lang.Class<?> wildcardClass51 = week50.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        int int53 = week52.getWeek();
//        org.jfree.data.time.Year year54 = week52.getYear();
//        java.util.Date date55 = year54.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        int int57 = week56.getWeek();
//        long long58 = week56.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass59 = week56.getClass();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        int int61 = week60.getWeek();
//        org.jfree.data.time.Year year62 = week60.getYear();
//        java.util.Date date63 = year62.getEnd();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date63, timeZone64);
//        long long66 = week65.getMiddleMillisecond();
//        java.util.Date date67 = week65.getStart();
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        int int69 = week68.getWeek();
//        org.jfree.data.time.Year year70 = week68.getYear();
//        java.util.Date date71 = year70.getEnd();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date71, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date67, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date55, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date44, timeZone72);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date29, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = week77.next();
//        boolean boolean79 = week14.equals((java.lang.Object) week77);
//        boolean boolean80 = week6.equals((java.lang.Object) week14);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107061L + "'", long8 == 107061L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577908799999L + "'", long15 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577908799999L + "'", long22 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560063600000L + "'", long35 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 24 + "'", int38 == 24);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577908799999L + "'", long43 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 24 + "'", int53 == 24);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 24 + "'", int57 == 24);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560063600000L + "'", long58 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 24 + "'", int61 == 24);
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1577908799999L + "'", long66 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 24 + "'", int69 == 24);
//        org.junit.Assert.assertNotNull(year70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 10, year8);
//        java.lang.String str10 = week9.toString();
//        long long11 = week9.getMiddleMillisecond();
//        java.lang.String str12 = week9.toString();
//        int int13 = week9.getYearValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577606400000L + "'", long7 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 10, 2020" + "'", str10.equals("Week 10, 2020"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1583351999999L + "'", long11 == 1583351999999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 10, 2020" + "'", str12.equals("Week 10, 2020"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2020 + "'", int13 == 2020);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(2019, year3);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 10);
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        long long9 = week7.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        long long17 = week16.getMiddleMillisecond();
//        java.util.Date date18 = week16.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date5, timeZone23);
//        long long27 = week26.getMiddleMillisecond();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getWeek();
//        org.jfree.data.time.Year year30 = week28.getYear();
//        java.util.Date date31 = year30.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date31, timeZone32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date31);
//        long long35 = week34.getLastMillisecond();
//        long long36 = week34.getMiddleMillisecond();
//        int int37 = week26.compareTo((java.lang.Object) long36);
//        java.lang.Class<?> wildcardClass38 = week26.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577908799999L + "'", long17 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560365999999L + "'", long27 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1578211199999L + "'", long35 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577908799999L + "'", long36 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = year4.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.lang.String str14 = week12.toString();
//        long long15 = week12.getFirstMillisecond();
//        java.util.Date date16 = week12.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        java.lang.Class<?> wildcardClass23 = week22.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        int int25 = week24.getWeek();
//        org.jfree.data.time.Year year26 = week24.getYear();
//        java.util.Date date27 = year26.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getWeek();
//        long long30 = week28.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        int int33 = week32.getWeek();
//        org.jfree.data.time.Year year34 = week32.getYear();
//        java.util.Date date35 = year34.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
//        long long38 = week37.getMiddleMillisecond();
//        java.util.Date date39 = week37.getStart();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int41 = week40.getWeek();
//        org.jfree.data.time.Year year42 = week40.getYear();
//        java.util.Date date43 = year42.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date39, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        int int49 = week48.getWeek();
//        org.jfree.data.time.Year year50 = week48.getYear();
//        java.util.Date date51 = year50.getEnd();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date51, timeZone52);
//        long long54 = week53.getMiddleMillisecond();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        int int56 = week55.getWeek();
//        org.jfree.data.time.Year year57 = week55.getYear();
//        java.util.Date date58 = year57.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        long long61 = week60.getMiddleMillisecond();
//        java.util.Date date62 = week60.getStart();
//        int int63 = week53.compareTo((java.lang.Object) date62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        int int66 = week64.compareTo((java.lang.Object) 10);
//        java.util.Date date67 = week64.getStart();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date67, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date62, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone68);
//        java.lang.Class class72 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 1, 2020" + "'", str14.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577908799999L + "'", long38 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 24 + "'", int49 == 24);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577908799999L + "'", long54 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 24 + "'", int56 == 24);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1577908799999L + "'", long61 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(class72);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        boolean boolean6 = week0.equals((java.lang.Object) 1551599999999L);
//        java.util.Date date7 = week0.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        boolean boolean6 = week0.equals((java.lang.Object) 1551599999999L);
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getWeek();
//        java.util.Calendar calendar9 = null;
//        try {
//            week5.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week2.equals(obj6);
//        org.jfree.data.time.Year year8 = week2.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(year8);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = week5.getEnd();
//        long long9 = week5.getFirstMillisecond();
//        long long10 = week5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577606400000L + "'", long9 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577606400000L + "'", long10 == 1577606400000L);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.util.Date date14 = week12.getStart();
//        int int15 = week5.compareTo((java.lang.Object) date14);
//        java.util.Date date16 = week5.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        long long23 = week22.getMiddleMillisecond();
//        java.lang.String str24 = week22.toString();
//        int int25 = week22.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week22.previous();
//        int int27 = week5.compareTo((java.lang.Object) regularTimePeriod26);
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = regularTimePeriod26.getMiddleMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577908799999L + "'", long23 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 1, 2020" + "'", str24.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone16);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.util.Date date20 = null;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        int int22 = week21.getWeek();
//        org.jfree.data.time.Year year23 = week21.getYear();
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int30 = week28.compareTo((java.lang.Object) 10);
//        java.util.Date date31 = week28.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date31, timeZone32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date24, timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone32);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(53, year3);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.lang.Class<?> wildcardClass11 = year10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int14 = week13.getWeek();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        java.util.Date date16 = year15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date16, timeZone17);
//        java.lang.Class<?> wildcardClass19 = week18.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        int int21 = week20.getWeek();
//        org.jfree.data.time.Year year22 = week20.getYear();
//        java.util.Date date23 = year22.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        int int25 = week24.getWeek();
//        long long26 = week24.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass27 = week24.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getWeek();
//        org.jfree.data.time.Year year30 = week28.getYear();
//        java.util.Date date31 = year30.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date31, timeZone32);
//        long long34 = week33.getMiddleMillisecond();
//        java.util.Date date35 = week33.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        int int37 = week36.getWeek();
//        org.jfree.data.time.Year year38 = week36.getYear();
//        java.util.Date date39 = year38.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date35, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone40);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        int int45 = week44.getWeek();
//        org.jfree.data.time.Year year46 = week44.getYear();
//        java.util.Date date47 = year46.getEnd();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date47, timeZone48);
//        long long50 = week49.getMiddleMillisecond();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        int int52 = week51.getWeek();
//        org.jfree.data.time.Year year53 = week51.getYear();
//        java.util.Date date54 = year53.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
//        long long57 = week56.getMiddleMillisecond();
//        java.util.Date date58 = week56.getStart();
//        int int59 = week49.compareTo((java.lang.Object) date58);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        int int62 = week60.compareTo((java.lang.Object) 10);
//        java.util.Date date63 = week60.getStart();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date63, timeZone64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date58, timeZone64);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        int int68 = week67.getWeek();
//        long long69 = week67.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass70 = week67.getClass();
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        int int72 = week71.getWeek();
//        org.jfree.data.time.Year year73 = week71.getYear();
//        java.util.Date date74 = year73.getEnd();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date74, timeZone75);
//        long long77 = week76.getMiddleMillisecond();
//        java.util.Date date78 = week76.getStart();
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week();
//        int int80 = week79.getWeek();
//        org.jfree.data.time.Year year81 = week79.getYear();
//        java.util.Date date82 = year81.getEnd();
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date82, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date78, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date58, timeZone83);
//        int int87 = week5.compareTo((java.lang.Object) regularTimePeriod86);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577908799999L + "'", long34 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 24 + "'", int45 == 24);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577908799999L + "'", long50 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 24 + "'", int52 == 24);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577908799999L + "'", long57 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 24 + "'", int68 == 24);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560063600000L + "'", long69 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 24 + "'", int72 == 24);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1577908799999L + "'", long77 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 24 + "'", int80 == 24);
//        org.junit.Assert.assertNotNull(year81);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 9, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = week9.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int16 = week15.getWeek();
//        long long17 = week15.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        long long25 = week24.getMiddleMillisecond();
//        java.util.Date date26 = week24.getStart();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date26, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        long long41 = week40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        int int43 = week42.getWeek();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        long long48 = week47.getMiddleMillisecond();
//        java.util.Date date49 = week47.getStart();
//        int int50 = week40.compareTo((java.lang.Object) date49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        int int53 = week51.compareTo((java.lang.Object) 10);
//        java.util.Date date54 = week51.getStart();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date49, timeZone55);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date3, timeZone55);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        int int60 = week59.getWeek();
//        org.jfree.data.time.Year year61 = week59.getYear();
//        java.util.Date date62 = year61.getEnd();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date62, timeZone63);
//        long long65 = week64.getMiddleMillisecond();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        int int67 = week66.getWeek();
//        org.jfree.data.time.Year year68 = week66.getYear();
//        java.util.Date date69 = year68.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date69, timeZone70);
//        long long72 = week71.getMiddleMillisecond();
//        java.util.Date date73 = week71.getStart();
//        int int74 = week64.compareTo((java.lang.Object) date73);
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date73, timeZone75);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date73);
//        int int78 = week58.compareTo((java.lang.Object) date73);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577908799999L + "'", long25 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577908799999L + "'", long41 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577908799999L + "'", long48 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 24 + "'", int60 == 24);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1577908799999L + "'", long65 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 24 + "'", int67 == 24);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1577908799999L + "'", long72 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.util.Date date9 = week5.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) 10);
        java.util.Date date3 = week0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
//        java.util.Date date7 = week6.getEnd();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week6.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = week9.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int16 = week15.getWeek();
//        long long17 = week15.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        long long25 = week24.getMiddleMillisecond();
//        java.util.Date date26 = week24.getStart();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date26, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        long long41 = week40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        int int43 = week42.getWeek();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        long long48 = week47.getMiddleMillisecond();
//        java.util.Date date49 = week47.getStart();
//        int int50 = week40.compareTo((java.lang.Object) date49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        int int53 = week51.compareTo((java.lang.Object) 10);
//        java.util.Date date54 = week51.getStart();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date49, timeZone55);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date3, timeZone55);
//        long long59 = week58.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577908799999L + "'", long25 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577908799999L + "'", long41 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577908799999L + "'", long48 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 107061L + "'", long59 == 107061L);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str8 = timePeriodFormatException7.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        boolean boolean13 = week0.equals((java.lang.Object) timePeriodFormatException5);
//        long long14 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        long long8 = week5.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week5.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577606400000L + "'", long8 == 1577606400000L);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 53);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2020, 2020);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        long long9 = week6.getFirstMillisecond();
//        long long10 = week6.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1550995200000L + "'", long9 == 1550995200000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1551297599999L + "'", long10 == 1551297599999L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.String str15 = timePeriodFormatException13.toString();
        java.lang.String str16 = timePeriodFormatException13.toString();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str20 = timePeriodFormatException19.toString();
        java.lang.String str21 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str34 = timePeriodFormatException33.toString();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException33.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.String str40 = timePeriodFormatException19.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str34.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str40.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 10, year8);
//        java.lang.String str10 = week9.toString();
//        long long11 = week9.getMiddleMillisecond();
//        boolean boolean13 = week9.equals((java.lang.Object) "Week 9, 2019");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577606400000L + "'", long7 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 10, 2020" + "'", str10.equals("Week 10, 2020"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1583351999999L + "'", long11 == 1583351999999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getSerialIndex();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getLastMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week6.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107061L + "'", long7 == 107061L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577606400000L + "'", long8 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2020");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        java.lang.String str7 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 2020" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 2020"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        int int7 = week5.getYearValue();
//        java.util.Date date8 = week5.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = week14.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int17 = week16.getWeek();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        java.util.Date date19 = year18.getEnd();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        int int21 = week20.getWeek();
//        long long22 = week20.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass23 = week20.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        int int25 = week24.getWeek();
//        org.jfree.data.time.Year year26 = week24.getYear();
//        java.util.Date date27 = year26.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date27, timeZone28);
//        long long30 = week29.getMiddleMillisecond();
//        java.util.Date date31 = week29.getStart();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        int int33 = week32.getWeek();
//        org.jfree.data.time.Year year34 = week32.getYear();
//        java.util.Date date35 = year34.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date31, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int41 = week40.getWeek();
//        org.jfree.data.time.Year year42 = week40.getYear();
//        java.util.Date date43 = year42.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        long long46 = week45.getMiddleMillisecond();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        int int48 = week47.getWeek();
//        org.jfree.data.time.Year year49 = week47.getYear();
//        java.util.Date date50 = year49.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date50, timeZone51);
//        long long53 = week52.getMiddleMillisecond();
//        java.util.Date date54 = week52.getStart();
//        int int55 = week45.compareTo((java.lang.Object) date54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        int int58 = week56.compareTo((java.lang.Object) 10);
//        java.util.Date date59 = week56.getStart();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date59, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date54, timeZone60);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date8, timeZone60);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2020 + "'", int7 == 2020);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577908799999L + "'", long30 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577908799999L + "'", long46 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577908799999L + "'", long53 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.util.Date date14 = week12.getStart();
//        int int15 = week5.compareTo((java.lang.Object) date14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        java.util.Date date9 = week7.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        int int8 = week0.compareTo((java.lang.Object) regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) 10);
        java.util.Date date3 = week0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
        java.util.Date date6 = week5.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.Calendar calendar8 = null;
        try {
            week7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        java.lang.Object obj9 = null;
//        int int10 = week6.compareTo(obj9);
//        java.util.Date date11 = week6.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        long long8 = week5.getFirstMillisecond();
//        java.util.Date date9 = week5.getEnd();
//        java.lang.Class<?> wildcardClass10 = week5.getClass();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week5.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577606400000L + "'", long8 == 1577606400000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        java.util.Calendar calendar14 = null;
//        try {
//            week11.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week6.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        int int15 = week0.getWeek();
//        java.util.Date date16 = week0.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        long long18 = week17.getSerialIndex();
//        long long19 = week17.getSerialIndex();
//        java.lang.String str20 = week17.toString();
//        long long21 = week17.getMiddleMillisecond();
//        org.jfree.data.time.Year year22 = week17.getYear();
//        boolean boolean24 = week17.equals((java.lang.Object) "Week 10, 2020");
//        java.lang.Class<?> wildcardClass25 = week17.getClass();
//        int int26 = week0.compareTo((java.lang.Object) week17);
//        long long27 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107031L + "'", long18 == 107031L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 107031L + "'", long19 == 107031L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560365999999L + "'", long21 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 107031L + "'", long27 == 107031L);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.util.Date date14 = week12.getStart();
//        int int15 = week5.compareTo((java.lang.Object) date14);
//        java.util.Date date16 = week5.getEnd();
//        long long17 = week5.getSerialIndex();
//        java.lang.String str18 = week5.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107061L + "'", long17 == 107061L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 1, 2020" + "'", str18.equals("Week 1, 2020"));
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (byte) 10);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        long long8 = week7.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 10, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) -1, year9);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577606400000L + "'", long8 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getFirstMillisecond();
//        java.lang.String str11 = week6.toString();
//        java.lang.Class<?> wildcardClass12 = week6.getClass();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week6.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1550995200000L + "'", long10 == 1550995200000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 9, 2019" + "'", str11.equals("Week 9, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        long long9 = week5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107061L + "'", long9 == 107061L);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        int int9 = week6.getWeek();
//        long long10 = week6.getMiddleMillisecond();
//        java.lang.String str11 = week6.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1551297599999L + "'", long10 == 1551297599999L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 9, 2019" + "'", str11.equals("Week 9, 2019"));
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        int int15 = week0.getWeek();
//        java.util.Date date16 = week0.getEnd();
//        long long17 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        java.util.Date date10 = week5.getStart();
//        java.lang.String str11 = week5.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 1, 2020" + "'", str11.equals("Week 1, 2020"));
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (byte) 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date14);
//        int int18 = week9.compareTo((java.lang.Object) week17);
//        int int19 = week17.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week17.next();
//        java.util.Date date21 = week17.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        int int23 = week22.getWeek();
//        long long24 = week22.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass25 = week22.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int27 = week26.getWeek();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        java.util.Date date29 = year28.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date29, timeZone30);
//        long long32 = week31.getMiddleMillisecond();
//        java.util.Date date33 = week31.getStart();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        int int35 = week34.getWeek();
//        org.jfree.data.time.Year year36 = week34.getYear();
//        java.util.Date date37 = year36.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date33, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone38);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date21, timeZone42);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
//        java.lang.String str54 = timePeriodFormatException50.toString();
//        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
//        java.lang.Throwable[] throwableArray56 = timePeriodFormatException47.getSuppressed();
//        int int57 = week43.compareTo((java.lang.Object) timePeriodFormatException47);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2020 + "'", int19 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560063600000L + "'", long24 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577908799999L + "'", long32 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 24 + "'", int35 == 24);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str54.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week2.equals(obj6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
//        long long9 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week2.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.util.Calendar calendar4 = null;
        try {
            week0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(class9);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = year4.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.lang.String str14 = week12.toString();
//        long long15 = week12.getFirstMillisecond();
//        java.util.Date date16 = week12.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        java.lang.Class<?> wildcardClass23 = week22.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        int int25 = week24.getWeek();
//        org.jfree.data.time.Year year26 = week24.getYear();
//        java.util.Date date27 = year26.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getWeek();
//        long long30 = week28.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        int int33 = week32.getWeek();
//        org.jfree.data.time.Year year34 = week32.getYear();
//        java.util.Date date35 = year34.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
//        long long38 = week37.getMiddleMillisecond();
//        java.util.Date date39 = week37.getStart();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int41 = week40.getWeek();
//        org.jfree.data.time.Year year42 = week40.getYear();
//        java.util.Date date43 = year42.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date39, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        int int49 = week48.getWeek();
//        org.jfree.data.time.Year year50 = week48.getYear();
//        java.util.Date date51 = year50.getEnd();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date51, timeZone52);
//        long long54 = week53.getMiddleMillisecond();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        int int56 = week55.getWeek();
//        org.jfree.data.time.Year year57 = week55.getYear();
//        java.util.Date date58 = year57.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        long long61 = week60.getMiddleMillisecond();
//        java.util.Date date62 = week60.getStart();
//        int int63 = week53.compareTo((java.lang.Object) date62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        int int66 = week64.compareTo((java.lang.Object) 10);
//        java.util.Date date67 = week64.getStart();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date67, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date62, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone68);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date16);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 1, 2020" + "'", str14.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577908799999L + "'", long38 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 24 + "'", int49 == 24);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577908799999L + "'", long54 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 24 + "'", int56 == 24);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1577908799999L + "'", long61 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getWeek();
//        long long3 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        java.util.Date date10 = week5.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week5.previous();
//        int int16 = week5.getYearValue();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        long long23 = week22.getMiddleMillisecond();
//        java.lang.String str24 = week22.toString();
//        long long25 = week22.getFirstMillisecond();
//        boolean boolean26 = week5.equals((java.lang.Object) week22);
//        java.util.Date date27 = week5.getStart();
//        java.util.Date date28 = week5.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2020 + "'", int16 == 2020);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577908799999L + "'", long23 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 1, 2020" + "'", str24.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577606400000L + "'", long25 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 9, 2019");
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        java.lang.String str7 = week6.toString();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        long long9 = week6.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 9, 2019" + "'", str7.equals("Week 9, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1550995200000L + "'", long9 == 1550995200000L);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        long long4 = week2.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(9, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year6);
//        long long9 = week8.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107007L + "'", long9 == 107007L);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        long long8 = week5.getFirstMillisecond();
//        java.util.Date date9 = week5.getEnd();
//        java.lang.Class<?> wildcardClass10 = week5.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577606400000L + "'", long8 == 1577606400000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 53);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week5.previous();
//        java.util.Calendar calendar16 = null;
//        try {
//            week5.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        boolean boolean7 = week0.equals((java.lang.Object) "Week 10, 2020");
//        java.util.Date date8 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getWeek();
//        int int9 = week5.getYearValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2020 + "'", int9 == 2020);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = week17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        long long25 = week23.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        long long33 = week32.getMiddleMillisecond();
//        java.util.Date date34 = week32.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone39);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577908799999L + "'", long33 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        java.util.Date date8 = week6.getEnd();
//        long long9 = week6.getLastMillisecond();
//        java.lang.Object obj10 = null;
//        int int11 = week6.compareTo(obj10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str16 = timePeriodFormatException15.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean24 = week6.equals((java.lang.Object) timePeriodFormatException22);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        long long16 = week13.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str19 = timePeriodFormatException18.toString();
//        java.lang.Throwable[] throwableArray20 = timePeriodFormatException18.getSuppressed();
//        int int21 = week13.compareTo((java.lang.Object) timePeriodFormatException18);
//        java.lang.String str22 = timePeriodFormatException18.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577606400000L + "'", long16 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        long long5 = week3.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        java.lang.String str7 = week3.toString();
//        java.util.Date date8 = week3.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        int int11 = week10.getWeek();
//        long long12 = week10.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass13 = week10.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        int int15 = week14.getWeek();
//        org.jfree.data.time.Year year16 = week14.getYear();
//        java.util.Date date17 = year16.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        long long20 = week19.getMiddleMillisecond();
//        java.util.Date date21 = week19.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        int int23 = week22.getWeek();
//        org.jfree.data.time.Year year24 = week22.getYear();
//        java.util.Date date25 = year24.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date21, timeZone26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date8, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date2, timeZone26);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577908799999L + "'", long20 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int9 = week8.getWeek();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        java.util.Date date11 = year10.getEnd();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
//        java.lang.Class<?> wildcardClass14 = week13.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int16 = week15.getWeek();
//        org.jfree.data.time.Year year17 = week15.getYear();
//        java.util.Date date18 = year17.getEnd();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        long long21 = week19.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass22 = week19.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        org.jfree.data.time.Year year25 = week23.getYear();
//        java.util.Date date26 = year25.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
//        long long29 = week28.getMiddleMillisecond();
//        java.util.Date date30 = week28.getStart();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        int int32 = week31.getWeek();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        java.util.Date date34 = year33.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date30, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone35);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        int int40 = week39.getWeek();
//        org.jfree.data.time.Year year41 = week39.getYear();
//        java.util.Date date42 = year41.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date42, timeZone43);
//        long long45 = week44.getMiddleMillisecond();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        int int47 = week46.getWeek();
//        org.jfree.data.time.Year year48 = week46.getYear();
//        java.util.Date date49 = year48.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49, timeZone50);
//        long long52 = week51.getMiddleMillisecond();
//        java.util.Date date53 = week51.getStart();
//        int int54 = week44.compareTo((java.lang.Object) date53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        int int57 = week55.compareTo((java.lang.Object) 10);
//        java.util.Date date58 = week55.getStart();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date53, timeZone59);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date7, timeZone59);
//        boolean boolean63 = week0.equals((java.lang.Object) date7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577908799999L + "'", long29 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 24 + "'", int32 == 24);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577908799999L + "'", long45 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 24 + "'", int47 == 24);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577908799999L + "'", long52 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 0);
        long long3 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62153798400000L) + "'", long3 == (-62153798400000L));
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.util.Date date14 = week12.getStart();
//        int int15 = week5.compareTo((java.lang.Object) date14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int18 = week16.compareTo((java.lang.Object) 10);
//        java.util.Date date19 = week16.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date14, timeZone20);
//        long long23 = week22.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1578211199999L + "'", long23 == 1578211199999L);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str9 = timePeriodFormatException8.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week5.previous();
//        int int16 = week5.getYearValue();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        long long23 = week22.getMiddleMillisecond();
//        java.lang.String str24 = week22.toString();
//        long long25 = week22.getFirstMillisecond();
//        boolean boolean26 = week5.equals((java.lang.Object) week22);
//        java.util.Date date27 = week5.getStart();
//        java.util.Calendar calendar28 = null;
//        try {
//            week5.peg(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2020 + "'", int16 == 2020);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577908799999L + "'", long23 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 1, 2020" + "'", str24.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577606400000L + "'", long25 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(date27);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 10, year8);
//        java.lang.String str10 = week9.toString();
//        long long11 = week9.getMiddleMillisecond();
//        java.lang.String str12 = week9.toString();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week9.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577606400000L + "'", long7 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 10, 2020" + "'", str10.equals("Week 10, 2020"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1583351999999L + "'", long11 == 1583351999999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 10, 2020" + "'", str12.equals("Week 10, 2020"));
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        int int5 = week0.compareTo((java.lang.Object) week2);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week2.equals(obj6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week2.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getSerialIndex();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getLastMillisecond();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, year13);
//        long long15 = week14.getSerialIndex();
//        boolean boolean16 = week6.equals((java.lang.Object) week14);
//        java.lang.String str17 = week14.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107061L + "'", long7 == 107061L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577606400000L + "'", long8 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107007L + "'", long15 == 107007L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 0, 2019" + "'", str17.equals("Week 0, 2019"));
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (byte) 10);
        long long3 = week2.getFirstMillisecond();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61821158400000L) + "'", long3 == (-61821158400000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 2019");
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        int int9 = week6.getWeek();
//        int int10 = week6.getYearValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        java.util.Date date6 = week4.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        int int15 = week13.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.next();
//        java.util.Date date17 = week13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        long long19 = week18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week18.previous();
//        java.util.Calendar calendar21 = null;
//        try {
//            week18.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2020 + "'", int15 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1578211199999L + "'", long19 == 1578211199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        int int15 = week13.getYearValue();
//        org.jfree.data.time.Year year16 = week13.getYear();
//        long long17 = week13.getFirstMillisecond();
//        int int18 = week13.getYearValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2020 + "'", int15 == 2020);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577606400000L + "'", long17 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2020 + "'", int18 == 2020);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, 1);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 4, 1" + "'", str3.equals("Week 4, 1"));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        int int15 = week0.getWeek();
//        int int16 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        boolean boolean3 = week0.equals((java.lang.Object) "Week 24, 2019");
//        java.util.Date date4 = week0.getEnd();
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        java.lang.String str7 = week6.toString();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 9, 2019" + "'", str7.equals("Week 9, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        int int7 = week5.getWeek();
//        java.lang.Object obj8 = null;
//        int int9 = week5.compareTo(obj8);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = year4.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(class8);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 2020");
        java.lang.String str21 = timePeriodFormatException20.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 10, 2020" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: Week 10, 2020"));
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Year year10 = week9.getYear();
//        long long11 = week9.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577606400000L + "'", long11 == 1577606400000L);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            week5.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        int int8 = week6.getWeek();
//        java.util.Calendar calendar9 = null;
//        try {
//            week6.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        int int10 = week6.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getSerialIndex();
//        java.util.Date date12 = week6.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1550995200000L + "'", long10 == 1550995200000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107016L + "'", long11 == 107016L);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        long long9 = week5.getLastMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            week5.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getSerialIndex();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107061L + "'", long8 == 107061L);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, year3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        long long8 = week7.getSerialIndex();
//        long long9 = week7.getFirstMillisecond();
//        long long10 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107107L + "'", long8 == 107107L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1606032000000L + "'", long9 == 1606032000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1606334399999L + "'", long10 == 1606334399999L);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        long long2 = week0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str5 = timePeriodFormatException4.toString();
//        java.lang.String str6 = timePeriodFormatException4.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2020");
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        boolean boolean10 = week0.equals((java.lang.Object) timePeriodFormatException8);
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException8.getSuppressed();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(throwableArray11);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = week17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        long long25 = week23.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        long long33 = week32.getMiddleMillisecond();
//        java.util.Date date34 = week32.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone39);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class45);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577908799999L + "'", long33 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(class46);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        long long9 = week5.getLastMillisecond();
//        org.jfree.data.time.Year year10 = week5.getYear();
//        java.util.Date date11 = week5.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        boolean boolean6 = week0.equals((java.lang.Object) 1551599999999L);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        long long9 = week7.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.util.Date date14 = year13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        long long17 = week16.getMiddleMillisecond();
//        java.util.Date date18 = week16.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        java.lang.Class<?> wildcardClass25 = week24.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int27 = week26.getWeek();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        java.util.Date date29 = year28.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        int int31 = week30.getWeek();
//        long long32 = week30.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass33 = week30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        int int35 = week34.getWeek();
//        org.jfree.data.time.Year year36 = week34.getYear();
//        java.util.Date date37 = year36.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37, timeZone38);
//        long long40 = week39.getMiddleMillisecond();
//        java.util.Date date41 = week39.getStart();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        int int43 = week42.getWeek();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date41, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone46);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date3, timeZone46);
//        java.lang.Class<?> wildcardClass52 = date3.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577908799999L + "'", long17 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 24 + "'", int35 == 24);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577908799999L + "'", long40 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 2);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 2" + "'", str3.equals("Week 1, 2"));
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        boolean boolean7 = week0.equals((java.lang.Object) "Week 10, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        int int9 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = week17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        long long25 = week23.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        long long33 = week32.getMiddleMillisecond();
//        java.util.Date date34 = week32.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone39);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize(class47);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577908799999L + "'", long33 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(class48);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
//        int int7 = week6.getYearValue();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week6.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2020 + "'", int7 == 2020);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        int int8 = week7.getWeek();
//        int int9 = week7.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getWeek();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = year7.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8, timeZone9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date8);
//        long long12 = week11.getLastMillisecond();
//        java.util.Date date13 = week11.getEnd();
//        long long14 = week11.getLastMillisecond();
//        java.lang.Object obj15 = null;
//        int int16 = week11.compareTo(obj15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        long long23 = week22.getMiddleMillisecond();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        int int25 = week24.getWeek();
//        org.jfree.data.time.Year year26 = week24.getYear();
//        java.util.Date date27 = year26.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date27, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date27);
//        int int31 = week22.compareTo((java.lang.Object) week30);
//        int int32 = week30.getYearValue();
//        org.jfree.data.time.Year year33 = week30.getYear();
//        int int34 = week11.compareTo((java.lang.Object) year33);
//        boolean boolean35 = week0.equals((java.lang.Object) week11);
//        org.jfree.data.time.Year year36 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1578211199999L + "'", long12 == 1578211199999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1578211199999L + "'", long14 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577908799999L + "'", long23 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2020 + "'", int32 == 2020);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(year36);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        int int9 = week6.getWeek();
//        long long10 = week6.getMiddleMillisecond();
//        int int11 = week6.getYearValue();
//        java.lang.String str12 = week6.toString();
//        int int13 = week6.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1551297599999L + "'", long10 == 1551297599999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 9, 2019" + "'", str12.equals("Week 9, 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        long long14 = week11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1551599999999L + "'", long14 == 1551599999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.util.Date date14 = week12.getStart();
//        int int15 = week5.compareTo((java.lang.Object) date14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int18 = week16.compareTo((java.lang.Object) 10);
//        java.util.Date date19 = week16.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date14, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        long long25 = week23.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        java.lang.String str27 = week23.toString();
//        java.util.Date date28 = week23.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        int int31 = week30.getWeek();
//        long long32 = week30.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass33 = week30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        int int35 = week34.getWeek();
//        org.jfree.data.time.Year year36 = week34.getYear();
//        java.util.Date date37 = year36.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37, timeZone38);
//        long long40 = week39.getMiddleMillisecond();
//        java.util.Date date41 = week39.getStart();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        int int43 = week42.getWeek();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date41, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date28, timeZone46);
//        java.util.Locale locale50 = null;
//        try {
//            org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date14, timeZone46, locale50);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 24 + "'", int35 == 24);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577908799999L + "'", long40 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 10, 2020");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getWeek();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        int int11 = week10.getWeek();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        java.util.Date date13 = year12.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
//        long long16 = week15.getMiddleMillisecond();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        long long23 = week22.getMiddleMillisecond();
//        java.util.Date date24 = week22.getStart();
//        int int25 = week15.compareTo((java.lang.Object) date24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int28 = week26.compareTo((java.lang.Object) 10);
//        java.util.Date date29 = week26.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date24, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone30);
//        java.util.Date date34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        long long41 = week40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        int int43 = week42.getWeek();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        long long48 = week47.getMiddleMillisecond();
//        java.util.Date date49 = week47.getStart();
//        int int50 = week40.compareTo((java.lang.Object) date49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date49, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date34, timeZone51);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577908799999L + "'", long16 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577908799999L + "'", long23 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577908799999L + "'", long41 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577908799999L + "'", long48 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        long long16 = week13.getFirstMillisecond();
//        java.util.Date date17 = week13.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577606400000L + "'", long16 == 1577606400000L);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        long long9 = week5.getLastMillisecond();
//        org.jfree.data.time.Year year10 = week5.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        long long14 = week12.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        java.lang.String str16 = week12.toString();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        int int19 = week18.getWeek();
//        long long20 = week18.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass21 = week18.getClass();
//        org.jfree.data.time.Year year22 = week18.getYear();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(9, year22);
//        long long24 = week23.getSerialIndex();
//        int int25 = week12.compareTo((java.lang.Object) week23);
//        org.jfree.data.time.Year year26 = week23.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) 'a', year26);
//        int int28 = week5.compareTo((java.lang.Object) 'a');
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1578211199999L + "'", long9 == 1578211199999L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107016L + "'", long24 == 107016L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        java.lang.String str9 = week5.toString();
//        int int10 = week5.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 1, 2020" + "'", str9.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        long long4 = week2.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(9, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = week17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        long long25 = week23.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        long long33 = week32.getMiddleMillisecond();
//        java.util.Date date34 = week32.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone39);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        int int45 = week44.getWeek();
//        org.jfree.data.time.Year year46 = week44.getYear();
//        java.util.Date date47 = year46.getEnd();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date47, timeZone48);
//        long long50 = week49.getMiddleMillisecond();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        int int52 = week51.getWeek();
//        org.jfree.data.time.Year year53 = week51.getYear();
//        java.util.Date date54 = year53.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
//        long long57 = week56.getMiddleMillisecond();
//        java.util.Date date58 = week56.getStart();
//        int int59 = week49.compareTo((java.lang.Object) date58);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date58, timeZone60);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        int int63 = week62.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week62.next();
//        java.lang.Class<?> wildcardClass65 = week62.getClass();
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass65);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        int int68 = week67.getWeek();
//        org.jfree.data.time.Year year69 = week67.getYear();
//        java.util.Date date70 = year69.getEnd();
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date70);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        int int73 = week72.getWeek();
//        org.jfree.data.time.Year year74 = week72.getYear();
//        java.util.Date date75 = year74.getEnd();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date75, timeZone76);
//        long long78 = week77.getMiddleMillisecond();
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week();
//        int int80 = week79.getWeek();
//        org.jfree.data.time.Year year81 = week79.getYear();
//        java.util.Date date82 = year81.getEnd();
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date82, timeZone83);
//        long long85 = week84.getMiddleMillisecond();
//        java.util.Date date86 = week84.getStart();
//        int int87 = week77.compareTo((java.lang.Object) date86);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week();
//        int int90 = week88.compareTo((java.lang.Object) 10);
//        java.util.Date date91 = week88.getStart();
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date91, timeZone92);
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date86, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date70, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date58, timeZone92);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577908799999L + "'", long33 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 24 + "'", int45 == 24);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577908799999L + "'", long50 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 24 + "'", int52 == 24);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577908799999L + "'", long57 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 24 + "'", int68 == 24);
//        org.junit.Assert.assertNotNull(year69);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 24 + "'", int73 == 24);
//        org.junit.Assert.assertNotNull(year74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1577908799999L + "'", long78 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 24 + "'", int80 == 24);
//        org.junit.Assert.assertNotNull(year81);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1577908799999L + "'", long85 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNotNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int28 = week26.compareTo((java.lang.Object) 10);
//        java.util.Date date29 = week26.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date29, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone30);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(class33);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = week5.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        long long11 = week9.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        org.jfree.data.time.Year year13 = week9.getYear();
//        java.lang.Class<?> wildcardClass14 = year13.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int17 = week16.getWeek();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        java.util.Date date19 = year18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        java.lang.Class<?> wildcardClass22 = week21.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        org.jfree.data.time.Year year25 = week23.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        long long29 = week27.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass30 = week27.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        int int32 = week31.getWeek();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        java.util.Date date34 = year33.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        long long37 = week36.getMiddleMillisecond();
//        java.util.Date date38 = week36.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        int int40 = week39.getWeek();
//        org.jfree.data.time.Year year41 = week39.getYear();
//        java.util.Date date42 = year41.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date42, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        int int48 = week47.getWeek();
//        org.jfree.data.time.Year year49 = week47.getYear();
//        java.util.Date date50 = year49.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date50, timeZone51);
//        long long53 = week52.getMiddleMillisecond();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        int int55 = week54.getWeek();
//        org.jfree.data.time.Year year56 = week54.getYear();
//        java.util.Date date57 = year56.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date57, timeZone58);
//        long long60 = week59.getMiddleMillisecond();
//        java.util.Date date61 = week59.getStart();
//        int int62 = week52.compareTo((java.lang.Object) date61);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        int int65 = week63.compareTo((java.lang.Object) 10);
//        java.util.Date date66 = week63.getStart();
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date66, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date61, timeZone67);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
//        int int71 = week70.getWeek();
//        long long72 = week70.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass73 = week70.getClass();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        int int75 = week74.getWeek();
//        org.jfree.data.time.Year year76 = week74.getYear();
//        java.util.Date date77 = year76.getEnd();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date77, timeZone78);
//        long long80 = week79.getMiddleMillisecond();
//        java.util.Date date81 = week79.getStart();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        int int83 = week82.getWeek();
//        org.jfree.data.time.Year year84 = week82.getYear();
//        java.util.Date date85 = year84.getEnd();
//        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date85, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date81, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date61, timeZone86);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date8, timeZone86);
//        int int91 = week90.getYearValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560063600000L + "'", long29 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 24 + "'", int32 == 24);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577908799999L + "'", long37 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577908799999L + "'", long53 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 24 + "'", int55 == 24);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577908799999L + "'", long60 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 24 + "'", int71 == 24);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560063600000L + "'", long72 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 24 + "'", int75 == 24);
//        org.junit.Assert.assertNotNull(year76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1577908799999L + "'", long80 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 24 + "'", int83 == 24);
//        org.junit.Assert.assertNotNull(year84);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(timeZone86);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 2020 + "'", int91 == 2020);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) 10);
        int int3 = week0.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week5.next();
//        org.jfree.data.time.Year year11 = week5.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 4, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        long long15 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560365999999L + "'", long15 == 1560365999999L);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.String str15 = timePeriodFormatException13.toString();
        java.lang.String str16 = timePeriodFormatException13.toString();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException13.getSuppressed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        java.lang.Class<?> wildcardClass25 = week24.getClass();
//        int int26 = week24.getYearValue();
//        java.util.Date date27 = week24.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date27, timeZone29);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2020 + "'", int26 == 2020);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 10);
//        java.util.Date date3 = week0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = date3.getClass();
//        java.util.Date date7 = null;
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int9 = week8.getWeek();
//        long long10 = week8.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getWeek();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date20, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        int int25 = week24.getWeek();
//        long long26 = week24.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass27 = week24.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getWeek();
//        org.jfree.data.time.Year year30 = week28.getYear();
//        java.util.Date date31 = year30.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date31, timeZone32);
//        long long34 = week33.getMiddleMillisecond();
//        java.util.Date date35 = week33.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        int int37 = week36.getWeek();
//        org.jfree.data.time.Year year38 = week36.getYear();
//        java.util.Date date39 = year38.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date39, timeZone40);
//        java.lang.Class<?> wildcardClass42 = week41.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        int int44 = week43.getWeek();
//        org.jfree.data.time.Year year45 = week43.getYear();
//        java.util.Date date46 = year45.getEnd();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        int int48 = week47.getWeek();
//        long long49 = week47.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass50 = week47.getClass();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        int int52 = week51.getWeek();
//        org.jfree.data.time.Year year53 = week51.getYear();
//        java.util.Date date54 = year53.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
//        long long57 = week56.getMiddleMillisecond();
//        java.util.Date date58 = week56.getStart();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        int int60 = week59.getWeek();
//        org.jfree.data.time.Year year61 = week59.getYear();
//        java.util.Date date62 = year61.getEnd();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date62, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date58, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date46, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date35, timeZone63);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date20, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone63);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577908799999L + "'", long34 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 24 + "'", int44 == 24);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560063600000L + "'", long49 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 24 + "'", int52 == 24);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577908799999L + "'", long57 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 24 + "'", int60 == 24);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        java.util.Date date6 = year5.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
//        long long9 = week8.getMiddleMillisecond();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        int int11 = week10.getWeek();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        java.util.Date date13 = year12.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
//        int int17 = week8.compareTo((java.lang.Object) week16);
//        long long18 = week16.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week16.previous();
//        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        int int22 = week2.compareTo((java.lang.Object) class21);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577908799999L + "'", long9 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577606400000L + "'", long18 == 1577606400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getSerialIndex();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        boolean boolean7 = week0.equals((java.lang.Object) "Week 10, 2020");
//        java.lang.Object obj8 = null;
//        boolean boolean9 = week0.equals(obj8);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week0.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) 10);
        java.util.Date date3 = week0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
        java.util.Date date6 = week5.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (byte) 10);
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577908799999L + "'", long8 == 1577908799999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(class9);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(53, year3);
//        java.util.Date date6 = year3.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getSerialIndex();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week6.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1550995200000L + "'", long10 == 1550995200000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107016L + "'", long11 == 107016L);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        long long7 = week6.getLastMillisecond();
//        java.util.Date date8 = week6.getEnd();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week6.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1578211199999L + "'", long7 == 1578211199999L);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getMiddleMillisecond();
//        java.util.Date date11 = week6.getStart();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1551297599999L + "'", long10 == 1551297599999L);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        int int9 = week6.getWeek();
//        long long10 = week6.getMiddleMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week6.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1551297599999L + "'", long10 == 1551297599999L);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.lang.String str2 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        long long16 = week13.getLastMillisecond();
//        long long17 = week13.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1578211199999L + "'", long16 == 1578211199999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577606400000L + "'", long17 == 1577606400000L);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        java.util.Date date8 = week5.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) '4');
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.String str7 = week5.toString();
//        int int8 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        long long10 = week5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1578211199999L + "'", long10 == 1578211199999L);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = week5.getEnd();
//        long long9 = week5.getFirstMillisecond();
//        java.util.Date date10 = week5.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577606400000L + "'", long6 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577606400000L + "'", long9 == 1577606400000L);
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(53, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', year5);
//        java.lang.Class<?> wildcardClass10 = year5.getClass();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        int int7 = week6.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(12, year3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        int int15 = week13.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.next();
//        java.util.Date date17 = week13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = week18.getMiddleMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2020 + "'", int15 == 2020);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        int int7 = week5.getYearValue();
//        long long8 = week5.getLastMillisecond();
//        java.util.Date date9 = week5.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2020 + "'", int7 == 2020);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1578211199999L + "'", long8 == 1578211199999L);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        long long13 = week12.getMiddleMillisecond();
//        java.util.Date date14 = week12.getStart();
//        int int15 = week5.compareTo((java.lang.Object) date14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int18 = week16.compareTo((java.lang.Object) 10);
//        java.util.Date date19 = week16.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date14, timeZone20);
//        java.util.Date date23 = week22.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577908799999L + "'", long13 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(date23);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
//        long long10 = week9.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1578211199999L + "'", long10 == 1578211199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        long long12 = week6.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1550995200000L + "'", long10 == 1550995200000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1550995200000L + "'", long11 == 1550995200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1551599999999L + "'", long12 == 1551599999999L);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        long long5 = week3.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        java.lang.String str7 = week3.toString();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        long long11 = week9.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        org.jfree.data.time.Year year13 = week9.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(9, year13);
//        long long15 = week14.getSerialIndex();
//        int int16 = week3.compareTo((java.lang.Object) week14);
//        org.jfree.data.time.Year year17 = week14.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) 'a', year17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(0, year17);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((-1), year17);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107016L + "'", long15 == 107016L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(year17);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        int int14 = week5.compareTo((java.lang.Object) week13);
//        long long15 = week13.getFirstMillisecond();
//        long long16 = week13.getFirstMillisecond();
//        long long17 = week13.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577606400000L + "'", long15 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577606400000L + "'", long16 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577908799999L + "'", long17 == 1577908799999L);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1551599999999L + "'", long10 == 1551599999999L);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1578211199999L + "'", long6 == 1578211199999L);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        long long6 = week5.getMiddleMillisecond();
//        java.util.Date date7 = week5.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int9 = week8.getWeek();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        java.util.Date date11 = year10.getEnd();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
//        java.lang.Class<?> wildcardClass14 = week13.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int16 = week15.getWeek();
//        org.jfree.data.time.Year year17 = week15.getYear();
//        java.util.Date date18 = year17.getEnd();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        long long21 = week19.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass22 = week19.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        org.jfree.data.time.Year year25 = week23.getYear();
//        java.util.Date date26 = year25.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
//        long long29 = week28.getMiddleMillisecond();
//        java.util.Date date30 = week28.getStart();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        int int32 = week31.getWeek();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        java.util.Date date34 = year33.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date30, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone35);
//        java.util.Locale locale39 = null;
//        try {
//            org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date7, timeZone35, locale39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577908799999L + "'", long6 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577908799999L + "'", long29 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 24 + "'", int32 == 24);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        java.lang.Object obj9 = null;
//        int int10 = week6.compareTo(obj9);
//        org.jfree.data.time.Year year11 = week6.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(15, (int) (byte) 100);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        int int6 = week1.compareTo((java.lang.Object) week3);
//        boolean boolean7 = week0.equals((java.lang.Object) week3);
//        long long8 = week3.getSerialIndex();
//        java.util.Date date9 = week3.getStart();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        long long4 = week2.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(9, year6);
//        boolean boolean9 = week7.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.previous();
//        int int12 = week7.compareTo((java.lang.Object) ' ');
//        org.jfree.data.time.Year year13 = week7.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(24, year13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(year13);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 2020);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Date date7 = year6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
//        long long10 = week9.getMiddleMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = week17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int20 = week19.getWeek();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getWeek();
//        long long25 = week23.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date30, timeZone31);
//        long long33 = week32.getMiddleMillisecond();
//        java.util.Date date34 = week32.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone39);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize(class46);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577908799999L + "'", long10 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577908799999L + "'", long33 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(class47);
//    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str8 = timePeriodFormatException7.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        boolean boolean13 = week0.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        int int7 = week5.getYearValue();
//        long long8 = week5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
//        java.util.Date date10 = week5.getStart();
//        java.lang.String str11 = week5.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2020 + "'", int7 == 2020);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1578211199999L + "'", long8 == 1578211199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 1, 2020" + "'", str11.equals("Week 1, 2020"));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week0.next();
//        int int15 = week0.getWeek();
//        java.util.Date date16 = week0.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(date16);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 53);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str16 = timePeriodFormatException15.toString();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str28 = timePeriodFormatException27.toString();
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException27.getSuppressed();
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str36 = timePeriodFormatException35.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        java.lang.String str41 = timePeriodFormatException38.toString();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        java.lang.String str43 = timePeriodFormatException38.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str36.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str41.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str43.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
//        long long12 = week11.getSerialIndex();
//        int int13 = week0.compareTo((java.lang.Object) week11);
//        java.lang.String str14 = week11.toString();
//        org.jfree.data.time.Year year15 = week11.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107016L + "'", long12 == 107016L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 9, 2019" + "'", str14.equals("Week 9, 2019"));
//        org.junit.Assert.assertNotNull(year15);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        long long5 = week3.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        java.lang.String str7 = week3.toString();
//        java.util.Date date8 = week3.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        int int11 = week10.getWeek();
//        long long12 = week10.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass13 = week10.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        int int15 = week14.getWeek();
//        org.jfree.data.time.Year year16 = week14.getYear();
//        java.util.Date date17 = year16.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        long long20 = week19.getMiddleMillisecond();
//        java.util.Date date21 = week19.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        int int23 = week22.getWeek();
//        org.jfree.data.time.Year year24 = week22.getYear();
//        java.util.Date date25 = year24.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date21, timeZone26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date8, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date2, timeZone26);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        int int32 = week31.getWeek();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        java.util.Date date34 = year33.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        long long37 = week36.getMiddleMillisecond();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        int int39 = week38.getWeek();
//        org.jfree.data.time.Year year40 = week38.getYear();
//        java.util.Date date41 = year40.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41, timeZone42);
//        long long44 = week43.getMiddleMillisecond();
//        java.util.Date date45 = week43.getStart();
//        int int46 = week36.compareTo((java.lang.Object) date45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        int int49 = week47.compareTo((java.lang.Object) 10);
//        java.util.Date date50 = week47.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date50, timeZone51);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date45, timeZone51);
//        java.util.Locale locale54 = null;
//        try {
//            org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date2, timeZone51, locale54);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577908799999L + "'", long20 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 24 + "'", int32 == 24);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577908799999L + "'", long37 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 24 + "'", int39 == 24);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577908799999L + "'", long44 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 2");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        long long3 = week1.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        boolean boolean8 = week6.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        long long10 = week6.getFirstMillisecond();
//        java.lang.String str11 = week6.toString();
//        java.lang.Class<?> wildcardClass12 = week6.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        int int15 = week14.getWeek();
//        long long16 = week14.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Year year18 = week14.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(9, year18);
//        boolean boolean21 = week19.equals((java.lang.Object) "Week 1, 2020");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week19.previous();
//        int int24 = week19.compareTo((java.lang.Object) ' ');
//        org.jfree.data.time.Year year25 = week19.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getWeek();
//        long long29 = week27.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass30 = week27.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        int int32 = week31.getWeek();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        java.util.Date date34 = year33.getEnd();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        int int37 = week36.getWeek();
//        org.jfree.data.time.Year year38 = week36.getYear();
//        java.util.Date date39 = year38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date39, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        int int44 = week43.getWeek();
//        long long45 = week43.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass46 = week43.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        int int48 = week47.getWeek();
//        org.jfree.data.time.Year year49 = week47.getYear();
//        java.util.Date date50 = year49.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date50, timeZone51);
//        long long53 = week52.getMiddleMillisecond();
//        java.util.Date date54 = week52.getStart();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        int int56 = week55.getWeek();
//        org.jfree.data.time.Year year57 = week55.getYear();
//        java.util.Date date58 = year57.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        java.lang.Class<?> wildcardClass61 = week60.getClass();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        int int63 = week62.getWeek();
//        org.jfree.data.time.Year year64 = week62.getYear();
//        java.util.Date date65 = year64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        int int67 = week66.getWeek();
//        long long68 = week66.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass69 = week66.getClass();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
//        int int71 = week70.getWeek();
//        org.jfree.data.time.Year year72 = week70.getYear();
//        java.util.Date date73 = year72.getEnd();
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date73, timeZone74);
//        long long76 = week75.getMiddleMillisecond();
//        java.util.Date date77 = week75.getStart();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        int int79 = week78.getWeek();
//        org.jfree.data.time.Year year80 = week78.getYear();
//        java.util.Date date81 = year80.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date81, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date77, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date65, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date54, timeZone82);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date39, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date34, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date26, timeZone82);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1550995200000L + "'", long10 == 1550995200000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 9, 2019" + "'", str11.equals("Week 9, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560063600000L + "'", long29 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 24 + "'", int32 == 24);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 24 + "'", int44 == 24);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560063600000L + "'", long45 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577908799999L + "'", long53 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 24 + "'", int56 == 24);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 24 + "'", int63 == 24);
//        org.junit.Assert.assertNotNull(year64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 24 + "'", int67 == 24);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560063600000L + "'", long68 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 24 + "'", int71 == 24);
//        org.junit.Assert.assertNotNull(year72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1577908799999L + "'", long76 == 1577908799999L);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 24 + "'", int79 == 24);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//    }
//}

