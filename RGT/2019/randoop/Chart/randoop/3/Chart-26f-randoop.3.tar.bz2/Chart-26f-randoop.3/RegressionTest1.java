import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = plotRenderingInfo11.getSubplotInfo(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation6 = ringPlot1.getDirection();
        java.awt.Paint paint7 = ringPlot1.getSeparatorPaint();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        java.awt.Paint paint11 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot9.setSectionPaint((java.lang.Comparable) 1.0f, paint11);
        java.awt.Paint paint13 = ringPlot9.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation14 = ringPlot9.getDirection();
        java.awt.Paint paint15 = ringPlot9.getSeparatorPaint();
        ringPlot1.setSeparatorPaint(paint15);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setBase(8.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = barRenderer7.getGradientPaintTransformer();
        barRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) month0);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = categoryMarker2.getLabelOffsetType();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 10, (float) 1561964399999L, (float) 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-131072) + "'", int3 == (-131072));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.mapDatasetToRangeAxis(2958465, 15);
        xYPlot0.setRangeCrosshairValue(1.0d, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        double double3 = categoryAxis0.getLowerMargin();
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        float float6 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke26 = stackedAreaRenderer0.getItemStroke(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = stackedAreaRenderer0.getSeriesItemLabelGenerator((-1));
        stackedAreaRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true);
        java.awt.Stroke stroke33 = stackedAreaRenderer0.lookupSeriesOutlineStroke(0);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.Plot plot1 = dateAxis0.getPlot();
        double double2 = dateAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis20.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle24.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = textTitle24.getPosition();
        textTitle24.setHeight((double) 1);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle24.draw(graphics2D29, rectangle2D30);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle24.setFont(font32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle24.getBounds();
        dateAxis20.setLeftArrow((java.awt.Shape) rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer42);
        stackedAreaRenderer42.setBaseCreateEntities(false);
        java.awt.Stroke stroke54 = stackedAreaRenderer42.lookupSeriesOutlineStroke((-1));
        categoryPlot36.setDomainGridlineStroke(stroke54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean58 = categoryPlot57.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.renderer.RendererState rendererState64 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo63);
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot57.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo63, point2D65);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState67 = stackedAreaRenderer0.initialise(graphics2D19, rectangle2D34, categoryPlot36, 3, plotRenderingInfo63);
        java.lang.Boolean boolean69 = stackedAreaRenderer0.getSeriesVisible(9);
        boolean boolean70 = stackedAreaRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator71 = stackedAreaRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererState67);
        org.junit.Assert.assertNull(boolean69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator71);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 9, 100.0f, 12.0d, 8 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 9, 100.0f, 12.0d, 8 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 9, 100.0f, 12.0d, 8 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 9, 100.0f, 12.0d, 8 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 9, 100.0f, 12.0d, 8 };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray10, numberArray15, numberArray20, numberArray25 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1, (short) -1, 8.0d, 9, (-1.0d), (-1.0d) };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1, (short) -1, 8.0d, 9, (-1.0d), (-1.0d) };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 1, (short) -1, 8.0d, 9, (-1.0d), (-1.0d) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1, (short) -1, 8.0d, 9, (-1.0d), (-1.0d) };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray33, numberArray40, numberArray47, numberArray54 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset56 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray26, numberArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset50.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean55 = flowArrangement48.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D57 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int58 = defaultKeyedValues2D57.getColumnCount();
        boolean boolean59 = flowArrangement48.equals((java.lang.Object) defaultKeyedValues2D57);
        defaultKeyedValues2D57.clear();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 10, (float) '#');
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        jFreeChart9.setBackgroundImageAlpha((float) 100);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart9.getLegend();
        jFreeChart9.setAntiAlias(true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(legendTitle10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis20.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle24.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = textTitle24.getPosition();
        textTitle24.setHeight((double) 1);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle24.draw(graphics2D29, rectangle2D30);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle24.setFont(font32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle24.getBounds();
        dateAxis20.setLeftArrow((java.awt.Shape) rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer42);
        stackedAreaRenderer42.setBaseCreateEntities(false);
        java.awt.Stroke stroke54 = stackedAreaRenderer42.lookupSeriesOutlineStroke((-1));
        categoryPlot36.setDomainGridlineStroke(stroke54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean58 = categoryPlot57.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.renderer.RendererState rendererState64 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo63);
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot57.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo63, point2D65);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState67 = stackedAreaRenderer0.initialise(graphics2D19, rectangle2D34, categoryPlot36, 3, plotRenderingInfo63);
        org.jfree.chart.entity.EntityCollection entityCollection68 = categoryItemRendererState67.getEntityCollection();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererState67);
        org.junit.Assert.assertNull(entityCollection68);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setAnchorValue((double) 1.0f, true);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = waterfallBarRenderer5.getBaseURLGenerator();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) waterfallBarRenderer5, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 10, 0.0d, (double) (short) 0, 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean6 = categoryPlot5.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo11, point2D13);
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomRangeAxes((double) ' ', (double) (-1.0f), plotRenderingInfo11, point2D15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke26 = stackedAreaRenderer0.getItemStroke(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = stackedAreaRenderer0.getSeriesItemLabelGenerator((-1));
        stackedAreaRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true);
        java.awt.Stroke stroke33 = stackedAreaRenderer0.getSeriesOutlineStroke((int) (byte) 100);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
        org.junit.Assert.assertNull(stroke33);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getLabelLinkPaint();
        numberAxis1.setTickMarkPaint(paint9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange11, false, true);
        numberAxis1.setFixedDimension((double) (-131072));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image11, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        projectInfo7.setLicenceName("ChartChangeEventType.GENERAL");
        java.lang.String str19 = projectInfo7.toString();
        java.awt.Image image20 = projectInfo7.getLogo();
        java.awt.Image image21 = null;
        projectInfo7.setLogo(image21);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "({0}, {1}) = {2} version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:({0}, {1}) = {2} hi! ().\n({0}, {1}) = {2} LICENCE TERMS:\nCategoryLabelWidthType.RANGE" + "'", str19.equals("({0}, {1}) = {2} version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:({0}, {1}) = {2} hi! ().\n({0}, {1}) = {2} LICENCE TERMS:\nCategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNull(image20);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font4 = null;
        stackedAreaRenderer3.setBaseItemLabelFont(font4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator8, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        stackedAreaRenderer3.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition12, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer3.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color16, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = stackedAreaRenderer3.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = null;
        stackedAreaRenderer3.setLegendItemURLGenerator(categorySeriesLabelGenerator22);
        stackedAreaRenderer3.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke28 = stackedAreaRenderer3.getItemStroke((int) 'a', 0);
        java.awt.Stroke stroke29 = stackedAreaRenderer3.getBaseStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke29);
        java.awt.Color color31 = java.awt.Color.YELLOW;
        xYPlot0.setOutlinePaint((java.awt.Paint) color31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        double double3 = ringPlot0.getSectionDepth();
        ringPlot0.setInnerSeparatorExtension(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        categoryPlot0.configureDomainAxes();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = textTitle16.getMargin();
        double double19 = rectangleInsets17.calculateLeftOutset((double) 10.0f);
        double double21 = rectangleInsets17.calculateLeftInset(100.0d);
        double double23 = rectangleInsets17.calculateTopOutset((double) 1L);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle25.getMargin();
        double double28 = rectangleInsets26.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        textTitle30.draw(graphics2D31, rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle30.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo37.getDataArea();
        boolean boolean39 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D34, rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets26.createOutsetRectangle(rectangle2D34, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity43 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets17.createInsetRectangle(rectangle2D42);
        try {
            categoryPlot0.drawBackground(graphics2D14, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D44);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 1.0f, false);
        double double7 = dateRange0.getLength();
        java.util.Date date8 = dateRange0.getLowerDate();
        java.util.TimeZone timeZone9 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone9;
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date8, timeZone9);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getLabelLinkPaint();
        stackedAreaRenderer0.setBaseFillPaint(paint9, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font14 = null;
        stackedAreaRenderer13.setBaseItemLabelFont(font14, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        stackedAreaRenderer13.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator18, false);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer13);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font24 = null;
        stackedAreaRenderer23.setBaseItemLabelFont(font24, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = null;
        stackedAreaRenderer23.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator28, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        stackedAreaRenderer23.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition32, false);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer23.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color36, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = stackedAreaRenderer23.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer13.setSeriesNegativeItemLabelPosition(9, itemLabelPosition41);
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition41, true);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        boolean boolean48 = dateAxis46.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = dateAxis46.getTickUnit();
        java.awt.Stroke stroke50 = dateAxis46.getAxisLineStroke();
        stackedAreaRenderer0.setSeriesStroke(2958465, stroke50);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(itemLabelPosition41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTickUnit49);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange0, 12.0d);
        boolean boolean7 = dateRange0.contains(100.0d);
        java.lang.String str8 = dateRange0.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        boolean boolean20 = ringPlot0.equals((java.lang.Object) (short) 10);
        ringPlot0.setNoDataMessage("CategoryLabelWidthType.RANGE");
        java.awt.Stroke stroke23 = ringPlot0.getSeparatorStroke();
        try {
            ringPlot0.setBackgroundImageAlpha((float) (-131072));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 60000L);
        axisState1.cursorUp((double) 1.0f);
        double double4 = axisState1.getCursor();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        java.util.List list7 = defaultStatisticalCategoryDataset5.getRowKeys();
        axisState1.setTicks(list7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 59999.0d + "'", double4 == 59999.0d);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Size2D[width=0.0, height=0.0]");
        numberAxis3D1.setFixedAutoRange((double) (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle4.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle4.getPosition();
        textTitle4.setHeight((double) 1);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        textTitle4.draw(graphics2D9, rectangle2D10);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle4.setFont(font12);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle4.getBounds();
        dateAxis0.setLeftArrow((java.awt.Shape) rectangle2D14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState((double) 60000L);
        axisState18.cursorUp((double) 1.0f);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot21.getRangeMarkers((int) (byte) 100, layer23);
        xYPlot21.setDomainCrosshairValue(10.0d, false);
        xYPlot21.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = textTitle32.getMargin();
        double double35 = rectangleInsets33.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        textTitle37.draw(graphics2D38, rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle37.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection42 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = new org.jfree.chart.ChartRenderingInfo(entityCollection42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        java.awt.geom.Rectangle2D rectangle2D45 = plotRenderingInfo44.getDataArea();
        boolean boolean46 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D41, rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets33.createOutsetRectangle(rectangle2D41, false, true);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        int int51 = xYPlot50.getDomainAxisCount();
        java.util.List list52 = xYPlot50.getAnnotations();
        xYPlot21.drawRangeTickBands(graphics2D30, rectangle2D49, list52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        java.util.List list55 = dateAxis0.refreshTicks(graphics2D16, axisState18, rectangle2D49, rectangleEdge54);
        org.jfree.data.time.DateRange dateRange56 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range59 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange56, (double) (byte) -1, false);
        org.jfree.data.Range range62 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange56, (double) 1.0f, false);
        dateAxis0.setRange(range62, false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNull(list55);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(range62);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.lang.Object obj2 = defaultCategoryDataset0.clone();
        try {
            java.lang.Number number5 = defaultCategoryDataset0.getValue(6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) 100, (double) 1.0f, (double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis5.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle9.getPosition();
        textTitle9.setHeight((double) 1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle9.draw(graphics2D14, rectangle2D15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle9.setFont(font17);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle9.getBounds();
        dateAxis5.setLeftArrow((java.awt.Shape) rectangle2D19);
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets4.createInsetRectangle(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) (byte) -1, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range9, (org.jfree.data.general.Dataset) taskSeriesCollection10);
        boolean boolean13 = taskSeriesCollection10.equals((java.lang.Object) 9);
        boolean boolean14 = categoryAxis0.hasListener((java.util.EventListener) taskSeriesCollection10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.previous();
        int int18 = taskSeriesCollection10.indexOf((java.lang.Comparable) regularTimePeriod17);
        try {
            int int21 = taskSeriesCollection10.getSubIntervalCount(5, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        java.awt.Paint paint78 = stackedAreaRenderer48.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        int int80 = xYPlot79.getDomainAxisCount();
        java.util.List list81 = xYPlot79.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray88 = new org.jfree.chart.axis.ValueAxis[] { dateAxis82, dateAxis83, dateAxis84, dateAxis85, dateAxis86, dateAxis87 };
        xYPlot79.setDomainAxes(valueAxisArray88);
        stackedAreaRenderer48.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot79);
        boolean boolean91 = xYPlot79.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(valueAxisArray88);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        int int3 = xYPlot2.getDomainAxisCount();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot2.setRangeTickBandPaint((java.awt.Paint) color4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot2.getRangeAxisLocation(3);
        xYPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean10 = numberAxis8.hasListener((java.util.EventListener) taskSeriesCollection9);
        java.text.NumberFormat numberFormat11 = null;
        numberAxis8.setNumberFormatOverride(numberFormat11);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis8);
        java.lang.Object obj14 = numberAxis8.clone();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle3.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle3.getPosition();
        textTitle3.setHeight((double) 1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        textTitle3.draw(graphics2D8, rectangle2D9);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle3.setFont(font11);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle3.getBounds();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis3.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.util.Date date7 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.lang.String str13 = dateTickUnit11.valueToString((double) 100.0f);
        java.util.Date date14 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit11);
        boolean boolean15 = dateAxis0.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12/31/69 4:00 PM" + "'", str13.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 3);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        segmentedTimeline4.setStartTime((long) 'a');
        java.util.Date date8 = segmentedTimeline4.getDate((long) '4');
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange9, (double) (byte) -1, false);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange9, (double) 1.0f, false);
        double double16 = dateRange9.getLength();
        java.util.Date date17 = dateRange9.getLowerDate();
        try {
            org.jfree.data.gantt.Task task18 = new org.jfree.data.gantt.Task("ThreadContext", date8, date17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setShadowYOffset((double) 100);
        boolean boolean5 = month0.equals((java.lang.Object) ringPlot2);
        java.util.Date date6 = month0.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("June 2019", graphics2D1, 0.0d, (float) (short) 10, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.block.BlockResult blockResult3 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        blockResult3.setEntityCollection(entityCollection4);
        boolean boolean6 = categoryPlot0.equals((java.lang.Object) entityCollection4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer3D0.getBaseToolTipGenerator();
        java.awt.Paint paint8 = barRenderer3D0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle1.setHorizontalAlignment(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.GENERAL");
        labelBlock1.setURLText("");
        org.jfree.chart.block.BlockFrame blockFrame4 = labelBlock1.getFrame();
        org.junit.Assert.assertNotNull(blockFrame4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot2.setDomainAxisLocation((int) 'a', axisLocation8);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot2.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle13.getMargin();
        double double16 = rectangleInsets14.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle18.draw(graphics2D19, rectangle2D20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle18.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo25.getDataArea();
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D22, rectangle2D26);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets14.createOutsetRectangle(rectangle2D22, false, true);
        try {
            lineRenderer3D0.drawBackground(graphics2D1, categoryPlot2, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        stackedAreaRenderer0.setBaseCreateEntities(false);
        java.awt.Stroke stroke12 = stackedAreaRenderer0.lookupSeriesOutlineStroke((-1));
        stackedAreaRenderer0.setRenderAsPercentages(true);
        java.awt.Shape shape17 = stackedAreaRenderer0.getItemShape(5, 10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getYOffset();
        java.awt.Paint paint2 = barRenderer3D0.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        boolean boolean7 = numberAxis4.getAutoRangeIncludesZero();
        numberAxis4.setTickMarkInsideLength(0.0f);
        boolean boolean10 = barRenderer3D0.equals((java.lang.Object) numberAxis4);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis4.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(markerAxisBand11);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot3.addChangeListener(plotChangeListener5);
        categoryPlot3.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions2.getLabelPosition(rectangleEdge9);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions2);
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(categoryLabelPosition10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        segmentedTimeline3.setStartTime((long) 'a');
        java.util.Date date7 = segmentedTimeline3.getDate((long) '4');
        long long8 = segmentedTimeline3.getSegmentSize();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-447L) + "'", long8 == (-447L));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        java.awt.Paint paint78 = stackedAreaRenderer48.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        int int80 = xYPlot79.getDomainAxisCount();
        java.util.List list81 = xYPlot79.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray88 = new org.jfree.chart.axis.ValueAxis[] { dateAxis82, dateAxis83, dateAxis84, dateAxis85, dateAxis86, dateAxis87 };
        xYPlot79.setDomainAxes(valueAxisArray88);
        stackedAreaRenderer48.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot79);
        java.awt.Stroke stroke91 = xYPlot79.getRangeGridlineStroke();
        java.lang.Object obj92 = xYPlot79.clone();
        try {
            java.awt.Paint paint94 = xYPlot79.getQuadrantPaint((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(valueAxisArray88);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(obj92);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis20.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle24.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = textTitle24.getPosition();
        textTitle24.setHeight((double) 1);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle24.draw(graphics2D29, rectangle2D30);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle24.setFont(font32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle24.getBounds();
        dateAxis20.setLeftArrow((java.awt.Shape) rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer42);
        stackedAreaRenderer42.setBaseCreateEntities(false);
        java.awt.Stroke stroke54 = stackedAreaRenderer42.lookupSeriesOutlineStroke((-1));
        categoryPlot36.setDomainGridlineStroke(stroke54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean58 = categoryPlot57.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.renderer.RendererState rendererState64 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo63);
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot57.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo63, point2D65);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState67 = stackedAreaRenderer0.initialise(graphics2D19, rectangle2D34, categoryPlot36, 3, plotRenderingInfo63);
        java.lang.Boolean boolean69 = stackedAreaRenderer0.getSeriesVisible(9);
        boolean boolean70 = stackedAreaRenderer0.getAutoPopulateSeriesFillPaint();
        java.lang.Object obj71 = stackedAreaRenderer0.clone();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererState67);
        org.junit.Assert.assertNull(boolean69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(obj71);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) (byte) -1, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range9, (org.jfree.data.general.Dataset) taskSeriesCollection10);
        boolean boolean13 = taskSeriesCollection10.equals((java.lang.Object) 9);
        boolean boolean14 = categoryAxis0.hasListener((java.util.EventListener) taskSeriesCollection10);
        try {
            java.lang.Number number17 = taskSeriesCollection10.getPercentComplete(30, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 30, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        int int4 = taskSeriesCollection2.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "ClassContext", "");
        java.awt.Shape shape12 = chartEntity11.getArea();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle14.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = textTitle14.getPosition();
        textTitle14.setHeight((double) 1);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle14.draw(graphics2D19, rectangle2D20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle14.setFont(font22);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle14.getBounds();
        chartEntity11.setArea((java.awt.Shape) rectangle2D24);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        ringPlot28.setShadowYOffset((double) 100);
        java.awt.Font font31 = ringPlot28.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.lang.Object obj38 = textTitle32.draw(graphics2D33, rectangle2D34, (java.lang.Object) plotRenderingInfo37);
        org.jfree.chart.plot.CrosshairState crosshairState39 = null;
        boolean boolean40 = xYPlot0.render(graphics2D5, rectangle2D24, (int) '#', plotRenderingInfo37, crosshairState39);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection43 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean44 = numberAxis42.hasListener((java.util.EventListener) taskSeriesCollection43);
        boolean boolean45 = numberAxis42.getAutoRangeIncludesZero();
        numberAxis42.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.RingPlot ringPlot49 = new org.jfree.chart.plot.RingPlot(pieDataset48);
        java.awt.Paint paint50 = ringPlot49.getLabelLinkPaint();
        numberAxis42.setTickMarkPaint(paint50);
        org.jfree.data.time.DateRange dateRange52 = new org.jfree.data.time.DateRange();
        numberAxis42.setRangeWithMargins((org.jfree.data.Range) dateRange52, false, true);
        org.jfree.data.Range range56 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis42);
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = xYPlot0.getOrientation();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(range56);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(plotOrientation58);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(15, 9, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) (byte) -1, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range9, (org.jfree.data.general.Dataset) taskSeriesCollection10);
        boolean boolean13 = taskSeriesCollection10.equals((java.lang.Object) 9);
        boolean boolean14 = categoryAxis0.hasListener((java.util.EventListener) taskSeriesCollection10);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getLabelPaint();
        java.text.DateFormat dateFormat17 = dateAxis15.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis18.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = dateAxis18.getTickUnit();
        java.util.Date date22 = dateAxis15.calculateHighestVisibleTickValue(dateTickUnit21);
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone23;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date22, timeZone23);
        try {
            java.lang.Number number28 = taskSeriesCollection10.getEndValue((java.lang.Comparable) date22, (java.lang.Comparable) "Other", 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font3 = null;
        stackedAreaRenderer2.setBaseItemLabelFont(font3, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedAreaRenderer2.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator7, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedAreaRenderer2.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition11, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer2.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color15, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedAreaRenderer2.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer2.setBasePaint((java.awt.Paint) color21, true);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        ringPlot25.setShadowYOffset((double) 100);
        java.awt.Font font28 = ringPlot25.getNoDataMessageFont();
        stackedAreaRenderer2.setSeriesItemLabelFont((int) '4', font28);
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot31.addChangeListener(plotChangeListener33);
        categoryPlot31.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot31.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = textTitle41.getMargin();
        double double44 = rectangleInsets42.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font28, paint30, rectangleEdge37, horizontalAlignment38, verticalAlignment39, rectangleInsets42);
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement49 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment38, verticalAlignment46, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer50 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement49);
        blockContainer50.clear();
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = textTitle53.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = textTitle53.getPosition();
        textTitle53.setHeight((double) 1);
        textTitle53.setWidth((double) (byte) 0);
        boolean boolean60 = textTitle53.getNotify();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment61 = textTitle53.getTextAlignment();
        java.lang.Object obj62 = null;
        blockContainer50.add((org.jfree.chart.block.Block) textTitle53, obj62);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint65 = null;
        try {
            org.jfree.chart.util.Size2D size2D66 = borderArrangement0.arrange(blockContainer50, graphics2D64, rectangleConstraint65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment61);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset(xYDataset9);
        boolean boolean11 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) (short) 100);
        double double6 = rectangleInsets2.extendHeight((double) 2019L);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2019.0d + "'", double6 == 2019.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator17 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator18 = null;
        try {
            java.lang.String str19 = categoryItemEntity16.getImageMapAreaTag(toolTipTagFragmentGenerator17, uRLTagFragmentGenerator18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        java.awt.Shape shape17 = null;
        try {
            categoryItemEntity16.setArea(shape17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        stackedAreaRenderer0.setBaseCreateEntities(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis14.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle18.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle18.getPosition();
        textTitle18.setHeight((double) 1);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        textTitle18.draw(graphics2D23, rectangle2D24);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle18.setFont(font26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle18.getBounds();
        dateAxis14.setLeftArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape33, "ClassContext", "");
        java.awt.Shape shape37 = chartEntity36.getArea();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle39.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = textTitle39.getPosition();
        textTitle39.setHeight((double) 1);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        textTitle39.draw(graphics2D44, rectangle2D45);
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle39.setFont(font47);
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle39.getBounds();
        chartEntity36.setArea((java.awt.Shape) rectangle2D49);
        stackedAreaRenderer0.drawRangeMarker(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis14, marker30, rectangle2D49);
        stackedAreaRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator55 = null;
        stackedAreaRenderer0.setSeriesItemLabelGenerator((int) (byte) 10, categoryItemLabelGenerator55, false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(rectangle2D49);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange0, (double) 10, (double) (-131072));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-10.0) <= upper (-131071.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setBase(8.0d);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator8 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D0.setSeriesToolTipGenerator(15, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        boolean boolean9 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getMargin();
        double double14 = rectangleInsets12.calculateLeftOutset((double) 10.0f);
        double double16 = rectangleInsets12.extendWidth((double) 0.0f);
        xYPlot0.setAxisOffset(rectangleInsets12);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot18.getRangeMarkers((int) (byte) 100, layer20);
        java.awt.Paint paint22 = xYPlot18.getRangeGridlinePaint();
        xYPlot0.setDomainCrosshairPaint(paint22);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation6 = ringPlot1.getDirection();
        ringPlot1.setStartAngle((double) 'a');
        ringPlot1.setSectionDepth((double) 1561964399999L);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer6);
        stackedAreaRenderer6.setBaseCreateEntities(false);
        java.awt.Stroke stroke18 = stackedAreaRenderer6.lookupSeriesOutlineStroke((-1));
        categoryPlot0.setDomainGridlineStroke(stroke18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot0.getRenderer((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = xYPlot50.getRangeMarkers((int) (byte) 100, layer52);
        xYPlot50.setDomainCrosshairValue(10.0d, false);
        xYPlot50.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot50);
        float float60 = jFreeChart59.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot61 = jFreeChart59.getXYPlot();
        org.jfree.chart.title.LegendTitle legendTitle62 = jFreeChart59.getLegend();
        blockContainer49.add((org.jfree.chart.block.Block) legendTitle62);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = legendTitle62.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.5f + "'", float60 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot61);
        org.junit.Assert.assertNotNull(legendTitle62);
        org.junit.Assert.assertNotNull(rectangleInsets64);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesOutlinePaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        minMaxCategoryRenderer0.setGroupStroke(stroke1);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint16 = categoryAxis15.getAxisLinePaint();
        categoryPlot0.setDomainAxis(0, categoryAxis15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) 1.0f);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 3600000L, (java.lang.Comparable) "CategoryLabelWidthType.RANGE", 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = ringPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        java.lang.Comparable comparable17 = categoryItemEntity16.getRowKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 4.0d + "'", comparable17.equals(4.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100.0f);
        int int5 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 4);
        java.util.List list6 = defaultCategoryDataset0.getColumnKeys();
        int int8 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 100.0d);
        java.util.List list9 = defaultCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        java.awt.Paint paint2 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        double[] doubleArray12 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray19 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray26 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray33 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray40 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray47 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray48 = new double[][] { doubleArray12, doubleArray19, doubleArray26, doubleArray33, doubleArray40, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer52 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font53 = null;
        stackedAreaRenderer52.setBaseItemLabelFont(font53, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator57 = null;
        stackedAreaRenderer52.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator57, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = null;
        stackedAreaRenderer52.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition61, false);
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer52.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color65, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition70 = stackedAreaRenderer52.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator71 = null;
        stackedAreaRenderer52.setLegendItemURLGenerator(categorySeriesLabelGenerator71);
        stackedAreaRenderer52.setBaseItemLabelsVisible(false);
        java.awt.Paint paint76 = stackedAreaRenderer52.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer52);
        java.awt.Paint paint78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean79 = stackedAreaRenderer52.equals((java.lang.Object) paint78);
        java.awt.Paint paint80 = stackedAreaRenderer52.getBaseFillPaint();
        java.awt.Paint paint82 = stackedAreaRenderer52.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot();
        int int84 = xYPlot83.getDomainAxisCount();
        java.util.List list85 = xYPlot83.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis88 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis89 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis90 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis91 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray92 = new org.jfree.chart.axis.ValueAxis[] { dateAxis86, dateAxis87, dateAxis88, dateAxis89, dateAxis90, dateAxis91 };
        xYPlot83.setDomainAxes(valueAxisArray92);
        stackedAreaRenderer52.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot83);
        java.awt.Stroke stroke95 = xYPlot83.getRangeGridlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke95);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(itemLabelPosition70);
        org.junit.Assert.assertNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(paint82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(list85);
        org.junit.Assert.assertNotNull(valueAxisArray92);
        org.junit.Assert.assertNotNull(stroke95);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle1.draw(graphics2D2, rectangle2D3);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        stackedAreaRenderer6.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition15, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer6.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color19, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = stackedAreaRenderer6.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer6.setBasePaint((java.awt.Paint) color25, true);
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        ringPlot29.setShadowYOffset((double) 100);
        java.awt.Font font32 = ringPlot29.getNoDataMessageFont();
        stackedAreaRenderer6.setSeriesItemLabelFont((int) '4', font32);
        java.awt.Paint paint34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean36 = categoryPlot35.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        categoryPlot35.addChangeListener(plotChangeListener37);
        categoryPlot35.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot35.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle45.getMargin();
        double double48 = rectangleInsets46.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font32, paint34, rectangleEdge41, horizontalAlignment42, verticalAlignment43, rectangleInsets46);
        textTitle1.setPosition(rectangleEdge41);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = textTitle1.getMargin();
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setCircular(false);
        ringPlot0.setLabelLinkMargin((double) (byte) 0);
        java.awt.Stroke stroke7 = ringPlot0.getLabelLinkStroke();
        java.awt.Shape shape8 = ringPlot0.getLegendItemShape();
        double double10 = ringPlot0.getExplodePercent((java.lang.Comparable) "CategoryLabelWidthType.RANGE");
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        java.awt.Stroke stroke4 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) "35");
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = ringPlot0.getLabelLinkStroke();
        ringPlot0.setOuterSeparatorExtension((double) 2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint16 = categoryAxis15.getAxisLinePaint();
        categoryPlot0.setDomainAxis(0, categoryAxis15);
        categoryAxis15.setMaximumCategoryLabelLines((-131072));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getSeriesCount();
        taskSeriesCollection0.removeAll();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setAnchorValue((double) 1.0f, true);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot6.setSectionPaint((java.lang.Comparable) 1.0f, paint8);
        java.awt.Paint paint10 = ringPlot6.getLabelShadowPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = ringPlot6.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(drawingSupplier11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        java.awt.RenderingHints renderingHints10 = null;
        try {
            jFreeChart9.setRenderingHints(renderingHints10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYPlot0.setDomainCrosshairPaint(paint2);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle4.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle4.getPosition();
        textTitle4.setHeight((double) 1);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        textTitle4.draw(graphics2D9, rectangle2D10);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle4.setFont(font12);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle4.getBounds();
        dateAxis0.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        java.lang.Object obj50 = blockContainer49.clone();
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = textTitle52.getMargin();
        double double55 = rectangleInsets53.calculateLeftOutset((double) (short) 100);
        double double56 = rectangleInsets53.getBottom();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType57 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str58 = categoryLabelWidthType57.toString();
        boolean boolean59 = rectangleInsets53.equals((java.lang.Object) str58);
        double double61 = rectangleInsets53.extendHeight((-1.0d));
        blockContainer49.setPadding(rectangleInsets53);
        java.lang.Object obj63 = blockContainer49.clone();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelWidthType57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str58.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-1.0d) + "'", double61 == (-1.0d));
        org.junit.Assert.assertNotNull(obj63);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str4 = numberTickUnit2.valueToString((double) '#');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list6 = taskSeriesCollection5.getRowKeys();
        taskSeriesCollection5.removeAll();
        boolean boolean8 = numberTickUnit2.equals((java.lang.Object) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        java.text.DateFormat dateFormat11 = dateAxis9.getDateFormatOverride();
        boolean boolean12 = dateAxis9.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis13.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis13.getTickUnit();
        java.awt.Stroke stroke17 = dateAxis13.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis13.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline21);
        dateAxis9.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline21);
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis9.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        java.text.DateFormat dateFormat27 = dateAxis25.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis28.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis28.getTickUnit();
        java.util.Date date32 = dateAxis25.calculateHighestVisibleTickValue(dateTickUnit31);
        java.util.Date date33 = dateTickUnit24.addToDate(date32);
        java.lang.Comparable[] comparableArray35 = new java.lang.Comparable[] { "RangeType.FULL", 1514793600000L, numberTickUnit2, date33, 1L };
        java.lang.Comparable[] comparableArray36 = null;
        double[] doubleArray45 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray52 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray59 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray66 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray73 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray80 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray81 = new double[][] { doubleArray45, doubleArray52, doubleArray59, doubleArray66, doubleArray73, doubleArray80 };
        org.jfree.data.category.CategoryDataset categoryDataset82 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray81);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset83 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray35, comparableArray36, doubleArray81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "35" + "'", str4.equals("35"));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(dateFormat27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(comparableArray35);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(categoryDataset82);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle18.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle18.getPosition();
        textTitle18.setHeight((double) 1);
        textTitle18.setWidth((double) (byte) 0);
        boolean boolean25 = textTitle18.getNotify();
        textTitle18.setPadding((double) 100.0f, (double) 2.0f, (double) 900000L, (double) (byte) -1);
        boolean boolean31 = categoryItemEntity16.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = minMaxCategoryRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis3.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.util.Date date7 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        int int8 = dateTickUnit6.getRollUnit();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot11.addChangeListener(plotChangeListener13);
        categoryPlot11.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = categoryLabelPositions10.getLabelPosition(rectangleEdge17);
        categoryAxis8.setCategoryLabelPositions(categoryLabelPositions10);
        java.lang.String str21 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        categoryPlot0.setDomainAxis(categoryAxis8);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean25 = categoryPlot24.isOutlineVisible();
        java.awt.Paint paint26 = categoryPlot24.getOutlinePaint();
        categoryPlot24.mapDatasetToDomainAxis((int) (byte) 100, 100);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot31.addChangeListener(plotChangeListener33);
        categoryPlot31.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot31.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace38 = new org.jfree.chart.axis.AxisSpace();
        axisSpace38.setLeft(Double.NaN);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean43 = categoryPlot42.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener44 = null;
        categoryPlot42.addChangeListener(plotChangeListener44);
        categoryPlot42.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot42.getRangeAxisEdge();
        boolean boolean49 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge48);
        axisSpace38.add(0.0d, rectangleEdge48);
        org.jfree.chart.axis.AxisSpace axisSpace51 = new org.jfree.chart.axis.AxisSpace();
        axisSpace51.setLeft(Double.NaN);
        axisSpace51.setRight(0.0d);
        axisSpace38.ensureAtLeast(axisSpace51);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace57 = categoryAxis8.reserveSpace(graphics2D23, (org.jfree.chart.plot.Plot) categoryPlot24, rectangle2D30, rectangleEdge37, axisSpace51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(categoryLabelPosition18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        int int5 = defaultCategoryDataset2.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        int int7 = defaultCategoryDataset2.getColumnCount();
        defaultCategoryDataset2.removeColumn((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library library14 = new org.jfree.chart.ui.Library("SerialDate.weekInMonthToString(): invalid code.", "February", "ClassContext", "Size2D[width=0.0, height=0.0]");
        boolean boolean15 = defaultCategoryDataset2.equals((java.lang.Object) library14);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot2.addChangeListener(plotChangeListener4);
        categoryPlot2.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot2.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions1.getLabelPosition(rectangleEdge8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean11 = categoryPlot10.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot10.addChangeListener(plotChangeListener12);
        categoryPlot10.clearRangeMarkers((int) ' ');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        categoryPlot10.datasetChanged(datasetChangeEvent16);
        boolean boolean18 = rectangleEdge8.equals((java.lang.Object) categoryPlot10);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke25 = stackedAreaRenderer0.getItemStroke((int) 'a', 0);
        java.awt.Stroke stroke28 = stackedAreaRenderer0.getItemOutlineStroke((int) (byte) 100, 255);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        blockContainer49.clear();
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = textTitle52.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = textTitle52.getPosition();
        textTitle52.setHeight((double) 1);
        textTitle52.setWidth((double) (byte) 0);
        boolean boolean59 = textTitle52.getNotify();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = textTitle52.getTextAlignment();
        java.lang.Object obj61 = null;
        blockContainer49.add((org.jfree.chart.block.Block) textTitle52, obj61);
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer65 = null;
        java.util.Collection collection66 = xYPlot63.getRangeMarkers((int) (byte) 100, layer65);
        xYPlot63.setDomainCrosshairValue(10.0d, false);
        xYPlot63.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart72 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot63);
        float float73 = jFreeChart72.getBackgroundImageAlpha();
        jFreeChart72.fireChartChanged();
        textTitle52.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart72);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNull(collection66);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 0.5f + "'", float73 == 0.5f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        java.lang.String str3 = textTitle1.getURLText();
        boolean boolean4 = textTitle1.getNotify();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle6.getPosition();
        textTitle6.setHeight((double) 1);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle6.draw(graphics2D11, rectangle2D12);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle6.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment14);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(verticalAlignment14);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        boolean boolean5 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        java.lang.Boolean boolean7 = stackedAreaRenderer0.getSeriesVisible(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer0.getSeriesURLGenerator(2958465);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        stackedAreaRenderer0.setBaseStroke(stroke10, true);
        stackedAreaRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis2.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle6.getPosition();
        textTitle6.setHeight((double) 1);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle6.draw(graphics2D11, rectangle2D12);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle6.setFont(font14);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle6.getBounds();
        dateAxis2.setLeftArrow((java.awt.Shape) rectangle2D16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle19.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = textTitle19.getPosition();
        double double22 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D16, rectangleEdge21);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "WMAP_Plot");
        waterfallBarRenderer0.setSeriesShape((int) (byte) 100, (java.awt.Shape) rectangle2D16, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean4 = ringPlot0.equals((java.lang.Object) paint3);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis10.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis10.getTickUnit();
        java.awt.Stroke stroke14 = dateAxis10.getAxisLineStroke();
        java.awt.Shape shape16 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D17 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double18 = barRenderer3D17.getYOffset();
        java.awt.Paint paint19 = barRenderer3D17.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection22 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean23 = numberAxis21.hasListener((java.util.EventListener) taskSeriesCollection22);
        boolean boolean24 = numberAxis21.getAutoRangeIncludesZero();
        numberAxis21.setTickMarkInsideLength(0.0f);
        boolean boolean27 = barRenderer3D17.equals((java.lang.Object) numberAxis21);
        boolean boolean28 = numberAxis21.isAxisLineVisible();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean31 = dateAxis29.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        java.awt.Stroke stroke33 = dateAxis29.getAxisLineStroke();
        numberAxis21.setTickMarkStroke(stroke33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot(pieDataset36);
        java.awt.Paint paint39 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot37.setSectionPaint((java.lang.Comparable) 1.0f, paint39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot37.setLabelLinkPaint((java.awt.Paint) color41);
        boolean boolean43 = color35.equals((java.lang.Object) color41);
        try {
            org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem(attributedString0, "RangeType.FULL", "SortOrder.ASCENDING", "Pie Plot", false, shape5, false, paint7, true, paint9, stroke14, true, shape16, stroke33, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart9.getXYPlot();
        jFreeChart9.fireChartChanged();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart9.getPadding();
        double double15 = rectangleInsets13.calculateTopInset((double) 30);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset(xYDataset9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange11, (double) (byte) -1, false);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange11, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection18 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range17, (org.jfree.data.general.Dataset) taskSeriesCollection18);
        xYPlot0.datasetChanged(datasetChangeEvent19);
        java.lang.Object obj21 = xYPlot0.clone();
        boolean boolean22 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "ClassContext", "");
        java.awt.Shape shape12 = chartEntity11.getArea();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle14.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = textTitle14.getPosition();
        textTitle14.setHeight((double) 1);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle14.draw(graphics2D19, rectangle2D20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle14.setFont(font22);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle14.getBounds();
        chartEntity11.setArea((java.awt.Shape) rectangle2D24);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        ringPlot28.setShadowYOffset((double) 100);
        java.awt.Font font31 = ringPlot28.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.lang.Object obj38 = textTitle32.draw(graphics2D33, rectangle2D34, (java.lang.Object) plotRenderingInfo37);
        org.jfree.chart.plot.CrosshairState crosshairState39 = null;
        boolean boolean40 = xYPlot0.render(graphics2D5, rectangle2D24, (int) '#', plotRenderingInfo37, crosshairState39);
        java.awt.Paint paint41 = xYPlot0.getRangeCrosshairPaint();
        int int42 = xYPlot0.getWeight();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot44.getRangeAxisLocation();
        xYPlot0.setDomainAxisLocation((int) (short) 1, axisLocation45, true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        ringPlot23.setShadowYOffset((double) 100);
        java.awt.Font font26 = ringPlot23.getNoDataMessageFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font26);
        int int28 = stackedAreaRenderer0.getColumnCount();
        boolean boolean29 = stackedAreaRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-447));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis4.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis4.getTickUnit();
        java.awt.Stroke stroke8 = dateAxis4.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis4.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline12);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint17 = dateAxis16.getLabelPaint();
        java.text.DateFormat dateFormat18 = dateAxis16.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis19.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis19.getTickUnit();
        java.util.Date date23 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit22);
        java.util.Date date24 = dateTickUnit15.addToDate(date23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        java.text.DateFormat dateFormat27 = dateAxis25.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis28.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis28.getTickUnit();
        java.util.Date date32 = dateAxis25.calculateHighestVisibleTickValue(dateTickUnit31);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        segmentedTimeline36.setStartTime((long) 'a');
        java.util.Date date40 = segmentedTimeline36.getDate((long) '4');
        java.util.TimeZone timeZone41 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone41;
        java.util.Date date43 = dateTickUnit31.addToDate(date40, timeZone41);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date24, timeZone41);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(dateFormat18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(dateFormat27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(date43);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft(Double.NaN);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot4.addChangeListener(plotChangeListener6);
        categoryPlot4.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getRangeAxisEdge();
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge10);
        axisSpace0.add(0.0d, rectangleEdge10);
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        axisSpace13.setLeft(Double.NaN);
        axisSpace13.setRight(0.0d);
        axisSpace0.ensureAtLeast(axisSpace13);
        double double19 = axisSpace13.getRight();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        textTitle2.setHeight((double) 1);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle2.draw(graphics2D7, rectangle2D8);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle2.setFont(font10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        java.lang.Object obj13 = chartRenderingInfo12.clone();
        centerArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) chartRenderingInfo12);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.Object obj5 = null;
        boolean boolean6 = textAnchor4.equals(obj5);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) 10L, textAnchor4, (double) 8, textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Color color2 = java.awt.Color.getColor("({0}, {1}) = {2}", 2);
        int int3 = color2.getBlue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        double double3 = stackedBarRenderer3D2.getUpperClip();
        stackedBarRenderer3D2.setRenderAsPercentages(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        stackedBarRenderer3D2.setSeriesItemLabelGenerator(10, categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setTickMarkInsideLength(0.0f);
        boolean boolean8 = numberAxis1.equals((java.lang.Object) "({0}, {1}) = {3} - {4}");
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot10.getRangeMarkers((int) (byte) 100, layer12);
        xYPlot10.setDomainCrosshairValue(10.0d, false);
        xYPlot10.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle21.getMargin();
        double double24 = rectangleInsets22.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        textTitle26.draw(graphics2D27, rectangle2D28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle26.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo33.getDataArea();
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D30, rectangle2D34);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets22.createOutsetRectangle(rectangle2D30, false, true);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        int int40 = xYPlot39.getDomainAxisCount();
        java.util.List list41 = xYPlot39.getAnnotations();
        xYPlot10.drawRangeTickBands(graphics2D19, rectangle2D38, list41);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        textTitle44.draw(graphics2D45, rectangle2D46);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer49 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font50 = null;
        stackedAreaRenderer49.setBaseItemLabelFont(font50, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = null;
        stackedAreaRenderer49.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator54, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition58 = null;
        stackedAreaRenderer49.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition58, false);
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer49.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color62, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition67 = stackedAreaRenderer49.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color68 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer49.setBasePaint((java.awt.Paint) color68, true);
        org.jfree.chart.plot.RingPlot ringPlot72 = new org.jfree.chart.plot.RingPlot();
        ringPlot72.setShadowYOffset((double) 100);
        java.awt.Font font75 = ringPlot72.getNoDataMessageFont();
        stackedAreaRenderer49.setSeriesItemLabelFont((int) '4', font75);
        java.awt.Paint paint77 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean79 = categoryPlot78.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener80 = null;
        categoryPlot78.addChangeListener(plotChangeListener80);
        categoryPlot78.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = categoryPlot78.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment85 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment86 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle88 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets89 = textTitle88.getMargin();
        double double91 = rectangleInsets89.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle92 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font75, paint77, rectangleEdge84, horizontalAlignment85, verticalAlignment86, rectangleInsets89);
        textTitle44.setPosition(rectangleEdge84);
        double double94 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D38, rectangleEdge84);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(itemLabelPosition67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertNotNull(horizontalAlignment85);
        org.junit.Assert.assertNotNull(verticalAlignment86);
        org.junit.Assert.assertNotNull(rectangleInsets89);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(8.0d, 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot0.getDatasetRenderingOrder();
        java.util.List list6 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setShadowYOffset((double) 100);
        java.awt.Font font5 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font5);
        java.awt.Color color7 = java.awt.Color.pink;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("RangeType.NEGATIVE", font5, (java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        chartRenderingInfo1.clear();
        chartRenderingInfo1.clear();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = chartRenderingInfo1.getPlotInfo();
        org.junit.Assert.assertNotNull(plotRenderingInfo4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        boolean boolean5 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis1.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = barRenderer3D6.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer3D6.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D6.setMinimumBarLength((double) (short) 1);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot14.addChangeListener(plotChangeListener16);
        categoryPlot14.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font21 = null;
        stackedAreaRenderer20.setBaseItemLabelFont(font21, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedAreaRenderer20.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator25, false);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer20);
        stackedAreaRenderer20.setBaseCreateEntities(false);
        java.awt.Stroke stroke32 = stackedAreaRenderer20.lookupSeriesOutlineStroke((-1));
        categoryPlot14.setDomainGridlineStroke(stroke32);
        categoryPlot14.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection37 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean38 = numberAxis36.hasListener((java.util.EventListener) taskSeriesCollection37);
        boolean boolean39 = numberAxis36.getAutoRangeIncludesZero();
        numberAxis36.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot(pieDataset42);
        java.awt.Paint paint44 = ringPlot43.getLabelLinkPaint();
        numberAxis36.setTickMarkPaint(paint44);
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange();
        numberAxis36.setRangeWithMargins((org.jfree.data.Range) dateRange46, false, true);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = textTitle51.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = textTitle51.getPosition();
        textTitle51.setHeight((double) 1);
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        textTitle51.draw(graphics2D56, rectangle2D57);
        java.awt.Font font59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle51.setFont(font59);
        java.awt.geom.Rectangle2D rectangle2D61 = textTitle51.getBounds();
        barRenderer3D6.drawRangeGridline(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis36, rectangle2D61, (double) 100L);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer64);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image11, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        projectInfo7.setLicenceName("ChartChangeEventType.GENERAL");
        java.lang.String str19 = projectInfo7.toString();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot20.getRangeMarkers((int) (byte) 100, layer22);
        xYPlot20.setDomainCrosshairValue(10.0d, false);
        xYPlot20.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        java.lang.Object obj30 = jFreeChart29.getTextAntiAlias();
        org.jfree.chart.entity.EntityCollection entityCollection33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo(entityCollection33);
        chartRenderingInfo34.clear();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis36.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = textTitle40.getPosition();
        textTitle40.setHeight((double) 1);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        textTitle40.draw(graphics2D45, rectangle2D46);
        java.awt.Font font48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle40.setFont(font48);
        java.awt.geom.Rectangle2D rectangle2D50 = textTitle40.getBounds();
        dateAxis36.setLeftArrow((java.awt.Shape) rectangle2D50);
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D50);
        chartRenderingInfo34.setChartArea(rectangle2D50);
        java.awt.image.BufferedImage bufferedImage54 = jFreeChart29.createBufferedImage(4, 5, chartRenderingInfo34);
        projectInfo7.setLogo((java.awt.Image) bufferedImage54);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "({0}, {1}) = {2} version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:({0}, {1}) = {2} hi! ().\n({0}, {1}) = {2} LICENCE TERMS:\nCategoryLabelWidthType.RANGE" + "'", str19.equals("({0}, {1}) = {2} version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:({0}, {1}) = {2} hi! ().\n({0}, {1}) = {2} LICENCE TERMS:\nCategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(bufferedImage54);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        java.text.DateFormat dateFormat7 = dateAxis5.getDateFormatOverride();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        java.awt.Font font9 = dateAxis5.getLabelFont();
        dateAxis0.setLabelFont(font9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.util.List list2 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isDomainGridlinesVisible();
        java.awt.Paint paint3 = categoryPlot1.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        int int7 = xYPlot6.getDomainAxisCount();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot6.setRangeTickBandPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot6.getRangeAxisLocation(3);
        categoryPlot1.setRangeAxisLocation(axisLocation11, false);
        boolean boolean14 = categoryPlot1.isRangeZoomable();
        java.awt.Font font15 = categoryPlot1.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double17 = barRenderer3D16.getYOffset();
        java.awt.Paint paint18 = barRenderer3D16.getWallPaint();
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("ClassContext version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ClassContext:({0}, {1}) = {2} hi! ().\nClassContext LICENCE TERMS:\nCategoryLabelWidthType.RANGE", font15, paint18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(textBlock19);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        taskSeriesCollection0.removeAll();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        java.text.DateFormat dateFormat5 = dateAxis3.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis6.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis6.getTickUnit();
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        int int11 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) date10);
        java.util.List list12 = taskSeriesCollection0.getColumnKeys();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = blockBorder0.equals((java.lang.Object) month1);
        int int4 = month1.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font9 = null;
        stackedAreaRenderer8.setBaseItemLabelFont(font9, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator13, false);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer8.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedAreaRenderer8.getPositiveItemLabelPosition(4, (int) (byte) -1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(legendItemCollection24);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font11 = null;
        stackedAreaRenderer10.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        stackedAreaRenderer10.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition19, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color23, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer10.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setBasePaint((java.awt.Paint) color29, true);
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        ringPlot33.setShadowYOffset((double) 100);
        java.awt.Font font36 = ringPlot33.getNoDataMessageFont();
        stackedAreaRenderer10.setSeriesItemLabelFont((int) '4', font36);
        stackedAreaRenderer10.setItemLabelAnchorOffset(1.0d);
        org.jfree.chart.entity.EntityCollection entityCollection41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo(entityCollection41);
        chartRenderingInfo42.clear();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = dateAxis44.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = textTitle48.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = textTitle48.getPosition();
        textTitle48.setHeight((double) 1);
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        textTitle48.draw(graphics2D53, rectangle2D54);
        java.awt.Font font56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle48.setFont(font56);
        java.awt.geom.Rectangle2D rectangle2D58 = textTitle48.getBounds();
        dateAxis44.setLeftArrow((java.awt.Shape) rectangle2D58);
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D58);
        chartRenderingInfo42.setChartArea(rectangle2D58);
        stackedAreaRenderer10.setSeriesShape(1, (java.awt.Shape) rectangle2D58, false);
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer66 = null;
        java.util.Collection collection67 = xYPlot64.getRangeMarkers((int) (byte) 100, layer66);
        xYPlot64.setDomainCrosshairValue(10.0d, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        int int72 = xYPlot64.getIndexOf(xYItemRenderer71);
        try {
            java.lang.Object obj73 = legendTitle8.draw(graphics2D9, rectangle2D58, (java.lang.Object) xYItemRenderer71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNull(collection67);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setShadowYOffset((double) 100);
        java.awt.Font font4 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.lang.Object obj11 = textTitle5.draw(graphics2D6, rectangle2D7, (java.lang.Object) plotRenderingInfo10);
        textTitle5.setMargin(0.0d, (double) (-447L), 2019.0d, (double) 1561964399999L);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Other", graphics2D1, (float) 3600000L, (float) '#', textAnchor4, (double) 2.0f, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font6 = null;
        stackedAreaRenderer5.setBaseItemLabelFont(font6, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedAreaRenderer5.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        stackedAreaRenderer5.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition14, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer5.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color18, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = stackedAreaRenderer5.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer5.setBasePaint((java.awt.Paint) color24, true);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        ringPlot28.setShadowYOffset((double) 100);
        java.awt.Font font31 = ringPlot28.getNoDataMessageFont();
        stackedAreaRenderer5.setSeriesItemLabelFont((int) '4', font31);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) (short) 10, (double) 100.0f, 1.0d, (double) (-1.0f), font31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder34 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean35 = markerAxisBand33.equals((java.lang.Object) datasetRenderingOrder34);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = null;
        markerAxisBand33.addMarker(intervalMarker36);
        java.awt.Graphics2D graphics2D38 = null;
        try {
            double double39 = markerAxisBand33.getHeight(graphics2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        java.util.Date date3 = null;
        try {
            dateAxis0.setMinimumDate(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        java.lang.Object obj5 = xYPlot0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean8 = categoryPlot7.isDomainGridlinesVisible();
        java.awt.Paint paint9 = categoryPlot7.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot7.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        int int13 = xYPlot12.getDomainAxisCount();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot12.getRangeAxisLocation(3);
        categoryPlot7.setRangeAxisLocation(axisLocation17, false);
        try {
            xYPlot0.setRangeAxisLocation((-447), axisLocation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        double double6 = rectangleInsets2.calculateLeftInset(100.0d);
        double double8 = rectangleInsets2.calculateRightInset((double) (-1.0f));
        double double10 = rectangleInsets2.calculateLeftOutset((double) 2958465);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1322434302L), (double) 100L);
        java.awt.Paint paint4 = barRenderer3D2.getSeriesItemLabelPaint(2958465);
        java.awt.Shape shape6 = barRenderer3D2.getSeriesShape((int) (byte) 100);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis3.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.util.Date date7 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.lang.String str13 = dateTickUnit11.valueToString((double) 100.0f);
        java.util.Date date14 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit11);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis15.setTickLabelFont(font16);
        float float18 = dateAxis15.getTickMarkInsideLength();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        dateAxis0.setUpArrow(shape19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12/31/69 4:00 PM" + "'", str13.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer6);
        stackedAreaRenderer6.setBaseCreateEntities(false);
        java.awt.Stroke stroke18 = stackedAreaRenderer6.lookupSeriesOutlineStroke((-1));
        categoryPlot0.setDomainGridlineStroke(stroke18);
        categoryPlot0.clearDomainAxes();
        categoryPlot0.setAnchorValue((double) 2.0f);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        try {
            boolean boolean24 = categoryPlot0.removeAnnotation(categoryAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
//        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) lengthAdjustmentType2);
//        boolean boolean5 = defaultKeyedValues2D1.equals((java.lang.Object) 10.0d);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
//        ringPlot8.setShadowYOffset((double) 100);
//        boolean boolean11 = month6.equals((java.lang.Object) ringPlot8);
//        long long12 = month6.getLastMillisecond();
//        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) month6);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        boolean boolean16 = segmentedTimeline14.containsDomainValue((long) (byte) 10);
//        boolean boolean18 = segmentedTimeline14.containsDomainValue((long) (-1));
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
//        java.util.Date date22 = regularTimePeriod21.getStart();
//        long long23 = segmentedTimeline14.getTime(date22);
//        int int24 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) date22);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertNotNull(segmentedTimeline14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1514793600000L + "'", long23 == 1514793600000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot8.addChangeListener(plotChangeListener10);
        categoryPlot8.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font15 = null;
        stackedAreaRenderer14.setBaseItemLabelFont(font15, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedAreaRenderer14.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator19, false);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer14);
        stackedAreaRenderer14.setBaseCreateEntities(false);
        java.awt.Stroke stroke26 = stackedAreaRenderer14.lookupSeriesOutlineStroke((-1));
        categoryPlot8.setDomainGridlineStroke(stroke26);
        categoryPlot8.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean32 = numberAxis30.hasListener((java.util.EventListener) taskSeriesCollection31);
        boolean boolean33 = numberAxis30.getAutoRangeIncludesZero();
        numberAxis30.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot(pieDataset36);
        java.awt.Paint paint38 = ringPlot37.getLabelLinkPaint();
        numberAxis30.setTickMarkPaint(paint38);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        numberAxis30.setRangeWithMargins((org.jfree.data.Range) dateRange40, false, true);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle45.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = textTitle45.getPosition();
        textTitle45.setHeight((double) 1);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        textTitle45.draw(graphics2D50, rectangle2D51);
        java.awt.Font font53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle45.setFont(font53);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle45.getBounds();
        barRenderer3D0.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis30, rectangle2D55, (double) 100L);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = null;
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = textTitle61.getMargin();
        double double64 = rectangleInsets62.calculateLeftOutset((double) 10.0f);
        double double66 = rectangleInsets62.calculateLeftInset(100.0d);
        double double68 = rectangleInsets62.calculateTopOutset((double) 1L);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = textTitle70.getMargin();
        double double73 = rectangleInsets71.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle75 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D76 = null;
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        textTitle75.draw(graphics2D76, rectangle2D77);
        java.awt.geom.Rectangle2D rectangle2D79 = textTitle75.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection80 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = new org.jfree.chart.ChartRenderingInfo(entityCollection80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo81);
        java.awt.geom.Rectangle2D rectangle2D83 = plotRenderingInfo82.getDataArea();
        boolean boolean84 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D79, rectangle2D83);
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets71.createOutsetRectangle(rectangle2D79, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity88 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D87);
        java.awt.geom.Rectangle2D rectangle2D89 = rectangleInsets62.createInsetRectangle(rectangle2D87);
        try {
            barRenderer3D0.drawBackground(graphics2D58, categoryPlot59, rectangle2D89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertNotNull(rectangle2D89);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        double double3 = ringPlot0.getOuterSeparatorExtension();
        ringPlot0.setShadowYOffset((double) 1514793600000L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double23 = barRenderer3D22.getYOffset();
        java.awt.Paint paint24 = barRenderer3D22.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection27 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean28 = numberAxis26.hasListener((java.util.EventListener) taskSeriesCollection27);
        boolean boolean29 = numberAxis26.getAutoRangeIncludesZero();
        numberAxis26.setTickMarkInsideLength(0.0f);
        boolean boolean32 = barRenderer3D22.equals((java.lang.Object) numberAxis26);
        boolean boolean33 = stackedAreaRenderer0.equals((java.lang.Object) numberAxis26);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font38 = null;
        stackedAreaRenderer37.setBaseItemLabelFont(font38, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator42 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator42, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = null;
        stackedAreaRenderer37.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition46, false);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer37.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color50, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = stackedAreaRenderer37.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer37.setBasePaint((java.awt.Paint) color56, true);
        org.jfree.chart.plot.RingPlot ringPlot60 = new org.jfree.chart.plot.RingPlot();
        ringPlot60.setShadowYOffset((double) 100);
        java.awt.Font font63 = ringPlot60.getNoDataMessageFont();
        stackedAreaRenderer37.setSeriesItemLabelFont((int) '4', font63);
        java.awt.Paint paint65 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean67 = categoryPlot66.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        categoryPlot66.addChangeListener(plotChangeListener68);
        categoryPlot66.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = categoryPlot66.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment73 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment74 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle76 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = textTitle76.getMargin();
        double double79 = rectangleInsets77.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle80 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font63, paint65, rectangleEdge72, horizontalAlignment73, verticalAlignment74, rectangleInsets77);
        try {
            double double81 = numberAxis26.valueToJava2D((double) (-1.0f), rectangle2D35, rectangleEdge72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(horizontalAlignment73);
        org.junit.Assert.assertNotNull(verticalAlignment74);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot3.addChangeListener(plotChangeListener5);
        categoryPlot3.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions2.getLabelPosition(rectangleEdge9);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions2);
        categoryAxis0.setLabelURL("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(categoryLabelPosition10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        java.lang.Object obj6 = plotChangeEvent5.getSource();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer1);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font12 = null;
        stackedAreaRenderer11.setBaseItemLabelFont(font12, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        stackedAreaRenderer11.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator16, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        stackedAreaRenderer11.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition20, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer11.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color24, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = stackedAreaRenderer11.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition(9, itemLabelPosition29);
        java.awt.Paint paint31 = stackedAreaRenderer1.getBaseFillPaint();
        boolean boolean32 = waterfallBarRenderer0.equals((java.lang.Object) stackedAreaRenderer1);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity8 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis0, shape5, "June 2019", "ClassContext");
        org.jfree.chart.axis.Axis axis9 = axisLabelEntity8.getAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(axis9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot2.getLegendLabelGenerator();
        ringPlot2.setMinimumArcAngleToDraw((double) (byte) 1);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        ringPlot2.setLabelOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font9 = null;
        stackedAreaRenderer8.setBaseItemLabelFont(font9, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator13, false);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font19 = null;
        stackedAreaRenderer18.setBaseItemLabelFont(font19, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        stackedAreaRenderer18.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator23, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        stackedAreaRenderer18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition27, false);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer18.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color31, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = stackedAreaRenderer18.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer8.setSeriesNegativeItemLabelPosition(9, itemLabelPosition36);
        java.awt.Paint paint38 = stackedAreaRenderer8.getBaseFillPaint();
        ringPlot2.setOutlinePaint(paint38);
        boolean boolean40 = keyedObjects0.equals((java.lang.Object) ringPlot2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = plotRenderingInfo2.getOwner();
        java.lang.Object obj4 = plotRenderingInfo2.clone();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis5.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle9.getPosition();
        textTitle9.setHeight((double) 1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle9.draw(graphics2D14, rectangle2D15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle9.setFont(font17);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle9.getBounds();
        dateAxis5.setLeftArrow((java.awt.Shape) rectangle2D19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle22.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle22.getPosition();
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge24);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D19, "WMAP_Plot");
        plotRenderingInfo2.setDataArea(rectangle2D19);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(chartRenderingInfo3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("35", graphics2D1, 0.0f, (float) 2958465, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str12 = categoryLabelWidthType11.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10, categoryLabelWidthType11, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType15 = categoryLabelPosition14.getWidthType();
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryLabelPosition14.getRotationAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str12.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType15);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setShadowYOffset((double) 100);
        boolean boolean5 = month0.equals((java.lang.Object) ringPlot2);
        ringPlot2.setIgnoreNullValues(true);
        ringPlot2.setCircular(false, false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.getDrawSharedDomainAxis();
        boolean boolean3 = categoryPlot1.isRangeZoomable();
        int int4 = year0.compareTo((java.lang.Object) categoryPlot1);
        categoryPlot1.mapDatasetToRangeAxis(0, 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        ringPlot1.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer7);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font18 = null;
        stackedAreaRenderer17.setBaseItemLabelFont(font18, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        stackedAreaRenderer17.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator22, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        stackedAreaRenderer17.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer17.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color30, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedAreaRenderer17.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer7.setSeriesNegativeItemLabelPosition(9, itemLabelPosition35);
        java.awt.Paint paint37 = stackedAreaRenderer7.getBaseFillPaint();
        ringPlot1.setOutlinePaint(paint37);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot39.getRangeMarkers((int) (byte) 100, layer41);
        xYPlot39.setDomainCrosshairValue(10.0d, false);
        xYPlot39.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot39);
        float float49 = jFreeChart48.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot50 = jFreeChart48.getXYPlot();
        jFreeChart48.fireChartChanged();
        org.jfree.chart.title.LegendTitle legendTitle52 = jFreeChart48.getLegend();
        ringPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart48);
        ringPlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.5f + "'", float49 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot50);
        org.junit.Assert.assertNotNull(legendTitle52);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("February", "", "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { dateAxis3, dateAxis4, dateAxis5, dateAxis6, dateAxis7, dateAxis8 };
        xYPlot0.setDomainAxes(valueAxisArray9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot0.getDomainAxisForDataset((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNull(xYItemRenderer11);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean8 = categoryPlot7.isDomainGridlinesVisible();
        java.awt.Paint paint9 = categoryPlot7.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot7.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        int int13 = xYPlot12.getDomainAxisCount();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot12.getRangeAxisLocation(3);
        categoryPlot7.setRangeAxisLocation(axisLocation17, false);
        boolean boolean20 = categoryPlot7.isRangeZoomable();
        java.awt.Font font21 = categoryPlot7.getNoDataMessageFont();
        barRenderer3D0.setBaseItemLabelFont(font21);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        ringPlot1.setLabelOutlinePaint((java.awt.Paint) color5);
        java.lang.String str7 = ringPlot1.getPlotType();
        ringPlot1.setSectionDepth((double) 32L);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint12 = categoryAxis11.getAxisLinePaint();
        float float13 = categoryAxis11.getMaximumCategoryLabelWidthRatio();
        double double14 = categoryAxis11.getLowerMargin();
        int int15 = categoryAxis11.getCategoryLabelPositionOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font19 = null;
        stackedAreaRenderer18.setBaseItemLabelFont(font19, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        stackedAreaRenderer18.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator23, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        stackedAreaRenderer18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition27, false);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer18.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color31, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = stackedAreaRenderer18.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer18.setBasePaint((java.awt.Paint) color37, true);
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        ringPlot41.setShadowYOffset((double) 100);
        java.awt.Font font44 = ringPlot41.getNoDataMessageFont();
        stackedAreaRenderer18.setSeriesItemLabelFont((int) '4', font44);
        stackedAreaRenderer18.setItemLabelAnchorOffset(1.0d);
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        chartRenderingInfo50.clear();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        boolean boolean54 = dateAxis52.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = textTitle56.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = textTitle56.getPosition();
        textTitle56.setHeight((double) 1);
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        textTitle56.draw(graphics2D61, rectangle2D62);
        java.awt.Font font64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle56.setFont(font64);
        java.awt.geom.Rectangle2D rectangle2D66 = textTitle56.getBounds();
        dateAxis52.setLeftArrow((java.awt.Shape) rectangle2D66);
        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D66);
        chartRenderingInfo50.setChartArea(rectangle2D66);
        stackedAreaRenderer18.setSeriesShape(1, (java.awt.Shape) rectangle2D66, false);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = textTitle73.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = textTitle73.getPosition();
        double double76 = categoryAxis11.getCategoryEnd(15, 8, rectangle2D66, rectangleEdge75);
        org.jfree.chart.plot.PiePlot piePlot77 = null;
        org.jfree.chart.plot.RingPlot ringPlot80 = new org.jfree.chart.plot.RingPlot();
        ringPlot80.setShadowYOffset((double) 100);
        java.awt.Font font83 = ringPlot80.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle84 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font83);
        java.awt.Graphics2D graphics2D85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.entity.EntityCollection entityCollection87 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo88 = new org.jfree.chart.ChartRenderingInfo(entityCollection87);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo89 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo88);
        java.lang.Object obj90 = textTitle84.draw(graphics2D85, rectangle2D86, (java.lang.Object) plotRenderingInfo89);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState91 = ringPlot1.initialise(graphics2D10, rectangle2D66, piePlot77, (java.lang.Integer) 5, plotRenderingInfo89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(font83);
        org.junit.Assert.assertNull(obj90);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean12 = numberAxis10.hasListener((java.util.EventListener) taskSeriesCollection11);
        java.text.NumberFormat numberFormat13 = null;
        numberAxis10.setNumberFormatOverride(numberFormat13);
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        boolean boolean16 = numberAxis10.isVisible();
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(categoryAxis18);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator20 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        stackedAreaRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean24 = categoryPlot23.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot23.addChangeListener(plotChangeListener25);
        categoryPlot23.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot23.getRangeAxisEdge();
        categoryPlot23.clearRangeMarkers((int) (byte) 100);
        java.util.List list32 = categoryPlot23.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot23.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        double double35 = categoryAxis34.getCategoryMargin();
        categoryAxis34.setTickMarkInsideLength((float) 1);
        categoryAxis34.setMaximumCategoryLabelLines(0);
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = null;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = textTitle42.getMargin();
        double double45 = rectangleInsets43.calculateLeftOutset((double) 10.0f);
        double double47 = rectangleInsets43.calculateLeftInset(100.0d);
        double double49 = rectangleInsets43.calculateTopOutset((double) 1L);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = textTitle51.getMargin();
        double double54 = rectangleInsets52.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        textTitle56.draw(graphics2D57, rectangle2D58);
        java.awt.geom.Rectangle2D rectangle2D60 = textTitle56.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        java.awt.geom.Rectangle2D rectangle2D64 = plotRenderingInfo63.getDataArea();
        boolean boolean65 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D60, rectangle2D64);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets52.createOutsetRectangle(rectangle2D60, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity69 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D68);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets43.createInsetRectangle(rectangle2D68);
        try {
            stackedAreaRenderer0.drawDomainMarker(graphics2D22, categoryPlot23, categoryAxis34, categoryMarker40, rectangle2D70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.2d + "'", double35 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity8 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis0, shape5, "June 2019", "ClassContext");
        dateAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getYOffset();
        double double2 = barRenderer3D0.getLowerClip();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            dateAxis0.setTickLabelInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo6, point2D8);
        int int10 = plotRenderingInfo6.getSubplotCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart9.getLegend();
        java.awt.Paint paint11 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean15 = categoryPlot14.isDomainGridlinesVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        categoryPlot12.setOutlinePaint(paint16);
        categoryPlot12.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo(entityCollection21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        categoryPlot12.handleClick(9, (int) (short) 100, plotRenderingInfo23);
        java.awt.Stroke stroke25 = categoryPlot12.getRangeCrosshairStroke();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle27.getMargin();
        double double30 = rectangleInsets28.calculateLeftOutset((double) 10.0f);
        double double32 = rectangleInsets28.calculateLeftInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder(paint11, stroke25, rectangleInsets28);
        jFreeChart9.setBorderStroke(stroke25);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot3.getLegendItems();
        org.jfree.chart.LegendItem legendItem5 = null;
        legendItemCollection4.add(legendItem5);
        xYPlot0.setFixedLegendItems(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = stackedAreaRenderer0.getBaseFillPaint();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getDomainAxisCount();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot8.setRangeTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot8.getRangeAxisLocation(3);
        xYPlot6.setDomainAxisLocation((int) (byte) 10, axisLocation13);
        stackedAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot6);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot6.getDomainAxisLocation();
        xYPlot6.clearDomainAxes();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font19 = null;
        stackedAreaRenderer18.setBaseItemLabelFont(font19, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        stackedAreaRenderer18.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator23, false);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer18);
        stackedAreaRenderer18.setBaseCreateEntities(false);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.isDomainGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis32.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = textTitle36.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = textTitle36.getPosition();
        textTitle36.setHeight((double) 1);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        textTitle36.draw(graphics2D41, rectangle2D42);
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle36.setFont(font44);
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle36.getBounds();
        dateAxis32.setLeftArrow((java.awt.Shape) rectangle2D46);
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity54 = new org.jfree.chart.entity.ChartEntity(shape51, "ClassContext", "");
        java.awt.Shape shape55 = chartEntity54.getArea();
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = textTitle57.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = textTitle57.getPosition();
        textTitle57.setHeight((double) 1);
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        textTitle57.draw(graphics2D62, rectangle2D63);
        java.awt.Font font65 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle57.setFont(font65);
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle57.getBounds();
        chartEntity54.setArea((java.awt.Shape) rectangle2D67);
        stackedAreaRenderer18.drawRangeMarker(graphics2D29, categoryPlot30, (org.jfree.chart.axis.ValueAxis) dateAxis32, marker48, rectangle2D67);
        java.awt.Paint paint71 = stackedAreaRenderer18.lookupSeriesOutlinePaint(1);
        xYPlot6.setRangeZeroBaselinePaint(paint71);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart9.getXYPlot();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = null;
        try {
            xYPlot11.setRangeAxes(valueAxisArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        boolean boolean11 = jFreeChart9.isNotify();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesShapesVisible((int) (byte) 0, false);
        boolean boolean4 = lineRenderer3D0.getBaseLinesVisible();
        lineRenderer3D0.setUseOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj3 = objectList0.get(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle6.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo13.getDataArea();
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D10, rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets2.createOutsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D18);
        org.jfree.chart.axis.NumberAxis numberAxis20 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        stackedAreaRenderer25.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color38, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = stackedAreaRenderer25.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setBasePaint((java.awt.Paint) color44, true);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        ringPlot48.setShadowYOffset((double) 100);
        java.awt.Font font51 = ringPlot48.getNoDataMessageFont();
        stackedAreaRenderer25.setSeriesItemLabelFont((int) '4', font51);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis20, (double) (short) 10, (double) 100.0f, 1.0d, (double) (-1.0f), font51);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean55 = markerAxisBand53.equals((java.lang.Object) datasetRenderingOrder54);
        boolean boolean56 = legendItemEntity19.equals((java.lang.Object) markerAxisBand53);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset57 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset57.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        legendItemEntity19.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset57);
        java.lang.String str63 = legendItemEntity19.getURLText();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str63);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = xYPlot50.getRangeMarkers((int) (byte) 100, layer52);
        xYPlot50.setDomainCrosshairValue(10.0d, false);
        xYPlot50.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot50);
        float float60 = jFreeChart59.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot61 = jFreeChart59.getXYPlot();
        org.jfree.chart.title.LegendTitle legendTitle62 = jFreeChart59.getLegend();
        blockContainer49.add((org.jfree.chart.block.Block) legendTitle62);
        blockContainer49.clear();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.5f + "'", float60 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot61);
        org.junit.Assert.assertNotNull(legendTitle62);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.Number number0 = null;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(number0, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = waterfallBarRenderer0.getBaseURLGenerator();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        boolean boolean4 = lengthAdjustmentType2.equals((java.lang.Object) itemLabelAnchor3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor5);
        waterfallBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range9 = waterfallBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        org.junit.Assert.assertNull(categoryURLGenerator1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        dateAxis0.setLabelFont(font2);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo6, point2D8);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font12 = null;
        stackedAreaRenderer11.setBaseItemLabelFont(font12, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        stackedAreaRenderer11.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator16, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        stackedAreaRenderer11.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition20, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer11.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color24, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = stackedAreaRenderer11.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = null;
        stackedAreaRenderer11.setLegendItemURLGenerator(categorySeriesLabelGenerator30);
        java.awt.Stroke stroke34 = stackedAreaRenderer11.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke37 = stackedAreaRenderer11.getItemStroke(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator39 = stackedAreaRenderer11.getSeriesItemLabelGenerator((-1));
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot(pieDataset41);
        java.awt.Paint paint44 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot42.setSectionPaint((java.lang.Comparable) 1.0f, paint44);
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot42.setLabelLinkPaint((java.awt.Paint) color46);
        stackedAreaRenderer11.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color46, false);
        boolean boolean50 = itemLabelAnchor10.equals((java.lang.Object) color46);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color46);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(categoryItemLabelGenerator39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType1 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str2 = categoryLabelWidthType1.toString();
        boolean boolean3 = lineBorder0.equals((java.lang.Object) str2);
        java.awt.Stroke stroke4 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(categoryLabelWidthType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str2.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        java.text.DateFormat dateFormat5 = dateAxis3.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getTickLabelInsets();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis3, shape8, "June 2019", "ClassContext");
        try {
            java.awt.GradientPaint gradientPaint12 = standardGradientPaintTransformer1.transform(gradientPaint2, shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (short) 100, (java.lang.Number) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint4 = categoryAxis3.getAxisLinePaint();
        float float5 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        double double6 = categoryAxis3.getLowerMargin();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str9 = numberTickUnit7.valueToString((double) '#');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list11 = taskSeriesCollection10.getRowKeys();
        taskSeriesCollection10.removeAll();
        boolean boolean13 = numberTickUnit7.equals((java.lang.Object) taskSeriesCollection10);
        java.awt.Font font14 = categoryAxis3.getTickLabelFont((java.lang.Comparable) numberTickUnit7);
        boolean boolean15 = meanAndStandardDeviation2.equals((java.lang.Object) font14);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline0.toMillisecond(10L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208959999990L) + "'", long2 == (-2208959999990L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot2.getRangeMarkers((int) (byte) 100, layer4);
        java.awt.Paint paint6 = xYPlot2.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getLabelPaint();
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal(paint6, paint8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font11 = null;
        stackedAreaRenderer10.setBaseItemLabelFont(font11, true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font15 = null;
        stackedAreaRenderer14.setBaseItemLabelFont(font15, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedAreaRenderer14.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator19, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = null;
        stackedAreaRenderer14.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition23, false);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer14.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color27, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = stackedAreaRenderer14.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator33 = null;
        stackedAreaRenderer14.setLegendItemURLGenerator(categorySeriesLabelGenerator33);
        java.awt.Stroke stroke37 = stackedAreaRenderer14.getItemOutlineStroke((-447), 100);
        stackedAreaRenderer10.setBaseOutlineStroke(stroke37);
        java.awt.Paint paint39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean41 = categoryPlot40.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean43 = categoryPlot42.isDomainGridlinesVisible();
        java.awt.Paint paint44 = categoryPlot42.getDomainGridlinePaint();
        categoryPlot40.setOutlinePaint(paint44);
        categoryPlot40.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo50);
        categoryPlot40.handleClick(9, (int) (short) 100, plotRenderingInfo51);
        java.awt.Stroke stroke53 = categoryPlot40.getRangeCrosshairStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier54 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke55 = defaultDrawingSupplier54.getNextStroke();
        categoryPlot40.setDomainGridlineStroke(stroke55);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker58 = new org.jfree.chart.plot.IntervalMarker((double) 32L, (double) (short) -1, paint6, stroke37, paint39, stroke55, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        java.util.List list2 = axisCollection0.getAxesAtTop();
        java.util.List list3 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ThreadContext", "WMAP_Plot");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        int int1 = booleanList0.size();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = chartRenderingInfo3.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = plotRenderingInfo4.getOwner();
        java.lang.Object obj6 = plotRenderingInfo4.clone();
        boolean boolean7 = booleanList0.equals((java.lang.Object) plotRenderingInfo4);
        try {
            booleanList0.setBoolean((-1), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(plotRenderingInfo4);
        org.junit.Assert.assertNotNull(chartRenderingInfo5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        categoryPlot0.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        boolean boolean15 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        ringPlot1.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer7);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font18 = null;
        stackedAreaRenderer17.setBaseItemLabelFont(font18, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        stackedAreaRenderer17.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator22, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        stackedAreaRenderer17.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer17.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color30, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedAreaRenderer17.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer7.setSeriesNegativeItemLabelPosition(9, itemLabelPosition35);
        java.awt.Paint paint37 = stackedAreaRenderer7.getBaseFillPaint();
        ringPlot1.setOutlinePaint(paint37);
        java.awt.Stroke stroke40 = ringPlot1.getSectionOutlineStroke((java.lang.Comparable) 10.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(stroke40);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        java.awt.Paint paint4 = dateAxis0.getTickMarkPaint();
        double double5 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getLabelLinkPaint();
        stackedAreaRenderer0.setBaseFillPaint(paint9, false);
        boolean boolean14 = stackedAreaRenderer0.isItemLabelVisible((int) (short) 10, 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        java.awt.Stroke stroke4 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) "35");
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        java.awt.Paint paint12 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot10.setSectionPaint((java.lang.Comparable) 1.0f, paint12);
        java.awt.Paint paint14 = ringPlot10.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation15 = ringPlot10.getDirection();
        java.awt.Paint paint16 = ringPlot10.getSeparatorPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot0.initialise(graphics2D7, rectangle2D8, (org.jfree.chart.plot.PiePlot) ringPlot10, (java.lang.Integer) 9, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 15, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        boolean boolean5 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        java.lang.Boolean boolean7 = stackedAreaRenderer0.getSeriesVisible(10);
        double double8 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        stackedAreaRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        java.lang.Object obj11 = stackedAreaRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextStroke();
        categoryPlot0.setDomainGridlineStroke(stroke15);
        double[] doubleArray25 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray53 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray60 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray61 = new double[][] { doubleArray25, doubleArray32, doubleArray39, doubleArray46, doubleArray53, doubleArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray61);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer65 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font66 = null;
        stackedAreaRenderer65.setBaseItemLabelFont(font66, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator70 = null;
        stackedAreaRenderer65.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator70, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition74 = null;
        stackedAreaRenderer65.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition74, false);
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer65.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color78, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition83 = stackedAreaRenderer65.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator84 = null;
        stackedAreaRenderer65.setLegendItemURLGenerator(categorySeriesLabelGenerator84);
        stackedAreaRenderer65.setBaseItemLabelsVisible(false);
        java.awt.Paint paint89 = stackedAreaRenderer65.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot90 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, valueAxis64, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer65);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer65, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(itemLabelPosition83);
        org.junit.Assert.assertNull(paint89);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis3.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.util.Date date7 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone8;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle13.draw(graphics2D14, rectangle2D15);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle13.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo20.getDataArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D17, rectangle2D21);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity25 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month10, (java.awt.Shape) rectangle2D21, "CategoryLabelWidthType.RANGE", "");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        float float13 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) itemLabelAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis1.setNumberFormatOverride(numberFormat4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setTickMarkInsideLength((float) (-1322433855L));
        org.jfree.data.Range range9 = numberAxis1.getRange();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setTickMarkInsideLength((float) 1);
        categoryAxis0.setMaximumCategoryLabelLines(0);
        categoryAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation6 = ringPlot1.getDirection();
        java.awt.Paint paint7 = ringPlot1.getSeparatorPaint();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint9 = null;
        ringPlot8.setShadowPaint(paint9);
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot8.setOutlinePaint(paint11);
        ringPlot1.setBaseSectionOutlinePaint(paint11);
        java.awt.Paint paint15 = ringPlot1.getSectionOutlinePaint((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.RendererState rendererState5 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo4);
        boolean boolean6 = categoryLabelWidthType0.equals((java.lang.Object) rendererState5);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str1.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint4 = categoryAxis3.getAxisLinePaint();
        float float5 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        double double6 = categoryAxis3.getLowerMargin();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str9 = numberTickUnit7.valueToString((double) '#');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list11 = taskSeriesCollection10.getRowKeys();
        taskSeriesCollection10.removeAll();
        boolean boolean13 = numberTickUnit7.equals((java.lang.Object) taskSeriesCollection10);
        java.awt.Font font14 = categoryAxis3.getTickLabelFont((java.lang.Comparable) numberTickUnit7);
        int int15 = categoryPlot0.getDomainAxisIndex(categoryAxis3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("Size2D[width=0.0, height=0.0]", font1, paint2);
        boolean boolean5 = textBlock3.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.text.TextLine textLine6 = textBlock3.getLastLine();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getLabelPaint();
        java.text.DateFormat dateFormat9 = dateAxis7.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis7.getTickMarkPosition();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        ringPlot12.setShadowYOffset((double) 100);
        java.awt.Font font15 = ringPlot12.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font15);
        org.jfree.chart.text.TextFragment textFragment17 = null;
        textLine16.addFragment(textFragment17);
        boolean boolean19 = dateTickMarkPosition10.equals((java.lang.Object) textLine16);
        textBlock3.addLine(textLine16);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textLine6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font5 = null;
        stackedAreaRenderer4.setBaseItemLabelFont(font5, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        stackedAreaRenderer4.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        stackedAreaRenderer4.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition13, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer4.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color17, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedAreaRenderer4.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = null;
        stackedAreaRenderer4.setLegendItemURLGenerator(categorySeriesLabelGenerator23);
        java.awt.Stroke stroke27 = stackedAreaRenderer4.getItemOutlineStroke((-447), 100);
        stackedAreaRenderer0.setBaseOutlineStroke(stroke27);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer0.getLegendItemLabelGenerator();
        stackedAreaRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Font font34 = stackedAreaRenderer0.getItemLabelFont((-447), (int) (byte) -1);
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNull(font34);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range6, (org.jfree.data.general.Dataset) taskSeriesCollection7);
        boolean boolean10 = taskSeriesCollection7.equals((java.lang.Object) 9);
        int int11 = taskSeriesCollection7.getColumnCount();
        try {
            java.lang.Number number14 = taskSeriesCollection7.getPercentComplete((int) 'a', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        java.awt.Paint paint10 = stackedAreaRenderer0.getItemFillPaint(0, 0);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer6);
        stackedAreaRenderer6.setBaseCreateEntities(false);
        java.awt.Stroke stroke18 = stackedAreaRenderer6.lookupSeriesOutlineStroke((-1));
        categoryPlot0.setDomainGridlineStroke(stroke18);
        categoryPlot0.clearDomainAxes();
        java.awt.Stroke stroke21 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot0.setRenderer((int) 'a', categoryItemRenderer23);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, (double) 1L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) "CategoryLabelWidthType.RANGE");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RangeType.NEGATIVE", graphics2D1, (float) 2958465, (float) 0L, textAnchor4, (double) 100L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = xYPlot1.getRangeMarkers((int) (byte) 100, layer3);
        xYPlot1.setDomainCrosshairValue(10.0d, false);
        xYPlot1.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        int int14 = defaultCategoryDataset11.getColumnIndex((java.lang.Comparable) 100.0f);
        int int16 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) 4);
        java.util.List list17 = defaultCategoryDataset11.getColumnKeys();
        jFreeChart10.setSubtitles(list17);
        segmentedTimeline0.setExceptionSegments(list17);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        java.awt.Paint paint2 = categoryPlot0.getOutlinePaint();
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 100, 100);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle7.getMargin();
        double double10 = rectangleInsets8.calculateLeftOutset((double) (short) 100);
        double double11 = rectangleInsets8.getBottom();
        categoryPlot0.setAxisOffset(rectangleInsets8);
        org.jfree.chart.axis.NumberAxis numberAxis13 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font19 = null;
        stackedAreaRenderer18.setBaseItemLabelFont(font19, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        stackedAreaRenderer18.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator23, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        stackedAreaRenderer18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition27, false);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer18.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color31, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = stackedAreaRenderer18.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer18.setBasePaint((java.awt.Paint) color37, true);
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        ringPlot41.setShadowYOffset((double) 100);
        java.awt.Font font44 = ringPlot41.getNoDataMessageFont();
        stackedAreaRenderer18.setSeriesItemLabelFont((int) '4', font44);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis13, (double) (short) 10, (double) 100.0f, 1.0d, (double) (-1.0f), font44);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean48 = markerAxisBand46.equals((java.lang.Object) datasetRenderingOrder47);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity55 = new org.jfree.chart.entity.ChartEntity(shape52, "ClassContext", "");
        java.awt.Shape shape56 = chartEntity55.getArea();
        org.jfree.chart.title.TextTitle textTitle58 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = textTitle58.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = textTitle58.getPosition();
        textTitle58.setHeight((double) 1);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        textTitle58.draw(graphics2D63, rectangle2D64);
        java.awt.Font font66 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle58.setFont(font66);
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle58.getBounds();
        chartEntity55.setArea((java.awt.Shape) rectangle2D68);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        markerAxisBand46.draw(graphics2D49, rectangle2D68, rectangle2D70, 0.0d, (double) (short) 10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType75 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor76 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        boolean boolean77 = lengthAdjustmentType75.equals((java.lang.Object) itemLabelAnchor76);
        java.awt.geom.Rectangle2D rectangle2D78 = rectangleInsets8.createAdjustedRectangle(rectangle2D68, lengthAdjustmentType74, lengthAdjustmentType75);
        java.awt.Shape shape79 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D68);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(lengthAdjustmentType75);
        org.junit.Assert.assertNotNull(itemLabelAnchor76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(shape79);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setCircular(false);
        ringPlot0.setLabelLinkMargin((double) (byte) 0);
        java.awt.Stroke stroke7 = ringPlot0.getLabelLinkStroke();
        try {
            ringPlot0.setInteriorGap((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getSeriesCount();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font4 = null;
        stackedAreaRenderer3.setBaseItemLabelFont(font4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator8, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        stackedAreaRenderer3.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition12, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer3.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color16, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = stackedAreaRenderer3.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer3.setBasePaint((java.awt.Paint) color22, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D25 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double26 = barRenderer3D25.getYOffset();
        java.awt.Paint paint27 = barRenderer3D25.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection30 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean31 = numberAxis29.hasListener((java.util.EventListener) taskSeriesCollection30);
        boolean boolean32 = numberAxis29.getAutoRangeIncludesZero();
        numberAxis29.setTickMarkInsideLength(0.0f);
        boolean boolean35 = barRenderer3D25.equals((java.lang.Object) numberAxis29);
        boolean boolean36 = stackedAreaRenderer3.equals((java.lang.Object) numberAxis29);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str39 = numberTickUnit37.valueToString((double) '#');
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean41 = numberTickUnit37.equals((java.lang.Object) horizontalAlignment40);
        numberAxis29.setTickUnit(numberTickUnit37, false, true);
        try {
            java.lang.Number number46 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 1561964399999L, (java.lang.Comparable) true, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(numberTickUnit37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "35" + "'", str39.equals("35"));
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.data.Range range26 = stackedAreaRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        java.awt.Stroke stroke28 = stackedAreaRenderer0.getSeriesStroke((int) (short) 0);
        java.awt.Paint paint30 = stackedAreaRenderer0.lookupSeriesPaint(6);
        java.lang.Object obj31 = stackedAreaRenderer0.clone();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0d + "'", number25.equals(0.0d));
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font13 = null;
        stackedAreaRenderer12.setBaseItemLabelFont(font13, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        stackedAreaRenderer12.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator17, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        stackedAreaRenderer12.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition21, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color25, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedAreaRenderer12.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setBasePaint((java.awt.Paint) color31, true);
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        ringPlot35.setShadowYOffset((double) 100);
        java.awt.Font font38 = ringPlot35.getNoDataMessageFont();
        stackedAreaRenderer12.setSeriesItemLabelFont((int) '4', font38);
        java.awt.Paint paint40 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean42 = categoryPlot41.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot41.addChangeListener(plotChangeListener43);
        categoryPlot41.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot41.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = textTitle51.getMargin();
        double double54 = rectangleInsets52.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font38, paint40, rectangleEdge47, horizontalAlignment48, verticalAlignment49, rectangleInsets52);
        legendTitle8.setLegendItemGraphicPadding(rectangleInsets52);
        java.lang.String str57 = rectangleInsets52.toString();
        org.jfree.chart.util.UnitType unitType58 = rectangleInsets52.getUnitType();
        double double60 = rectangleInsets52.calculateLeftInset((double) 'a');
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str57.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(unitType58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 1561964399999L, (float) (byte) -1, 4.0d, (float) (-131072), (float) 2958465);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        double double5 = stackedBarRenderer3D2.getBase();
        java.awt.Shape shape7 = stackedBarRenderer3D2.lookupSeriesShape((int) ' ');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape3, "ClassContext", "");
        java.awt.Shape shape7 = chartEntity6.getArea();
        boolean boolean8 = itemLabelAnchor0.equals((java.lang.Object) chartEntity6);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str3 = numberTickUnit1.valueToString((double) '#');
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean5 = numberTickUnit1.equals((java.lang.Object) horizontalAlignment4);
        java.lang.Object obj6 = null;
        keyedObjects0.setObject((java.lang.Comparable) boolean5, obj6);
        java.lang.Comparable comparable8 = null;
        java.lang.Object obj9 = keyedObjects0.getObject(comparable8);
        java.lang.Object obj11 = keyedObjects0.getObject((int) (byte) 0);
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle10.draw(graphics2D11, rectangle2D12);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle10.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo17.getDataArea();
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D14, rectangle2D18);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D14, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str25 = categoryLabelWidthType24.toString();
        boolean boolean26 = lineBorder23.equals((java.lang.Object) str25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis28.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = textTitle32.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = textTitle32.getPosition();
        textTitle32.setHeight((double) 1);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        textTitle32.draw(graphics2D37, rectangle2D38);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle32.setFont(font40);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle32.getBounds();
        dateAxis28.setLeftArrow((java.awt.Shape) rectangle2D42);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D42);
        lineBorder23.draw(graphics2D27, rectangle2D42);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer47 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font48 = null;
        stackedAreaRenderer47.setBaseItemLabelFont(font48, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator52 = null;
        stackedAreaRenderer47.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator52, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = null;
        stackedAreaRenderer47.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition56, false);
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer47.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color60, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = stackedAreaRenderer47.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer47.setBasePaint((java.awt.Paint) color66, true);
        org.jfree.chart.plot.RingPlot ringPlot70 = new org.jfree.chart.plot.RingPlot();
        ringPlot70.setShadowYOffset((double) 100);
        java.awt.Font font73 = ringPlot70.getNoDataMessageFont();
        stackedAreaRenderer47.setSeriesItemLabelFont((int) '4', font73);
        java.awt.Paint paint75 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean77 = categoryPlot76.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener78 = null;
        categoryPlot76.addChangeListener(plotChangeListener78);
        categoryPlot76.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = categoryPlot76.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment83 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment84 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle86 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = textTitle86.getMargin();
        double double89 = rectangleInsets87.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle90 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font73, paint75, rectangleEdge82, horizontalAlignment83, verticalAlignment84, rectangleInsets87);
        org.jfree.chart.entity.EntityCollection entityCollection91 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo92 = new org.jfree.chart.ChartRenderingInfo(entityCollection91);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo92);
        java.awt.geom.Rectangle2D rectangle2D94 = plotRenderingInfo93.getDataArea();
        org.jfree.data.resources.DataPackageResources dataPackageResources95 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean96 = plotRenderingInfo93.equals((java.lang.Object) dataPackageResources95);
        try {
            org.jfree.chart.axis.AxisState axisState97 = numberAxis1.draw(graphics2D7, (double) (byte) 0, rectangle2D14, rectangle2D42, rectangleEdge82, plotRenderingInfo93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(categoryLabelWidthType24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str25.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(itemLabelPosition65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertNotNull(horizontalAlignment83);
        org.junit.Assert.assertNotNull(verticalAlignment84);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D94);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((-131072), 4, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        int int5 = defaultCategoryDataset2.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        defaultCategoryDataset2.removeColumn((java.lang.Comparable) numberTickUnit7);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(numberTickUnit7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle2.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo9.getDataArea();
        boolean boolean11 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D6, rectangle2D10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) "Other", (java.awt.Shape) rectangle2D10, "AxisLocation.TOP_OR_RIGHT", "");
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "ClassContext", "");
        java.awt.Shape shape12 = chartEntity11.getArea();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle14.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = textTitle14.getPosition();
        textTitle14.setHeight((double) 1);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle14.draw(graphics2D19, rectangle2D20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle14.setFont(font22);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle14.getBounds();
        chartEntity11.setArea((java.awt.Shape) rectangle2D24);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        ringPlot28.setShadowYOffset((double) 100);
        java.awt.Font font31 = ringPlot28.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.lang.Object obj38 = textTitle32.draw(graphics2D33, rectangle2D34, (java.lang.Object) plotRenderingInfo37);
        org.jfree.chart.plot.CrosshairState crosshairState39 = null;
        boolean boolean40 = xYPlot0.render(graphics2D5, rectangle2D24, (int) '#', plotRenderingInfo37, crosshairState39);
        java.awt.geom.Rectangle2D rectangle2D41 = plotRenderingInfo37.getDataArea();
        java.awt.geom.Point2D point2D42 = null;
        try {
            int int43 = plotRenderingInfo37.getSubplotIndex(point2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        java.awt.Paint paint3 = xYPlot0.getNoDataMessagePaint();
        xYPlot0.setRangeCrosshairValue((double) 255, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getDataArea();
        org.jfree.data.resources.DataPackageResources dataPackageResources4 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean5 = plotRenderingInfo2.equals((java.lang.Object) dataPackageResources4);
        java.util.Enumeration<java.lang.String> strEnumeration6 = dataPackageResources4.getKeys();
        try {
            java.lang.Object obj8 = dataPackageResources4.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strEnumeration6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        java.util.List list2 = axisCollection0.getAxesAtLeft();
        java.util.List list3 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) (short) 100);
        double double5 = rectangleInsets2.getBottom();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str7 = categoryLabelWidthType6.toString();
        boolean boolean8 = rectangleInsets2.equals((java.lang.Object) str7);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets2.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelWidthType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str7.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint20 = categoryAxis19.getAxisLinePaint();
        float float21 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range25 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange22, (double) (byte) -1, false);
        org.jfree.data.Range range28 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange22, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection29 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range28, (org.jfree.data.general.Dataset) taskSeriesCollection29);
        boolean boolean32 = taskSeriesCollection29.equals((java.lang.Object) 9);
        boolean boolean33 = categoryAxis19.hasListener((java.util.EventListener) taskSeriesCollection29);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
        int int37 = taskSeriesCollection29.indexOf((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = taskSeriesCollection5.hasListener((java.util.EventListener) taskSeriesCollection29);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline8);
        int int10 = segmentedTimeline8.getSegmentsIncluded();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getVersion();
        projectInfo0.setName("AxisLocation.TOP_OR_RIGHT");
        projectInfo0.setLicenceText("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0.6" + "'", str1.equals("1.0.6"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isOutlineVisible();
        java.awt.Paint paint5 = categoryPlot3.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot3.getColumnRenderingOrder();
        java.lang.String str7 = sortOrder6.toString();
        categoryPlot0.setRowRenderingOrder(sortOrder6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SortOrder.ASCENDING" + "'", str7.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "12/31/69 4:00 PM", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis1.isHiddenValue((long) 'a');
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) dateAxis1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getYOffset();
        java.awt.Paint paint2 = barRenderer3D0.getWallPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = barRenderer3D0.getLegendItems();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        stackedAreaRenderer7.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition16, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer7.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color20, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = stackedAreaRenderer7.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer7.setBasePaint((java.awt.Paint) color26, true);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        ringPlot30.setShadowYOffset((double) 100);
        java.awt.Font font33 = ringPlot30.getNoDataMessageFont();
        stackedAreaRenderer7.setSeriesItemLabelFont((int) '4', font33);
        java.awt.Paint paint35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot36.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = textTitle46.getMargin();
        double double49 = rectangleInsets47.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font33, paint35, rectangleEdge42, horizontalAlignment43, verticalAlignment44, rectangleInsets47);
        org.jfree.chart.text.TextFragment textFragment51 = new org.jfree.chart.text.TextFragment("hi!", font33);
        barRenderer3D0.setSeriesItemLabelFont(2, font33, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        double double3 = stackedBarRenderer3D2.getUpperClip();
        stackedBarRenderer3D2.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font9 = null;
        stackedAreaRenderer8.setBaseItemLabelFont(font9, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator13, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        stackedAreaRenderer8.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition17, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer8.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color21, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = stackedAreaRenderer8.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer8.setBasePaint((java.awt.Paint) color27, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D30 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double31 = barRenderer3D30.getYOffset();
        java.awt.Paint paint32 = barRenderer3D30.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection35 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean36 = numberAxis34.hasListener((java.util.EventListener) taskSeriesCollection35);
        boolean boolean37 = numberAxis34.getAutoRangeIncludesZero();
        numberAxis34.setTickMarkInsideLength(0.0f);
        boolean boolean40 = barRenderer3D30.equals((java.lang.Object) numberAxis34);
        boolean boolean41 = stackedAreaRenderer8.equals((java.lang.Object) numberAxis34);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray42 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { stackedAreaRenderer8 };
        categoryPlot7.setRenderers(categoryItemRendererArray42);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis44.setTickLabelFont(font45);
        float float47 = dateAxis44.getTickMarkInsideLength();
        java.awt.Shape shape48 = dateAxis44.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = xYPlot49.getRangeMarkers((int) (byte) 100, layer51);
        xYPlot49.setDomainCrosshairValue(10.0d, false);
        xYPlot49.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = textTitle60.getMargin();
        double double63 = rectangleInsets61.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        textTitle65.draw(graphics2D66, rectangle2D67);
        java.awt.geom.Rectangle2D rectangle2D69 = textTitle65.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection70 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = new org.jfree.chart.ChartRenderingInfo(entityCollection70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        java.awt.geom.Rectangle2D rectangle2D73 = plotRenderingInfo72.getDataArea();
        boolean boolean74 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D69, rectangle2D73);
        java.awt.geom.Rectangle2D rectangle2D77 = rectangleInsets61.createOutsetRectangle(rectangle2D69, false, true);
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot();
        int int79 = xYPlot78.getDomainAxisCount();
        java.util.List list80 = xYPlot78.getAnnotations();
        xYPlot49.drawRangeTickBands(graphics2D58, rectangle2D77, list80);
        java.awt.Shape shape82 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D77);
        stackedBarRenderer3D2.drawRangeGridline(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis44, rectangle2D77, (double) ' ');
        double double85 = stackedBarRenderer3D2.getXOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 8.0d + "'", double31 == 8.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(list80);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 100.0d + "'", double85 == 100.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset(xYDataset4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft(Double.NaN);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot4.addChangeListener(plotChangeListener6);
        categoryPlot4.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getRangeAxisEdge();
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge10);
        axisSpace0.add(0.0d, rectangleEdge10);
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        axisSpace13.setLeft(Double.NaN);
        axisSpace13.setRight(0.0d);
        axisSpace0.ensureAtLeast(axisSpace13);
        double double19 = axisSpace0.getLeft();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        multiplePiePlot1.setAggregatedItemsPaint(paint4);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange6, (double) (byte) -1, false);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange6, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection13 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range12, (org.jfree.data.general.Dataset) taskSeriesCollection13);
        boolean boolean16 = taskSeriesCollection13.equals((java.lang.Object) 9);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection13);
        java.lang.Comparable comparable18 = multiplePiePlot1.getAggregatedItemsKey();
        multiplePiePlot1.setLimit((double) 100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "Other" + "'", comparable18.equals("Other"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape(10);
        java.awt.Shape shape4 = shapeList0.getShape((-131072));
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image11, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.lang.String str17 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceName("");
        java.awt.Image image20 = null;
        projectInfo7.setLogo(image20);
        org.jfree.chart.ui.Library[] libraryArray22 = projectInfo7.getLibraries();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray22);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        java.awt.Paint paint6 = stackedBarRenderer3D2.getSeriesPaint((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean10 = numberAxis8.hasListener((java.util.EventListener) taskSeriesCollection9);
        java.text.NumberFormat numberFormat11 = null;
        numberAxis8.setNumberFormatOverride(numberFormat11);
        org.jfree.data.Range range13 = numberAxis8.getDefaultAutoRange();
        numberAxis8.setTickMarksVisible(false);
        boolean boolean16 = stackedBarRenderer3D2.equals((java.lang.Object) false);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getDataArea();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        boolean boolean5 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedAreaRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = stackedAreaRenderer0.getDrawingSupplier();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        stackedAreaRenderer0.setBaseItemLabelFont(font8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Comparable comparable3 = null;
        try {
            defaultKeyedValues2D1.addValue((java.lang.Number) 900000L, comparable3, (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        double double7 = ringPlot1.getExplodePercent((java.lang.Comparable) (-447));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent(0.0d);
        double double3 = ganttRenderer0.getStartPercent();
        ganttRenderer0.setEndPercent(100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle4.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle4.getPosition();
        textTitle4.setHeight((double) 1);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        textTitle4.draw(graphics2D9, rectangle2D10);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle4.setFont(font12);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle4.getBounds();
        dateAxis0.setLeftArrow((java.awt.Shape) rectangle2D14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState((double) 60000L);
        axisState18.cursorUp((double) 1.0f);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot21.getRangeMarkers((int) (byte) 100, layer23);
        xYPlot21.setDomainCrosshairValue(10.0d, false);
        xYPlot21.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = textTitle32.getMargin();
        double double35 = rectangleInsets33.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        textTitle37.draw(graphics2D38, rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle37.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection42 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = new org.jfree.chart.ChartRenderingInfo(entityCollection42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        java.awt.geom.Rectangle2D rectangle2D45 = plotRenderingInfo44.getDataArea();
        boolean boolean46 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D41, rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets33.createOutsetRectangle(rectangle2D41, false, true);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        int int51 = xYPlot50.getDomainAxisCount();
        java.util.List list52 = xYPlot50.getAnnotations();
        xYPlot21.drawRangeTickBands(graphics2D30, rectangle2D49, list52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        java.util.List list55 = dateAxis0.refreshTicks(graphics2D16, axisState18, rectangle2D49, rectangleEdge54);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        axisState18.moveCursor((-1.0d), rectangleEdge57);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNull(list55);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        boolean boolean4 = xYPlot0.isSubplot();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font13 = null;
        stackedAreaRenderer12.setBaseItemLabelFont(font13, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        stackedAreaRenderer12.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator17, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        stackedAreaRenderer12.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition21, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color25, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedAreaRenderer12.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setBasePaint((java.awt.Paint) color31, true);
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        ringPlot35.setShadowYOffset((double) 100);
        java.awt.Font font38 = ringPlot35.getNoDataMessageFont();
        stackedAreaRenderer12.setSeriesItemLabelFont((int) '4', font38);
        java.awt.Paint paint40 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean42 = categoryPlot41.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot41.addChangeListener(plotChangeListener43);
        categoryPlot41.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot41.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = textTitle51.getMargin();
        double double54 = rectangleInsets52.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font38, paint40, rectangleEdge47, horizontalAlignment48, verticalAlignment49, rectangleInsets52);
        legendTitle8.setLegendItemGraphicPadding(rectangleInsets52);
        java.lang.String str57 = rectangleInsets52.toString();
        double double59 = rectangleInsets52.calculateLeftInset((double) ' ');
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str57.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        java.lang.String str17 = categoryItemEntity16.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) '#', true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("12/31/69 4:00 PM", "35", "hi!", "35", "");
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
//        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) lengthAdjustmentType2);
//        boolean boolean5 = defaultKeyedValues2D1.equals((java.lang.Object) 10.0d);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
//        ringPlot8.setShadowYOffset((double) 100);
//        boolean boolean11 = month6.equals((java.lang.Object) ringPlot8);
//        long long12 = month6.getLastMillisecond();
//        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) month6);
//        java.lang.Comparable comparable16 = null;
//        try {
//            defaultKeyedValues2D1.setValue((java.lang.Number) 1514793600000L, (java.lang.Comparable) 2.0f, comparable16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.Number number4 = null;
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0L, (java.lang.Number) 1559372400000L, (java.lang.Number) (short) -1, (java.lang.Number) (-1322433855L), number4, number5, (java.lang.Number) 5, (java.lang.Number) 15, list8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font11 = null;
        stackedAreaRenderer10.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, false);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = stackedAreaRenderer10.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean25 = categoryPlot24.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean27 = categoryPlot26.isDomainGridlinesVisible();
        java.awt.Paint paint28 = categoryPlot26.getDomainGridlinePaint();
        categoryPlot24.setOutlinePaint(paint28);
        categoryPlot24.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo(entityCollection33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        categoryPlot24.handleClick(9, (int) (short) 100, plotRenderingInfo35);
        java.awt.Stroke stroke37 = categoryPlot24.getRangeCrosshairStroke();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle39.getMargin();
        double double42 = rectangleInsets40.calculateLeftOutset((double) 10.0f);
        double double44 = rectangleInsets40.calculateLeftInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder45 = new org.jfree.chart.block.LineBorder(paint23, stroke37, rectangleInsets40);
        stackedAreaRenderer10.setSeriesStroke((int) (short) 10, stroke37);
        boolean boolean47 = boxAndWhiskerItem9.equals((java.lang.Object) stackedAreaRenderer10);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setDrawLines(false);
        minMaxCategoryRenderer0.setDrawLines(false);
        javax.swing.Icon icon5 = minMaxCategoryRenderer0.getMinIcon();
        javax.swing.Icon icon6 = minMaxCategoryRenderer0.getMaxIcon();
        org.junit.Assert.assertNotNull(icon5);
        org.junit.Assert.assertNotNull(icon6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline8);
        org.jfree.chart.axis.AxisCollection axisCollection10 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list11 = axisCollection10.getAxesAtBottom();
        java.util.List list12 = axisCollection10.getAxesAtTop();
        segmentedTimeline8.addExceptions(list12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        java.awt.Paint paint2 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation((-1));
        java.lang.String str5 = axisLocation4.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str5.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = xYPlot0.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray3 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer2 };
        xYPlot0.setRenderers(xYItemRendererArray3);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(xYItemRendererArray3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        xYPlot0.mapDatasetToRangeAxis((int) 'a', 0);
        org.junit.Assert.assertNull(valueAxis1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(10.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(categoryDataset12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryAxis7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        java.awt.Paint paint78 = stackedAreaRenderer48.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        int int80 = xYPlot79.getDomainAxisCount();
        java.util.List list81 = xYPlot79.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray88 = new org.jfree.chart.axis.ValueAxis[] { dateAxis82, dateAxis83, dateAxis84, dateAxis85, dateAxis86, dateAxis87 };
        xYPlot79.setDomainAxes(valueAxisArray88);
        stackedAreaRenderer48.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot79);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer92 = null;
        xYPlot79.setRenderer((int) (byte) 0, xYItemRenderer92);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(valueAxisArray88);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        int int8 = xYPlot0.getIndexOf(xYItemRenderer7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(15, (double) (short) 100);
        double double5 = layeredBarRenderer0.getSeriesBarWidth(5);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, false);
        int int19 = taskSeriesCollection5.getColumnCount();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle6.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo13.getDataArea();
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D10, rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets2.createOutsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D18);
        org.jfree.chart.axis.NumberAxis numberAxis20 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        stackedAreaRenderer25.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color38, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = stackedAreaRenderer25.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setBasePaint((java.awt.Paint) color44, true);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        ringPlot48.setShadowYOffset((double) 100);
        java.awt.Font font51 = ringPlot48.getNoDataMessageFont();
        stackedAreaRenderer25.setSeriesItemLabelFont((int) '4', font51);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis20, (double) (short) 10, (double) 100.0f, 1.0d, (double) (-1.0f), font51);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean55 = markerAxisBand53.equals((java.lang.Object) datasetRenderingOrder54);
        boolean boolean56 = legendItemEntity19.equals((java.lang.Object) markerAxisBand53);
        java.awt.Graphics2D graphics2D57 = null;
        double double58 = markerAxisBand53.getHeight(graphics2D57);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        long long5 = segmentedTimeline3.getSegmentsExcludedSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2958465 + "'", int4 == 2958465);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1322433855L) + "'", long5 == (-1322433855L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot6.addChangeListener(plotChangeListener8);
        categoryPlot6.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot6.getRangeAxisEdge();
        categoryPlot6.clearRangeMarkers((int) (byte) 100);
        java.util.List list15 = categoryPlot6.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot6.getDomainAxis(0);
        java.awt.Stroke stroke18 = categoryPlot6.getDomainGridlineStroke();
        ringPlot0.setLabelLinkStroke(stroke18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.lang.String str8 = projectInfo7.getLicenceName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("({0}, {1}) = {2}", "Sep", "", "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        basicProjectInfo14.setLicenceName("");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo14);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 59999.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.END" + "'", str1.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = stackedAreaRenderer0.getBaseFillPaint();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getDomainAxisCount();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot8.setRangeTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot8.getRangeAxisLocation(3);
        xYPlot6.setDomainAxisLocation((int) (byte) 10, axisLocation13);
        stackedAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot6);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot6.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        try {
            xYPlot6.addRangeMarker(marker17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis3.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.util.Date date7 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.lang.String str13 = dateTickUnit11.valueToString((double) 100.0f);
        java.util.Date date14 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit11);
        java.lang.String str15 = dateTickUnit11.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12/31/69 4:00 PM" + "'", str13.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str15.equals("DateTickUnit[DAY, 1]"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesShapesVisible((int) (byte) 0, false);
        boolean boolean4 = lineRenderer3D0.getBaseLinesVisible();
        lineRenderer3D0.setSeriesShapesVisible(5, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        java.awt.Font font4 = dateAxis0.getLabelFont();
        boolean boolean5 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) (byte) 10);
        boolean boolean10 = segmentedTimeline6.containsDomainValue((long) (-1));
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.previous();
        java.util.Date date14 = regularTimePeriod13.getStart();
        long long15 = segmentedTimeline6.getTime(date14);
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo18.getDataArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean21 = categoryPlot20.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot20.addChangeListener(plotChangeListener22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot20.getRangeAxisEdge();
        double double25 = dateAxis0.dateToJava2D(date14, rectangle2D19, rectangleEdge24);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1514793600000L + "'", long15 == 1514793600000L);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        java.awt.Paint paint78 = stackedAreaRenderer48.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        int int80 = xYPlot79.getDomainAxisCount();
        java.util.List list81 = xYPlot79.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray88 = new org.jfree.chart.axis.ValueAxis[] { dateAxis82, dateAxis83, dateAxis84, dateAxis85, dateAxis86, dateAxis87 };
        xYPlot79.setDomainAxes(valueAxisArray88);
        stackedAreaRenderer48.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot79);
        java.awt.Stroke stroke91 = xYPlot79.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection94 = xYPlot79.getRangeMarkers((int) (byte) 1, layer93);
        java.lang.String str95 = layer93.toString();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(valueAxisArray88);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertNull(collection94);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "Layer.FOREGROUND" + "'", str95.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100L, 8.0d, (double) 0L, (double) (-2208959999990L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        java.awt.Paint paint8 = barRenderer3D0.getSeriesFillPaint(0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getRangeAxisLocation();
        xYPlot0.clearAnnotations();
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        int int5 = defaultCategoryDataset2.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.data.RangeType rangeType7 = org.jfree.data.RangeType.FULL;
        java.lang.Object obj8 = null;
        boolean boolean9 = rangeType7.equals(obj8);
        boolean boolean10 = defaultCategoryDataset2.equals((java.lang.Object) rangeType7);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        java.lang.Object obj10 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        chartRenderingInfo14.clear();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis16.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle20.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle20.getPosition();
        textTitle20.setHeight((double) 1);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        textTitle20.draw(graphics2D25, rectangle2D26);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle20.setFont(font28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle20.getBounds();
        dateAxis16.setLeftArrow((java.awt.Shape) rectangle2D30);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D30);
        chartRenderingInfo14.setChartArea(rectangle2D30);
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart9.createBufferedImage(4, 5, chartRenderingInfo14);
        org.jfree.chart.plot.XYPlot xYPlot35 = jFreeChart9.getXYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace36 = new org.jfree.chart.axis.AxisSpace();
        double double37 = axisSpace36.getTop();
        axisSpace36.setLeft((double) ' ');
        xYPlot35.setFixedDomainAxisSpace(axisSpace36);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertNotNull(xYPlot35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.Plot plot1 = dateAxis0.getPlot();
        double double2 = dateAxis0.getLowerMargin();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean5 = segmentedTimeline3.containsDomainValue((long) (byte) 10);
        boolean boolean7 = segmentedTimeline3.containsDomainValue((long) (-1));
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        java.util.Date date11 = regularTimePeriod10.getStart();
        long long12 = segmentedTimeline3.getTime(date11);
        dateAxis0.setMaximumDate(date11);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1514793600000L + "'", long12 == 1514793600000L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator4);
        java.awt.Paint paint6 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot7.getRangeMarkers((int) (byte) 100, layer9);
        xYPlot7.setDomainCrosshairValue(10.0d, false);
        xYPlot7.clearDomainMarkers((int) (byte) 0);
        boolean boolean16 = xYPlot7.isRangeCrosshairVisible();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = ringPlot18.getLegendLabelGenerator();
        ringPlot18.setMinimumArcAngleToDraw((double) (byte) 1);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font23 = null;
        stackedAreaRenderer22.setBaseItemLabelFont(font23, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        stackedAreaRenderer22.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator27, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        stackedAreaRenderer22.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition31, false);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer22.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color35, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = stackedAreaRenderer22.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator41 = null;
        stackedAreaRenderer22.setLegendItemURLGenerator(categorySeriesLabelGenerator41);
        stackedAreaRenderer22.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke47 = stackedAreaRenderer22.getItemStroke((int) 'a', 0);
        ringPlot18.setLabelOutlineStroke(stroke47);
        xYPlot7.setRangeGridlineStroke(stroke47);
        ringPlot0.setLabelOutlineStroke(stroke47);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.clearRangeMarkers((int) (byte) 100);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis(0);
        java.awt.Stroke stroke12 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        boolean boolean2 = verticalAlignment0.equals((java.lang.Object) xYPlot1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = xYPlot1.getRenderer();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYItemRenderer3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        multiplePiePlot1.setAggregatedItemsPaint(paint4);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange6, (double) (byte) -1, false);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange6, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection13 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range12, (org.jfree.data.general.Dataset) taskSeriesCollection13);
        boolean boolean16 = taskSeriesCollection13.equals((java.lang.Object) 9);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection13);
        org.jfree.data.gantt.TaskSeries taskSeries19 = taskSeriesCollection13.getSeries((java.lang.Comparable) (-1322434302L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(taskSeries19);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Pie Plot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset50.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean55 = flowArrangement48.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D57 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int58 = defaultKeyedValues2D57.getColumnCount();
        boolean boolean59 = flowArrangement48.equals((java.lang.Object) defaultKeyedValues2D57);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
        org.jfree.data.time.Year year62 = month60.getYear();
        defaultKeyedValues2D57.removeColumn((java.lang.Comparable) month60);
        int int65 = defaultKeyedValues2D57.getRowIndex((java.lang.Comparable) 9);
        try {
            java.lang.Comparable comparable67 = defaultKeyedValues2D57.getColumnKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(year62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        boolean boolean6 = ringPlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        double double5 = numberAxis1.getLowerMargin();
        java.awt.Stroke stroke6 = numberAxis1.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            dateAxis0.setLabelInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesShapesVisible((int) (byte) 0, false);
        double double4 = lineRenderer3D0.getYOffset();
        lineRenderer3D0.setYOffset((double) 2019L);
        boolean boolean9 = lineRenderer3D0.getItemShapeVisible(255, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1322434302L), (double) 100L);
        try {
            barRenderer3D2.setSeriesVisible((-1), (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getLabelLinkPaint();
        numberAxis1.setTickMarkPaint(paint9);
        numberAxis1.configure();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot12.getRangeMarkers((int) (byte) 100, layer14);
        java.awt.Color color16 = java.awt.Color.BLACK;
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color16);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        java.awt.Font font4 = dateAxis0.getLabelFont();
        boolean boolean5 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis6.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis6.getTickUnit();
        int int10 = dateTickUnit9.getCount();
        java.util.Date date11 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit9);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTickUnit12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset50.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean55 = flowArrangement48.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D57 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int58 = defaultKeyedValues2D57.getColumnCount();
        boolean boolean59 = flowArrangement48.equals((java.lang.Object) defaultKeyedValues2D57);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
        org.jfree.data.time.Year year62 = month60.getYear();
        defaultKeyedValues2D57.removeColumn((java.lang.Comparable) month60);
        int int65 = defaultKeyedValues2D57.getRowIndex((java.lang.Comparable) 9);
        try {
            defaultKeyedValues2D57.removeRow(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(year62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str2.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        double double6 = rectangleInsets2.trimHeight(0.0d);
        double double7 = rectangleInsets2.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        int int3 = xYPlot2.getDomainAxisCount();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot2.setRangeTickBandPaint((java.awt.Paint) color4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot2.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot2.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color5);
        ringPlot1.setSeparatorsVisible(false);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = regularTimePeriod11.getStart();
        java.awt.Paint paint13 = null;
        ringPlot1.setSectionPaint((java.lang.Comparable) date12, paint13);
        ringPlot1.setCircular(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(markerAxisBand6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        java.util.Date date4 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font11 = null;
        stackedAreaRenderer10.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        stackedAreaRenderer10.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition19, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color23, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer10.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition(9, itemLabelPosition28);
        stackedAreaRenderer0.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape34 = stackedAreaRenderer0.getItemShape(2958465, (int) (byte) 100);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setShadowYOffset((double) 15);
        org.jfree.data.general.DatasetGroup datasetGroup5 = ringPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D6 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean8 = categoryPlot7.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot7.addChangeListener(plotChangeListener9);
        categoryPlot7.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font14 = null;
        stackedAreaRenderer13.setBaseItemLabelFont(font14, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        stackedAreaRenderer13.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator18, false);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer13);
        stackedAreaRenderer13.setBaseCreateEntities(false);
        java.awt.Stroke stroke25 = stackedAreaRenderer13.lookupSeriesOutlineStroke((-1));
        categoryPlot7.setDomainGridlineStroke(stroke25);
        categoryPlot7.setDrawSharedDomainAxis(false);
        boolean boolean29 = lineRenderer3D6.equals((java.lang.Object) categoryPlot7);
        boolean boolean30 = ringPlot0.equals((java.lang.Object) lineRenderer3D6);
        lineRenderer3D6.setSeriesShapesFilled(255, false);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getItemLabelPadding();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        int int13 = color11.getAlpha();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.clearRangeMarkers((int) (byte) 100);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis(0);
        java.awt.Stroke stroke12 = categoryPlot0.getDomainGridlineStroke();
        double double13 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.setRangeCrosshairValue((double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = year2.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer6);
        stackedAreaRenderer6.setBaseCreateEntities(false);
        java.awt.Stroke stroke18 = stackedAreaRenderer6.lookupSeriesOutlineStroke((-1));
        categoryPlot0.setDomainGridlineStroke(stroke18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font21 = null;
        stackedAreaRenderer20.setBaseItemLabelFont(font21, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedAreaRenderer20.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator25, false);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = stackedAreaRenderer20.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer20);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D33 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double34 = barRenderer3D33.getYOffset();
        java.awt.Paint paint35 = barRenderer3D33.getWallPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = barRenderer3D33.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection36);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        ringPlot38.setShadowYOffset((double) 100);
        ringPlot38.setCircular(false);
        ringPlot38.setLabelLinkMargin((double) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = ringPlot38.getLegendItems();
        legendItemCollection36.addAll(legendItemCollection45);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 8.0d + "'", double34 == 8.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(legendItemCollection45);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getItemLabelPadding();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        int int12 = xYPlot11.getDomainAxisCount();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot11);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray14 = legendTitle13.getSources();
        legendTitle8.setSources(legendItemSourceArray14);
        legendTitle8.setMargin((double) (-1322434302L), (double) 10L, (-1.0d), (double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(legendItemSourceArray14);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis4.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis4.getTickUnit();
        java.awt.Stroke stroke8 = dateAxis4.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis4.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline12);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis15.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.util.Date date19 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesShapesVisible((int) (byte) 0, false);
        lineRenderer3D0.setSeriesShapesFilled(5, true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint13 = null;
        try {
            categoryPlot0.setRangeGridlinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.lang.Object obj2 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        java.text.DateFormat dateFormat7 = dateAxis5.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.util.Date date12 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit11);
        keyedObjects2D0.addObject(obj2, (java.lang.Comparable) numberTickUnit4, (java.lang.Comparable) dateTickUnit11);
        java.util.List list14 = keyedObjects2D0.getColumnKeys();
        java.lang.Object obj17 = keyedObjects2D0.getObject((java.lang.Comparable) "35", (java.lang.Comparable) "hi!");
        java.lang.Object obj18 = keyedObjects2D0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getDataArea();
        org.jfree.data.resources.DataPackageResources dataPackageResources4 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean5 = plotRenderingInfo2.equals((java.lang.Object) dataPackageResources4);
        java.util.Enumeration<java.lang.String> strEnumeration6 = dataPackageResources4.getKeys();
        boolean boolean8 = dataPackageResources4.containsKey("June 2019");
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strEnumeration6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("1.0.6");
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset(xYDataset9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange11, (double) (byte) -1, false);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange11, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection18 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range17, (org.jfree.data.general.Dataset) taskSeriesCollection18);
        xYPlot0.datasetChanged(datasetChangeEvent19);
        java.lang.String str21 = datasetChangeEvent19.toString();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=Range[1.0,2.0]]" + "'", str21.equals("org.jfree.data.general.DatasetChangeEvent[source=Range[1.0,2.0]]"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) '#', (double) (-447), (double) (short) 1);
        double double6 = rectangleInsets4.calculateRightInset(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { "Layer.FOREGROUND" };
        double[] doubleArray11 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray18 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray25 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray47 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray47);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray2, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke26 = stackedAreaRenderer0.getItemStroke(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = stackedAreaRenderer0.getSeriesItemLabelGenerator((-1));
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot(pieDataset30);
        java.awt.Paint paint33 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot31.setSectionPaint((java.lang.Comparable) 1.0f, paint33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot31.setLabelLinkPaint((java.awt.Paint) color35);
        stackedAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color35, false);
        boolean boolean39 = stackedAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        boolean boolean5 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker7);
        categoryPlot0.clearDomainMarkers((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setOutlineVisible(false);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setSectionDepth(1.0E-5d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range6, (org.jfree.data.general.Dataset) taskSeriesCollection7);
        boolean boolean10 = taskSeriesCollection7.equals((java.lang.Object) 9);
        int int11 = taskSeriesCollection7.getSeriesCount();
        try {
            java.lang.Number number15 = taskSeriesCollection7.getPercentComplete((int) (byte) 1, (int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.setAnchorValue((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setShadowYOffset((double) 100);
        java.awt.Font font4 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle5.draw(graphics2D6, rectangle2D7);
        double double9 = textTitle5.getContentXOffset();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis3.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.util.Date date7 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        java.util.Date date8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean11 = categoryPlot10.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot10.addChangeListener(plotChangeListener12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot10.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot10.setDomainAxisLocation((int) 'a', axisLocation16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot10.getRangeAxisEdge();
        try {
            double double19 = dateAxis0.dateToJava2D(date8, rectangle2D9, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str1 = axisSpace0.toString();
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        numberAxis1.setLowerBound((double) 15);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double8 = defaultStatisticalCategoryDataset6.getRangeLowerBound(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str13 = numberTickUnit11.valueToString((double) '#');
        defaultStatisticalCategoryDataset6.add((java.lang.Number) (-1L), (java.lang.Number) 0, (java.lang.Comparable) numberTickUnit11, (java.lang.Comparable) 1.0E-5d);
        numberAxis1.setTickUnit(numberTickUnit11, true, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "35" + "'", str13.equals("35"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        java.lang.Object obj10 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart9.getPadding();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getYOffset();
        barRenderer3D0.setAutoPopulateSeriesShape(false);
        java.awt.Paint paint5 = barRenderer3D0.getSeriesOutlinePaint(4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getCompletePaint();
        double double2 = ganttRenderer0.getStartPercent();
        java.awt.Paint paint3 = ganttRenderer0.getCompletePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.35d + "'", double2 == 0.35d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, (double) 0.0f);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = waterfallBarRenderer4.getBaseURLGenerator();
        java.awt.Paint paint6 = waterfallBarRenderer4.getPositiveBarPaint();
        barRenderer3D2.setSeriesFillPaint(0, paint6, true);
        java.awt.Paint paint11 = barRenderer3D2.getItemFillPaint((int) '#', 0);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str7 = numberTickUnit5.valueToString((double) '#');
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) 0, (java.lang.Comparable) numberTickUnit5, (java.lang.Comparable) 1.0E-5d);
        int int11 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35" + "'", str7.equals("35"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        java.text.DateFormat dateFormat3 = dateAxis1.getDateFormatOverride();
        boolean boolean4 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis5.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis5.getTickUnit();
        java.awt.Stroke stroke9 = dateAxis5.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis5.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline13);
        dateAxis1.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline13);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint18 = dateAxis17.getLabelPaint();
        java.text.DateFormat dateFormat19 = dateAxis17.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis20.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        java.util.Date date24 = dateAxis17.calculateHighestVisibleTickValue(dateTickUnit23);
        java.util.Date date25 = dateTickUnit16.addToDate(date24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date24);
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(dateFormat19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        java.awt.Paint paint2 = categoryPlot0.getOutlinePaint();
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 100, 100);
        int int6 = categoryPlot0.getRangeAxisCount();
        double double7 = categoryPlot0.getAnchorValue();
        categoryPlot0.setRangeCrosshairValue((double) 3, false);
        boolean boolean11 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.chart.LegendItem legendItem24 = stackedAreaRenderer0.getLegendItem((int) (short) -1, 5);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType25 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        stackedAreaRenderer0.setEndType(areaRendererEndType25);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(areaRendererEndType25);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot8.addChangeListener(plotChangeListener10);
        categoryPlot8.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font15 = null;
        stackedAreaRenderer14.setBaseItemLabelFont(font15, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedAreaRenderer14.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator19, false);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer14);
        stackedAreaRenderer14.setBaseCreateEntities(false);
        java.awt.Stroke stroke26 = stackedAreaRenderer14.lookupSeriesOutlineStroke((-1));
        categoryPlot8.setDomainGridlineStroke(stroke26);
        categoryPlot8.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean32 = numberAxis30.hasListener((java.util.EventListener) taskSeriesCollection31);
        boolean boolean33 = numberAxis30.getAutoRangeIncludesZero();
        numberAxis30.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot(pieDataset36);
        java.awt.Paint paint38 = ringPlot37.getLabelLinkPaint();
        numberAxis30.setTickMarkPaint(paint38);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        numberAxis30.setRangeWithMargins((org.jfree.data.Range) dateRange40, false, true);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle45.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = textTitle45.getPosition();
        textTitle45.setHeight((double) 1);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        textTitle45.draw(graphics2D50, rectangle2D51);
        java.awt.Font font53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle45.setFont(font53);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle45.getBounds();
        barRenderer3D0.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis30, rectangle2D55, (double) 100L);
        numberAxis30.setFixedAutoRange(0.0d);
        double double60 = numberAxis30.getFixedDimension();
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str3 = numberTickUnit1.valueToString((double) '#');
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean5 = numberTickUnit1.equals((java.lang.Object) horizontalAlignment4);
        java.lang.Object obj6 = null;
        keyedObjects0.setObject((java.lang.Comparable) boolean5, obj6);
        java.lang.Comparable comparable8 = null;
        java.lang.Object obj9 = keyedObjects0.getObject(comparable8);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = barRenderer3D10.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer3D10.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D10.setMinimumBarLength((double) (short) 1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean19 = categoryPlot18.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot18.addChangeListener(plotChangeListener20);
        categoryPlot18.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font25 = null;
        stackedAreaRenderer24.setBaseItemLabelFont(font25, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = null;
        stackedAreaRenderer24.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator29, false);
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer24);
        stackedAreaRenderer24.setBaseCreateEntities(false);
        java.awt.Stroke stroke36 = stackedAreaRenderer24.lookupSeriesOutlineStroke((-1));
        categoryPlot18.setDomainGridlineStroke(stroke36);
        categoryPlot18.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection41 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean42 = numberAxis40.hasListener((java.util.EventListener) taskSeriesCollection41);
        boolean boolean43 = numberAxis40.getAutoRangeIncludesZero();
        numberAxis40.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot(pieDataset46);
        java.awt.Paint paint48 = ringPlot47.getLabelLinkPaint();
        numberAxis40.setTickMarkPaint(paint48);
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange();
        numberAxis40.setRangeWithMargins((org.jfree.data.Range) dateRange50, false, true);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = textTitle55.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = textTitle55.getPosition();
        textTitle55.setHeight((double) 1);
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        textTitle55.draw(graphics2D60, rectangle2D61);
        java.awt.Font font63 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle55.setFont(font63);
        java.awt.geom.Rectangle2D rectangle2D65 = textTitle55.getBounds();
        barRenderer3D10.drawRangeGridline(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis40, rectangle2D65, (double) 100L);
        int int68 = categoryPlot18.getDatasetCount();
        boolean boolean69 = categoryPlot18.isRangeCrosshairLockedOnData();
        boolean boolean70 = keyedObjects0.equals((java.lang.Object) categoryPlot18);
        java.lang.Object obj71 = keyedObjects0.clone();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(obj71);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 60000L);
        axisState1.cursorUp((double) 1.0f);
        double double4 = axisState1.getCursor();
        axisState1.cursorUp((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot8.addChangeListener(plotChangeListener10);
        categoryPlot8.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot8.getRangeAxisEdge();
        axisState1.moveCursor(59999.0d, rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 59999.0d + "'", double4 == 59999.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        double double3 = stackedBarRenderer3D2.getUpperClip();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D2.getLegendItemLabelGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.setOutlineVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot6.getOrientation();
        categoryPlot6.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection17 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean18 = numberAxis16.hasListener((java.util.EventListener) taskSeriesCollection17);
        boolean boolean19 = numberAxis16.getAutoRangeIncludesZero();
        double double20 = numberAxis16.getLowerMargin();
        numberAxis16.setUpperBound((double) (-447));
        double double23 = numberAxis16.getAutoRangeMinimumSize();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean25 = categoryPlot24.isDomainGridlinesVisible();
        java.awt.Paint paint26 = categoryPlot24.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent27);
        boolean boolean29 = categoryPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryPlot24.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker31);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = chartRenderingInfo33.getPlotInfo();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean36 = categoryPlot35.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo(entityCollection39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        org.jfree.chart.renderer.RendererState rendererState42 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo41);
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot35.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo41, point2D43);
        plotRenderingInfo34.addSubplotInfo(plotRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D46 = plotRenderingInfo34.getDataArea();
        stackedBarRenderer3D2.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.plot.Marker) categoryMarker31, rectangle2D46);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0E-8d + "'", double23 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) lengthAdjustmentType2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list5 = taskSeriesCollection4.getRowKeys();
        taskSeriesCollection4.removeAll();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getLabelPaint();
        java.text.DateFormat dateFormat9 = dateAxis7.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis10.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis10.getTickUnit();
        java.util.Date date14 = dateAxis7.calculateHighestVisibleTickValue(dateTickUnit13);
        int int15 = taskSeriesCollection4.getColumnIndex((java.lang.Comparable) date14);
        boolean boolean16 = lengthAdjustmentType2.equals((java.lang.Object) taskSeriesCollection4);
        try {
            java.lang.Number number19 = taskSeriesCollection4.getPercentComplete((int) ' ', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke26 = stackedAreaRenderer0.getItemStroke(0, 0);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font29 = null;
        stackedAreaRenderer28.setBaseItemLabelFont(font29, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = null;
        stackedAreaRenderer28.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator33, false);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer28);
        stackedAreaRenderer28.setBaseCreateEntities(false);
        java.awt.Stroke stroke40 = stackedAreaRenderer28.lookupSeriesOutlineStroke((-1));
        stackedAreaRenderer0.setSeriesStroke((int) (byte) 1, stroke40, true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        java.text.DateFormat dateFormat7 = dateAxis5.getDateFormatOverride();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis9.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        java.awt.Stroke stroke13 = dateAxis9.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis9.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline17);
        dateAxis5.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline17);
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis5.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint22 = dateAxis21.getLabelPaint();
        java.text.DateFormat dateFormat23 = dateAxis21.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis24.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis24.getTickUnit();
        java.util.Date date28 = dateAxis21.calculateHighestVisibleTickValue(dateTickUnit27);
        java.util.Date date29 = dateTickUnit20.addToDate(date28);
        java.util.Date date30 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(dateFormat23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle13.draw(graphics2D14, rectangle2D15);
        jFreeChart9.addSubtitle(0, (org.jfree.chart.title.Title) textTitle13);
        jFreeChart9.setNotify(true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        int int6 = defaultCategoryDataset3.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot2.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        java.util.List list8 = defaultCategoryDataset3.getColumnKeys();
        org.jfree.data.Range range9 = intervalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        java.util.List list10 = defaultCategoryDataset3.getColumnKeys();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle9.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType12 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str13 = categoryLabelWidthType12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor10, textBlockAnchor11, categoryLabelWidthType12, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType16 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str17 = categoryLabelWidthType16.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor11, categoryLabelWidthType16, (float) 100L);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint21 = dateAxis20.getLabelPaint();
        java.text.DateFormat dateFormat22 = dateAxis20.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition23 = dateAxis20.getTickMarkPosition();
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        ringPlot25.setShadowYOffset((double) 100);
        java.awt.Font font28 = ringPlot25.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("", font28);
        org.jfree.chart.text.TextFragment textFragment30 = null;
        textLine29.addFragment(textFragment30);
        boolean boolean32 = dateTickMarkPosition23.equals((java.lang.Object) textLine29);
        boolean boolean33 = rectangleAnchor0.equals((java.lang.Object) boolean32);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font35 = null;
        stackedAreaRenderer34.setBaseItemLabelFont(font35, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer34.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator39, false);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = legendTitle42.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType45 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str46 = categoryLabelWidthType45.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition48 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor43, textBlockAnchor44, categoryLabelWidthType45, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions50 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean52 = categoryPlot51.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener53 = null;
        categoryPlot51.addChangeListener(plotChangeListener53);
        categoryPlot51.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot51.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition58 = categoryLabelPositions50.getLabelPosition(rectangleEdge57);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font60 = null;
        stackedAreaRenderer59.setBaseItemLabelFont(font60, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator64 = null;
        stackedAreaRenderer59.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator64, false);
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer59);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = legendTitle67.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor69 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType70 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str71 = categoryLabelWidthType70.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition73 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor68, textBlockAnchor69, categoryLabelWidthType70, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType74 = categoryLabelPosition73.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer76 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font77 = null;
        stackedAreaRenderer76.setBaseItemLabelFont(font77, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator81 = null;
        stackedAreaRenderer76.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator81, false);
        org.jfree.chart.title.LegendTitle legendTitle84 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer76);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = legendTitle84.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor86 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType87 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str88 = categoryLabelWidthType87.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition90 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor85, textBlockAnchor86, categoryLabelWidthType87, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType91 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str92 = categoryLabelWidthType91.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition94 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor75, textBlockAnchor86, categoryLabelWidthType91, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions95 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition48, categoryLabelPosition58, categoryLabelPosition73, categoryLabelPosition94);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor96 = categoryLabelPosition58.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition97 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor96);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelWidthType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str13.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str17.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(dateFormat22);
        org.junit.Assert.assertNotNull(dateTickMarkPosition23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(categoryLabelWidthType45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str46.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(categoryLabelPosition58);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(textBlockAnchor69);
        org.junit.Assert.assertNotNull(categoryLabelWidthType70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str71.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType74);
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNotNull(textBlockAnchor86);
        org.junit.Assert.assertNotNull(categoryLabelWidthType87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str88.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType91);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str92.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(textBlockAnchor96);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isOutlineVisible();
        java.awt.Paint paint10 = categoryPlot8.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot8.getColumnRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder11);
        java.awt.Paint paint13 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.clearRangeMarkers((int) (byte) 100);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean15 = numberAxis13.hasListener((java.util.EventListener) taskSeriesCollection14);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis13.setNumberFormatOverride(numberFormat16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        boolean boolean19 = numberAxis13.isVisible();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis13, false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        numberAxis13.setLabelPaint((java.awt.Paint) color22);
        numberAxis13.setLowerMargin(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator20 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        stackedAreaRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator20);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        try {
            java.lang.String str25 = standardCategorySeriesLabelGenerator20.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font3 = null;
        stackedAreaRenderer2.setBaseItemLabelFont(font3, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedAreaRenderer2.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator7, false);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType13 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str14 = categoryLabelWidthType13.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12, categoryLabelWidthType13, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean20 = categoryPlot19.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot19.addChangeListener(plotChangeListener21);
        categoryPlot19.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = categoryLabelPositions18.getLabelPosition(rectangleEdge25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer27 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font28 = null;
        stackedAreaRenderer27.setBaseItemLabelFont(font28, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = null;
        stackedAreaRenderer27.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator32, false);
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle35.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType38 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str39 = categoryLabelWidthType38.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition41 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor36, textBlockAnchor37, categoryLabelWidthType38, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType42 = categoryLabelPosition41.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font45 = null;
        stackedAreaRenderer44.setBaseItemLabelFont(font45, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        stackedAreaRenderer44.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator49, false);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = legendTitle52.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor54 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType55 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str56 = categoryLabelWidthType55.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition58 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor53, textBlockAnchor54, categoryLabelWidthType55, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType59 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str60 = categoryLabelWidthType59.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition62 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor43, textBlockAnchor54, categoryLabelWidthType59, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions63 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition16, categoryLabelPosition26, categoryLabelPosition41, categoryLabelPosition62);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions64 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition62);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(categoryLabelWidthType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str14.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(categoryLabelPosition26);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertNotNull(categoryLabelWidthType38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str39.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(textBlockAnchor54);
        org.junit.Assert.assertNotNull(categoryLabelWidthType55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str56.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str60.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions64);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator((int) (short) -1, 15);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("SortOrder.ASCENDING");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean5 = numberAxis3.hasListener((java.util.EventListener) taskSeriesCollection4);
        boolean boolean6 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        java.awt.Paint paint11 = ringPlot10.getLabelLinkPaint();
        numberAxis3.setTickMarkPaint(paint11);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        numberAxis3.setRangeWithMargins((org.jfree.data.Range) dateRange13, false, true);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint19 = dateAxis18.getLabelPaint();
        java.text.DateFormat dateFormat20 = dateAxis18.getDateFormatOverride();
        boolean boolean21 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis22.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis22.getTickUnit();
        java.awt.Stroke stroke26 = dateAxis22.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis22.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline30);
        dateAxis18.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline30);
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range36 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange33, (double) (byte) -1, false);
        org.jfree.data.Range range39 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange33, (double) 1.0f, false);
        double double40 = dateRange33.getLength();
        dateAxis18.setRange((org.jfree.data.Range) dateRange33, false, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange13, (org.jfree.data.Range) dateRange33);
        java.util.Date date45 = dateRange33.getUpperDate();
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(dateFormat20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = xYPlot50.getRangeMarkers((int) (byte) 100, layer52);
        xYPlot50.setDomainCrosshairValue(10.0d, false);
        xYPlot50.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot50);
        float float60 = jFreeChart59.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot61 = jFreeChart59.getXYPlot();
        org.jfree.chart.title.LegendTitle legendTitle62 = jFreeChart59.getLegend();
        blockContainer49.add((org.jfree.chart.block.Block) legendTitle62);
        org.jfree.chart.block.LineBorder lineBorder64 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType65 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str66 = categoryLabelWidthType65.toString();
        boolean boolean67 = lineBorder64.equals((java.lang.Object) str66);
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis();
        boolean boolean71 = dateAxis69.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = textTitle73.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = textTitle73.getPosition();
        textTitle73.setHeight((double) 1);
        java.awt.Graphics2D graphics2D78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        textTitle73.draw(graphics2D78, rectangle2D79);
        java.awt.Font font81 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle73.setFont(font81);
        java.awt.geom.Rectangle2D rectangle2D83 = textTitle73.getBounds();
        dateAxis69.setLeftArrow((java.awt.Shape) rectangle2D83);
        java.awt.Shape shape85 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D83);
        lineBorder64.draw(graphics2D68, rectangle2D83);
        blockContainer49.setFrame((org.jfree.chart.block.BlockFrame) lineBorder64);
        blockContainer49.clear();
        java.util.List list89 = blockContainer49.getBlocks();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.5f + "'", float60 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot61);
        org.junit.Assert.assertNotNull(legendTitle62);
        org.junit.Assert.assertNotNull(categoryLabelWidthType65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str66.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertNotNull(font81);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(list89);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke26 = stackedAreaRenderer0.getItemStroke(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = stackedAreaRenderer0.getSeriesItemLabelGenerator((-1));
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot(pieDataset30);
        java.awt.Paint paint33 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot31.setSectionPaint((java.lang.Comparable) 1.0f, paint33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot31.setLabelLinkPaint((java.awt.Paint) color35);
        stackedAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color35, false);
        java.awt.Paint paint39 = stackedAreaRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        boolean boolean1 = layeredBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        java.text.DateFormat dateFormat5 = dateAxis3.getDateFormatOverride();
        boolean boolean6 = dateAxis3.isTickLabelsVisible();
        java.awt.Font font7 = dateAxis3.getLabelFont();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke9 = defaultDrawingSupplier8.getNextStroke();
        dateAxis3.setAxisLineStroke(stroke9);
        layeredBarRenderer0.setSeriesStroke(9, stroke9, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer6);
        stackedAreaRenderer6.setBaseCreateEntities(false);
        java.awt.Stroke stroke18 = stackedAreaRenderer6.lookupSeriesOutlineStroke((-1));
        categoryPlot0.setDomainGridlineStroke(stroke18);
        categoryPlot0.clearDomainAxes();
        java.awt.Stroke stroke21 = categoryPlot0.getRangeGridlineStroke();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle10.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle10.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str12 = categoryLabelWidthType11.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10, categoryLabelWidthType11, (float) 100L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = categoryLabelPosition14.getLabelAnchor();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        boolean boolean18 = textBlockAnchor15.equals((java.lang.Object) defaultDrawingSupplier16);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str12.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        java.awt.Paint paint3 = xYPlot0.getDomainGridlinePaint();
        java.awt.Paint paint4 = xYPlot0.getRangeTickBandPaint();
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 5);
        int int5 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 1.0f, false);
        boolean boolean8 = range6.contains((double) 1514793600000L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.clearRangeMarkers((int) (byte) 100);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis(0);
        java.awt.Stroke stroke12 = categoryPlot0.getDomainGridlineStroke();
        double double13 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot0.setDomainAxis(categoryAxis14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot8.addChangeListener(plotChangeListener10);
        categoryPlot8.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font15 = null;
        stackedAreaRenderer14.setBaseItemLabelFont(font15, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedAreaRenderer14.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator19, false);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer14);
        stackedAreaRenderer14.setBaseCreateEntities(false);
        java.awt.Stroke stroke26 = stackedAreaRenderer14.lookupSeriesOutlineStroke((-1));
        categoryPlot8.setDomainGridlineStroke(stroke26);
        categoryPlot8.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean32 = numberAxis30.hasListener((java.util.EventListener) taskSeriesCollection31);
        boolean boolean33 = numberAxis30.getAutoRangeIncludesZero();
        numberAxis30.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot(pieDataset36);
        java.awt.Paint paint38 = ringPlot37.getLabelLinkPaint();
        numberAxis30.setTickMarkPaint(paint38);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        numberAxis30.setRangeWithMargins((org.jfree.data.Range) dateRange40, false, true);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle45.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = textTitle45.getPosition();
        textTitle45.setHeight((double) 1);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        textTitle45.draw(graphics2D50, rectangle2D51);
        java.awt.Font font53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle45.setFont(font53);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle45.getBounds();
        barRenderer3D0.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis30, rectangle2D55, (double) 100L);
        int int58 = categoryPlot8.getDatasetCount();
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer61 = null;
        java.util.Collection collection62 = xYPlot59.getRangeMarkers((int) (byte) 100, layer61);
        xYPlot59.setDomainCrosshairValue(10.0d, false);
        xYPlot59.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart68 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot59);
        float float69 = jFreeChart68.getBackgroundImageAlpha();
        categoryPlot8.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart68);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertTrue("'" + float69 + "' != '" + 0.5f + "'", float69 == 0.5f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.GENERAL");
        labelBlock1.setToolTipText("Sep");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = labelBlock1.getPadding();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot6.getRangeMarkers((int) (byte) 100, layer8);
        java.awt.Paint paint10 = xYPlot6.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape14, "ClassContext", "");
        java.awt.Shape shape18 = chartEntity17.getArea();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle20.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle20.getPosition();
        textTitle20.setHeight((double) 1);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        textTitle20.draw(graphics2D25, rectangle2D26);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle20.setFont(font28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle20.getBounds();
        chartEntity17.setArea((java.awt.Shape) rectangle2D30);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        ringPlot34.setShadowYOffset((double) 100);
        java.awt.Font font37 = ringPlot34.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.entity.EntityCollection entityCollection41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo(entityCollection41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        java.lang.Object obj44 = textTitle38.draw(graphics2D39, rectangle2D40, (java.lang.Object) plotRenderingInfo43);
        org.jfree.chart.plot.CrosshairState crosshairState45 = null;
        boolean boolean46 = xYPlot6.render(graphics2D11, rectangle2D30, (int) '#', plotRenderingInfo43, crosshairState45);
        java.awt.geom.Rectangle2D rectangle2D47 = plotRenderingInfo43.getDataArea();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.RingPlot ringPlot49 = new org.jfree.chart.plot.RingPlot(pieDataset48);
        java.awt.Paint paint51 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot49.setSectionPaint((java.lang.Comparable) 1.0f, paint51);
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot49.setLabelLinkPaint((java.awt.Paint) color53);
        double double56 = ringPlot49.getExplodePercent((java.lang.Comparable) (short) 1);
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        boolean boolean60 = dateAxis58.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = dateAxis58.getTickUnit();
        java.awt.Stroke stroke62 = dateAxis58.getAxisLineStroke();
        ringPlot49.setSectionOutlineStroke((java.lang.Comparable) true, stroke62);
        try {
            java.lang.Object obj64 = labelBlock1.draw(graphics2D5, rectangle2D47, (java.lang.Object) ringPlot49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dateTickUnit61);
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getDataArea();
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot1.addChangeListener(plotChangeListener3);
        categoryPlot1.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer7);
        stackedAreaRenderer7.setBaseCreateEntities(false);
        java.awt.Stroke stroke19 = stackedAreaRenderer7.lookupSeriesOutlineStroke((-1));
        categoryPlot1.setDomainGridlineStroke(stroke19);
        categoryPlot1.setDrawSharedDomainAxis(false);
        boolean boolean23 = lineRenderer3D0.equals((java.lang.Object) categoryPlot1);
        lineRenderer3D0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        java.awt.Font font4 = dateAxis0.getLabelFont();
        boolean boolean5 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis6.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis6.getTickUnit();
        int int10 = dateTickUnit9.getCount();
        java.util.Date date11 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot12.getRangeMarkers((int) (byte) 100, layer14);
        xYPlot12.setWeight(0);
        boolean boolean18 = dateTickUnit9.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle5.getMargin();
        double double8 = rectangleInsets6.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle10.draw(graphics2D11, rectangle2D12);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle10.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo17.getDataArea();
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D14, rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets6.createOutsetRectangle(rectangle2D14, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity23 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D22);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font25 = null;
        stackedAreaRenderer24.setBaseItemLabelFont(font25, true);
        boolean boolean28 = stackedAreaRenderer24.getBaseCreateEntities();
        boolean boolean29 = stackedAreaRenderer24.getAutoPopulateSeriesShape();
        java.lang.Boolean boolean31 = stackedAreaRenderer24.getSeriesVisible(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = stackedAreaRenderer24.getSeriesURLGenerator(2958465);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        stackedAreaRenderer24.setBaseStroke(stroke34, true);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot(pieDataset37);
        java.awt.Paint paint40 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot38.setSectionPaint((java.lang.Comparable) 1.0f, paint40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot38.setLabelLinkPaint((java.awt.Paint) color42);
        try {
            org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem(attributedString0, "DateTickMarkPosition.END", "({0}, {1}) = {3} - {4}", "RectangleEdge.LEFT", (java.awt.Shape) rectangle2D22, stroke34, (java.awt.Paint) color42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNull(categoryURLGenerator33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setCircular(false);
        ringPlot0.setLabelLinkMargin((double) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = ringPlot0.getLegendItems();
        java.lang.Object obj8 = legendItemCollection7.clone();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean3 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) standardCategorySeriesLabelGenerator2);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font5 = null;
        stackedAreaRenderer4.setBaseItemLabelFont(font5, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        stackedAreaRenderer4.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        stackedAreaRenderer4.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition13, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer4.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color17, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedAreaRenderer4.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = null;
        stackedAreaRenderer4.setLegendItemURLGenerator(categorySeriesLabelGenerator23);
        stackedAreaRenderer4.setBaseItemLabelsVisible(false);
        boolean boolean27 = standardCategorySeriesLabelGenerator2.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font3 = null;
        stackedAreaRenderer2.setBaseItemLabelFont(font3, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedAreaRenderer2.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator7, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedAreaRenderer2.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition11, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer2.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color15, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedAreaRenderer2.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer2.setBasePaint((java.awt.Paint) color21, true);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        ringPlot25.setShadowYOffset((double) 100);
        java.awt.Font font28 = ringPlot25.getNoDataMessageFont();
        stackedAreaRenderer2.setSeriesItemLabelFont((int) '4', font28);
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot31.addChangeListener(plotChangeListener33);
        categoryPlot31.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot31.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = textTitle41.getMargin();
        double double44 = rectangleInsets42.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font28, paint30, rectangleEdge37, horizontalAlignment38, verticalAlignment39, rectangleInsets42);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("hi!", font28);
        float float47 = textFragment46.getBaselineOffset();
        java.awt.Font font48 = textFragment46.getFont();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(font48);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        ringPlot23.setShadowYOffset((double) 100);
        java.awt.Font font26 = ringPlot23.getNoDataMessageFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font26);
        stackedAreaRenderer0.setItemLabelAnchorOffset(1.0d);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        stackedAreaRenderer0.notifyListeners(rendererChangeEvent30);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset50.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean55 = flowArrangement48.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D57 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int58 = defaultKeyedValues2D57.getColumnCount();
        boolean boolean59 = flowArrangement48.equals((java.lang.Object) defaultKeyedValues2D57);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
        org.jfree.data.time.Year year62 = month60.getYear();
        defaultKeyedValues2D57.removeColumn((java.lang.Comparable) month60);
        try {
            java.lang.Number number66 = defaultKeyedValues2D57.getValue(1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(year62);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle6.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo13.getDataArea();
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D10, rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets2.createOutsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D18);
        org.jfree.chart.axis.NumberAxis numberAxis20 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        stackedAreaRenderer25.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color38, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = stackedAreaRenderer25.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setBasePaint((java.awt.Paint) color44, true);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        ringPlot48.setShadowYOffset((double) 100);
        java.awt.Font font51 = ringPlot48.getNoDataMessageFont();
        stackedAreaRenderer25.setSeriesItemLabelFont((int) '4', font51);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis20, (double) (short) 10, (double) 100.0f, 1.0d, (double) (-1.0f), font51);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean55 = markerAxisBand53.equals((java.lang.Object) datasetRenderingOrder54);
        boolean boolean56 = legendItemEntity19.equals((java.lang.Object) markerAxisBand53);
        java.lang.Comparable comparable57 = legendItemEntity19.getSeriesKey();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(comparable57);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis20.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle24.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = textTitle24.getPosition();
        textTitle24.setHeight((double) 1);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle24.draw(graphics2D29, rectangle2D30);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle24.setFont(font32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle24.getBounds();
        dateAxis20.setLeftArrow((java.awt.Shape) rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer42);
        stackedAreaRenderer42.setBaseCreateEntities(false);
        java.awt.Stroke stroke54 = stackedAreaRenderer42.lookupSeriesOutlineStroke((-1));
        categoryPlot36.setDomainGridlineStroke(stroke54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean58 = categoryPlot57.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.renderer.RendererState rendererState64 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo63);
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot57.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo63, point2D65);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState67 = stackedAreaRenderer0.initialise(graphics2D19, rectangle2D34, categoryPlot36, 3, plotRenderingInfo63);
        double double68 = categoryItemRendererState67.getSeriesRunningTotal();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererState67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test455");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
//        ringPlot2.setShadowYOffset((double) 100);
//        boolean boolean5 = month0.equals((java.lang.Object) ringPlot2);
//        long long6 = month0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) 9);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        int int4 = xYPlot3.getDomainAxisCount();
        boolean boolean5 = axisSpace0.equals((java.lang.Object) int4);
        double double6 = axisSpace0.getTop();
        double double7 = axisSpace0.getLeft();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis3.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.util.Date date7 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.lang.String str13 = dateTickUnit11.valueToString((double) 100.0f);
        java.util.Date date14 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit11);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis15.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle19.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = textTitle19.getPosition();
        textTitle19.setHeight((double) 1);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        textTitle19.draw(graphics2D24, rectangle2D25);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle19.setFont(font27);
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle19.getBounds();
        dateAxis15.setLeftArrow((java.awt.Shape) rectangle2D29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = textTitle32.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = textTitle32.getPosition();
        double double35 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D29, rectangleEdge34);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D29, "WMAP_Plot");
        dateAxis0.setRightArrow((java.awt.Shape) rectangle2D29);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12/31/69 4:00 PM" + "'", str13.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setOutlineVisible(false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image11, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.lang.String str17 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceName("");
        java.awt.Image image20 = null;
        projectInfo7.setLogo(image20);
        projectInfo7.setName("ClassContext");
        java.lang.String str24 = projectInfo7.toString();
        java.lang.String str25 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ClassContext version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ClassContext:({0}, {1}) = {2} hi! ().\nClassContext LICENCE TERMS:\nCategoryLabelWidthType.RANGE" + "'", str24.equals("ClassContext version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ClassContext:({0}, {1}) = {2} hi! ().\nClassContext LICENCE TERMS:\nCategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ClassContext version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ClassContext:({0}, {1}) = {2} hi! ().\nClassContext LICENCE TERMS:\nCategoryLabelWidthType.RANGE" + "'", str25.equals("ClassContext version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ClassContext:({0}, {1}) = {2} hi! ().\nClassContext LICENCE TERMS:\nCategoryLabelWidthType.RANGE"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot11.addChangeListener(plotChangeListener13);
        categoryPlot11.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = categoryLabelPositions10.getLabelPosition(rectangleEdge17);
        categoryAxis8.setCategoryLabelPositions(categoryLabelPositions10);
        java.lang.String str21 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        categoryPlot0.setDomainAxis(categoryAxis8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot0.getRenderer((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation25);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(categoryLabelPosition18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNotNull(plotOrientation25);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10, (float) (byte) 1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("February");
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        double double6 = rectangleInsets2.calculateLeftInset(100.0d);
        double double8 = rectangleInsets2.calculateTopOutset((double) 1L);
        double double10 = rectangleInsets2.calculateRightOutset(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle13.draw(graphics2D14, rectangle2D15);
        jFreeChart9.addSubtitle(0, (org.jfree.chart.title.Title) textTitle13);
        java.awt.RenderingHints renderingHints18 = null;
        try {
            jFreeChart9.setRenderingHints(renderingHints18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        java.lang.Object obj10 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        chartRenderingInfo14.clear();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis16.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle20.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle20.getPosition();
        textTitle20.setHeight((double) 1);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        textTitle20.draw(graphics2D25, rectangle2D26);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle20.setFont(font28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle20.getBounds();
        dateAxis16.setLeftArrow((java.awt.Shape) rectangle2D30);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D30);
        chartRenderingInfo14.setChartArea(rectangle2D30);
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart9.createBufferedImage(4, 5, chartRenderingInfo14);
        org.jfree.chart.plot.XYPlot xYPlot35 = jFreeChart9.getXYPlot();
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        ringPlot36.setShadowYOffset((double) 100);
        ringPlot36.setIgnoreNullValues(true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ringPlot36.setSectionOutlinePaint((java.lang.Comparable) 30, (java.awt.Paint) color42);
        xYPlot35.setDomainTickBandPaint((java.awt.Paint) color42);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertNotNull(xYPlot35);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.clearRangeMarkers((int) (byte) 100);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getRGB();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray7 = new float[] { (byte) -1, (-1.0f), 10, (short) 10 };
        float[] floatArray8 = color2.getComponents(floatArray7);
        float[] floatArray9 = color0.getRGBComponents(floatArray7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray17 = new float[] { (byte) -1, (-1.0f), 10, (short) 10 };
        float[] floatArray18 = color12.getComponents(floatArray17);
        float[] floatArray19 = color0.getColorComponents(colorSpace11, floatArray18);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, false);
        java.lang.Comparable comparable19 = null;
        try {
            java.lang.Number number21 = taskSeriesCollection5.getValue(comparable19, (java.lang.Comparable) 0.25d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer2 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer2.setStartPercent(0.0d);
        double double5 = ganttRenderer2.getStartPercent();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        ganttRenderer2.setSeriesPaint(1900, (java.awt.Paint) color7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot10.getDomainAxis();
        java.awt.Stroke stroke12 = xYPlot10.getRangeCrosshairStroke();
        xYPlot9.setRangeCrosshairStroke(stroke12);
        java.awt.Color color14 = java.awt.Color.cyan;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot15.getDomainAxis();
        java.awt.Stroke stroke17 = xYPlot15.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 15, (java.awt.Paint) color7, stroke12, (java.awt.Paint) color14, stroke17, (float) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator4);
        java.awt.Paint paint6 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint7 = ringPlot0.getShadowPaint();
        java.lang.Object obj8 = ringPlot0.clone();
        ringPlot0.setInteriorGap(Double.NaN);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange0, 12.0d);
        java.lang.Object obj6 = null;
        boolean boolean7 = range5.equals(obj6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range5, (double) 10.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedHeight((double) 1L);
        org.jfree.data.Range range12 = rectangleConstraint11.getHeightRange();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation6 = ringPlot1.getDirection();
        java.awt.Paint paint7 = ringPlot1.getSeparatorPaint();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint9 = null;
        ringPlot8.setShadowPaint(paint9);
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot8.setOutlinePaint(paint11);
        ringPlot1.setBaseSectionOutlinePaint(paint11);
        double double14 = ringPlot1.getMaximumLabelWidth();
        ringPlot1.setPieIndex(255);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image11, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.lang.String str17 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceName("");
        java.awt.Image image20 = null;
        projectInfo7.setLogo(image20);
        org.jfree.chart.ui.Library[] libraryArray22 = projectInfo7.getOptionalLibraries();
        java.lang.String str23 = projectInfo7.getVersion();
        projectInfo7.setName("CategoryLabelWidthType.RANGE");
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (byte) 100, layer6);
        xYPlot4.setDomainCrosshairValue(10.0d, false);
        xYPlot4.clearDomainMarkers((int) (byte) 0);
        java.awt.Paint paint13 = null;
        xYPlot4.setRangeTickBandPaint(paint13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getRangeAxis();
        ringPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.lang.Object obj18 = plotChangeEvent17.getSource();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        ringPlot1.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer7);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font18 = null;
        stackedAreaRenderer17.setBaseItemLabelFont(font18, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        stackedAreaRenderer17.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator22, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        stackedAreaRenderer17.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer17.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color30, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedAreaRenderer17.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer7.setSeriesNegativeItemLabelPosition(9, itemLabelPosition35);
        java.awt.Paint paint37 = stackedAreaRenderer7.getBaseFillPaint();
        ringPlot1.setOutlinePaint(paint37);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot39.getRangeMarkers((int) (byte) 100, layer41);
        xYPlot39.setDomainCrosshairValue(10.0d, false);
        xYPlot39.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot39);
        float float49 = jFreeChart48.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot50 = jFreeChart48.getXYPlot();
        jFreeChart48.fireChartChanged();
        org.jfree.chart.title.LegendTitle legendTitle52 = jFreeChart48.getLegend();
        ringPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart48);
        jFreeChart48.fireChartChanged();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.5f + "'", float49 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot50);
        org.junit.Assert.assertNotNull(legendTitle52);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(30, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        double double3 = stackedBarRenderer3D2.getUpperClip();
        stackedBarRenderer3D2.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font9 = null;
        stackedAreaRenderer8.setBaseItemLabelFont(font9, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator13, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        stackedAreaRenderer8.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition17, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer8.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color21, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = stackedAreaRenderer8.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer8.setBasePaint((java.awt.Paint) color27, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D30 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double31 = barRenderer3D30.getYOffset();
        java.awt.Paint paint32 = barRenderer3D30.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection35 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean36 = numberAxis34.hasListener((java.util.EventListener) taskSeriesCollection35);
        boolean boolean37 = numberAxis34.getAutoRangeIncludesZero();
        numberAxis34.setTickMarkInsideLength(0.0f);
        boolean boolean40 = barRenderer3D30.equals((java.lang.Object) numberAxis34);
        boolean boolean41 = stackedAreaRenderer8.equals((java.lang.Object) numberAxis34);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray42 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { stackedAreaRenderer8 };
        categoryPlot7.setRenderers(categoryItemRendererArray42);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis44.setTickLabelFont(font45);
        float float47 = dateAxis44.getTickMarkInsideLength();
        java.awt.Shape shape48 = dateAxis44.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = xYPlot49.getRangeMarkers((int) (byte) 100, layer51);
        xYPlot49.setDomainCrosshairValue(10.0d, false);
        xYPlot49.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = textTitle60.getMargin();
        double double63 = rectangleInsets61.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        textTitle65.draw(graphics2D66, rectangle2D67);
        java.awt.geom.Rectangle2D rectangle2D69 = textTitle65.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection70 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = new org.jfree.chart.ChartRenderingInfo(entityCollection70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        java.awt.geom.Rectangle2D rectangle2D73 = plotRenderingInfo72.getDataArea();
        boolean boolean74 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D69, rectangle2D73);
        java.awt.geom.Rectangle2D rectangle2D77 = rectangleInsets61.createOutsetRectangle(rectangle2D69, false, true);
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot();
        int int79 = xYPlot78.getDomainAxisCount();
        java.util.List list80 = xYPlot78.getAnnotations();
        xYPlot49.drawRangeTickBands(graphics2D58, rectangle2D77, list80);
        java.awt.Shape shape82 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D77);
        stackedBarRenderer3D2.drawRangeGridline(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis44, rectangle2D77, (double) ' ');
        java.awt.Paint paint86 = stackedBarRenderer3D2.getSeriesPaint((int) (byte) 10);
        stackedBarRenderer3D2.setIncludeBaseInRange(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 8.0d + "'", double31 == 8.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(list80);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNull(paint86);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("SortOrder.ASCENDING");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean5 = numberAxis3.hasListener((java.util.EventListener) taskSeriesCollection4);
        boolean boolean6 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        java.awt.Paint paint11 = ringPlot10.getLabelLinkPaint();
        numberAxis3.setTickMarkPaint(paint11);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        numberAxis3.setRangeWithMargins((org.jfree.data.Range) dateRange13, false, true);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        dateAxis1.setLowerBound((double) 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        categoryPlot0.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        int int15 = categoryPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font5 = null;
        stackedAreaRenderer4.setBaseItemLabelFont(font5, true);
        stackedAreaRenderer4.setBaseItemLabelsVisible(false, true);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        java.awt.Paint paint13 = ringPlot12.getLabelLinkPaint();
        stackedAreaRenderer4.setBaseFillPaint(paint13, false);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) (-447), (-1.0d), (double) 3600000L, (double) 8, paint13);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot17.getRangeMarkers((int) (byte) 100, layer19);
        xYPlot17.mapDatasetToRangeAxis(2958465, 15);
        boolean boolean24 = blockBorder16.equals((java.lang.Object) xYPlot17);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "ClassContext", "");
        java.awt.Shape shape12 = chartEntity11.getArea();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle14.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = textTitle14.getPosition();
        textTitle14.setHeight((double) 1);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle14.draw(graphics2D19, rectangle2D20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle14.setFont(font22);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle14.getBounds();
        chartEntity11.setArea((java.awt.Shape) rectangle2D24);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        ringPlot28.setShadowYOffset((double) 100);
        java.awt.Font font31 = ringPlot28.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.lang.Object obj38 = textTitle32.draw(graphics2D33, rectangle2D34, (java.lang.Object) plotRenderingInfo37);
        org.jfree.chart.plot.CrosshairState crosshairState39 = null;
        boolean boolean40 = xYPlot0.render(graphics2D5, rectangle2D24, (int) '#', plotRenderingInfo37, crosshairState39);
        java.awt.Paint paint41 = xYPlot0.getRangeCrosshairPaint();
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder43 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        multiplePiePlot1.setLimit((double) 10);
        java.lang.String str4 = multiplePiePlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.lang.String str2 = chartChangeEventType0.toString();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        int int4 = xYPlot3.getDomainAxisCount();
        java.util.List list5 = xYPlot3.getAnnotations();
        java.awt.Paint paint6 = xYPlot3.getDomainGridlinePaint();
        java.awt.Paint paint7 = xYPlot3.getRangeTickBandPaint();
        boolean boolean8 = chartChangeEventType0.equals((java.lang.Object) paint7);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str2.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        int int6 = xYPlot5.getDomainAxisCount();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot5.setRangeTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot5.getRangeAxisLocation(3);
        categoryPlot0.setRangeAxisLocation(axisLocation10, false);
        boolean boolean13 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot0.getDomainAxis((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset50.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean55 = flowArrangement48.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D57 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int58 = defaultKeyedValues2D57.getColumnCount();
        boolean boolean59 = flowArrangement48.equals((java.lang.Object) defaultKeyedValues2D57);
        try {
            java.lang.Number number62 = defaultKeyedValues2D57.getValue(0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("SerialDate.weekInMonthToString(): invalid code.", "({0}, {1}) = {2}", "", "hi!", "CategoryLabelWidthType.RANGE");
        boolean boolean8 = categoryLabelPositions1.equals((java.lang.Object) "");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font10 = null;
        stackedAreaRenderer9.setBaseItemLabelFont(font10, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator14, false);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle17.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType20 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str21 = categoryLabelWidthType20.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor18, textBlockAnchor19, categoryLabelWidthType20, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions25 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean27 = categoryPlot26.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot26.addChangeListener(plotChangeListener28);
        categoryPlot26.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot26.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = categoryLabelPositions25.getLabelPosition(rectangleEdge32);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font35 = null;
        stackedAreaRenderer34.setBaseItemLabelFont(font35, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer34.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator39, false);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = legendTitle42.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType45 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str46 = categoryLabelWidthType45.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition48 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor43, textBlockAnchor44, categoryLabelWidthType45, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType49 = categoryLabelPosition48.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer51 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font52 = null;
        stackedAreaRenderer51.setBaseItemLabelFont(font52, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator56 = null;
        stackedAreaRenderer51.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator56, false);
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer51);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = legendTitle59.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor61 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType62 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str63 = categoryLabelWidthType62.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition65 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor60, textBlockAnchor61, categoryLabelWidthType62, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType66 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str67 = categoryLabelWidthType66.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition69 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor50, textBlockAnchor61, categoryLabelWidthType66, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions70 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition23, categoryLabelPosition33, categoryLabelPosition48, categoryLabelPosition69);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor71 = categoryLabelPosition33.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions72 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions1, categoryLabelPosition33);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(categoryLabelWidthType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str21.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(categoryLabelPosition33);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(categoryLabelWidthType45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str46.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType49);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(textBlockAnchor61);
        org.junit.Assert.assertNotNull(categoryLabelWidthType62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str63.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str67.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(textBlockAnchor71);
        org.junit.Assert.assertNotNull(categoryLabelPositions72);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range8 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange5, (double) (byte) -1, false);
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, 12.0d);
        dateAxis0.setRange((org.jfree.data.Range) dateRange5, false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        java.lang.Object obj10 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        chartRenderingInfo14.clear();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis16.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle20.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle20.getPosition();
        textTitle20.setHeight((double) 1);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        textTitle20.draw(graphics2D25, rectangle2D26);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle20.setFont(font28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle20.getBounds();
        dateAxis16.setLeftArrow((java.awt.Shape) rectangle2D30);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D30);
        chartRenderingInfo14.setChartArea(rectangle2D30);
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart9.createBufferedImage(4, 5, chartRenderingInfo14);
        org.jfree.chart.plot.XYPlot xYPlot35 = jFreeChart9.getXYPlot();
        org.jfree.chart.title.LegendTitle legendTitle37 = jFreeChart9.getLegend(6);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertNotNull(xYPlot35);
        org.junit.Assert.assertNull(legendTitle37);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        stackedAreaRenderer6.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition15, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer6.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color19, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = stackedAreaRenderer6.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer6.setBasePaint((java.awt.Paint) color25, true);
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        ringPlot29.setShadowYOffset((double) 100);
        java.awt.Font font32 = ringPlot29.getNoDataMessageFont();
        stackedAreaRenderer6.setSeriesItemLabelFont((int) '4', font32);
        java.awt.Paint paint34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean36 = categoryPlot35.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        categoryPlot35.addChangeListener(plotChangeListener37);
        categoryPlot35.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot35.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle45.getMargin();
        double double48 = rectangleInsets46.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font32, paint34, rectangleEdge41, horizontalAlignment42, verticalAlignment43, rectangleInsets46);
        org.jfree.chart.text.TextFragment textFragment50 = new org.jfree.chart.text.TextFragment("hi!", font32);
        float float51 = textFragment50.getBaselineOffset();
        boolean boolean52 = dateTickUnit3.equals((java.lang.Object) textFragment50);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint54 = dateAxis53.getLabelPaint();
        java.text.DateFormat dateFormat55 = dateAxis53.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        boolean boolean58 = dateAxis56.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit59 = dateAxis56.getTickUnit();
        java.util.Date date60 = dateAxis53.calculateHighestVisibleTickValue(dateTickUnit59);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline64 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        segmentedTimeline64.setStartTime((long) 'a');
        java.util.Date date68 = segmentedTimeline64.getDate((long) '4');
        java.util.TimeZone timeZone69 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone69;
        java.util.Date date71 = dateTickUnit59.addToDate(date68, timeZone69);
        java.lang.Class class72 = null;
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        long long74 = year73.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year73.previous();
        java.util.Date date76 = regularTimePeriod75.getStart();
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint78 = dateAxis77.getLabelPaint();
        java.text.DateFormat dateFormat79 = dateAxis77.getDateFormatOverride();
        boolean boolean80 = dateAxis77.isTickLabelsVisible();
        java.awt.Font font81 = dateAxis77.getLabelFont();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection82 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list83 = taskSeriesCollection82.getRowKeys();
        taskSeriesCollection82.removeAll();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint86 = dateAxis85.getLabelPaint();
        java.text.DateFormat dateFormat87 = dateAxis85.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis88 = new org.jfree.chart.axis.DateAxis();
        boolean boolean90 = dateAxis88.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit91 = dateAxis88.getTickUnit();
        java.util.Date date92 = dateAxis85.calculateHighestVisibleTickValue(dateTickUnit91);
        int int93 = taskSeriesCollection82.getColumnIndex((java.lang.Comparable) date92);
        dateAxis77.setMinimumDate(date92);
        java.util.TimeZone timeZone95 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year96 = new org.jfree.data.time.Year(date92, timeZone95);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date76, timeZone95);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone95;
        java.util.Date date99 = dateTickUnit3.addToDate(date68, timeZone95);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 0.0f + "'", float51 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(dateFormat55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dateTickUnit59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 2019L + "'", long74 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNull(dateFormat79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(font81);
        org.junit.Assert.assertNotNull(list83);
        org.junit.Assert.assertNotNull(paint86);
        org.junit.Assert.assertNull(dateFormat87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(dateTickUnit91);
        org.junit.Assert.assertNotNull(date92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(timeZone95);
        org.junit.Assert.assertNull(regularTimePeriod97);
        org.junit.Assert.assertNotNull(date99);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = xYPlot50.getRangeMarkers((int) (byte) 100, layer52);
        xYPlot50.setDomainCrosshairValue(10.0d, false);
        xYPlot50.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot50);
        float float60 = jFreeChart59.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot61 = jFreeChart59.getXYPlot();
        org.jfree.chart.title.LegendTitle legendTitle62 = jFreeChart59.getLegend();
        blockContainer49.add((org.jfree.chart.block.Block) legendTitle62);
        org.jfree.chart.block.BlockFrame blockFrame64 = blockContainer49.getFrame();
        blockContainer49.clear();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.5f + "'", float60 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot61);
        org.junit.Assert.assertNotNull(legendTitle62);
        org.junit.Assert.assertNotNull(blockFrame64);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) 100, (double) 1.0f, (double) 10.0f);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        double double8 = stackedBarRenderer3D7.getUpperClip();
        stackedBarRenderer3D7.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font14 = null;
        stackedAreaRenderer13.setBaseItemLabelFont(font14, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        stackedAreaRenderer13.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator18, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        stackedAreaRenderer13.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition22, false);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer13.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color26, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = stackedAreaRenderer13.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer13.setBasePaint((java.awt.Paint) color32, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D35 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double36 = barRenderer3D35.getYOffset();
        java.awt.Paint paint37 = barRenderer3D35.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection40 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean41 = numberAxis39.hasListener((java.util.EventListener) taskSeriesCollection40);
        boolean boolean42 = numberAxis39.getAutoRangeIncludesZero();
        numberAxis39.setTickMarkInsideLength(0.0f);
        boolean boolean45 = barRenderer3D35.equals((java.lang.Object) numberAxis39);
        boolean boolean46 = stackedAreaRenderer13.equals((java.lang.Object) numberAxis39);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray47 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { stackedAreaRenderer13 };
        categoryPlot12.setRenderers(categoryItemRendererArray47);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis49.setTickLabelFont(font50);
        float float52 = dateAxis49.getTickMarkInsideLength();
        java.awt.Shape shape53 = dateAxis49.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = xYPlot54.getRangeMarkers((int) (byte) 100, layer56);
        xYPlot54.setDomainCrosshairValue(10.0d, false);
        xYPlot54.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = textTitle65.getMargin();
        double double68 = rectangleInsets66.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        textTitle70.draw(graphics2D71, rectangle2D72);
        java.awt.geom.Rectangle2D rectangle2D74 = textTitle70.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection75 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo76 = new org.jfree.chart.ChartRenderingInfo(entityCollection75);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo76);
        java.awt.geom.Rectangle2D rectangle2D78 = plotRenderingInfo77.getDataArea();
        boolean boolean79 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D74, rectangle2D78);
        java.awt.geom.Rectangle2D rectangle2D82 = rectangleInsets66.createOutsetRectangle(rectangle2D74, false, true);
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot();
        int int84 = xYPlot83.getDomainAxisCount();
        java.util.List list85 = xYPlot83.getAnnotations();
        xYPlot54.drawRangeTickBands(graphics2D63, rectangle2D82, list85);
        java.awt.Shape shape87 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D82);
        stackedBarRenderer3D7.drawRangeGridline(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis49, rectangle2D82, (double) ' ');
        java.awt.geom.Rectangle2D rectangle2D90 = rectangleInsets4.createInsetRectangle(rectangle2D82);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.0d + "'", double36 == 8.0d);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray47);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.0f + "'", float52 == 0.0f);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(list85);
        org.junit.Assert.assertNotNull(shape87);
        org.junit.Assert.assertNotNull(rectangle2D90);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        stackedAreaRenderer0.setRenderAsPercentages(false);
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesShapesVisible((int) (byte) 0, false);
        boolean boolean4 = lineRenderer3D0.getBaseLinesVisible();
        boolean boolean5 = lineRenderer3D0.getDrawOutlines();
        boolean boolean8 = lineRenderer3D0.getItemShapeFilled((int) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean4 = dateAxis0.isHiddenValue(0L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        java.awt.Paint paint2 = categoryPlot0.getOutlinePaint();
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 100, 100);
        int int6 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot7.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation8);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        ringPlot10.setShadowYOffset((double) 100);
        ringPlot10.setOutlineVisible(false);
        ringPlot10.setSectionOutlinesVisible(false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        ringPlot17.setShadowYOffset((double) 100);
        ringPlot17.setCircular(false);
        ringPlot17.setLabelLinkMargin((double) (byte) 0);
        java.awt.Stroke stroke24 = ringPlot17.getLabelLinkStroke();
        ringPlot10.setSeparatorStroke(stroke24);
        categoryPlot0.setRangeCrosshairStroke(stroke24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) month0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryMarker2.getLabelOffset();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }
}

