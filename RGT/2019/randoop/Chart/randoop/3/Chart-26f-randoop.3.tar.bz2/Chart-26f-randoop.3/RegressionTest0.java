import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font1, paint2, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.TickLabelEntity tickLabelEntity3 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, 0.0d, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.DateTick dateTick5 = new org.jfree.chart.axis.DateTick(date0, "hi!", textAnchor2, textAnchor3, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            textTitle1.setBounds(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        java.util.ResourceBundle.clearCache(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        try {
            categoryPlot0.handleClick(100, (int) (short) -1, plotRenderingInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        try {
            stackedAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        java.awt.Stroke stroke4 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447) + "'", int1 == (-447));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray50 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray51 = new double[][] { doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray51);
        try {
            stackedAreaRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, valueAxis6, categoryDataset52, (int) '4', (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        try {
            stackedAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle1.draw(graphics2D2, rectangle2D3);
        java.lang.Object obj5 = textTitle1.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 1L, 0.2d, (double) (-1.0f), (double) (short) 0, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("CategoryLabelWidthType.RANGE", "CategoryLabelWidthType.RANGE", "", "hi!");
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) false, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets2.createInsetRectangle(rectangle2D3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) month0, textBlock1, textBlockAnchor2, textAnchor3, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        java.lang.String str2 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str1.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str2.equals("CategoryLabelWidthType.RANGE"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        try {
            org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        size2D0.setHeight((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("hi!", (int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 10L, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("CategoryLabelWidthType.RANGE", graphics2D1, (float) 10L, (float) 100L, textAnchor4, (double) 1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ClassContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getColumnKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = stackedAreaRenderer0.getBaseFillPaint();
        java.awt.Paint paint6 = null;
        try {
            stackedAreaRenderer0.setBaseFillPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setCircular(false);
        double double5 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        java.awt.color.ColorSpace colorSpace16 = null;
        float[] floatArray18 = new float[] { 0.0f };
        try {
            float[] floatArray19 = color13.getComponents(colorSpace16, floatArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation6 = ringPlot1.getDirection();
        java.awt.Font font7 = null;
        try {
            ringPlot1.setLabelFont(font7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        boolean boolean20 = ringPlot0.equals((java.lang.Object) (short) 10);
        java.awt.Paint paint21 = ringPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        java.lang.String str3 = textTitle1.getURLText();
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle1.arrange(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint5 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot3.setSectionPaint((java.lang.Comparable) 1.0f, paint5);
        java.awt.Paint paint7 = ringPlot3.getLabelShadowPaint();
        try {
            org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font1, paint7, (float) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle1.draw(graphics2D4, rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (short) -1, (java.lang.Comparable) "ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: ClassContext");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(datasetGroup7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint paint1 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean2 = color0.equals((java.lang.Object) paint1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(9, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sep" + "'", str2.equals("Sep"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        categoryPlot0.setOutlineVisible(true);
        categoryPlot0.clearDomainMarkers((int) (byte) 100);
        org.jfree.chart.util.SortOrder sortOrder6 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        java.lang.String str3 = textTitle1.getURLText();
        double double4 = textTitle1.getContentYOffset();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        stackedAreaRenderer7.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition16, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer7.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color20, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = stackedAreaRenderer7.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = null;
        stackedAreaRenderer7.setLegendItemURLGenerator(categorySeriesLabelGenerator26);
        stackedAreaRenderer7.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke32 = stackedAreaRenderer7.getItemStroke((int) 'a', 0);
        java.lang.Object obj33 = textTitle1.draw(graphics2D5, rectangle2D6, (java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(obj33);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor74 = categoryPlot73.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(categoryAnchor74);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        categoryPlot0.setOutlineVisible(true);
        categoryPlot0.clearDomainMarkers((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot0.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            legendTitle8.setLegendItemGraphicEdge(rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = null;
        try {
            ringPlot0.setLabelDistributor(abstractPieLabelDistributor4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            categoryPlot0.addRangeMarker(0, marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        try {
            xYPlot0.setRangeAxisLocation(0, axisLocation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.getDrawSharedDomainAxis();
        boolean boolean4 = categoryLabelWidthType0.equals((java.lang.Object) boolean3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setShadowYOffset((double) 100);
        ringPlot5.setShadowYOffset((double) 15);
        boolean boolean10 = categoryLabelWidthType0.equals((java.lang.Object) ringPlot5);
        double double11 = ringPlot5.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str1.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100.0f);
        try {
            java.lang.Number number6 = defaultCategoryDataset0.getValue((int) (short) 100, (-447));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultStatisticalCategoryDataset0.getRowKey((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        long long4 = segmentedTimeline3.getStartTime();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.String str3 = standardCategoryToolTipGenerator0.generateRowLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation6 = ringPlot1.getDirection();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        java.awt.Paint paint11 = ringPlot10.getLabelLinkPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState14 = ringPlot1.initialise(graphics2D7, rectangle2D8, (org.jfree.chart.plot.PiePlot) ringPlot10, (java.lang.Integer) (-447), plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator79 = stackedAreaRenderer48.getToolTipGenerator((-1), (-447));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNull(categoryToolTipGenerator79);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        double double3 = ringPlot1.getStartAngle();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = borderArrangement0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle5.draw(graphics2D6, rectangle2D7);
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle5.getBounds();
        java.awt.Paint paint10 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font12 = null;
        stackedAreaRenderer11.setBaseItemLabelFont(font12, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        stackedAreaRenderer11.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator16, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        stackedAreaRenderer11.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition20, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer11.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color24, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = stackedAreaRenderer11.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = null;
        stackedAreaRenderer11.setLegendItemURLGenerator(categorySeriesLabelGenerator30);
        stackedAreaRenderer11.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke36 = stackedAreaRenderer11.getItemStroke((int) 'a', 0);
        java.awt.Paint paint37 = null;
        try {
            org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem(attributedString0, "CategoryLabelWidthType.RANGE", "ClassContext", "({0}, {1}) = {2}", (java.awt.Shape) rectangle2D9, paint10, stroke36, paint37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot3.addChangeListener(plotChangeListener5);
        categoryPlot3.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot3.getRangeAxisEdge();
        try {
            double double10 = dateAxis0.valueToJava2D((double) 3, rectangle2D2, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            java.lang.Number number4 = defaultCategoryDataset0.getValue((int) (byte) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double[] doubleArray6 = new double[] { 3, '4', 0, 0L, 2958465, (byte) -1 };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[] doubleArray16 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray51 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray52 = new double[][] { doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44, doubleArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray52);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray7, doubleArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        int int5 = defaultCategoryDataset2.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle12.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle12.getPosition();
        textTitle12.setHeight((double) 1);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle12.draw(graphics2D17, rectangle2D18);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle12.setFont(font20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle12.getBounds();
        dateAxis8.setLeftArrow((java.awt.Shape) rectangle2D22);
        java.awt.geom.Point2D point2D24 = null;
        org.jfree.chart.plot.PlotState plotState25 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo27.getPlotInfo();
        try {
            multiplePiePlot1.draw(graphics2D7, rectangle2D22, point2D24, plotState25, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, true);
        java.awt.Font font7 = stackedAreaRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font11 = null;
        stackedAreaRenderer10.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        stackedAreaRenderer10.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition19, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color23, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer10.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition(9, itemLabelPosition28);
        stackedAreaRenderer0.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setCircular(false);
        boolean boolean5 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        java.awt.Font font17 = null;
        stackedAreaRenderer0.setSeriesItemLabelFont((int) (byte) 0, font17);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font20 = null;
        stackedAreaRenderer19.setBaseItemLabelFont(font20, true);
        boolean boolean23 = stackedAreaRenderer19.getBaseCreateEntities();
        java.awt.Paint paint24 = stackedAreaRenderer19.getBaseFillPaint();
        stackedAreaRenderer0.setBaseOutlinePaint(paint24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = stackedAreaRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer27 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font28 = null;
        stackedAreaRenderer27.setBaseItemLabelFont(font28, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = null;
        stackedAreaRenderer27.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator32, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        stackedAreaRenderer27.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition36, false);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer27.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color40, true);
        java.awt.Font font44 = null;
        stackedAreaRenderer27.setSeriesItemLabelFont((int) (byte) 0, font44);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer46 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font47 = null;
        stackedAreaRenderer46.setBaseItemLabelFont(font47, true);
        boolean boolean50 = stackedAreaRenderer46.getBaseCreateEntities();
        java.awt.Paint paint51 = stackedAreaRenderer46.getBaseFillPaint();
        stackedAreaRenderer27.setBaseOutlinePaint(paint51);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = stackedAreaRenderer27.getLegendItems();
        legendItemCollection26.addAll(legendItemCollection53);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(legendItemCollection53);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        try {
            defaultKeyedValues2D1.removeRow((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            org.jfree.data.gantt.TaskSeries taskSeries2 = taskSeriesCollection0.getSeries(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.GENERAL");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            labelBlock1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle3.draw(graphics2D4, rectangle2D5);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle3.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = barRenderer3D0.initialise(graphics2D1, rectangle2D7, categoryPlot8, (int) (byte) -1, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        java.awt.Paint paint78 = stackedAreaRenderer48.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        int int80 = xYPlot79.getDomainAxisCount();
        java.util.List list81 = xYPlot79.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray88 = new org.jfree.chart.axis.ValueAxis[] { dateAxis82, dateAxis83, dateAxis84, dateAxis85, dateAxis86, dateAxis87 };
        xYPlot79.setDomainAxes(valueAxisArray88);
        stackedAreaRenderer48.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot79);
        org.jfree.chart.axis.AxisLocation axisLocation91 = null;
        try {
            xYPlot79.setRangeAxisLocation(axisLocation91, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(valueAxisArray88);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = ringPlot0.getURLGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator4);
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        int int25 = defaultCategoryDataset22.getColumnIndex((java.lang.Comparable) 100.0f);
        int int27 = defaultCategoryDataset22.getRowIndex((java.lang.Comparable) 4);
        boolean boolean28 = color19.equals((java.lang.Object) 4);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer6);
        stackedAreaRenderer6.setBaseCreateEntities(false);
        java.awt.Stroke stroke18 = stackedAreaRenderer6.lookupSeriesOutlineStroke((-1));
        categoryPlot0.setDomainGridlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            categoryPlot0.setRangeAxisLocation((int) (short) 0, axisLocation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        boolean boolean20 = ringPlot0.equals((java.lang.Object) (short) 10);
        ringPlot0.setNoDataMessage("CategoryLabelWidthType.RANGE");
        float float23 = ringPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.lang.String str1 = waferMapPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "WMAP_Plot" + "'", str1.equals("WMAP_Plot"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedAreaRenderer0.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        java.awt.Font font12 = stackedAreaRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = ringPlot1.getDataset();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis9.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle13.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = textTitle13.getPosition();
        textTitle13.setHeight((double) 1);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle13.draw(graphics2D18, rectangle2D19);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle13.setFont(font21);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle13.getBounds();
        dateAxis9.setLeftArrow((java.awt.Shape) rectangle2D23);
        org.jfree.chart.plot.PiePlot piePlot25 = null;
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState31 = ringPlot1.initialise(graphics2D8, rectangle2D23, piePlot25, (java.lang.Integer) 15, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font4 = null;
        stackedAreaRenderer3.setBaseItemLabelFont(font4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator8, false);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer3);
        stackedAreaRenderer3.setBaseCreateEntities(false);
        java.awt.Stroke stroke15 = stackedAreaRenderer3.lookupSeriesOutlineStroke((-1));
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font18 = null;
        stackedAreaRenderer17.setBaseItemLabelFont(font18, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        stackedAreaRenderer17.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator22, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        stackedAreaRenderer17.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer17.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color30, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedAreaRenderer17.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = null;
        stackedAreaRenderer17.setLegendItemURLGenerator(categorySeriesLabelGenerator36);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke42 = stackedAreaRenderer17.getItemStroke((int) 'a', 0);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) month0, paint2, stroke15, paint16, stroke42, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes((-1.0d), (double) 9, plotRenderingInfo4, point2D5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        try {
            java.lang.String str3 = dataPackageResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        java.awt.Paint paint2 = categoryPlot0.getOutlinePaint();
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 100, 100);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getYOffset();
        java.awt.Paint paint2 = barRenderer3D0.getWallPaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle6.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo13.getDataArea();
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D10, rectangle2D14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isDomainGridlinesVisible();
        java.awt.Paint paint18 = categoryPlot16.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        categoryPlot16.rendererChanged(rendererChangeEvent19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset24);
        try {
            barRenderer3D0.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D14, categoryPlot16, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis23, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset24, (int) (byte) 10, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        java.awt.Paint paint3 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = null;
        try {
            xYPlot0.setOrientation(plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setCopyright("");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis5.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle9.getPosition();
        textTitle9.setHeight((double) 1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle9.draw(graphics2D14, rectangle2D15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle9.setFont(font17);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle9.getBounds();
        dateAxis5.setLeftArrow((java.awt.Shape) rectangle2D19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle22.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle22.getPosition();
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge24);
        try {
            double double26 = dateAxis0.valueToJava2D((double) (short) 1, rectangle2D4, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Font font1 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isDomainGridlinesVisible();
        java.awt.Paint paint6 = categoryPlot4.getDomainGridlinePaint();
        multiplePiePlot3.setAggregatedItemsPaint(paint6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer10 = new org.jfree.chart.text.G2TextMeasurer(graphics2D9);
        try {
            org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelWidthType.RANGE", font1, paint6, (float) 2958465, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("Sep", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        long long5 = segmentedTimeline3.getSegmentsExcludedSize();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) 0, 60000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2958465 + "'", int4 == 2958465);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1322433855L) + "'", long5 == (-1322433855L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot0.setOutlinePaint(paint3);
        java.lang.Object obj5 = ringPlot0.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setWeight(0);
        java.awt.geom.Point2D point2D6 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'defaultGroup' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) lengthAdjustmentType2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis4.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis4.getTickUnit();
        try {
            java.lang.Number number9 = defaultKeyedValues2D1.getValue((java.lang.Comparable) dateTickUnit7, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = null;
        try {
            org.jfree.chart.util.Size2D size2D52 = blockContainer49.arrange(graphics2D50, rectangleConstraint51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        double double6 = rectangleInsets2.calculateLeftInset(100.0d);
        double double8 = rectangleInsets2.calculateRightInset((double) (-1.0f));
        double double10 = rectangleInsets2.calculateRightOutset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedAreaRenderer0.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font11 = null;
        stackedAreaRenderer10.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        stackedAreaRenderer10.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition19, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color23, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer10.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition(9, itemLabelPosition28);
        java.lang.Object obj30 = null;
        boolean boolean31 = itemLabelPosition28.equals(obj30);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        int int6 = xYPlot5.getDomainAxisCount();
        java.util.List list7 = xYPlot5.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { dateAxis8, dateAxis9, dateAxis10, dateAxis11, dateAxis12, dateAxis13 };
        xYPlot5.setDomainAxes(valueAxisArray14);
        xYPlot0.setDomainAxes(valueAxisArray14);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(valueAxisArray14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 2958465);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, (double) 1);
        boolean boolean4 = meanAndStandardDeviation2.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        size2D0.height = (short) 1;
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = null;
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = null;
        try {
            org.jfree.chart.util.Size2D size2D52 = flowArrangement48.arrange(blockContainer49, graphics2D50, rectangleConstraint51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double3 = defaultStatisticalCategoryDataset1.getRangeLowerBound(true);
        int int4 = defaultStatisticalCategoryDataset1.getRowCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer6 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset1, (java.lang.Comparable) month5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        categoryPlot0.setOutlineVisible(true);
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("({0}, {1}) = {2} version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:({0}, {1}) = {2} hi! ().\n({0}, {1}) = {2} LICENCE TERMS:\nCategoryLabelWidthType.RANGE");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        java.awt.Paint paint3 = ringPlot0.getBaseSectionOutlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        double double9 = rectangleInsets7.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        textTitle11.draw(graphics2D12, rectangle2D13);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle11.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo18.getDataArea();
        boolean boolean20 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D15, rectangle2D19);
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets7.createOutsetRectangle(rectangle2D15, false, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        double double27 = ringPlot24.getSectionDepth();
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        ringPlot30.setShadowYOffset((double) 100);
        java.awt.Font font33 = ringPlot30.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font33);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        java.lang.Object obj40 = textTitle34.draw(graphics2D35, rectangle2D36, (java.lang.Object) plotRenderingInfo39);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState41 = ringPlot0.initialise(graphics2D4, rectangle2D23, (org.jfree.chart.plot.PiePlot) ringPlot24, (java.lang.Integer) (-447), plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(obj40);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        boolean boolean5 = dateAxis0.isHiddenValue((long) 2958465);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        int int5 = defaultCategoryDataset2.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        java.util.List list7 = defaultCategoryDataset2.getColumnKeys();
        try {
            java.lang.Number number10 = defaultCategoryDataset2.getValue((java.lang.Comparable) "{0}", (java.lang.Comparable) 0L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font4 = null;
        stackedAreaRenderer3.setBaseItemLabelFont(font4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator8, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        stackedAreaRenderer3.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition12, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer3.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color16, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = stackedAreaRenderer3.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = null;
        stackedAreaRenderer3.setLegendItemURLGenerator(categorySeriesLabelGenerator22);
        stackedAreaRenderer3.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke28 = stackedAreaRenderer3.getItemStroke((int) 'a', 0);
        java.awt.Stroke stroke29 = stackedAreaRenderer3.getBaseStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot0.getRendererForDataset(xYDataset31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYItemRenderer32);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        java.awt.Stroke stroke3 = null;
        java.awt.Color color4 = java.awt.Color.gray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke3, (java.awt.Paint) color4, stroke5, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.setOutlineVisible(true);
        categoryPlot6.clearDomainMarkers((int) (byte) 100);
        java.awt.Paint paint12 = categoryPlot6.getNoDataMessagePaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis13.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle17.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle17.getPosition();
        textTitle17.setHeight((double) 1);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        textTitle17.draw(graphics2D22, rectangle2D23);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle17.setFont(font25);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle17.getBounds();
        dateAxis13.setLeftArrow((java.awt.Shape) rectangle2D27);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = textTitle30.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = textTitle30.getPosition();
        double double33 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D27, rectangleEdge32);
        try {
            barRenderer3D0.drawDomainGridline(graphics2D5, categoryPlot6, rectangle2D27, Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "ClassContext", (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean5 = stackedAreaRenderer0.isSeriesItemLabelsVisible(5);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        boolean boolean4 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font3 = null;
        stackedAreaRenderer2.setBaseItemLabelFont(font3, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedAreaRenderer2.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator7, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedAreaRenderer2.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition11, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer2.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color15, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedAreaRenderer2.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer2.setBasePaint((java.awt.Paint) color21, true);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        ringPlot25.setShadowYOffset((double) 100);
        java.awt.Font font28 = ringPlot25.getNoDataMessageFont();
        stackedAreaRenderer2.setSeriesItemLabelFont((int) '4', font28);
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot31.addChangeListener(plotChangeListener33);
        categoryPlot31.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot31.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = textTitle41.getMargin();
        double double44 = rectangleInsets42.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font28, paint30, rectangleEdge37, horizontalAlignment38, verticalAlignment39, rectangleInsets42);
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement49 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment38, verticalAlignment46, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer50 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = null;
        try {
            org.jfree.chart.util.Size2D size2D53 = borderArrangement0.arrange(blockContainer50, graphics2D51, rectangleConstraint52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment46);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        boolean boolean5 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        stackedAreaRenderer0.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image11, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.lang.String str17 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceName("");
        java.awt.Image image20 = null;
        projectInfo7.setLogo(image20);
        projectInfo7.setName("ClassContext");
        projectInfo7.setInfo("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke6 = lineBorder5.getStroke();
        xYPlot0.setRangeCrosshairStroke(stroke6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        java.awt.Paint paint79 = stackedAreaRenderer48.getItemOutlinePaint((int) (short) -1, 100);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint79);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getDataArea();
        org.jfree.data.resources.DataPackageResources dataPackageResources4 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean5 = plotRenderingInfo2.equals((java.lang.Object) dataPackageResources4);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = plotRenderingInfo2.getSubplotInfo((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            boolean boolean5 = xYPlot0.removeAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis2.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle6.getPosition();
        textTitle6.setHeight((double) 1);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle6.draw(graphics2D11, rectangle2D12);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle6.setFont(font14);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle6.getBounds();
        dateAxis2.setLeftArrow((java.awt.Shape) rectangle2D16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle19.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = textTitle19.getPosition();
        double double22 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D16, rectangleEdge21);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "WMAP_Plot");
        try {
            blockBorder0.draw(graphics2D1, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.lang.Comparable comparable2 = null;
        try {
            categoryAxis0.addCategoryLabelToolTip(comparable2, "WMAP_Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range6, (org.jfree.data.general.Dataset) taskSeriesCollection7);
        int int9 = taskSeriesCollection7.getColumnCount();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "February" + "'", str1.equals("February"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setIncludeBaseInRange(false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        stackedAreaRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font13 = null;
        stackedAreaRenderer12.setBaseItemLabelFont(font13, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        stackedAreaRenderer12.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator17, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        stackedAreaRenderer12.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition21, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color25, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedAreaRenderer12.getPositiveItemLabelPosition(0, (int) (short) 10);
        try {
            stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (short) -1, itemLabelPosition30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        java.lang.String str45 = rectangleEdge36.toString();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "RectangleEdge.LEFT" + "'", str45.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) -1, (double) 'a');
        size2D2.width = '4';
        size2D2.height = (short) 1;
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot2.addChangeListener(plotChangeListener4);
        java.awt.Paint paint6 = categoryPlot2.getRangeCrosshairPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font1, paint6);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        java.awt.Paint paint9 = legendTitle8.getItemPaint();
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer6);
        stackedAreaRenderer6.setBaseCreateEntities(false);
        java.awt.Stroke stroke18 = stackedAreaRenderer6.lookupSeriesOutlineStroke((-1));
        categoryPlot0.setDomainGridlineStroke(stroke18);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        stackedAreaRenderer0.setBaseCreateEntities(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis14.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle18.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle18.getPosition();
        textTitle18.setHeight((double) 1);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        textTitle18.draw(graphics2D23, rectangle2D24);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle18.setFont(font26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle18.getBounds();
        dateAxis14.setLeftArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape33, "ClassContext", "");
        java.awt.Shape shape37 = chartEntity36.getArea();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle39.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = textTitle39.getPosition();
        textTitle39.setHeight((double) 1);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        textTitle39.draw(graphics2D44, rectangle2D45);
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle39.setFont(font47);
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle39.getBounds();
        chartEntity36.setArea((java.awt.Shape) rectangle2D49);
        stackedAreaRenderer0.drawRangeMarker(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis14, marker30, rectangle2D49);
        java.awt.Paint paint53 = stackedAreaRenderer0.lookupSeriesOutlinePaint(1);
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            xYPlot0.addRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(layer10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        java.awt.Paint paint4 = null;
        try {
            dateAxis0.setLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        ringPlot6.setShadowYOffset((double) 100);
        ringPlot6.setCircular(false);
        ringPlot6.setLabelLinkMargin((double) (byte) 0);
        java.awt.Stroke stroke13 = ringPlot6.getLabelLinkStroke();
        barRenderer3D0.setSeriesOutlineStroke((int) '4', stroke13, true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray6 = new float[] { (byte) -1, (-1.0f), 10, (short) 10 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = rangeType0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("{0}", (int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor((double) 100);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray6 = new float[] { (byte) -1, (-1.0f), 10, (short) 10 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = verticalAlignment0.equals((java.lang.Object) floatArray6);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font13 = null;
        stackedAreaRenderer12.setBaseItemLabelFont(font13, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        stackedAreaRenderer12.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator17, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        stackedAreaRenderer12.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition21, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color25, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedAreaRenderer12.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setBasePaint((java.awt.Paint) color31, true);
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        ringPlot35.setShadowYOffset((double) 100);
        java.awt.Font font38 = ringPlot35.getNoDataMessageFont();
        stackedAreaRenderer12.setSeriesItemLabelFont((int) '4', font38);
        java.awt.Paint paint40 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean42 = categoryPlot41.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot41.addChangeListener(plotChangeListener43);
        categoryPlot41.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot41.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = textTitle51.getMargin();
        double double54 = rectangleInsets52.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font38, paint40, rectangleEdge47, horizontalAlignment48, verticalAlignment49, rectangleInsets52);
        legendTitle8.setLegendItemGraphicPadding(rectangleInsets52);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = null;
        try {
            legendTitle8.setItemLabelPadding(rectangleInsets57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font13 = null;
        stackedAreaRenderer12.setBaseItemLabelFont(font13, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        stackedAreaRenderer12.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator17, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        stackedAreaRenderer12.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition21, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color25, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedAreaRenderer12.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setBasePaint((java.awt.Paint) color31, true);
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        ringPlot35.setShadowYOffset((double) 100);
        java.awt.Font font38 = ringPlot35.getNoDataMessageFont();
        stackedAreaRenderer12.setSeriesItemLabelFont((int) '4', font38);
        java.awt.Paint paint40 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean42 = categoryPlot41.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot41.addChangeListener(plotChangeListener43);
        categoryPlot41.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot41.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = textTitle51.getMargin();
        double double54 = rectangleInsets52.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font38, paint40, rectangleEdge47, horizontalAlignment48, verticalAlignment49, rectangleInsets52);
        legendTitle8.setLegendItemGraphicPadding(rectangleInsets52);
        java.awt.Font font57 = legendTitle8.getItemFont();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(font57);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("({0}, {1}) = {3} - {4}", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 6, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = ringPlot1.getDataset();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.awt.Paint paint10 = ringPlot1.getSectionOutlinePaint((java.lang.Comparable) long9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Paint paint19 = stackedAreaRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint20 = stackedAreaRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        try {
            java.lang.Number number7 = taskSeriesCollection2.getEndValue((int) (byte) -1, 5, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            chartRenderingInfo0.setChartArea(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range6, (org.jfree.data.general.Dataset) taskSeriesCollection7);
        try {
            java.lang.Number number12 = taskSeriesCollection7.getPercentComplete(0, 6, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setShadowYOffset((double) 100);
        boolean boolean5 = month0.equals((java.lang.Object) ringPlot2);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        stackedAreaRenderer7.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition16, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer7.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color20, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = stackedAreaRenderer7.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer7.setBasePaint((java.awt.Paint) color26, true);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        ringPlot30.setShadowYOffset((double) 100);
        java.awt.Font font33 = ringPlot30.getNoDataMessageFont();
        stackedAreaRenderer7.setSeriesItemLabelFont((int) '4', font33);
        java.awt.Paint paint35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot36.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = textTitle46.getMargin();
        double double49 = rectangleInsets47.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font33, paint35, rectangleEdge42, horizontalAlignment43, verticalAlignment44, rectangleInsets47);
        ringPlot2.setNoDataMessageFont(font33);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setDrawBarOutline(true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            boolean boolean7 = xYPlot0.removeAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getLabelLinkPaint();
        numberAxis1.setTickMarkPaint(paint9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange11, false, true);
        boolean boolean15 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        java.lang.String str3 = textTitle1.getURLText();
        double double4 = textTitle1.getContentYOffset();
        java.lang.String str5 = textTitle1.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle1.getPadding();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        taskSeriesCollection0.removeAll();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 2, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis1.setNumberFormatOverride(numberFormat4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.data.RangeType rangeType7 = numberAxis1.getRangeType();
        java.lang.String str8 = rangeType7.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RangeType.FULL" + "'", str8.equals("RangeType.FULL"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) (-1L));
        try {
            defaultCategoryDataset0.removeColumn((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        taskSeriesCollection0.removeAll();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        java.text.DateFormat dateFormat5 = dateAxis3.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis6.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis6.getTickUnit();
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        int int11 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) date10);
        org.jfree.data.KeyToGroupMap keyToGroupMap12 = null;
        try {
            org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, keyToGroupMap12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        dateAxis0.setFixedDimension(90.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        int int11 = segmentedTimeline10.getSegmentsExcluded();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot12.addChangeListener(plotChangeListener14);
        categoryPlot12.clearRangeMarkers((int) ' ');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        categoryPlot12.datasetChanged(datasetChangeEvent18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean21 = categoryPlot20.isOutlineVisible();
        java.awt.Paint paint22 = categoryPlot20.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getColumnRenderingOrder();
        categoryPlot12.setColumnRenderingOrder(sortOrder23);
        boolean boolean25 = segmentedTimeline10.equals((java.lang.Object) categoryPlot12);
        boolean boolean26 = barRenderer3D0.hasListener((java.util.EventListener) categoryPlot12);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        textTitle29.draw(graphics2D30, rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle29.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo(entityCollection34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        java.awt.geom.Rectangle2D rectangle2D37 = plotRenderingInfo36.getDataArea();
        boolean boolean38 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D33, rectangle2D37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean40 = categoryPlot39.isOutlineVisible();
        categoryPlot39.setOutlineVisible(true);
        categoryPlot39.clearDomainMarkers((int) (byte) 100);
        org.jfree.chart.entity.EntityCollection entityCollection46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo(entityCollection46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo47);
        java.awt.geom.Rectangle2D rectangle2D49 = plotRenderingInfo48.getDataArea();
        org.jfree.data.resources.DataPackageResources dataPackageResources50 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean51 = plotRenderingInfo48.equals((java.lang.Object) dataPackageResources50);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState52 = barRenderer3D0.initialise(graphics2D27, rectangle2D33, categoryPlot39, (int) (short) 100, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2958465 + "'", int11 == 2958465);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Number number3 = defaultKeyedValues2D0.getValue(2958465, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle9.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType12 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str13 = categoryLabelWidthType12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor10, textBlockAnchor11, categoryLabelWidthType12, (float) 100L);
        org.jfree.chart.text.TextAnchor textAnchor16 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType18 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor11, textAnchor16, (double) (short) -1, categoryLabelWidthType18, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelWidthType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str13.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType18);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100.0f);
        int int5 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 4);
        java.lang.Comparable comparable7 = null;
        try {
            defaultCategoryDataset0.setValue((double) (short) 100, comparable7, (java.lang.Comparable) Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        java.awt.Paint paint2 = categoryPlot0.getOutlinePaint();
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 100, 100);
        int int6 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        ringPlot23.setShadowYOffset((double) 100);
        java.awt.Font font26 = ringPlot23.getNoDataMessageFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font26);
        stackedAreaRenderer0.setItemLabelAnchorOffset(1.0d);
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        chartRenderingInfo32.clear();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis34.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = textTitle38.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = textTitle38.getPosition();
        textTitle38.setHeight((double) 1);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        textTitle38.draw(graphics2D43, rectangle2D44);
        java.awt.Font font46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle38.setFont(font46);
        java.awt.geom.Rectangle2D rectangle2D48 = textTitle38.getBounds();
        dateAxis34.setLeftArrow((java.awt.Shape) rectangle2D48);
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D48);
        chartRenderingInfo32.setChartArea(rectangle2D48);
        stackedAreaRenderer0.setSeriesShape(1, (java.awt.Shape) rectangle2D48, false);
        double double54 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        long long5 = segmentedTimeline3.getSegmentsExcludedSize();
        long long6 = segmentedTimeline3.getSegmentsGroupSize();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2958465 + "'", int4 == 2958465);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1322433855L) + "'", long5 == (-1322433855L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1322434302L) + "'", long6 == (-1322434302L));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        textTitle1.setHeight((double) 1);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle1.draw(graphics2D6, rectangle2D7);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font13 = null;
        stackedAreaRenderer12.setBaseItemLabelFont(font13, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        stackedAreaRenderer12.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator17, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        stackedAreaRenderer12.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition21, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color25, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedAreaRenderer12.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer12.setBasePaint((java.awt.Paint) color31, true);
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        ringPlot35.setShadowYOffset((double) 100);
        java.awt.Font font38 = ringPlot35.getNoDataMessageFont();
        stackedAreaRenderer12.setSeriesItemLabelFont((int) '4', font38);
        java.awt.Paint paint40 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean42 = categoryPlot41.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot41.addChangeListener(plotChangeListener43);
        categoryPlot41.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot41.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = textTitle51.getMargin();
        double double54 = rectangleInsets52.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font38, paint40, rectangleEdge47, horizontalAlignment48, verticalAlignment49, rectangleInsets52);
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement59 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment48, verticalAlignment56, (double) (byte) 1, (double) 10.0f);
        textTitle1.setVerticalAlignment(verticalAlignment56);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment56);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) (short) 100);
        double double5 = rectangleInsets2.getBottom();
        double double6 = rectangleInsets2.getLeft();
        double double7 = rectangleInsets2.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str7 = categoryLabelWidthType6.toString();
        boolean boolean8 = lineBorder5.equals((java.lang.Object) str7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis10.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle14.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = textTitle14.getPosition();
        textTitle14.setHeight((double) 1);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle14.draw(graphics2D19, rectangle2D20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle14.setFont(font22);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle14.getBounds();
        dateAxis10.setLeftArrow((java.awt.Shape) rectangle2D24);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D24);
        lineBorder5.draw(graphics2D9, rectangle2D24);
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.plot.PlotState plotState29 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.entity.EntityCollection entityCollection30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo(entityCollection30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = chartRenderingInfo31.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = plotRenderingInfo32.getOwner();
        try {
            ringPlot0.draw(graphics2D4, rectangle2D24, point2D28, plotState29, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelWidthType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str7.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(plotRenderingInfo32);
        org.junit.Assert.assertNotNull(chartRenderingInfo33);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getBackgroundPaint();
        int int5 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("RangeType.FULL");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        ringPlot23.setShadowYOffset((double) 100);
        java.awt.Font font26 = ringPlot23.getNoDataMessageFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font26);
        stackedAreaRenderer0.setAutoPopulateSeriesPaint(true);
        boolean boolean30 = stackedAreaRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.GENERAL");
        labelBlock1.setToolTipText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis5.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle9.getPosition();
        textTitle9.setHeight((double) 1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle9.draw(graphics2D14, rectangle2D15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle9.setFont(font17);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle9.getBounds();
        dateAxis5.setLeftArrow((java.awt.Shape) rectangle2D19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle22.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle22.getPosition();
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge24);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D26 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double27 = barRenderer3D26.getYOffset();
        try {
            java.lang.Object obj28 = labelBlock1.draw(graphics2D4, rectangle2D19, (java.lang.Object) double27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 8.0d + "'", double27 == 8.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        java.awt.Paint paint78 = stackedAreaRenderer48.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        int int80 = xYPlot79.getDomainAxisCount();
        java.util.List list81 = xYPlot79.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray88 = new org.jfree.chart.axis.ValueAxis[] { dateAxis82, dateAxis83, dateAxis84, dateAxis85, dateAxis86, dateAxis87 };
        xYPlot79.setDomainAxes(valueAxisArray88);
        stackedAreaRenderer48.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot79);
        java.awt.Stroke stroke91 = xYPlot79.getRangeGridlineStroke();
        xYPlot79.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(valueAxisArray88);
        org.junit.Assert.assertNotNull(stroke91);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis20.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle24.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = textTitle24.getPosition();
        textTitle24.setHeight((double) 1);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle24.draw(graphics2D29, rectangle2D30);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle24.setFont(font32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle24.getBounds();
        dateAxis20.setLeftArrow((java.awt.Shape) rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer42);
        stackedAreaRenderer42.setBaseCreateEntities(false);
        java.awt.Stroke stroke54 = stackedAreaRenderer42.lookupSeriesOutlineStroke((-1));
        categoryPlot36.setDomainGridlineStroke(stroke54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean58 = categoryPlot57.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.renderer.RendererState rendererState64 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo63);
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot57.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo63, point2D65);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState67 = stackedAreaRenderer0.initialise(graphics2D19, rectangle2D34, categoryPlot36, 3, plotRenderingInfo63);
        java.lang.Boolean boolean69 = stackedAreaRenderer0.getSeriesVisible(9);
        boolean boolean70 = stackedAreaRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Stroke stroke71 = null;
        try {
            stackedAreaRenderer0.setBaseOutlineStroke(stroke71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererState67);
        org.junit.Assert.assertNull(boolean69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        double double6 = rectangleInsets2.calculateLeftInset(100.0d);
        double double8 = rectangleInsets2.calculateRightInset((double) (-1.0f));
        java.lang.String str9 = rectangleInsets2.toString();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getMargin();
        double double14 = rectangleInsets12.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle16.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo(entityCollection21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo23.getDataArea();
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D20, rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets12.createOutsetRectangle(rectangle2D20, false, true);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        int int30 = xYPlot29.getDomainAxisCount();
        java.util.List list31 = xYPlot29.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D9, rectangle2D28, list31);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D28, "Size2D[width=0.0, height=0.0]", "({0}, {1}) = {3} - {4}");
        chartEntity35.setURLText("ThreadContext");
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        boolean boolean5 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        stackedAreaRenderer0.setSeriesCreateEntities(3, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset50.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean55 = flowArrangement48.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D57 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int58 = defaultKeyedValues2D57.getColumnCount();
        boolean boolean59 = flowArrangement48.equals((java.lang.Object) defaultKeyedValues2D57);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
        org.jfree.data.time.Year year62 = month60.getYear();
        defaultKeyedValues2D57.removeColumn((java.lang.Comparable) month60);
        java.util.Calendar calendar64 = null;
        try {
            long long65 = month60.getLastMillisecond(calendar64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(year62);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        taskSeriesCollection0.removeAll();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete((int) (short) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Comparable comparable0 = null;
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject(comparable0, obj1);
        java.lang.Object obj3 = keyedObject2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis20.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle24.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = textTitle24.getPosition();
        textTitle24.setHeight((double) 1);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle24.draw(graphics2D29, rectangle2D30);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle24.setFont(font32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle24.getBounds();
        dateAxis20.setLeftArrow((java.awt.Shape) rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer42);
        stackedAreaRenderer42.setBaseCreateEntities(false);
        java.awt.Stroke stroke54 = stackedAreaRenderer42.lookupSeriesOutlineStroke((-1));
        categoryPlot36.setDomainGridlineStroke(stroke54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean58 = categoryPlot57.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.renderer.RendererState rendererState64 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo63);
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot57.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo63, point2D65);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState67 = stackedAreaRenderer0.initialise(graphics2D19, rectangle2D34, categoryPlot36, 3, plotRenderingInfo63);
        java.lang.Boolean boolean69 = stackedAreaRenderer0.getSeriesVisible(9);
        java.awt.Stroke stroke71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            stackedAreaRenderer0.setSeriesOutlineStroke((-1), stroke71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererState67);
        org.junit.Assert.assertNull(boolean69);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin(0.05d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getYOffset();
        java.awt.Paint paint2 = barRenderer3D0.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        boolean boolean7 = numberAxis4.getAutoRangeIncludesZero();
        numberAxis4.setTickMarkInsideLength(0.0f);
        boolean boolean10 = barRenderer3D0.equals((java.lang.Object) numberAxis4);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        ringPlot13.setShadowYOffset((double) 100);
        java.awt.Font font16 = ringPlot13.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font16);
        try {
            barRenderer3D0.setSeriesItemLabelFont((-1), font16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.height;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "ClassContext", "");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle12.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle12.getPosition();
        textTitle12.setHeight((double) 1);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle12.draw(graphics2D17, rectangle2D18);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle12.setFont(font20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle12.getBounds();
        chartEntity9.setArea((java.awt.Shape) rectangle2D22);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem(attributedString0, "", "RectangleEdge.LEFT", "", (java.awt.Shape) rectangle2D22, paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            lineBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(2, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        java.awt.Font font17 = null;
        stackedAreaRenderer0.setSeriesItemLabelFont((int) (byte) 0, font17);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font20 = null;
        stackedAreaRenderer19.setBaseItemLabelFont(font20, true);
        boolean boolean23 = stackedAreaRenderer19.getBaseCreateEntities();
        java.awt.Paint paint24 = stackedAreaRenderer19.getBaseFillPaint();
        stackedAreaRenderer0.setBaseOutlinePaint(paint24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = stackedAreaRenderer0.getLegendItems();
        int int27 = stackedAreaRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            xYPlot0.addDomainMarker(15, marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(layer8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        textTitle1.setHeight((double) 1);
        textTitle1.setWidth((double) (byte) 0);
        boolean boolean8 = textTitle1.getNotify();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle1.getTextAlignment();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = textTitle11.getPosition();
        textTitle11.setHeight((double) 1);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        textTitle11.draw(graphics2D16, rectangle2D17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle11.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement22 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment19, (double) (byte) 100, (double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) (byte) 10);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) (-1));
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        java.text.DateFormat dateFormat7 = dateAxis5.getDateFormatOverride();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis9.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        java.awt.Stroke stroke13 = dateAxis9.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis9.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline17);
        dateAxis5.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline17);
        try {
            segmentedTimeline0.setBaseTimeline(segmentedTimeline17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: baseTimeline.getSegmentSize() is smaller than segmentSize");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.GENERAL");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle4.getMargin();
        double double7 = rectangleInsets5.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        textTitle9.draw(graphics2D10, rectangle2D11);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle9.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getDataArea();
        boolean boolean18 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D13, rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets5.createOutsetRectangle(rectangle2D13, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D21);
        java.lang.Object obj23 = null;
        try {
            java.lang.Object obj24 = labelBlock1.draw(graphics2D2, rectangle2D21, obj23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Shape shape23 = stackedAreaRenderer0.getItemShape((int) (byte) 1, 100);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getLabelLinkPaint();
        stackedAreaRenderer0.setBaseFillPaint(paint9, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font14 = null;
        stackedAreaRenderer13.setBaseItemLabelFont(font14, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        stackedAreaRenderer13.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator18, false);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer13);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font24 = null;
        stackedAreaRenderer23.setBaseItemLabelFont(font24, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = null;
        stackedAreaRenderer23.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator28, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        stackedAreaRenderer23.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition32, false);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer23.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color36, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = stackedAreaRenderer23.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer13.setSeriesNegativeItemLabelPosition(9, itemLabelPosition41);
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition41, true);
        java.lang.Object obj45 = null;
        boolean boolean46 = stackedAreaRenderer0.equals(obj45);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(itemLabelPosition41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getDataArea();
        org.jfree.data.resources.DataPackageResources dataPackageResources4 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean5 = plotRenderingInfo2.equals((java.lang.Object) dataPackageResources4);
        java.util.Enumeration<java.lang.String> strEnumeration6 = dataPackageResources4.getKeys();
        java.util.Set<java.lang.String> strSet7 = dataPackageResources4.keySet();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strEnumeration6);
        org.junit.Assert.assertNotNull(strSet7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        stackedAreaRenderer48.setSeriesItemLabelsVisible(0, true);
        java.awt.Paint paint77 = stackedAreaRenderer48.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("Size2D[width=0.0, height=0.0]", font1, paint2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType18 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str19 = categoryLabelWidthType18.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor16, textBlockAnchor17, categoryLabelWidthType18, (float) 100L);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font23 = null;
        stackedAreaRenderer22.setBaseItemLabelFont(font23, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        stackedAreaRenderer22.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator27, false);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle30.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType33 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str34 = categoryLabelWidthType33.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition36 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor31, textBlockAnchor32, categoryLabelWidthType33, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType37 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str38 = categoryLabelWidthType37.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition40 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor16, textBlockAnchor32, categoryLabelWidthType37, 0.0f);
        try {
            java.awt.Shape shape44 = textBlock3.calculateBounds(graphics2D4, (float) (short) 10, 1.0f, textBlockAnchor32, (float) 3600000L, (float) 60000L, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(categoryLabelWidthType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str19.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(categoryLabelWidthType33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str34.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str38.equals("CategoryLabelWidthType.RANGE"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        textTitle1.setHeight((double) 1);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle1.draw(graphics2D6, rectangle2D7);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font9);
        textTitle1.setPadding(12.0d, (double) 2958465, 90.0d, (double) 2);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        ringPlot16.setShadowYOffset((double) 100);
        java.awt.Font font19 = ringPlot16.getNoDataMessageFont();
        textTitle1.setFont(font19);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.lang.Object obj2 = defaultCategoryDataset0.clone();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) "ChartChangeEventType.GENERAL");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = null;
        try {
            minMaxCategoryRenderer0.setObjectIcon(icon1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Sep");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 1);
        java.awt.Paint paint5 = ringPlot1.getShadowPaint();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        stackedAreaRenderer0.setBaseCreateEntities(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis14.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle18.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle18.getPosition();
        textTitle18.setHeight((double) 1);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        textTitle18.draw(graphics2D23, rectangle2D24);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle18.setFont(font26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle18.getBounds();
        dateAxis14.setLeftArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape33, "ClassContext", "");
        java.awt.Shape shape37 = chartEntity36.getArea();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle39.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = textTitle39.getPosition();
        textTitle39.setHeight((double) 1);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        textTitle39.draw(graphics2D44, rectangle2D45);
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle39.setFont(font47);
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle39.getBounds();
        chartEntity36.setArea((java.awt.Shape) rectangle2D49);
        stackedAreaRenderer0.drawRangeMarker(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis14, marker30, rectangle2D49);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer52 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font53 = null;
        stackedAreaRenderer52.setBaseItemLabelFont(font53, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator57 = null;
        stackedAreaRenderer52.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator57, false);
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer52);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition63 = stackedAreaRenderer52.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        stackedAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition63);
        java.awt.Paint paint67 = stackedAreaRenderer0.getItemFillPaint(10, 100);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(itemLabelPosition63);
        org.junit.Assert.assertNotNull(paint67);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        stackedAreaRenderer48.setSeriesItemLabelsVisible(0, true);
        stackedAreaRenderer48.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setBase(8.0d);
        double double7 = barRenderer3D0.getYOffset();
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setMinimumBarLength((double) 9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.data.UnknownKeyException unknownKeyException2 = new org.jfree.data.UnknownKeyException("hi!");
        boolean boolean3 = categoryLabelPositions0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) (-1L));
        java.util.List list7 = defaultCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot8.addChangeListener(plotChangeListener10);
        categoryPlot8.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font15 = null;
        stackedAreaRenderer14.setBaseItemLabelFont(font15, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedAreaRenderer14.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator19, false);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer14);
        stackedAreaRenderer14.setBaseCreateEntities(false);
        java.awt.Stroke stroke26 = stackedAreaRenderer14.lookupSeriesOutlineStroke((-1));
        categoryPlot8.setDomainGridlineStroke(stroke26);
        categoryPlot8.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean32 = numberAxis30.hasListener((java.util.EventListener) taskSeriesCollection31);
        boolean boolean33 = numberAxis30.getAutoRangeIncludesZero();
        numberAxis30.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot(pieDataset36);
        java.awt.Paint paint38 = ringPlot37.getLabelLinkPaint();
        numberAxis30.setTickMarkPaint(paint38);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        numberAxis30.setRangeWithMargins((org.jfree.data.Range) dateRange40, false, true);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle45.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = textTitle45.getPosition();
        textTitle45.setHeight((double) 1);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        textTitle45.draw(graphics2D50, rectangle2D51);
        java.awt.Font font53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle45.setFont(font53);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle45.getBounds();
        barRenderer3D0.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis30, rectangle2D55, (double) 100L);
        java.awt.Paint paint58 = null;
        try {
            barRenderer3D0.setWallPaint(paint58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        double double3 = ringPlot0.getOuterSeparatorExtension();
        double double5 = ringPlot0.getExplodePercent((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint6 = ringPlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) 1.0f);
        try {
            int int5 = taskSeriesCollection0.getSubIntervalCount((java.lang.Comparable) 1, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        java.awt.Paint paint3 = ringPlot0.getBaseSectionOutlinePaint();
        ringPlot0.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setShadowYOffset((double) 100);
        boolean boolean5 = month0.equals((java.lang.Object) ringPlot2);
        ringPlot2.setIgnoreNullValues(true);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = ringPlot2.getLegendItems();
        ringPlot2.setStartAngle((double) (byte) 10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        java.util.Map map2 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
        org.junit.Assert.assertNotNull(map2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(90.0d, (double) 15);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            xYPlot0.addDomainMarker(marker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(layer5);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
//        ringPlot2.setShadowYOffset((double) 100);
//        boolean boolean5 = month0.equals((java.lang.Object) ringPlot2);
//        long long6 = month0.getLastMillisecond();
//        long long7 = month0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis0.setTickLabelFont(font1);
        float float3 = dateAxis0.getTickMarkInsideLength();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        textTitle1.setMargin((double) (byte) 1, 0.0d, 0.0d, (double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setSeriesVisible(0, (java.lang.Boolean) true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        java.awt.Paint paint4 = dateAxis0.getTickMarkPaint();
        java.awt.Paint paint5 = dateAxis0.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot3D0.setURLGenerator(pieURLGenerator1);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = null;
        try {
            piePlot3D0.setLabelDistributor(abstractPieLabelDistributor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        int int5 = defaultCategoryDataset2.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        java.util.List list7 = defaultCategoryDataset2.getColumnKeys();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.chart.util.TableOrder tableOrder9 = null;
        try {
            multiplePiePlot8.setDataExtractOrder(tableOrder9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SortOrder.ASCENDING", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (15) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        textTitle2.setHeight((double) 1);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle2.draw(graphics2D7, rectangle2D8);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle2.setFont(font10);
        java.awt.Paint paint12 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean16 = categoryPlot15.isDomainGridlinesVisible();
        java.awt.Paint paint17 = categoryPlot15.getDomainGridlinePaint();
        categoryPlot13.setOutlinePaint(paint17);
        categoryPlot13.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        categoryPlot13.handleClick(9, (int) (short) 100, plotRenderingInfo24);
        java.awt.Stroke stroke26 = categoryPlot13.getRangeCrosshairStroke();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = textTitle28.getMargin();
        double double31 = rectangleInsets29.calculateLeftOutset((double) 10.0f);
        double double33 = rectangleInsets29.calculateLeftInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder34 = new org.jfree.chart.block.LineBorder(paint12, stroke26, rectangleInsets29);
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("Sep", font10, paint12, (float) 32L, (int) ' ', textMeasurer37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = blockBorder0.equals((java.lang.Object) month1);
        java.awt.Paint paint4 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart9.getXYPlot();
        jFreeChart9.fireChartChanged();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font14 = null;
        stackedAreaRenderer13.setBaseItemLabelFont(font14, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        stackedAreaRenderer13.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator18, false);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle21.setLegendItemGraphicAnchor(rectangleAnchor22);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        stackedAreaRenderer25.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color38, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = stackedAreaRenderer25.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setBasePaint((java.awt.Paint) color44, true);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        ringPlot48.setShadowYOffset((double) 100);
        java.awt.Font font51 = ringPlot48.getNoDataMessageFont();
        stackedAreaRenderer25.setSeriesItemLabelFont((int) '4', font51);
        java.awt.Paint paint53 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean55 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener56 = null;
        categoryPlot54.addChangeListener(plotChangeListener56);
        categoryPlot54.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot54.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment61 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = textTitle64.getMargin();
        double double67 = rectangleInsets65.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font51, paint53, rectangleEdge60, horizontalAlignment61, verticalAlignment62, rectangleInsets65);
        legendTitle21.setLegendItemGraphicPadding(rectangleInsets65);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle21);
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = legendTitle21.getItemLabelPadding();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot11);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(horizontalAlignment61);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets71);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Image image14 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(image14);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft(Double.NaN);
        axisSpace0.setRight(0.0d);
        axisSpace0.setBottom((double) 3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 0, 15, dateFormat2);
        int int4 = dateTickUnit3.getCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke26 = stackedAreaRenderer0.getItemStroke(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = stackedAreaRenderer0.getSeriesItemLabelGenerator((-1));
        stackedAreaRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true);
        stackedAreaRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        textTitle1.setHeight((double) 1);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle1.draw(graphics2D6, rectangle2D7);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle1.getBounds();
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape((java.awt.Shape) rectangle2D11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setShadowYOffset((double) 100);
        java.awt.Font font4 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.text.TextFragment textFragment6 = null;
        textLine5.addFragment(textFragment6);
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textLine5.calculateDimensions(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        java.lang.Comparable comparable5 = null;
        try {
            java.lang.Number number6 = taskSeriesCollection2.getValue((java.lang.Comparable) Double.NaN, comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot0.getRenderer(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        boolean boolean2 = rangeType0.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { dateAxis3, dateAxis4, dateAxis5, dateAxis6, dateAxis7, dateAxis8 };
        xYPlot0.setDomainAxes(valueAxisArray9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1.0.6");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis20.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle24.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = textTitle24.getPosition();
        textTitle24.setHeight((double) 1);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle24.draw(graphics2D29, rectangle2D30);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle24.setFont(font32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle24.getBounds();
        dateAxis20.setLeftArrow((java.awt.Shape) rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer42);
        stackedAreaRenderer42.setBaseCreateEntities(false);
        java.awt.Stroke stroke54 = stackedAreaRenderer42.lookupSeriesOutlineStroke((-1));
        categoryPlot36.setDomainGridlineStroke(stroke54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean58 = categoryPlot57.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.renderer.RendererState rendererState64 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo63);
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot57.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo63, point2D65);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState67 = stackedAreaRenderer0.initialise(graphics2D19, rectangle2D34, categoryPlot36, 3, plotRenderingInfo63);
        boolean boolean68 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererState67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean3 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) standardCategorySeriesLabelGenerator2);
        java.lang.Object obj4 = standardCategorySeriesLabelGenerator2.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RangeType.FULL", graphics2D1, (float) (byte) 0, 0.0f, textAnchor4, (double) (byte) -1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.String str3 = intervalCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke25 = stackedAreaRenderer0.getItemStroke((int) 'a', 0);
        java.awt.Stroke stroke26 = stackedAreaRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = stackedAreaRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis28.setTickLabelFont(font29);
        stackedAreaRenderer0.setBaseItemLabelFont(font29, false);
        boolean boolean33 = stackedAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            java.lang.Comparable comparable3 = defaultCategoryDataset0.getColumnKey(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        segmentedTimeline3.setStartTime((long) 'a');
        try {
            boolean boolean8 = segmentedTimeline3.containsDomainRange(1561964399999L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (0) < domainValueStart (1561964399999)");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(categoryItemRenderer2, true);
        try {
            categoryPlot0.zoom((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("SerialDate.weekInMonthToString(): invalid code.", "({0}, {1}) = {2}", "", "hi!", "CategoryLabelWidthType.RANGE");
        boolean boolean8 = categoryLabelPositions1.equals((java.lang.Object) "");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font10 = null;
        stackedAreaRenderer9.setBaseItemLabelFont(font10, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator14, false);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle17.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType20 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str21 = categoryLabelWidthType20.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor18, textBlockAnchor19, categoryLabelWidthType20, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions25 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean27 = categoryPlot26.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot26.addChangeListener(plotChangeListener28);
        categoryPlot26.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot26.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = categoryLabelPositions25.getLabelPosition(rectangleEdge32);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font35 = null;
        stackedAreaRenderer34.setBaseItemLabelFont(font35, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer34.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator39, false);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = legendTitle42.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType45 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str46 = categoryLabelWidthType45.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition48 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor43, textBlockAnchor44, categoryLabelWidthType45, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType49 = categoryLabelPosition48.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer51 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font52 = null;
        stackedAreaRenderer51.setBaseItemLabelFont(font52, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator56 = null;
        stackedAreaRenderer51.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator56, false);
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer51);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = legendTitle59.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor61 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType62 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str63 = categoryLabelWidthType62.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition65 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor60, textBlockAnchor61, categoryLabelWidthType62, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType66 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str67 = categoryLabelWidthType66.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition69 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor50, textBlockAnchor61, categoryLabelWidthType66, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions70 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition23, categoryLabelPosition33, categoryLabelPosition48, categoryLabelPosition69);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions71 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition23);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(categoryLabelWidthType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str21.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(categoryLabelPosition33);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(categoryLabelWidthType45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str46.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType49);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(textBlockAnchor61);
        org.junit.Assert.assertNotNull(categoryLabelWidthType62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str63.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str67.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions71);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = null;
        stackedAreaRenderer1.setLegendItemURLGenerator(categorySeriesLabelGenerator20);
        java.awt.Stroke stroke24 = stackedAreaRenderer1.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke27 = stackedAreaRenderer1.getItemStroke(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = stackedAreaRenderer1.getSeriesItemLabelGenerator((-1));
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot(pieDataset31);
        java.awt.Paint paint34 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot32.setSectionPaint((java.lang.Comparable) 1.0f, paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot32.setLabelLinkPaint((java.awt.Paint) color36);
        stackedAreaRenderer1.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color36, false);
        boolean boolean40 = itemLabelAnchor0.equals((java.lang.Object) color36);
        int int41 = color36.getAlpha();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 255 + "'", int41 == 255);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        stackedAreaRenderer0.setBaseCreateEntities(false);
        java.awt.Stroke stroke12 = stackedAreaRenderer0.lookupSeriesOutlineStroke((-1));
        stackedAreaRenderer0.setRenderAsPercentages(true);
        java.lang.Boolean boolean16 = stackedAreaRenderer0.getSeriesVisibleInLegend(2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range6, (org.jfree.data.general.Dataset) taskSeriesCollection7);
        try {
            java.lang.Number number11 = taskSeriesCollection7.getEndValue((int) '#', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("({0}, {1}) = {2} version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:({0}, {1}) = {2} hi! ().\n({0}, {1}) = {2} LICENCE TERMS:\nCategoryLabelWidthType.RANGE", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) lengthAdjustmentType2);
        try {
            java.lang.Number number6 = defaultKeyedValues2D1.getValue((int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str12 = categoryLabelWidthType11.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10, categoryLabelWidthType11, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot17.addChangeListener(plotChangeListener19);
        categoryPlot17.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot17.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition24 = categoryLabelPositions16.getLabelPosition(rectangleEdge23);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30, false);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = legendTitle33.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor35 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType36 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str37 = categoryLabelWidthType36.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition39 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor34, textBlockAnchor35, categoryLabelWidthType36, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType40 = categoryLabelPosition39.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = legendTitle50.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor52 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType53 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str54 = categoryLabelWidthType53.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition56 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor51, textBlockAnchor52, categoryLabelWidthType53, (float) 100L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType57 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str58 = categoryLabelWidthType57.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition60 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor41, textBlockAnchor52, categoryLabelWidthType57, (float) 100L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions61 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition14, categoryLabelPosition24, categoryLabelPosition39, categoryLabelPosition60);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor62 = categoryLabelPosition14.getLabelAnchor();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline63 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean64 = textBlockAnchor62.equals((java.lang.Object) segmentedTimeline63);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str12.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(categoryLabelPosition24);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(textBlockAnchor35);
        org.junit.Assert.assertNotNull(categoryLabelWidthType36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str37.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(textBlockAnchor52);
        org.junit.Assert.assertNotNull(categoryLabelWidthType53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str54.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str58.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(textBlockAnchor62);
        org.junit.Assert.assertNotNull(segmentedTimeline63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100.0f);
        int int5 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 4);
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue(15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-5d + "'", double3 == 1.0E-5d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        stackedAreaRenderer7.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition16, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer7.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color20, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = stackedAreaRenderer7.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer7.setBasePaint((java.awt.Paint) color26, true);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        ringPlot30.setShadowYOffset((double) 100);
        java.awt.Font font33 = ringPlot30.getNoDataMessageFont();
        stackedAreaRenderer7.setSeriesItemLabelFont((int) '4', font33);
        java.awt.Paint paint35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot36.addChangeListener(plotChangeListener38);
        categoryPlot36.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot36.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = textTitle46.getMargin();
        double double49 = rectangleInsets47.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font33, paint35, rectangleEdge42, horizontalAlignment43, verticalAlignment44, rectangleInsets47);
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement54 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment43, verticalAlignment51, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer55 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean61 = flowArrangement54.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D63 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int64 = defaultKeyedValues2D63.getColumnCount();
        boolean boolean65 = flowArrangement54.equals((java.lang.Object) defaultKeyedValues2D63);
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month66.next();
        org.jfree.data.time.Year year68 = month66.getYear();
        defaultKeyedValues2D63.removeColumn((java.lang.Comparable) month66);
        try {
            java.lang.Number number70 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) regularTimePeriod5, (java.lang.Comparable) month66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image11, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.lang.String str17 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceName("");
        java.awt.Image image20 = null;
        projectInfo7.setLogo(image20);
        projectInfo7.setName("ClassContext");
        projectInfo7.setCopyright("");
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) (short) 100);
        double double6 = rectangleInsets2.calculateRightOutset((double) 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator4);
        java.awt.Paint paint6 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint7 = ringPlot0.getShadowPaint();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis9.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle13.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = textTitle13.getPosition();
        textTitle13.setHeight((double) 1);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle13.draw(graphics2D18, rectangle2D19);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle13.setFont(font21);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle13.getBounds();
        dateAxis9.setLeftArrow((java.awt.Shape) rectangle2D23);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle26.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = textTitle26.getPosition();
        double double29 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D23, rectangleEdge28);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D23, "WMAP_Plot");
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint33 = null;
        ringPlot32.setShadowPaint(paint33);
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot32.setOutlinePaint(paint35);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean39 = categoryPlot38.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection42 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = new org.jfree.chart.ChartRenderingInfo(entityCollection42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        org.jfree.chart.renderer.RendererState rendererState45 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo44);
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot38.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo44, point2D46);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState48 = ringPlot0.initialise(graphics2D8, rectangle2D23, (org.jfree.chart.plot.PiePlot) ringPlot32, (java.lang.Integer) 100, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font5 = null;
        stackedAreaRenderer4.setBaseItemLabelFont(font5, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        stackedAreaRenderer4.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        stackedAreaRenderer4.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition13, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer4.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color17, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedAreaRenderer4.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = null;
        stackedAreaRenderer4.setLegendItemURLGenerator(categorySeriesLabelGenerator23);
        java.awt.Stroke stroke27 = stackedAreaRenderer4.getItemOutlineStroke((-447), 100);
        stackedAreaRenderer0.setBaseOutlineStroke(stroke27);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer0.getLegendItemLabelGenerator();
        stackedAreaRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType32 = null;
        try {
            stackedAreaRenderer0.setEndType(areaRendererEndType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator29);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double[][] doubleArray0 = null;
        double[] doubleArray9 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray16 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray45);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset47 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray0, doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font13 = null;
        stackedAreaRenderer12.setBaseItemLabelFont(font13, true);
        stackedAreaRenderer12.setBaseItemLabelsVisible(false, true);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot(pieDataset19);
        java.awt.Paint paint21 = ringPlot20.getLabelLinkPaint();
        stackedAreaRenderer12.setBaseFillPaint(paint21, false);
        xYPlot0.setDomainZeroBaselinePaint(paint21);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis1.setNumberFormatOverride(numberFormat4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setTickMarksVisible(false);
        float float9 = numberAxis1.getTickMarkOutsideLength();
        numberAxis1.setUpperMargin((double) (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
//        ringPlot2.setShadowYOffset((double) 100);
//        boolean boolean5 = month0.equals((java.lang.Object) ringPlot2);
//        long long6 = month0.getLastMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            month0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("SerialDate.weekInMonthToString(): invalid code.", "({0}, {1}) = {2}", "", "hi!", "CategoryLabelWidthType.RANGE");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        java.text.DateFormat dateFormat3 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setShadowYOffset((double) 15);
        double double5 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean6 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) (byte) -1, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range9, (org.jfree.data.general.Dataset) taskSeriesCollection10);
        boolean boolean13 = taskSeriesCollection10.equals((java.lang.Object) 9);
        boolean boolean14 = categoryAxis0.hasListener((java.util.EventListener) taskSeriesCollection10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.previous();
        int int18 = taskSeriesCollection10.indexOf((java.lang.Comparable) regularTimePeriod17);
        try {
            java.lang.Number number22 = taskSeriesCollection10.getStartValue((java.lang.Comparable) 1.0f, (java.lang.Comparable) "35", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis0.setTickLabelFont(font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState((double) 60000L);
        axisState5.cursorUp((double) 1.0f);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle9.getPosition();
        textTitle9.setHeight((double) 1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle9.draw(graphics2D14, rectangle2D15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle9.setFont(font17);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle9.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.util.List list21 = dateAxis0.refreshTicks(graphics2D3, axisState5, rectangle2D19, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        java.awt.Paint paint3 = legendTitle2.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        textTitle1.setHeight((double) 1);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle1.draw(graphics2D6, rectangle2D7);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle1.getBounds();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot14.getRangeMarkers((int) (byte) 100, layer16);
        xYPlot14.setDomainCrosshairValue(10.0d, false);
        xYPlot14.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle25.getMargin();
        double double28 = rectangleInsets26.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        textTitle30.draw(graphics2D31, rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle30.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo37.getDataArea();
        boolean boolean39 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D34, rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets26.createOutsetRectangle(rectangle2D34, false, true);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        int int44 = xYPlot43.getDomainAxisCount();
        java.util.List list45 = xYPlot43.getAnnotations();
        xYPlot14.drawRangeTickBands(graphics2D23, rectangle2D42, list45);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42, "Size2D[width=0.0, height=0.0]", "({0}, {1}) = {3} - {4}");
        java.lang.Object obj50 = textTitle1.draw(graphics2D12, rectangle2D13, (java.lang.Object) chartEntity49);
        java.lang.Object obj51 = chartEntity49.clone();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNull(obj50);
        org.junit.Assert.assertNotNull(obj51);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        textTitle2.setHeight((double) 1);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle2.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint11 = categoryAxis10.getAxisLinePaint();
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.Color cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        stackedAreaRenderer0.setBaseCreateEntities(false);
        java.awt.Stroke stroke12 = stackedAreaRenderer0.lookupSeriesOutlineStroke((-1));
        java.awt.Paint paint14 = null;
        stackedAreaRenderer0.setSeriesPaint(0, paint14);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        double double3 = categoryAxis0.getLowerMargin();
        java.lang.Comparable comparable4 = null;
        try {
            java.awt.Font font5 = categoryAxis0.getTickLabelFont(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) lengthAdjustmentType2);
        java.lang.Object obj4 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeColumn(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        java.awt.Font font3 = ringPlot0.getNoDataMessageFont();
        ringPlot0.setShadowXOffset((double) 9);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1559372400000L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        ringPlot23.setShadowYOffset((double) 100);
        java.awt.Font font26 = ringPlot23.getNoDataMessageFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        try {
            stackedAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition28, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setBase(8.0d);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator7 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat8 = standardCategoryToolTipGenerator7.getNumberFormat();
        barRenderer3D0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator7, true);
        double[] doubleArray19 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray26 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray33 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray40 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray47 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray54 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray55 = new double[][] { doubleArray19, doubleArray26, doubleArray33, doubleArray40, doubleArray47, doubleArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font60 = null;
        stackedAreaRenderer59.setBaseItemLabelFont(font60, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator64 = null;
        stackedAreaRenderer59.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator64, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition68 = null;
        stackedAreaRenderer59.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition68, false);
        java.awt.Color color72 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer59.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color72, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition77 = stackedAreaRenderer59.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator78 = null;
        stackedAreaRenderer59.setLegendItemURLGenerator(categorySeriesLabelGenerator78);
        stackedAreaRenderer59.setBaseItemLabelsVisible(false);
        java.awt.Paint paint83 = stackedAreaRenderer59.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, valueAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer59);
        try {
            java.lang.String str86 = standardCategoryToolTipGenerator7.generateColumnLabel(categoryDataset56, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(itemLabelPosition77);
        org.junit.Assert.assertNull(paint83);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) ' ', 1);
        barRenderer3D0.setMinimumBarLength((double) (short) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot8.addChangeListener(plotChangeListener10);
        categoryPlot8.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font15 = null;
        stackedAreaRenderer14.setBaseItemLabelFont(font15, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedAreaRenderer14.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator19, false);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer14);
        stackedAreaRenderer14.setBaseCreateEntities(false);
        java.awt.Stroke stroke26 = stackedAreaRenderer14.lookupSeriesOutlineStroke((-1));
        categoryPlot8.setDomainGridlineStroke(stroke26);
        categoryPlot8.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean32 = numberAxis30.hasListener((java.util.EventListener) taskSeriesCollection31);
        boolean boolean33 = numberAxis30.getAutoRangeIncludesZero();
        numberAxis30.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot(pieDataset36);
        java.awt.Paint paint38 = ringPlot37.getLabelLinkPaint();
        numberAxis30.setTickMarkPaint(paint38);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        numberAxis30.setRangeWithMargins((org.jfree.data.Range) dateRange40, false, true);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle45.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = textTitle45.getPosition();
        textTitle45.setHeight((double) 1);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        textTitle45.draw(graphics2D50, rectangle2D51);
        java.awt.Font font53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle45.setFont(font53);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle45.getBounds();
        barRenderer3D0.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis30, rectangle2D55, (double) 100L);
        boolean boolean58 = numberAxis30.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        double double3 = stackedBarRenderer3D2.getUpperClip();
        stackedBarRenderer3D2.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font9 = null;
        stackedAreaRenderer8.setBaseItemLabelFont(font9, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator13, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        stackedAreaRenderer8.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition17, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer8.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color21, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = stackedAreaRenderer8.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer8.setBasePaint((java.awt.Paint) color27, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D30 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double31 = barRenderer3D30.getYOffset();
        java.awt.Paint paint32 = barRenderer3D30.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection35 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean36 = numberAxis34.hasListener((java.util.EventListener) taskSeriesCollection35);
        boolean boolean37 = numberAxis34.getAutoRangeIncludesZero();
        numberAxis34.setTickMarkInsideLength(0.0f);
        boolean boolean40 = barRenderer3D30.equals((java.lang.Object) numberAxis34);
        boolean boolean41 = stackedAreaRenderer8.equals((java.lang.Object) numberAxis34);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray42 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { stackedAreaRenderer8 };
        categoryPlot7.setRenderers(categoryItemRendererArray42);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis44.setTickLabelFont(font45);
        float float47 = dateAxis44.getTickMarkInsideLength();
        java.awt.Shape shape48 = dateAxis44.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = xYPlot49.getRangeMarkers((int) (byte) 100, layer51);
        xYPlot49.setDomainCrosshairValue(10.0d, false);
        xYPlot49.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = textTitle60.getMargin();
        double double63 = rectangleInsets61.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        textTitle65.draw(graphics2D66, rectangle2D67);
        java.awt.geom.Rectangle2D rectangle2D69 = textTitle65.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection70 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = new org.jfree.chart.ChartRenderingInfo(entityCollection70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        java.awt.geom.Rectangle2D rectangle2D73 = plotRenderingInfo72.getDataArea();
        boolean boolean74 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D69, rectangle2D73);
        java.awt.geom.Rectangle2D rectangle2D77 = rectangleInsets61.createOutsetRectangle(rectangle2D69, false, true);
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot();
        int int79 = xYPlot78.getDomainAxisCount();
        java.util.List list80 = xYPlot78.getAnnotations();
        xYPlot49.drawRangeTickBands(graphics2D58, rectangle2D77, list80);
        java.awt.Shape shape82 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D77);
        stackedBarRenderer3D2.drawRangeGridline(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis44, rectangle2D77, (double) ' ');
        java.lang.String str85 = dateAxis44.getLabel();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 8.0d + "'", double31 == 8.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(list80);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNull(str85);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean3 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) standardCategorySeriesLabelGenerator2);
        java.lang.Object obj4 = defaultStatisticalCategoryDataset0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getDataArea();
        org.jfree.data.resources.DataPackageResources dataPackageResources4 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean5 = plotRenderingInfo2.equals((java.lang.Object) dataPackageResources4);
        try {
            java.lang.Object obj7 = dataPackageResources4.getObject("({0}, {1}) = {2} version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:({0}, {1}) = {2} hi! ().\n({0}, {1}) = {2} LICENCE TERMS:\nCategoryLabelWidthType.RANGE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ({0}, {1}) = {2} version hi!.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:({0}, {1}) = {2} hi! ().\n({0}, {1}) = {2} LICENCE TERMS:\nCategoryLabelWidthType.RANGE");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(255, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        boolean boolean5 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        java.lang.Boolean boolean7 = stackedAreaRenderer0.getSeriesVisible(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer0.getSeriesURLGenerator(2958465);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        stackedAreaRenderer0.setBaseStroke(stroke10, true);
        java.lang.Object obj13 = stackedAreaRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = regularTimePeriod2.getStart();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        segmentedTimeline7.setStartTime((long) 'a');
        java.util.Date date11 = segmentedTimeline7.getDate((long) '4');
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date3, date11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) 1, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) lengthAdjustmentType2);
        boolean boolean5 = defaultKeyedValues2D1.equals((java.lang.Object) 10.0d);
        java.lang.Comparable comparable6 = null;
        try {
            defaultKeyedValues2D1.removeValue(comparable6, (java.lang.Comparable) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) '#');
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.chart.block.Arrangement arrangement50 = blockContainer49.getArrangement();
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.axis.AxisSpace axisSpace52 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        boolean boolean55 = dateAxis53.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = textTitle57.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = textTitle57.getPosition();
        textTitle57.setHeight((double) 1);
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        textTitle57.draw(graphics2D62, rectangle2D63);
        java.awt.Font font65 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle57.setFont(font65);
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle57.getBounds();
        dateAxis53.setLeftArrow((java.awt.Shape) rectangle2D67);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = textTitle70.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = textTitle70.getPosition();
        double double73 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D67, rectangleEdge72);
        org.jfree.chart.entity.ChartEntity chartEntity75 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D67, "WMAP_Plot");
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        java.awt.geom.Rectangle2D rectangle2D77 = axisSpace52.shrink(rectangle2D67, rectangle2D76);
        try {
            blockContainer49.draw(graphics2D51, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(arrangement50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D77);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RangeType.FULL", graphics2D1, 0.0f, (float) 5, Double.NaN, (float) 2019L, (float) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray10 = new float[] { (byte) -1, (-1.0f), 10, (short) 10 };
        float[] floatArray11 = color5.getComponents(floatArray10);
        java.awt.Stroke stroke12 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font14 = null;
        stackedAreaRenderer13.setBaseItemLabelFont(font14, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        stackedAreaRenderer13.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator18, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        stackedAreaRenderer13.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition22, false);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer13.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color26, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = stackedAreaRenderer13.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer13.setBasePaint((java.awt.Paint) color32, true);
        try {
            org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem(attributedString0, "SerialDate.weekInMonthToString(): invalid code.", "Size2D[width=0.0, height=0.0]", "", shape4, (java.awt.Paint) color5, stroke12, (java.awt.Paint) color32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setShadowYOffset((double) 100);
        java.awt.Font font5 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot8.setSectionPaint((java.lang.Comparable) 1.0f, paint10);
        java.awt.Paint paint12 = ringPlot8.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation13 = ringPlot8.getDirection();
        java.awt.Paint paint14 = ringPlot8.getSeparatorPaint();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("hi!", font5, paint14);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rotation13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setBasePaint((java.awt.Paint) color19, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double23 = barRenderer3D22.getYOffset();
        java.awt.Paint paint24 = barRenderer3D22.getWallPaint();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection27 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean28 = numberAxis26.hasListener((java.util.EventListener) taskSeriesCollection27);
        boolean boolean29 = numberAxis26.getAutoRangeIncludesZero();
        numberAxis26.setTickMarkInsideLength(0.0f);
        boolean boolean32 = barRenderer3D22.equals((java.lang.Object) numberAxis26);
        boolean boolean33 = stackedAreaRenderer0.equals((java.lang.Object) numberAxis26);
        java.awt.Stroke stroke35 = null;
        stackedAreaRenderer0.setSeriesOutlineStroke(1, stroke35, false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        java.awt.Paint paint9 = null;
        xYPlot0.setRangeTickBandPaint(paint9);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = chartRenderingInfo8.getPlotInfo();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean11 = categoryPlot10.getDrawSharedDomainAxis();
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.RendererState rendererState17 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot10.zoomDomainAxes((double) 100, (double) 0L, plotRenderingInfo16, point2D18);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes((double) '4', (double) (byte) 100, plotRenderingInfo16, point2D21);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plotRenderingInfo9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = stackedAreaRenderer0.getSeriesItemLabelGenerator(2958465);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis3.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.util.Date date7 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        java.text.DateFormat dateFormat8 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(dateFormat8);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("SerialDate.weekInMonthToString(): invalid code.", graphics2D1, (float) 0L, (float) 900000L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        textTitle1.setHeight((double) 1);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle1.draw(graphics2D6, rectangle2D7);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle1.getBounds();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot14.getRangeMarkers((int) (byte) 100, layer16);
        xYPlot14.setDomainCrosshairValue(10.0d, false);
        xYPlot14.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle25.getMargin();
        double double28 = rectangleInsets26.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        textTitle30.draw(graphics2D31, rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle30.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo37.getDataArea();
        boolean boolean39 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D34, rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets26.createOutsetRectangle(rectangle2D34, false, true);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        int int44 = xYPlot43.getDomainAxisCount();
        java.util.List list45 = xYPlot43.getAnnotations();
        xYPlot14.drawRangeTickBands(graphics2D23, rectangle2D42, list45);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42, "Size2D[width=0.0, height=0.0]", "({0}, {1}) = {3} - {4}");
        java.lang.Object obj50 = textTitle1.draw(graphics2D12, rectangle2D13, (java.lang.Object) chartEntity49);
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = textTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNull(obj50);
        org.junit.Assert.assertNotNull(verticalAlignment51);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.Plot plot4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle6.getBounds();
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        axisSpace11.setLeft(Double.NaN);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot15.addChangeListener(plotChangeListener17);
        categoryPlot15.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        boolean boolean22 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge21);
        axisSpace11.add(0.0d, rectangleEdge21);
        org.jfree.chart.axis.AxisSpace axisSpace24 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis25.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle29.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = textTitle29.getPosition();
        textTitle29.setHeight((double) 1);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        textTitle29.draw(graphics2D34, rectangle2D35);
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle29.setFont(font37);
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle29.getBounds();
        dateAxis25.setLeftArrow((java.awt.Shape) rectangle2D39);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = textTitle42.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = textTitle42.getPosition();
        double double45 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D39, rectangleEdge44);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D39, "WMAP_Plot");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = axisSpace24.shrink(rectangle2D39, rectangle2D48);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace50 = categoryAxis0.reserveSpace(graphics2D3, plot4, rectangle2D10, rectangleEdge21, axisSpace24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D49);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = barRenderer3D0.getGradientPaintTransformer();
        java.awt.Stroke stroke4 = barRenderer3D0.getItemOutlineStroke(0, 100);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list3 = taskSeriesCollection2.getRowKeys();
        taskSeriesCollection2.removeAll();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        java.text.DateFormat dateFormat7 = dateAxis5.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.util.Date date12 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit11);
        int int13 = taskSeriesCollection2.getColumnIndex((java.lang.Comparable) date12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        segmentedTimeline17.setStartTime((long) 'a');
        java.util.Date date21 = segmentedTimeline17.getDate((long) '4');
        java.lang.Object obj22 = keyedObjects2D0.getObject((java.lang.Comparable) date12, (java.lang.Comparable) '4');
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(obj22);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 5);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 10L, (java.lang.Comparable) "{0}");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
//        java.lang.String str1 = chartChangeEventType0.toString();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        org.jfree.data.time.Year year4 = month2.getYear();
//        int int5 = month2.getMonth();
//        boolean boolean6 = chartChangeEventType0.equals((java.lang.Object) int5);
//        org.junit.Assert.assertNotNull(chartChangeEventType0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        int int16 = xYPlot15.getDomainAxisCount();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot15.getRangeAxisLocation(3);
        categoryPlot0.setRangeAxisLocation(100, axisLocation20, false);
        java.lang.String str23 = axisLocation20.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str23.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setName("ThreadContext");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer6);
        stackedAreaRenderer6.setBaseCreateEntities(false);
        java.awt.Stroke stroke18 = stackedAreaRenderer6.lookupSeriesOutlineStroke((-1));
        categoryPlot0.setDomainGridlineStroke(stroke18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font21 = null;
        stackedAreaRenderer20.setBaseItemLabelFont(font21, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedAreaRenderer20.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator25, false);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = stackedAreaRenderer20.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer20);
        try {
            categoryPlot0.setBackgroundImageAlpha((float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart9.getXYPlot();
        jFreeChart9.fireChartChanged();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font14 = null;
        stackedAreaRenderer13.setBaseItemLabelFont(font14, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        stackedAreaRenderer13.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator18, false);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle21.setLegendItemGraphicAnchor(rectangleAnchor22);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        stackedAreaRenderer25.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color38, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = stackedAreaRenderer25.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setBasePaint((java.awt.Paint) color44, true);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        ringPlot48.setShadowYOffset((double) 100);
        java.awt.Font font51 = ringPlot48.getNoDataMessageFont();
        stackedAreaRenderer25.setSeriesItemLabelFont((int) '4', font51);
        java.awt.Paint paint53 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean55 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener56 = null;
        categoryPlot54.addChangeListener(plotChangeListener56);
        categoryPlot54.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot54.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment61 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = textTitle64.getMargin();
        double double67 = rectangleInsets65.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font51, paint53, rectangleEdge60, horizontalAlignment61, verticalAlignment62, rectangleInsets65);
        legendTitle21.setLegendItemGraphicPadding(rectangleInsets65);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle21);
        jFreeChart9.fireChartChanged();
        java.awt.Paint paint72 = jFreeChart9.getBackgroundPaint();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot11);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(horizontalAlignment61);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(paint72);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) (byte) -1, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range9, (org.jfree.data.general.Dataset) taskSeriesCollection10);
        boolean boolean13 = taskSeriesCollection10.equals((java.lang.Object) 9);
        boolean boolean14 = categoryAxis0.hasListener((java.util.EventListener) taskSeriesCollection10);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) "Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("({0}, {1}) = {2}", graphics2D1, (double) 8, (float) 8, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        long long5 = segmentedTimeline3.getSegmentSize();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2958465 + "'", int4 == 2958465);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-447L) + "'", long5 == (-447L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Number number4 = null;
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0L, (java.lang.Number) 1559372400000L, (java.lang.Number) (short) -1, (java.lang.Number) (-1322433855L), number4, number5, (java.lang.Number) 5, (java.lang.Number) 15, list8);
        java.lang.String str10 = boxAndWhiskerItem9.toString();
    }
}

