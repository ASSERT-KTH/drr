import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis0.setTickLabelFont(font1);
        float float3 = dateAxis0.getTickMarkInsideLength();
        java.awt.Shape shape4 = dateAxis0.getLeftArrow();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle8.getMargin();
        double double11 = rectangleInsets9.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle13.draw(graphics2D14, rectangle2D15);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle13.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo20.getDataArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D17, rectangle2D21);
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets9.createOutsetRectangle(rectangle2D17, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot27.getRangeMarkers((int) (byte) 100, layer29);
        java.awt.Paint paint31 = xYPlot27.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape35, "ClassContext", "");
        java.awt.Shape shape39 = chartEntity38.getArea();
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = textTitle41.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = textTitle41.getPosition();
        textTitle41.setHeight((double) 1);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        textTitle41.draw(graphics2D46, rectangle2D47);
        java.awt.Font font49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle41.setFont(font49);
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle41.getBounds();
        chartEntity38.setArea((java.awt.Shape) rectangle2D51);
        org.jfree.chart.plot.RingPlot ringPlot55 = new org.jfree.chart.plot.RingPlot();
        ringPlot55.setShadowYOffset((double) 100);
        java.awt.Font font58 = ringPlot55.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font58);
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.entity.EntityCollection entityCollection62 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo63 = new org.jfree.chart.ChartRenderingInfo(entityCollection62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo63);
        java.lang.Object obj65 = textTitle59.draw(graphics2D60, rectangle2D61, (java.lang.Object) plotRenderingInfo64);
        org.jfree.chart.plot.CrosshairState crosshairState66 = null;
        boolean boolean67 = xYPlot27.render(graphics2D32, rectangle2D51, (int) '#', plotRenderingInfo64, crosshairState66);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.entity.EntityCollection entityCollection69 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = new org.jfree.chart.ChartRenderingInfo(entityCollection69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = chartRenderingInfo70.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo72 = plotRenderingInfo71.getOwner();
        try {
            org.jfree.chart.axis.AxisState axisState73 = dateAxis0.draw(graphics2D5, (double) 255, rectangle2D25, rectangle2D51, rectangleEdge68, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNull(obj65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(plotRenderingInfo71);
        org.junit.Assert.assertNotNull(chartRenderingInfo72);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.LegendItem legendItem3 = levelRenderer0.getLegendItem(10, (int) (short) 100);
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2958465);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer0);
        stackedAreaRenderer0.setBaseCreateEntities(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis14.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle18.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle18.getPosition();
        textTitle18.setHeight((double) 1);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        textTitle18.draw(graphics2D23, rectangle2D24);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle18.setFont(font26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle18.getBounds();
        dateAxis14.setLeftArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape33, "ClassContext", "");
        java.awt.Shape shape37 = chartEntity36.getArea();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle39.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = textTitle39.getPosition();
        textTitle39.setHeight((double) 1);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        textTitle39.draw(graphics2D44, rectangle2D45);
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle39.setFont(font47);
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle39.getBounds();
        chartEntity36.setArea((java.awt.Shape) rectangle2D49);
        stackedAreaRenderer0.drawRangeMarker(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis14, marker30, rectangle2D49);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline55 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        segmentedTimeline55.setStartTime((long) 'a');
        dateAxis14.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline55);
        org.jfree.chart.axis.Timeline timeline59 = dateAxis14.getTimeline();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(timeline59);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image3, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "hi!", "", image11, "Size2D[width=0.0, height=0.0]", "hi!", "CategoryLabelWidthType.RANGE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.lang.String str17 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceName("");
        java.awt.Image image20 = null;
        projectInfo7.setLogo(image20);
        org.jfree.chart.ui.Library[] libraryArray22 = projectInfo7.getOptionalLibraries();
        projectInfo7.setLicenceText("Multiple Pie Plot");
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray22);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis0.setTickLabelFont(font1);
        float float3 = dateAxis0.getTickMarkInsideLength();
        java.util.TimeZone timeZone4 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesShapesVisible((int) (byte) 0, false);
        lineRenderer3D0.setSeriesShapesVisible(100, true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset(xYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis13.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle17.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle17.getPosition();
        textTitle17.setHeight((double) 1);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        textTitle17.draw(graphics2D22, rectangle2D23);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle17.setFont(font25);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle17.getBounds();
        dateAxis13.setLeftArrow((java.awt.Shape) rectangle2D27);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = textTitle30.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = textTitle30.getPosition();
        double double33 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D27, rectangleEdge32);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27, "WMAP_Plot");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = axisSpace12.shrink(rectangle2D27, rectangle2D36);
        try {
            xYPlot0.drawBackground(graphics2D11, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) 100);
        ringPlot0.setOutlineVisible(false);
        ringPlot0.setSectionOutlinesVisible(false);
        java.awt.Color color7 = java.awt.Color.WHITE;
        int int8 = color7.getRGB();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray14 = new float[] { (byte) -1, (-1.0f), 10, (short) 10 };
        float[] floatArray15 = color9.getComponents(floatArray14);
        float[] floatArray16 = color7.getRGBComponents(floatArray14);
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getLabelPaint();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getRangeAxisLocation(4);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean10 = axisLocation8.equals((java.lang.Object) textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer1);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getMargin();
        double double14 = rectangleInsets12.calculateLeftOutset((double) 10.0f);
        double double16 = rectangleInsets12.calculateLeftInset(100.0d);
        double double18 = rectangleInsets12.calculateTopOutset((double) 1L);
        legendTitle9.setLegendItemGraphicPadding(rectangleInsets12);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font22 = null;
        stackedAreaRenderer21.setBaseItemLabelFont(font22, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = null;
        stackedAreaRenderer21.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator26, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = null;
        stackedAreaRenderer21.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition30, false);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer21.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color34, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = stackedAreaRenderer21.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer21.setBasePaint((java.awt.Paint) color40, true);
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        ringPlot44.setShadowYOffset((double) 100);
        java.awt.Font font47 = ringPlot44.getNoDataMessageFont();
        stackedAreaRenderer21.setSeriesItemLabelFont((int) '4', font47);
        java.awt.Paint paint49 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean51 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener52 = null;
        categoryPlot50.addChangeListener(plotChangeListener52);
        categoryPlot50.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot50.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment57 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = textTitle60.getMargin();
        double double63 = rectangleInsets61.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font47, paint49, rectangleEdge56, horizontalAlignment57, verticalAlignment58, rectangleInsets61);
        legendTitle9.setVerticalAlignment(verticalAlignment58);
        org.jfree.chart.block.ColumnArrangement columnArrangement68 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment58, (double) 1.0f, (double) ' ');
        boolean boolean70 = columnArrangement68.equals((java.lang.Object) (-131072));
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(horizontalAlignment57);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionPaint((java.lang.Comparable) "June 2019");
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        multiplePiePlot1.setAggregatedItemsPaint(paint4);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange6, (double) (byte) -1, false);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange6, (double) 1.0f, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection13 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) range12, (org.jfree.data.general.Dataset) taskSeriesCollection13);
        boolean boolean16 = taskSeriesCollection13.equals((java.lang.Object) 9);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection13);
        try {
            java.lang.Comparable comparable19 = taskSeriesCollection13.getSeriesKey(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 30, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        boolean boolean5 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        try {
            stackedAreaRenderer0.setSeriesCreateEntities((-447), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getCompletePaint();
        ganttRenderer0.setEndPercent(4.0d);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 5);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D1.getColumnKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle1.draw(graphics2D2, rectangle2D3);
        java.awt.geom.Rectangle2D rectangle2D5 = textTitle1.getBounds();
        textTitle1.setMargin((double) 6, (double) 8, (double) (byte) 0, (double) (short) 100);
        textTitle1.setWidth((double) (short) 100);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle1.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        textTitle1.setHeight((double) 1);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle1.draw(graphics2D6, rectangle2D7);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder9);
        java.awt.Paint paint11 = lineBorder9.getPaint();
        java.awt.Paint paint12 = lineBorder9.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = lineBorder9.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Stroke stroke1 = null;
        try {
            waterfallBarRenderer0.setBaseStroke(stroke1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isDomainGridlinesVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        multiplePiePlot5.setAggregatedItemsPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, paint8);
        double double12 = rectangleInsets3.extendWidth(1.0d);
        double double14 = rectangleInsets3.calculateRightOutset((double) 2);
        double double16 = rectangleInsets3.calculateTopInset((double) (byte) 0);
        double double17 = rectangleInsets3.getLeft();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 9.0d + "'", double12 == 9.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isDomainGridlinesVisible();
        java.awt.Paint paint5 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot3.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getDomainAxisCount();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot8.setRangeTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot8.getRangeAxisLocation(3);
        categoryPlot3.setRangeAxisLocation(axisLocation13, false);
        boolean boolean16 = categoryPlot3.isRangeZoomable();
        java.awt.Font font17 = categoryPlot3.getNoDataMessageFont();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        ringPlot21.setShadowYOffset((double) 100);
        java.awt.Font font24 = ringPlot21.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.entity.EntityCollection entityCollection28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo(entityCollection28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.lang.Object obj31 = textTitle25.draw(graphics2D26, rectangle2D27, (java.lang.Object) plotRenderingInfo30);
        categoryPlot3.handleClick((int) 'a', (int) ' ', plotRenderingInfo30);
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (-1), (double) 2019L, plotRenderingInfo30, point2D33);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        stackedAreaRenderer6.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition15, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer6.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color19, true);
        java.awt.Font font23 = null;
        stackedAreaRenderer6.setSeriesItemLabelFont((int) (byte) 0, font23);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        boolean boolean29 = stackedAreaRenderer25.getBaseCreateEntities();
        java.awt.Paint paint30 = stackedAreaRenderer25.getBaseFillPaint();
        stackedAreaRenderer6.setBaseOutlinePaint(paint30);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = stackedAreaRenderer6.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection32);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection34 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list35 = taskSeriesCollection34.getRowKeys();
        taskSeriesCollection34.removeAll();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint38 = dateAxis37.getLabelPaint();
        java.text.DateFormat dateFormat39 = dateAxis37.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis40.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = dateAxis40.getTickUnit();
        java.util.Date date44 = dateAxis37.calculateHighestVisibleTickValue(dateTickUnit43);
        int int45 = taskSeriesCollection34.getColumnIndex((java.lang.Comparable) date44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot0.getRendererForDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection34);
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(dateFormat39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateTickUnit43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer46);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis4.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis4.getTickUnit();
        java.awt.Stroke stroke8 = dateAxis4.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis4.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline12);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint17 = dateAxis16.getLabelPaint();
        java.text.DateFormat dateFormat18 = dateAxis16.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis19.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis19.getTickUnit();
        java.util.Date date23 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit22);
        java.util.Date date24 = dateTickUnit15.addToDate(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getPreviousDayOfWeek(4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(dateFormat18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getMargin();
        double double14 = rectangleInsets12.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle16.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo(entityCollection21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo23.getDataArea();
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D20, rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets12.createOutsetRectangle(rectangle2D20, false, true);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        int int30 = xYPlot29.getDomainAxisCount();
        java.util.List list31 = xYPlot29.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D9, rectangle2D28, list31);
        boolean boolean33 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot0.getRendererForDataset(xYDataset34);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(xYItemRenderer35);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.awt.Color color0 = java.awt.Color.GREEN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint16 = categoryAxis15.getAxisLinePaint();
        categoryPlot0.setDomainAxis(0, categoryAxis15);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font20 = null;
        stackedAreaRenderer19.setBaseItemLabelFont(font20, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        stackedAreaRenderer19.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator24, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        stackedAreaRenderer19.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition28, false);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer19.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color32, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = stackedAreaRenderer19.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer19.setBasePaint((java.awt.Paint) color38, true);
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
        ringPlot42.setShadowYOffset((double) 100);
        java.awt.Font font45 = ringPlot42.getNoDataMessageFont();
        stackedAreaRenderer19.setSeriesItemLabelFont((int) '4', font45);
        java.awt.Paint paint47 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean49 = categoryPlot48.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener50 = null;
        categoryPlot48.addChangeListener(plotChangeListener50);
        categoryPlot48.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot48.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle58 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = textTitle58.getMargin();
        double double61 = rectangleInsets59.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font45, paint47, rectangleEdge54, horizontalAlignment55, verticalAlignment56, rectangleInsets59);
        org.jfree.chart.util.VerticalAlignment verticalAlignment63 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement66 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment55, verticalAlignment63, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer67 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement66);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset68 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset68.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean73 = flowArrangement66.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D75 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int76 = defaultKeyedValues2D75.getColumnCount();
        boolean boolean77 = flowArrangement66.equals((java.lang.Object) defaultKeyedValues2D75);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = month78.next();
        org.jfree.data.time.Year year80 = month78.getYear();
        defaultKeyedValues2D75.removeColumn((java.lang.Comparable) month78);
        java.awt.Paint paint82 = categoryAxis15.getTickLabelPaint((java.lang.Comparable) month78);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment63);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(year80);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Paint paint24 = stackedAreaRenderer0.getSeriesOutlinePaint(4);
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(false, true);
        java.awt.Paint paint28 = null;
        stackedAreaRenderer0.setBasePaint(paint28, false);
        java.awt.Font font32 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        stackedAreaRenderer0.setSeriesItemLabelFont(8, font32, false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation6 = ringPlot1.getDirection();
        java.awt.Paint paint7 = ringPlot1.getSeparatorPaint();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint9 = null;
        ringPlot8.setShadowPaint(paint9);
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot8.setOutlinePaint(paint11);
        ringPlot1.setBaseSectionOutlinePaint(paint11);
        java.awt.Paint paint15 = ringPlot1.getSectionOutlinePaint((java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick(9, (int) (short) 100, plotRenderingInfo11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        boolean boolean75 = stackedAreaRenderer48.equals((java.lang.Object) paint74);
        java.awt.Paint paint76 = stackedAreaRenderer48.getBaseFillPaint();
        java.awt.Paint paint78 = stackedAreaRenderer48.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        int int80 = xYPlot79.getDomainAxisCount();
        java.util.List list81 = xYPlot79.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray88 = new org.jfree.chart.axis.ValueAxis[] { dateAxis82, dateAxis83, dateAxis84, dateAxis85, dateAxis86, dateAxis87 };
        xYPlot79.setDomainAxes(valueAxisArray88);
        stackedAreaRenderer48.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot79);
        java.awt.Stroke stroke91 = xYPlot79.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection94 = xYPlot79.getRangeMarkers((int) (byte) 1, layer93);
        try {
            xYPlot79.setBackgroundImageAlpha((float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(valueAxisArray88);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertNull(collection94);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange0, 12.0d);
        java.lang.Object obj6 = null;
        boolean boolean7 = range5.equals(obj6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range5, (double) 10.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedWidth((double) 1900);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font11 = null;
        stackedAreaRenderer10.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        stackedAreaRenderer10.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition19, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color23, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer10.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setBasePaint((java.awt.Paint) color29, true);
        java.awt.Paint paint33 = stackedAreaRenderer10.getSeriesFillPaint((int) (byte) 1);
        xYPlot0.setDomainGridlinePaint(paint33);
        boolean boolean35 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.data.Range range26 = stackedAreaRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        java.awt.Stroke stroke28 = stackedAreaRenderer0.getSeriesStroke((int) (short) 0);
        java.awt.Paint paint30 = stackedAreaRenderer0.lookupSeriesPaint(6);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator32 = null;
        stackedAreaRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator32);
        java.awt.Paint paint35 = stackedAreaRenderer0.lookupSeriesOutlinePaint(15);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextStroke();
        stackedAreaRenderer0.setBaseStroke(stroke37, false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0d + "'", number25.equals(0.0d));
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        int int3 = defaultStatisticalCategoryDataset0.getRowCount();
        java.lang.Number number6 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) (byte) 10, (java.lang.Comparable) 1.0d);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int8 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        java.awt.Font font4 = dateAxis0.getLabelFont();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list6 = taskSeriesCollection5.getRowKeys();
        taskSeriesCollection5.removeAll();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        int int16 = taskSeriesCollection5.getColumnIndex((java.lang.Comparable) date15);
        dateAxis0.setMinimumDate(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date15, timeZone18);
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("Size2D[width=0.0, height=0.0]", font21, paint22);
        boolean boolean25 = textBlock23.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.text.TextLine textLine26 = textBlock23.getLastLine();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer27 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font28 = null;
        stackedAreaRenderer27.setBaseItemLabelFont(font28, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = null;
        stackedAreaRenderer27.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator32, false);
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle35.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType38 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str39 = categoryLabelWidthType38.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition41 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor36, textBlockAnchor37, categoryLabelWidthType38, (float) 100L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor43 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        boolean boolean44 = lengthAdjustmentType42.equals((java.lang.Object) itemLabelAnchor43);
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor43, textAnchor45);
        org.jfree.chart.axis.CategoryTick categoryTick48 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) year19, textBlock23, textBlockAnchor37, textAnchor45, 0.0d);
        double double49 = categoryTick48.getAngle();
        java.awt.Shape shape50 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        boolean boolean51 = categoryTick48.equals((java.lang.Object) shape50);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(textLine26);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertNotNull(categoryLabelWidthType38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str39.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
        org.junit.Assert.assertNotNull(itemLabelAnchor43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(categoryAnchor7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Pie Plot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) -1, (double) 'a');
        size2D2.setWidth((double) 0L);
        size2D2.height = 0.2d;
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace3);
        xYPlot0.clearDomainMarkers((int) (short) -1);
        xYPlot0.zoom(59999.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean6 = numberAxis4.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "Size2D[width=0.0, height=0.0]", "AxisLocation.TOP_OR_RIGHT", (org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) 4.0d, (java.lang.Comparable) date15);
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D((double) (short) -1, (double) 'a');
        size2D19.setWidth((double) 0L);
        java.lang.Object obj22 = size2D19.clone();
        boolean boolean23 = categoryItemEntity16.equals(obj22);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        java.awt.Font font17 = null;
        stackedAreaRenderer0.setSeriesItemLabelFont((int) (byte) 0, font17);
        boolean boolean21 = stackedAreaRenderer0.getItemCreateEntity(4, 100);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        numberAxis1.setLowerBound((double) 15);
        double double6 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Paint paint24 = stackedAreaRenderer0.getSeriesOutlinePaint(4);
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(false, true);
        java.awt.Paint paint28 = null;
        stackedAreaRenderer0.setBasePaint(paint28, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer32 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font33 = null;
        stackedAreaRenderer32.setBaseItemLabelFont(font33, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        stackedAreaRenderer32.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator37, false);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer32);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font43 = null;
        stackedAreaRenderer42.setBaseItemLabelFont(font43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = null;
        stackedAreaRenderer42.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator47, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = null;
        stackedAreaRenderer42.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition51, false);
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer42.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color55, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = stackedAreaRenderer42.getPositiveItemLabelPosition(0, (int) (short) 10);
        stackedAreaRenderer32.setSeriesNegativeItemLabelPosition(9, itemLabelPosition60);
        stackedAreaRenderer0.setSeriesPositiveItemLabelPosition(6, itemLabelPosition60, true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(itemLabelPosition60);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        int int3 = defaultStatisticalCategoryDataset0.getRowCount();
        java.lang.Number number6 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) (byte) 10, (java.lang.Comparable) 1.0d);
        int int7 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        java.text.DateFormat dateFormat10 = dateAxis8.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis11.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        java.util.TimeZone timeZone16 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone16;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone16);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        int int25 = defaultCategoryDataset22.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot21.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.util.List list27 = defaultCategoryDataset22.getColumnKeys();
        org.jfree.data.Range range28 = intervalBarRenderer19.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        ringPlot31.setShadowYOffset((double) 100);
        boolean boolean34 = month29.equals((java.lang.Object) ringPlot31);
        ringPlot31.setIgnoreNullValues(true);
        org.jfree.chart.LegendItemCollection legendItemCollection37 = ringPlot31.getLegendItems();
        defaultCategoryDataset22.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot31);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint41 = dateAxis40.getLabelPaint();
        java.text.DateFormat dateFormat42 = dateAxis40.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis43.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = dateAxis43.getTickUnit();
        java.util.Date date47 = dateAxis40.calculateHighestVisibleTickValue(dateTickUnit46);
        java.util.TimeZone timeZone48 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone48;
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date47, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month52.next();
        org.jfree.data.time.Year year54 = month52.getYear();
        long long55 = year54.getLastMillisecond();
        defaultCategoryDataset22.setValue((java.lang.Number) 5, (java.lang.Comparable) regularTimePeriod51, (java.lang.Comparable) year54);
        java.lang.Number number57 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) date15, (java.lang.Comparable) year54);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(legendItemCollection37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(dateFormat42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNull(number57);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.clearRangeMarkers((int) (byte) 100);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean15 = numberAxis13.hasListener((java.util.EventListener) taskSeriesCollection14);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis13.setNumberFormatOverride(numberFormat16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        boolean boolean19 = numberAxis13.isVisible();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis13, false);
        categoryPlot0.setForegroundAlpha((float) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot1.getDomainAxis();
        java.awt.Stroke stroke3 = xYPlot1.getRangeCrosshairStroke();
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation((int) '4', axisLocation6, true);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.clearRangeMarkers((int) (byte) 100);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean15 = numberAxis13.hasListener((java.util.EventListener) taskSeriesCollection14);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis13.setNumberFormatOverride(numberFormat16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        boolean boolean19 = numberAxis13.isVisible();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis13, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxisForDataset((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.lang.Object obj2 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        java.text.DateFormat dateFormat7 = dateAxis5.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.util.Date date12 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit11);
        keyedObjects2D0.addObject(obj2, (java.lang.Comparable) numberTickUnit4, (java.lang.Comparable) dateTickUnit11);
        java.util.List list14 = keyedObjects2D0.getColumnKeys();
        int int15 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, 8.0d);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot6.getRangeMarkers((int) (byte) 100, layer8);
        java.awt.Paint paint10 = xYPlot6.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape14, "ClassContext", "");
        java.awt.Shape shape18 = chartEntity17.getArea();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle20.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle20.getPosition();
        textTitle20.setHeight((double) 1);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        textTitle20.draw(graphics2D25, rectangle2D26);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle20.setFont(font28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle20.getBounds();
        chartEntity17.setArea((java.awt.Shape) rectangle2D30);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        ringPlot34.setShadowYOffset((double) 100);
        java.awt.Font font37 = ringPlot34.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.entity.EntityCollection entityCollection41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo(entityCollection41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        java.lang.Object obj44 = textTitle38.draw(graphics2D39, rectangle2D40, (java.lang.Object) plotRenderingInfo43);
        org.jfree.chart.plot.CrosshairState crosshairState45 = null;
        boolean boolean46 = xYPlot6.render(graphics2D11, rectangle2D30, (int) '#', plotRenderingInfo43, crosshairState45);
        java.awt.Paint paint47 = xYPlot6.getRangeCrosshairPaint();
        xYPlot6.clearDomainMarkers();
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 1);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font6 = null;
        stackedAreaRenderer5.setBaseItemLabelFont(font6, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedAreaRenderer5.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        stackedAreaRenderer5.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition14, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer5.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color18, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = stackedAreaRenderer5.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = null;
        stackedAreaRenderer5.setLegendItemURLGenerator(categorySeriesLabelGenerator24);
        stackedAreaRenderer5.setBaseItemLabelsVisible(false);
        java.awt.Stroke stroke30 = stackedAreaRenderer5.getItemStroke((int) 'a', 0);
        ringPlot1.setLabelOutlineStroke(stroke30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot1.setLabelPaint((java.awt.Paint) color32);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.util.List list2 = xYPlot0.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace3);
        xYPlot0.clearDomainMarkers((int) (short) -1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        double double4 = rectangleInsets2.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle6.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo13.getDataArea();
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D10, rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets2.createOutsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D18);
        org.jfree.chart.axis.NumberAxis numberAxis20 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        stackedAreaRenderer25.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color38, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = stackedAreaRenderer25.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setBasePaint((java.awt.Paint) color44, true);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        ringPlot48.setShadowYOffset((double) 100);
        java.awt.Font font51 = ringPlot48.getNoDataMessageFont();
        stackedAreaRenderer25.setSeriesItemLabelFont((int) '4', font51);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis20, (double) (short) 10, (double) 100.0f, 1.0d, (double) (-1.0f), font51);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean55 = markerAxisBand53.equals((java.lang.Object) datasetRenderingOrder54);
        boolean boolean56 = legendItemEntity19.equals((java.lang.Object) markerAxisBand53);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset57 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset57.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        legendItemEntity19.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset57);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        long long66 = year65.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year65.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year65.previous();
        long long69 = year65.getFirstMillisecond();
        defaultCategoryDataset57.addValue((double) 3600000L, (java.lang.Comparable) "{0}", (java.lang.Comparable) long69);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1546329600000L + "'", long69 == 1546329600000L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("Size2D[width=0.0, height=0.0]", font2, paint3);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font6 = null;
        stackedAreaRenderer5.setBaseItemLabelFont(font6, true);
        boolean boolean9 = stackedAreaRenderer5.getBaseCreateEntities();
        java.awt.Paint paint10 = stackedAreaRenderer5.getBaseFillPaint();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("DateTickMarkPosition.MIDDLE", font2, paint10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.Object obj1 = null;
        boolean boolean2 = axisSpace0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer2 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer2.setStartPercent(0.0d);
        double double5 = ganttRenderer2.getStartPercent();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        ganttRenderer2.setSeriesPaint(1900, (java.awt.Paint) color7);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        java.util.List list4 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke2 = levelRenderer0.getSeriesOutlineStroke((int) (short) 100);
        levelRenderer0.setItemMargin(0.0d);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        int int8 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis1.setNumberFormatOverride(numberFormat4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setTickMarkInsideLength((float) (-1322433855L));
        numberAxis1.setInverted(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        categoryPlot0.setOutlineVisible(true);
        categoryPlot0.clearDomainMarkers((int) (byte) 100);
        java.awt.Paint paint6 = categoryPlot0.getNoDataMessagePaint();
        int int7 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        ringPlot1.setSectionPaint((java.lang.Comparable) 1.0f, paint3);
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.jfree.chart.util.Rotation rotation6 = ringPlot1.getDirection();
        ringPlot1.setStartAngle((double) 'a');
        java.awt.Stroke stroke10 = ringPlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = ringPlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(pieToolTipGenerator11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[] doubleArray6 = new double[] { 9, 15, 6, (-1) };
        double[] doubleArray11 = new double[] { 9, 15, 6, (-1) };
        double[] doubleArray16 = new double[] { 9, 15, 6, (-1) };
        double[] doubleArray21 = new double[] { 9, 15, 6, (-1) };
        double[] doubleArray26 = new double[] { 9, 15, 6, (-1) };
        double[] doubleArray31 = new double[] { 9, 15, 6, (-1) };
        double[][] doubleArray32 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray0, comparableArray1, doubleArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis4.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis4.getTickUnit();
        java.awt.Stroke stroke8 = dateAxis4.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis4.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline12);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis0.getTickUnit();
        dateAxis0.setLowerBound((double) (short) 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(dateTickUnit15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setShadowYOffset((double) 100);
        java.awt.Font font4 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot6.setRenderer(categoryItemRenderer8, true);
        boolean boolean11 = textLine5.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[][] doubleArray52 = new double[][] { doubleArray46, doubleArray47, doubleArray48, doubleArray49, doubleArray50, doubleArray51 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset53 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray44, doubleArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of categories in the start value dataset does not match the number of categories in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.lang.Object obj2 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        java.text.DateFormat dateFormat7 = dateAxis5.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis8.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.util.Date date12 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit11);
        keyedObjects2D0.addObject(obj2, (java.lang.Comparable) numberTickUnit4, (java.lang.Comparable) dateTickUnit11);
        java.util.List list14 = keyedObjects2D0.getColumnKeys();
        java.lang.Object obj17 = keyedObjects2D0.getObject((java.lang.Comparable) "35", (java.lang.Comparable) "hi!");
        keyedObjects2D0.removeColumn(0);
        java.util.List list20 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        boolean boolean4 = stackedAreaRenderer0.getBaseCreateEntities();
        boolean boolean5 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        java.lang.Boolean boolean7 = stackedAreaRenderer0.getSeriesVisible(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer0.getSeriesURLGenerator(2958465);
        stackedAreaRenderer0.setSeriesItemLabelsVisible(5, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { (-1322433855L) };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1322433855L) };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1322433855L) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1322433855L) };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "1.0.6", numberArray10);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setShadowYOffset((double) 100);
        java.awt.Font font4 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.RANGE", font4);
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle5.getBounds();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font12 = null;
        stackedAreaRenderer11.setBaseItemLabelFont(font12, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        stackedAreaRenderer11.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator16, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        stackedAreaRenderer11.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition20, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer11.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color24, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = stackedAreaRenderer11.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = null;
        stackedAreaRenderer11.setLegendItemURLGenerator(categorySeriesLabelGenerator30);
        java.awt.Stroke stroke34 = stackedAreaRenderer11.getItemOutlineStroke((-447), 100);
        stackedAreaRenderer7.setBaseOutlineStroke(stroke34);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = stackedAreaRenderer7.getBaseNegativeItemLabelPosition();
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint39 = null;
        ringPlot38.setShadowPaint(paint39);
        double double41 = ringPlot38.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator42 = null;
        ringPlot38.setToolTipGenerator(pieToolTipGenerator42);
        ringPlot38.setForegroundAlpha((float) 1L);
        java.awt.Paint paint46 = ringPlot38.getLabelPaint();
        stackedAreaRenderer7.setSeriesItemLabelPaint(8, paint46, true);
        textTitle5.setPaint(paint46);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        boolean boolean1 = layeredBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = layeredBarRenderer0.getNegativeItemLabelPositionFallback();
        double double3 = layeredBarRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getMargin();
        double double14 = rectangleInsets12.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle16.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo(entityCollection21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo23.getDataArea();
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D20, rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets12.createOutsetRectangle(rectangle2D20, false, true);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        int int30 = xYPlot29.getDomainAxisCount();
        java.util.List list31 = xYPlot29.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D9, rectangle2D28, list31);
        boolean boolean33 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot0.getRendererForDataset(xYDataset34);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot0.setDataset(0, xYDataset37);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(xYItemRenderer35);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) lengthAdjustmentType2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list5 = taskSeriesCollection4.getRowKeys();
        taskSeriesCollection4.removeAll();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getLabelPaint();
        java.text.DateFormat dateFormat9 = dateAxis7.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis10.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis10.getTickUnit();
        java.util.Date date14 = dateAxis7.calculateHighestVisibleTickValue(dateTickUnit13);
        int int15 = taskSeriesCollection4.getColumnIndex((java.lang.Comparable) date14);
        boolean boolean16 = lengthAdjustmentType2.equals((java.lang.Object) taskSeriesCollection4);
        try {
            taskSeriesCollection4.remove(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot1.addChangeListener(plotChangeListener3);
        categoryPlot1.clearRangeMarkers((int) ' ');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font8 = null;
        stackedAreaRenderer7.setBaseItemLabelFont(font8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer7.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator12, false);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer7);
        stackedAreaRenderer7.setBaseCreateEntities(false);
        java.awt.Stroke stroke19 = stackedAreaRenderer7.lookupSeriesOutlineStroke((-1));
        categoryPlot1.setDomainGridlineStroke(stroke19);
        categoryPlot1.setDrawSharedDomainAxis(false);
        boolean boolean23 = lineRenderer3D0.equals((java.lang.Object) categoryPlot1);
        boolean boolean24 = categoryPlot1.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) '4');
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle4.getMargin();
        double double7 = rectangleInsets5.calculateLeftOutset((double) 10.0f);
        double double9 = rectangleInsets5.calculateLeftInset(100.0d);
        double double11 = rectangleInsets5.calculateTopOutset((double) 1L);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle13.getMargin();
        double double16 = rectangleInsets14.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle18.draw(graphics2D19, rectangle2D20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle18.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo25.getDataArea();
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D22, rectangle2D26);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets14.createOutsetRectangle(rectangle2D22, false, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity31 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets5.createInsetRectangle(rectangle2D30);
        boolean boolean33 = intervalMarker2.equals((java.lang.Object) rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke23 = stackedAreaRenderer0.getItemOutlineStroke((-447), 100);
        java.awt.Stroke stroke26 = stackedAreaRenderer0.getItemStroke(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = stackedAreaRenderer0.getSeriesItemLabelGenerator((-1));
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        ringPlot30.setShadowYOffset((double) 100);
        java.awt.Font font33 = ringPlot30.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("", font33);
        stackedAreaRenderer0.setBaseItemLabelFont(font33);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator38 = stackedAreaRenderer0.getToolTipGenerator(1, 255);
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(false);
        java.lang.Object obj41 = stackedAreaRenderer0.clone();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(categoryToolTipGenerator38);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible(6);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double[] doubleArray8 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, (-1.0f), (byte) 1, 100.0f, 0, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font49 = null;
        stackedAreaRenderer48.setBaseItemLabelFont(font49, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedAreaRenderer48.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedAreaRenderer48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition57, false);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer48.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color61, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = stackedAreaRenderer48.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = null;
        stackedAreaRenderer48.setLegendItemURLGenerator(categorySeriesLabelGenerator67);
        stackedAreaRenderer48.setBaseItemLabelsVisible(false);
        java.awt.Paint paint72 = stackedAreaRenderer48.getSeriesOutlinePaint(4);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer48);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean75 = categoryPlot74.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean77 = categoryPlot76.isDomainGridlinesVisible();
        java.awt.Paint paint78 = categoryPlot76.getDomainGridlinePaint();
        categoryPlot74.setOutlinePaint(paint78);
        categoryPlot73.setOutlinePaint(paint78);
        org.jfree.chart.plot.PlotOrientation plotOrientation81 = categoryPlot73.getOrientation();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(plotOrientation81);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean3 = numberAxis1.hasListener((java.util.EventListener) taskSeriesCollection2);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font11 = null;
        stackedAreaRenderer10.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        stackedAreaRenderer10.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition19, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color23, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer10.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer10.setBasePaint((java.awt.Paint) color29, true);
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        ringPlot33.setShadowYOffset((double) 100);
        java.awt.Font font36 = ringPlot33.getNoDataMessageFont();
        stackedAreaRenderer10.setSeriesItemLabelFont((int) '4', font36);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, (double) (short) 10, (double) 100.0f, 1.0d, (double) (-1.0f), font36);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean40 = markerAxisBand38.equals((java.lang.Object) datasetRenderingOrder39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity(shape44, "ClassContext", "");
        java.awt.Shape shape48 = chartEntity47.getArea();
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = textTitle50.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = textTitle50.getPosition();
        textTitle50.setHeight((double) 1);
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        textTitle50.draw(graphics2D55, rectangle2D56);
        java.awt.Font font58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle50.setFont(font58);
        java.awt.geom.Rectangle2D rectangle2D60 = textTitle50.getBounds();
        chartEntity47.setArea((java.awt.Shape) rectangle2D60);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        markerAxisBand38.draw(graphics2D41, rectangle2D60, rectangle2D62, 0.0d, (double) (short) 10);
        numberAxis1.setMarkerBand(markerAxisBand38);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(rectangle2D60);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font9 = null;
        stackedAreaRenderer8.setBaseItemLabelFont(font9, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator13, false);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer8.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedAreaRenderer8.getPositiveItemLabelPosition(4, (int) (byte) -1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        org.jfree.chart.util.SortOrder sortOrder24 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(sortOrder24);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        categoryPlot0.clearDomainAxes();
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer((int) (short) 100, categoryItemRenderer10, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint14 = categoryAxis13.getAxisLinePaint();
        float float15 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        categoryPlot0.setDomainAxis(categoryAxis13);
        java.lang.Comparable comparable17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        ringPlot18.setShadowYOffset((double) 100);
        java.awt.Font font21 = ringPlot18.getNoDataMessageFont();
        try {
            categoryAxis13.setTickLabelFont(comparable17, font21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getDomainGridlinePaint();
        categoryPlot0.setOutlinePaint(paint4);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font7 = null;
        stackedAreaRenderer6.setBaseItemLabelFont(font7, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator11, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        stackedAreaRenderer6.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition15, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer6.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color19, true);
        java.awt.Font font23 = null;
        stackedAreaRenderer6.setSeriesItemLabelFont((int) (byte) 0, font23);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        boolean boolean29 = stackedAreaRenderer25.getBaseCreateEntities();
        java.awt.Paint paint30 = stackedAreaRenderer25.getBaseFillPaint();
        stackedAreaRenderer6.setBaseOutlinePaint(paint30);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = stackedAreaRenderer6.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection32);
        boolean boolean34 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        java.awt.Font font18 = null;
        stackedAreaRenderer1.setSeriesItemLabelFont((int) (byte) 0, font18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font21 = null;
        stackedAreaRenderer20.setBaseItemLabelFont(font21, true);
        boolean boolean24 = stackedAreaRenderer20.getBaseCreateEntities();
        java.awt.Paint paint25 = stackedAreaRenderer20.getBaseFillPaint();
        stackedAreaRenderer1.setBaseOutlinePaint(paint25);
        piePlot3D0.setLabelOutlinePaint(paint25);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle29.getMargin();
        double double32 = rectangleInsets30.calculateLeftOutset((double) (short) 100);
        double double33 = rectangleInsets30.getBottom();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType34 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str35 = categoryLabelWidthType34.toString();
        boolean boolean36 = rectangleInsets30.equals((java.lang.Object) str35);
        double double38 = rectangleInsets30.extendHeight((-1.0d));
        org.jfree.chart.util.UnitType unitType39 = rectangleInsets30.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets(unitType39, 4.0d, (double) ' ', (double) 15, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = new org.jfree.chart.util.RectangleInsets(unitType39, 9.0d, (double) 10L, 0.05d, (double) (byte) 1);
        piePlot3D0.setInsets(rectangleInsets49, true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelWidthType34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str35.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertNotNull(unitType39);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (byte) -1, false);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange0, 12.0d);
        java.lang.Object obj6 = null;
        boolean boolean7 = range5.equals(obj6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range5, (double) 10.0f);
        double double10 = rectangleConstraint9.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart9.getXYPlot();
        jFreeChart9.fireChartChanged();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font14 = null;
        stackedAreaRenderer13.setBaseItemLabelFont(font14, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        stackedAreaRenderer13.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator18, false);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle21.setLegendItemGraphicAnchor(rectangleAnchor22);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font26 = null;
        stackedAreaRenderer25.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        stackedAreaRenderer25.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color38, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = stackedAreaRenderer25.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer25.setBasePaint((java.awt.Paint) color44, true);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        ringPlot48.setShadowYOffset((double) 100);
        java.awt.Font font51 = ringPlot48.getNoDataMessageFont();
        stackedAreaRenderer25.setSeriesItemLabelFont((int) '4', font51);
        java.awt.Paint paint53 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean55 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener56 = null;
        categoryPlot54.addChangeListener(plotChangeListener56);
        categoryPlot54.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot54.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment61 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = textTitle64.getMargin();
        double double67 = rectangleInsets65.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font51, paint53, rectangleEdge60, horizontalAlignment61, verticalAlignment62, rectangleInsets65);
        legendTitle21.setLegendItemGraphicPadding(rectangleInsets65);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle21);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = legendTitle21.getLegendItemGraphicEdge();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(xYPlot11);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(horizontalAlignment61);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("SortOrder.ASCENDING");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("CategoryLabelWidthType.RANGE");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean5 = numberAxis3.hasListener((java.util.EventListener) taskSeriesCollection4);
        boolean boolean6 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setTickMarkInsideLength(0.0f);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        java.awt.Paint paint11 = ringPlot10.getLabelLinkPaint();
        numberAxis3.setTickMarkPaint(paint11);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        numberAxis3.setRangeWithMargins((org.jfree.data.Range) dateRange13, false, true);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint19 = dateAxis18.getLabelPaint();
        java.text.DateFormat dateFormat20 = dateAxis18.getDateFormatOverride();
        boolean boolean21 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis22.isHiddenValue((long) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis22.getTickUnit();
        java.awt.Stroke stroke26 = dateAxis22.getAxisLineStroke();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = new org.jfree.chart.axis.SegmentedTimeline((long) (-447), (int) (short) 1, 2958465);
        dateAxis22.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline30);
        dateAxis18.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline30);
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range36 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange33, (double) (byte) -1, false);
        org.jfree.data.Range range39 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange33, (double) 1.0f, false);
        double double40 = dateRange33.getLength();
        dateAxis18.setRange((org.jfree.data.Range) dateRange33, false, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange13, (org.jfree.data.Range) dateRange33);
        double double45 = dateRange13.getCentralValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(dateFormat20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.5d + "'", double45 == 0.5d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue((long) 'a');
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle4.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle4.getPosition();
        textTitle4.setHeight((double) 1);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        textTitle4.draw(graphics2D9, rectangle2D10);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle4.setFont(font12);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle4.getBounds();
        dateAxis0.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle17.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle17.getPosition();
        double double20 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D14, rectangleEdge19);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D14, "WMAP_Plot");
        java.lang.String str23 = chartEntity22.getURLText();
        java.lang.String str24 = chartEntity22.getShapeType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "rect" + "'", str24.equals("rect"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray7 = new float[] { (byte) -1, (-1.0f), 10, (short) 10 };
        float[] floatArray8 = color2.getComponents(floatArray7);
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart9.getLegend();
        java.awt.image.BufferedImage bufferedImage13 = jFreeChart9.createBufferedImage((int) (short) 10, 255);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(bufferedImage13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double23 = barRenderer3D22.getYOffset();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator25 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat26 = standardCategoryToolTipGenerator25.getNumberFormat();
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator27 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", numberFormat26);
        barRenderer3D22.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator27);
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (byte) 1, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator27);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset30);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset32 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset32);
        int int35 = defaultCategoryDataset32.getColumnIndex((java.lang.Comparable) 100.0f);
        multiplePiePlot31.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset32);
        int int37 = defaultCategoryDataset32.getColumnCount();
        defaultCategoryDataset32.removeColumn((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        try {
            java.lang.String str42 = intervalCategoryToolTipGenerator27.generateToolTip((org.jfree.data.category.CategoryDataset) defaultCategoryDataset32, 255, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertNotNull(numberFormat26);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0.0d + "'", number33.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = waterfallBarRenderer0.getBaseURLGenerator();
        java.awt.Paint paint2 = waterfallBarRenderer0.getPositiveBarPaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font4 = null;
        stackedAreaRenderer3.setBaseItemLabelFont(font4, true);
        boolean boolean7 = stackedAreaRenderer3.getBaseCreateEntities();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedAreaRenderer3.getBaseNegativeItemLabelPosition();
        waterfallBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryURLGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesShapesVisible((int) (byte) 0, false);
        lineRenderer3D0.setBaseShapesVisible(false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        boolean boolean5 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker7);
        java.lang.Comparable comparable10 = categoryMarker7.getKey();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 'a' + "'", comparable10.equals('a'));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers((int) (byte) 100, layer2);
        xYPlot0.setDomainCrosshairValue(10.0d, false);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot0);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getRangeAxisEdge(4);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font1 = null;
        stackedAreaRenderer0.setBaseItemLabelFont(font1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer0.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer0.getPositiveItemLabelPosition(0, (int) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedAreaRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        boolean boolean23 = stackedAreaRenderer0.getItemVisible(3, (-1));
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        ringPlot26.setShadowYOffset((double) 100);
        java.awt.Font font29 = ringPlot26.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("", font29);
        stackedAreaRenderer0.setSeriesItemLabelFont((int) (byte) 10, font29);
        boolean boolean33 = stackedAreaRenderer0.isSeriesItemLabelsVisible(100);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot0.addChangeListener(plotChangeListener2);
        categoryPlot0.clearRangeMarkers((int) ' ');
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font9 = null;
        stackedAreaRenderer8.setBaseItemLabelFont(font9, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator13, false);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer8.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedAreaRenderer8.getPositiveItemLabelPosition(4, (int) (byte) -1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        double double24 = stackedAreaRenderer8.getItemLabelAnchorOffset();
        stackedAreaRenderer8.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Font font2 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font2, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition10, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(0, (int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color20, true);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setShadowYOffset((double) 100);
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot30.addChangeListener(plotChangeListener32);
        categoryPlot30.clearRangeMarkers((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle40.getMargin();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font27, paint29, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment45, (double) (byte) 1, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset50.setValue((double) '#', (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable) "ClassContext");
        boolean boolean55 = flowArrangement48.equals((java.lang.Object) "ClassContext");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D57 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int58 = defaultKeyedValues2D57.getColumnCount();
        boolean boolean59 = flowArrangement48.equals((java.lang.Object) defaultKeyedValues2D57);
        int int60 = defaultKeyedValues2D57.getColumnCount();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }
}

