import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            timeSeries3.add(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        try {
            timeSeries3.delete(0, 9999, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = null;
        try {
            timeSeries3.add(timeSeriesDataItem4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
        try {
            timeSeries3.add(timeSeriesDataItem8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.addOrUpdate(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            int int6 = timeSeries4.getIndex(regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries15.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str11 = timeSeries10.getDescription();
        timeSeries10.setRangeDescription("hi!");
        timeSeries10.setDescription("");
        timeSeries10.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month18, (double) (byte) 1, true);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month18, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = null;
        try {
            timeSeries3.add(timeSeriesDataItem14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            java.lang.Number number7 = timeSeries3.getValue(regularTimePeriod6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        timeSeries3.removeAgedItems((long) (byte) 10, true);
        try {
            timeSeries3.setMaximumItemCount((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = null;
        try {
            timeSeries9.add(timeSeriesDataItem18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            day0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        try {
            java.lang.Number number17 = timeSeries3.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "", "");
        try {
            timeSeries3.delete((int) (byte) 1, 7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries3.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        java.lang.String str7 = timeSeries3.getDescription();
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1);
//        long long16 = fixedMillisecond13.getLastMillisecond();
//        long long17 = fixedMillisecond13.getFirstMillisecond();
//        try {
//            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560183728740L + "'", long16 == 1560183728740L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560183728740L + "'", long17 == 1560183728740L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        try {
            java.lang.Number number14 = timeSeries3.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        int int16 = timeSeries9.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries9.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183730068L + "'", long2 == 1560183730068L);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        double double5 = timeSeries4.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        boolean boolean11 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str16 = timeSeries15.getDescription();
        timeSeries15.setRangeDescription("hi!");
        java.lang.String str19 = timeSeries15.getDescription();
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries9.addAndOrUpdate(timeSeries15);
        java.lang.String str22 = timeSeries15.getRangeDescription();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        timeSeries27.setDescription("");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int35 = month33.compareTo((java.lang.Object) (byte) 0);
        int int36 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month33, (double) (-1.0f), false);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 9223372036854775807L, false);
        int int43 = month33.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1);
//        long long10 = fixedMillisecond7.getLastMillisecond();
//        int int11 = day0.compareTo((java.lang.Object) fixedMillisecond7);
//        long long12 = day0.getSerialIndex();
//        java.util.Calendar calendar13 = null;
//        try {
//            day0.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183731503L + "'", long10 == 1560183731503L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries3.add(regularTimePeriod13, (double) 1560183730046L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        int int16 = timeSeries9.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.Object obj6 = timeSeries3.clone();
        try {
            java.lang.Number number8 = timeSeries3.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
        try {
            timeSeries9.add(regularTimePeriod18, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date1, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        int int35 = month27.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year36 = month27.getYear();
        java.util.Calendar calendar37 = null;
        try {
            month27.peg(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(year36);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '4');
        boolean boolean4 = year2.equals((java.lang.Object) 0);
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(2019, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
        int int21 = year19.compareTo((java.lang.Object) (-1.0f));
        int int22 = year19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (short) -1);
        java.util.Calendar calendar25 = null;
        try {
            year19.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        long long18 = day16.getLastMillisecond();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str24 = timeSeries23.getDescription();
//        timeSeries23.setRangeDescription("hi!");
//        timeSeries23.setDescription("");
//        timeSeries23.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries23.addPropertyChangeListener(propertyChangeListener31);
//        java.lang.String str33 = timeSeries23.getDescription();
//        java.lang.String str34 = timeSeries23.getDomainDescription();
//        boolean boolean35 = day16.equals((java.lang.Object) timeSeries23);
//        try {
//            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 43617L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy(9, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str14 = timeSeries13.getDescription();
        boolean boolean15 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str20 = timeSeries19.getDescription();
        timeSeries19.setRangeDescription("hi!");
        java.lang.String str23 = timeSeries19.getDescription();
        int int24 = timeSeries19.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.lang.String str26 = timeSeries19.getRangeDescription();
        timeSeries19.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str32 = timeSeries31.getDescription();
        timeSeries31.setRangeDescription("hi!");
        timeSeries31.setDescription("");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int39 = month37.compareTo((java.lang.Object) (byte) 0);
        int int40 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) month37);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month37, (double) (-1.0f), false);
        int int45 = month37.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year46 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month37, (double) 10L);
        try {
            timeSeries3.delete(52, 8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries3.getDescription();
//        java.lang.String str14 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1);
//        long long22 = fixedMillisecond19.getSerialIndex();
//        java.util.Date date23 = fixedMillisecond19.getTime();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (-9999), false);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str31 = timeSeries30.getDescription();
//        boolean boolean32 = timeSeries30.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str37 = timeSeries36.getDescription();
//        timeSeries36.setRangeDescription("hi!");
//        java.lang.String str40 = timeSeries36.getDescription();
//        int int41 = timeSeries36.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries30.addAndOrUpdate(timeSeries36);
//        java.lang.String str43 = timeSeries36.getRangeDescription();
//        timeSeries36.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str49 = timeSeries48.getDescription();
//        timeSeries48.setRangeDescription("hi!");
//        timeSeries48.setDescription("");
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        int int56 = month54.compareTo((java.lang.Object) (byte) 0);
//        int int57 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) month54);
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month54, (double) (-1.0f), false);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month61, 0.0d);
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
//        java.util.Date date65 = month64.getStart();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date65);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date65);
//        boolean boolean69 = timeSeriesDataItem63.equals((java.lang.Object) date65);
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str74 = timeSeries73.getDescription();
//        boolean boolean75 = timeSeries73.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str80 = timeSeries79.getDescription();
//        timeSeries79.setRangeDescription("hi!");
//        java.lang.String str83 = timeSeries79.getDescription();
//        int int84 = timeSeries79.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries73.addAndOrUpdate(timeSeries79);
//        java.lang.String str86 = timeSeries79.getRangeDescription();
//        timeSeries79.fireSeriesChanged();
//        java.util.List list88 = timeSeries79.getItems();
//        int int89 = timeSeriesDataItem63.compareTo((java.lang.Object) timeSeries79);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries3.addOrUpdate(timeSeriesDataItem63);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560183734202L + "'", long22 == 1560183734202L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
//        org.junit.Assert.assertNull(str49);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNull(str74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertNull(str80);
//        org.junit.Assert.assertNull(str83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
//        org.junit.Assert.assertNotNull(timeSeries85);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "hi!" + "'", str86.equals("hi!"));
//        org.junit.Assert.assertNotNull(list88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getSerialIndex();
//        java.util.Date date9 = fixedMillisecond5.getTime();
//        boolean boolean11 = fixedMillisecond5.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) '4');
//        long long14 = year13.getLastMillisecond();
//        boolean boolean15 = fixedMillisecond5.equals((java.lang.Object) year13);
//        try {
//            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 0, year13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183734296L + "'", long8 == 1560183734296L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60494745600001L) + "'", long14 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 4, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str11 = timeSeries10.getDescription();
        boolean boolean12 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str17 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("hi!");
        java.lang.String str20 = timeSeries16.getDescription();
        int int21 = timeSeries16.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries10.addAndOrUpdate(timeSeries16);
        java.lang.String str23 = timeSeries16.getRangeDescription();
        timeSeries16.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str29 = timeSeries28.getDescription();
        timeSeries28.setRangeDescription("hi!");
        timeSeries28.setDescription("");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int36 = month34.compareTo((java.lang.Object) (byte) 0);
        int int37 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) month34);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month34, (double) (-1.0f), false);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month41, 0.0d);
        timeSeriesDataItem43.setSelected(true);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries3.addOrUpdate(timeSeriesDataItem43);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries13.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '4');
        int int4 = year2.compareTo((java.lang.Object) (-1.0f));
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) '#', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setSelected(false);
        timeSeriesDataItem36.setValue((java.lang.Number) 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        boolean boolean3 = year1.equals((java.lang.Object) 0);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeries3.createCopy((int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '4');
        boolean boolean4 = year2.equals((java.lang.Object) 0);
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) ' ', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        timeSeries3.setNotify(true);
        java.lang.Object obj15 = null;
        boolean boolean16 = timeSeries3.equals(obj15);
        try {
            timeSeries3.delete((int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "" + "'", comparable4.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        long long4 = fixedMillisecond3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        int int8 = timeSeries3.getItemCount();
        try {
            java.lang.Number number10 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        java.lang.String str8 = timeSeries3.getRangeDescription();
        try {
            java.lang.Number number10 = timeSeries3.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        try {
            timeSeries3.delete((int) (byte) 100, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        timeSeries17.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        java.lang.String str36 = timeSeries32.getDescription();
        int int37 = timeSeries32.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
        java.lang.String str39 = timeSeries32.getRangeDescription();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        timeSeries44.setDescription("");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560183730068L);
        long long60 = month50.getLastMillisecond();
        java.util.Calendar calendar61 = null;
        try {
            long long62 = month50.getFirstMillisecond(calendar61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1561964399999L + "'", long60 == 1561964399999L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '4');
        int int4 = year2.compareTo((java.lang.Object) (-1.0f));
        int int5 = year2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries4, seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent9.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = seriesChangeEvent9.getSummary();
        java.lang.String str12 = seriesChangeEvent9.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(seriesChangeInfo10);
        org.junit.Assert.assertNull(seriesChangeInfo11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "hi!", "hi!");
        timeSeries18.setDescription("");
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        java.lang.Object obj23 = timeSeries3.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.util.Date date7 = month6.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) (short) 10);
        try {
            timeSeries3.delete((-9999), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.lang.String str16 = timeSeries3.getDescription();
        double double17 = timeSeries3.getMaxY();
        try {
            timeSeries3.delete(0, (int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day0.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183736868L + "'", long8 == 1560183736868L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) '4');
//        long long13 = year12.getLastMillisecond();
//        boolean boolean14 = fixedMillisecond4.equals((java.lang.Object) year12);
//        java.util.Calendar calendar15 = null;
//        try {
//            year12.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183736953L + "'", long7 == 1560183736953L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60494745600001L) + "'", long13 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 2147483647, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        try {
            timeSeries3.update(2, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1);
//        long long27 = fixedMillisecond24.getLastMillisecond();
//        int int28 = day19.compareTo((java.lang.Object) long27);
//        int int29 = day19.getDayOfMonth();
//        boolean boolean31 = day19.equals((java.lang.Object) (short) 100);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 'a', true);
//        timeSeries15.removeAgedItems(1560183733746L, false);
//        double double38 = timeSeries15.getMinY();
//        int int39 = timeSeries15.getMaximumItemCount();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183737345L + "'", long27 == 1560183737345L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 97.0d + "'", double38 == 97.0d);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        java.util.Calendar calendar21 = null;
        try {
            month16.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        java.util.Date date8 = regularTimePeriod6.getStart();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries4, seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        boolean boolean8 = timeSeries3.getNotify();
        int int9 = timeSeries3.getItemCount();
        timeSeries3.removeAgedItems(0L, false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener62 = null;
        timeSeries3.addChangeListener(seriesChangeListener62);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) '4');
        int int67 = year65.compareTo((java.lang.Object) (-1.0f));
        int int68 = year65.getYear();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year65, (java.lang.Number) 1560183730046L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 52 + "'", int68 == 52);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.util.Date date38 = month37.getStart();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date38);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date38);
        boolean boolean42 = timeSeriesDataItem36.equals((java.lang.Object) date38);
        java.lang.Object obj43 = null;
        int int44 = timeSeriesDataItem36.compareTo(obj43);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str14 = timeSeries13.getDescription();
//        boolean boolean15 = timeSeries13.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str20 = timeSeries19.getDescription();
//        timeSeries19.setRangeDescription("hi!");
//        java.lang.String str23 = timeSeries19.getDescription();
//        int int24 = timeSeries19.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
//        int int26 = timeSeries19.getMaximumItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener27);
//        boolean boolean29 = fixedMillisecond6.equals((java.lang.Object) timeSeries19);
//        long long30 = fixedMillisecond6.getSerialIndex();
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560183739372L + "'", long30 == 1560183739372L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = timeSeries53.getTimePeriod(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        int int10 = day0.getDayOfMonth();
//        java.lang.String str11 = day0.toString();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183739514L + "'", long8 == 1560183739514L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.util.Date date22 = month21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        int int25 = year23.compareTo((java.lang.Object) 0L);
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 1560183728885L);
        long long28 = year23.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        long long8 = fixedMillisecond4.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond4.getLastMillisecond(calendar9);
//        long long11 = fixedMillisecond4.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183740249L + "'", long7 == 1560183740249L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183740249L + "'", long8 == 1560183740249L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183740249L + "'", long10 == 1560183740249L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183740249L + "'", long11 == 1560183740249L);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 1);
//        long long24 = fixedMillisecond21.getSerialIndex();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries28 = timeSeries15.createCopy((int) 'a', (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183740291L + "'", long24 == 1560183740291L);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        double double9 = timeSeries3.getMinY();
        java.lang.Object obj10 = timeSeries3.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        timeSeries17.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        java.lang.String str36 = timeSeries32.getDescription();
        int int37 = timeSeries32.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
        java.lang.String str39 = timeSeries32.getRangeDescription();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        timeSeries44.setDescription("");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560183730068L);
        timeSeries3.setMaximumItemCount((int) (short) 100);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem59);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "1-June-2019", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        timeSeries9.removeAgedItems(1560183734646L, false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        java.util.Date date21 = month16.getEnd();
        java.util.TimeZone timeZone22 = null;
        try {
            org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.lang.Comparable comparable16 = null;
        try {
            timeSeries3.setKey(comparable16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener10);
        try {
            timeSeries4.update((-9999), (java.lang.Number) 1560183734727L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries4, seriesChangeInfo8);
        try {
            timeSeries4.delete(2147483647, (int) ' ', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        long long9 = timeSeries3.getMaximumItemAge();
        timeSeries3.setDomainDescription("");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, "hi!", "hi!");
        int int8 = month3.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "hi!", "hi!");
        timeSeries18.setDescription("");
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        timeSeries27.setDescription("");
        double double33 = timeSeries27.getMinY();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.util.Date date35 = month34.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.lang.Number number37 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
        try {
            timeSeries18.update(regularTimePeriod38, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month9, regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = collection8.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) '4');
        long long12 = year11.getLastMillisecond();
        java.util.Date date13 = year11.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date13, timeZone16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-60494745600001L) + "'", long12 == (-60494745600001L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        long long2 = year1.getLastMillisecond();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-60494745600001L) + "'", long2 == (-60494745600001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        int int35 = month27.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year36 = month27.getYear();
        long long37 = year36.getLastMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) (byte) 0);
        int int3 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        java.util.Calendar calendar62 = null;
        try {
            year54.peg(calendar62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1);
//        long long27 = fixedMillisecond24.getLastMillisecond();
//        int int28 = day19.compareTo((java.lang.Object) long27);
//        int int29 = day19.getDayOfMonth();
//        boolean boolean31 = day19.equals((java.lang.Object) (short) 100);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 'a', true);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str39 = timeSeries38.getDescription();
//        boolean boolean40 = timeSeries38.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str45 = timeSeries44.getDescription();
//        timeSeries44.setRangeDescription("hi!");
//        java.lang.String str48 = timeSeries44.getDescription();
//        int int49 = timeSeries44.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries38.addAndOrUpdate(timeSeries44);
//        java.lang.String str51 = timeSeries44.getRangeDescription();
//        timeSeries44.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str57 = timeSeries56.getDescription();
//        timeSeries56.setRangeDescription("hi!");
//        timeSeries56.setDescription("");
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
//        int int64 = month62.compareTo((java.lang.Object) (byte) 0);
//        int int65 = timeSeries56.getIndex((org.jfree.data.time.RegularTimePeriod) month62);
//        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) month62, (double) (-1.0f), false);
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month69, 0.0d);
//        timeSeriesDataItem71.setValue((java.lang.Number) 1560183728830L);
//        try {
//            timeSeries15.add(timeSeriesDataItem71, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183743471L + "'", long27 == 1560183743471L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem71);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1);
//        long long10 = fixedMillisecond7.getLastMillisecond();
//        int int11 = day0.compareTo((java.lang.Object) fixedMillisecond7);
//        int int12 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183743494L + "'", long10 == 1560183743494L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "hi!", "");
        timeSeries3.setMaximumItemAge(1560183739976L);
        int int6 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        timeSeries3.setNotify(true);
        timeSeries3.setMaximumItemCount(2019);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries3.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        int int4 = year2.compareTo((java.lang.Object) 0L);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        java.util.Calendar calendar62 = null;
        try {
            long long63 = year57.getMiddleMillisecond(calendar62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        timeSeries3.setNotify(true);
        java.lang.Object obj15 = null;
        boolean boolean16 = timeSeries3.equals(obj15);
        try {
            java.lang.Number number18 = timeSeries3.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "org.jfree.data.time.TimePeriodFormatException: hi!", "1-June-2019");
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        java.lang.String str21 = timeSeries17.getDescription();
        int int22 = timeSeries17.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries11.addAndOrUpdate(timeSeries17);
        java.lang.String str24 = timeSeries17.getRangeDescription();
        timeSeries17.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str30 = timeSeries29.getDescription();
        timeSeries29.setRangeDescription("hi!");
        timeSeries29.setDescription("");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        int int37 = month35.compareTo((java.lang.Object) (byte) 0);
        int int38 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month35, (double) (-1.0f), false);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month42, 0.0d);
        timeSeriesDataItem44.setValue((java.lang.Number) 1560183728830L);
        boolean boolean47 = timeSeriesDataItem44.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries6.addOrUpdate(timeSeriesDataItem44);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.util.Date date50 = month49.getStart();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date50);
        boolean boolean54 = fixedMillisecond52.equals((java.lang.Object) 10);
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) (-60526368000000L), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = regularTimePeriod6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("1-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day9.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "org.jfree.data.time.TimePeriodFormatException: hi!", "1-June-2019");
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        java.lang.String str21 = timeSeries17.getDescription();
        int int22 = timeSeries17.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries11.addAndOrUpdate(timeSeries17);
        java.lang.String str24 = timeSeries17.getRangeDescription();
        timeSeries17.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str30 = timeSeries29.getDescription();
        timeSeries29.setRangeDescription("hi!");
        timeSeries29.setDescription("");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        int int37 = month35.compareTo((java.lang.Object) (byte) 0);
        int int38 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month35, (double) (-1.0f), false);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month42, 0.0d);
        timeSeriesDataItem44.setValue((java.lang.Number) 1560183728830L);
        boolean boolean47 = timeSeriesDataItem44.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries6.addOrUpdate(timeSeriesDataItem44);
        timeSeriesDataItem44.setValue((java.lang.Number) 1560183739372L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        java.lang.Object obj9 = null;
//        int int10 = fixedMillisecond4.compareTo(obj9);
//        java.util.Date date11 = fixedMillisecond4.getTime();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        java.util.Calendar calendar13 = null;
//        try {
//            year12.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183744448L + "'", long7 == 1560183744448L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560183739514L, "", "org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1);
//        long long27 = fixedMillisecond24.getLastMillisecond();
//        int int28 = day19.compareTo((java.lang.Object) long27);
//        int int29 = day19.getDayOfMonth();
//        boolean boolean31 = day19.equals((java.lang.Object) (short) 100);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 'a', true);
//        java.util.Calendar calendar35 = null;
//        try {
//            long long36 = day19.getMiddleMillisecond(calendar35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183744968L + "'", long27 == 1560183744968L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        boolean boolean16 = timeSeries15.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries15.removeChangeListener(seriesChangeListener17);
        try {
            timeSeries15.delete(1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) (short) 1, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem36.getPeriod();
        boolean boolean40 = timeSeriesDataItem36.isSelected();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException14);
        java.lang.String str16 = seriesException14.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str16.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 2147483647, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "org.jfree.data.time.TimePeriodFormatException: hi!", "1-June-2019");
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        java.lang.String str21 = timeSeries17.getDescription();
        int int22 = timeSeries17.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries11.addAndOrUpdate(timeSeries17);
        java.lang.String str24 = timeSeries17.getRangeDescription();
        timeSeries17.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str30 = timeSeries29.getDescription();
        timeSeries29.setRangeDescription("hi!");
        timeSeries29.setDescription("");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        int int37 = month35.compareTo((java.lang.Object) (byte) 0);
        int int38 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month35, (double) (-1.0f), false);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month42, 0.0d);
        timeSeriesDataItem44.setValue((java.lang.Number) 1560183728830L);
        boolean boolean47 = timeSeriesDataItem44.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries6.addOrUpdate(timeSeriesDataItem44);
        try {
            int int50 = timeSeriesDataItem48.compareTo((java.lang.Object) 1560183734727L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        int int10 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day12.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183745980L + "'", long8 == 1560183745980L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            java.lang.Number number15 = timeSeries13.getValue(regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        int int35 = month27.compareTo((java.lang.Object) (byte) 100);
        int int36 = month27.getYearValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDomainDescription("June 2019");
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-2013), (int) 'a', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class<?> wildcardClass1 = fixedMillisecond0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
        int int21 = year19.compareTo((java.lang.Object) (-1.0f));
        int int22 = year19.getYear();
        long long23 = year19.getFirstMillisecond();
        long long24 = year19.getLastMillisecond();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560183728885L, false);
        java.util.Calendar calendar28 = null;
        try {
            year19.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60526368000000L) + "'", long23 == (-60526368000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60494745600001L) + "'", long24 == (-60494745600001L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        int int16 = timeSeries9.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries9.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
//        timeSeries3.setMaximumItemAge(0L);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str27 = timeSeries26.getDescription();
//        timeSeries26.setRangeDescription("hi!");
//        timeSeries26.setDescription("");
//        double double32 = timeSeries26.getMinY();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.util.Date date34 = month33.getStart();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
//        java.lang.Number number36 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) year35);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        java.util.Date date38 = month37.getStart();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38);
//        long long41 = day40.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str47 = timeSeries46.getDescription();
//        timeSeries46.setRangeDescription("hi!");
//        timeSeries46.setDescription("");
//        double double52 = timeSeries46.getMinY();
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        java.util.Date date54 = month53.getStart();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
//        java.lang.Number number56 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) year55);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) 1);
//        long long64 = fixedMillisecond61.getLastMillisecond();
//        java.util.Date date65 = fixedMillisecond61.getTime();
//        java.lang.Object obj66 = null;
//        int int67 = fixedMillisecond61.compareTo(obj66);
//        java.util.Calendar calendar68 = null;
//        fixedMillisecond61.peg(calendar68);
//        int int70 = year55.compareTo((java.lang.Object) fixedMillisecond61);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (java.lang.Number) 1560183737717L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43617L + "'", long41 == 43617L);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNull(str47);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNull(number56);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560183746996L + "'", long64 == 1560183746996L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int5 = day3.compareTo((java.lang.Object) 1560183740314L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        timeSeries3.removeAgedItems((long) (byte) 10, true);
        timeSeries3.setMaximumItemAge(2019L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (java.lang.Number) 100.0d);
        timeSeriesDataItem6.setValue((java.lang.Number) 9999);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 1);
//        long long21 = fixedMillisecond18.getLastMillisecond();
//        int int22 = day13.compareTo((java.lang.Object) long21);
//        int int23 = day13.getDayOfMonth();
//        boolean boolean25 = day13.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean29 = year27.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day13, (org.jfree.data.time.RegularTimePeriod) year27);
//        try {
//            timeSeries3.update(9, (java.lang.Number) 1560183735558L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560183747576L + "'", long21 == 1560183747576L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(timeSeries30);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
        java.lang.String str4 = year1.toString();
        java.util.Calendar calendar5 = null;
        try {
            year1.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "52" + "'", str4.equals("52"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = collection8.getClass();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "hi!", "hi!");
        int int15 = month10.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month10.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date17, timeZone19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class22);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(class23);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        timeSeries3.setMaximumItemAge(0L);
        try {
            timeSeries3.delete(5, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        long long9 = timeSeries3.getMaximumItemAge();
        timeSeries3.setMaximumItemAge(1560183744574L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        boolean boolean22 = timeSeries3.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date24);
        java.lang.String str28 = month27.toString();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 12, true);
        java.util.Calendar calendar32 = null;
        try {
            month27.peg(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        boolean boolean10 = timeSeries1.isEmpty();
        int int11 = timeSeries1.getItemCount();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.removeChangeListener(seriesChangeListener19);
        timeSeries9.setNotify(false);
        java.lang.Comparable comparable23 = null;
        try {
            timeSeries9.setKey(comparable23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setValue((java.lang.Number) 1560183728830L);
        boolean boolean39 = timeSeriesDataItem36.isSelected();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo40 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean39, seriesChangeInfo40);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        long long6 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries4, seriesChangeInfo8);
        java.lang.String str10 = seriesChangeEvent9.toString();
        java.lang.Object obj11 = seriesChangeEvent9.getSource();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        int int16 = timeSeries9.getMaximumItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries9.removeChangeListener(seriesChangeListener17);
        int int19 = timeSeries9.getMaximumItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        int int4 = day0.compareTo((java.lang.Object) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar1 = null;
        fixedMillisecond0.peg(calendar1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        int int9 = timeSeriesDataItem6.compareTo((java.lang.Object) 1560183744235L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560183749099L + "'", long3 == 1560183749099L);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.lang.String str16 = timeSeries3.getDescription();
        timeSeries3.setDomainDescription("hi!");
        try {
            timeSeries3.delete(5, 2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        timeSeries53.removeAgedItems(true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond4.getMiddleMillisecond(calendar8);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183749622L + "'", long7 == 1560183749622L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183749622L + "'", long9 == 1560183749622L);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Overwritten values from: 100.0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo9);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        long long3 = month0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        int int10 = day0.getDayOfMonth();
//        boolean boolean12 = day0.equals((java.lang.Object) (short) 100);
//        int int13 = day0.getMonth();
//        java.util.Calendar calendar14 = null;
//        try {
//            day0.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183749800L + "'", long8 == 1560183749800L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.getDataItem(regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        int int14 = timeSeries3.getMaximumItemCount();
        java.lang.String str15 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        try {
            timeSeries3.update((int) (short) 0, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int18 = year16.compareTo((java.lang.Object) 0L);
        int int19 = year16.getYear();
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        long long21 = year16.getSerialIndex();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) long21, seriesChangeInfo22);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '4');
        int int4 = year2.compareTo((java.lang.Object) (-1.0f));
        int int5 = year2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(6, year2);
        int int8 = month7.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        boolean boolean21 = timeSeries3.isEmpty();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        int int35 = month27.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year36 = month27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries4, seriesChangeInfo8);
        java.lang.String str10 = seriesChangeEvent9.toString();
        java.lang.String str11 = seriesChangeEvent9.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setValue((java.lang.Number) 1560183728830L);
        boolean boolean39 = timeSeriesDataItem36.isSelected();
        boolean boolean41 = timeSeriesDataItem36.equals((java.lang.Object) 52);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int2 = month0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries4, seriesChangeInfo8);
        java.lang.String str10 = seriesChangeEvent9.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = seriesChangeEvent9.getSummary();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(seriesChangeInfo11);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.Object obj6 = timeSeries3.clone();
        double double7 = timeSeries3.getMinY();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        double double13 = timeSeries3.getMinY();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        timeSeries18.setDescription("");
        timeSeries18.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
        boolean boolean28 = timeSeries18.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        timeSeries32.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str42 = timeSeries41.getDescription();
        boolean boolean43 = timeSeries41.getNotify();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        timeSeries47.setRangeDescription("hi!");
        java.lang.String str51 = timeSeries47.getDescription();
        int int52 = timeSeries47.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries41.addAndOrUpdate(timeSeries47);
        java.lang.String str54 = timeSeries47.getRangeDescription();
        timeSeries47.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str60 = timeSeries59.getDescription();
        timeSeries59.setRangeDescription("hi!");
        timeSeries59.setDescription("");
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        int int67 = month65.compareTo((java.lang.Object) (byte) 0);
        int int68 = timeSeries59.getIndex((org.jfree.data.time.RegularTimePeriod) month65);
        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month65, (double) (-1.0f), false);
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) month65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) 1560183730068L);
        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = month75.next();
        int int77 = month75.getMonth();
        java.lang.String str78 = month75.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException80 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException82 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException80.addSuppressed((java.lang.Throwable) timePeriodFormatException82);
        int int84 = month75.compareTo((java.lang.Object) timePeriodFormatException82);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) month75);
        timeSeries3.add(timeSeriesDataItem85);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "June 2019" + "'", str78.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem85);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        long long16 = month11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        boolean boolean19 = month11.equals((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.previous();
        long long21 = fixedMillisecond18.getLastMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(1, year2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183727081L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560183749761L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month9.next();
        long long14 = month9.getFirstMillisecond();
        int int15 = month9.getMonth();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month9.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "", "");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str8 = timeSeries7.getDescription();
//        timeSeries7.setRangeDescription("hi!");
//        timeSeries7.setDescription("");
//        timeSeries7.setKey((java.lang.Comparable) 10);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month15, (double) (byte) 1, true);
//        long long20 = month15.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        boolean boolean23 = month15.equals((java.lang.Object) fixedMillisecond22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 1);
//        long long32 = fixedMillisecond29.getLastMillisecond();
//        int int33 = day24.compareTo((java.lang.Object) long32);
//        int int34 = day24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day24.getSerialDate();
//        boolean boolean36 = fixedMillisecond22.equals((java.lang.Object) day24);
//        timeSeries3.setKey((java.lang.Comparable) day24);
//        java.util.Calendar calendar38 = null;
//        try {
//            long long39 = day24.getLastMillisecond(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560183751776L + "'", long32 == 1560183751776L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1);
//        long long27 = fixedMillisecond24.getLastMillisecond();
//        int int28 = day19.compareTo((java.lang.Object) long27);
//        int int29 = day19.getDayOfMonth();
//        boolean boolean31 = day19.equals((java.lang.Object) (short) 100);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 'a', true);
//        timeSeries15.setRangeDescription("June 2019");
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183752029L + "'", long27 == 1560183752029L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        int int62 = year57.getYear();
        long long63 = year57.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        java.util.Date date8 = regularTimePeriod6.getStart();
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        timeSeries17.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        java.lang.String str36 = timeSeries32.getDescription();
        int int37 = timeSeries32.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
        java.lang.String str39 = timeSeries32.getRangeDescription();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        timeSeries44.setDescription("");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560183730068L);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
        int int62 = month60.getMonth();
        java.lang.String str63 = month60.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException65 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException67 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException65.addSuppressed((java.lang.Throwable) timePeriodFormatException67);
        int int69 = month60.compareTo((java.lang.Object) timePeriodFormatException67);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month60);
        timeSeriesDataItem70.setValue((java.lang.Number) 1560183733792L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "June 2019" + "'", str63.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem70);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        java.util.Date date8 = regularTimePeriod6.getStart();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        int int10 = day0.getDayOfMonth();
//        boolean boolean12 = day0.equals((java.lang.Object) (short) 100);
//        int int13 = day0.getMonth();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day0.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183752703L + "'", long8 == 1560183752703L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        java.util.TimeZone timeZone10 = null;
//        try {
//            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date8, timeZone10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183752859L + "'", long7 == 1560183752859L);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "", seriesChangeInfo1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries9.addChangeListener(seriesChangeListener18);
        double double20 = timeSeries9.getMaxY();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str14 = timeSeries13.getDescription();
        boolean boolean15 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str20 = timeSeries19.getDescription();
        timeSeries19.setRangeDescription("hi!");
        java.lang.String str23 = timeSeries19.getDescription();
        int int24 = timeSeries19.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.lang.String str26 = timeSeries19.getRangeDescription();
        timeSeries19.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str32 = timeSeries31.getDescription();
        timeSeries31.setRangeDescription("hi!");
        timeSeries31.setDescription("");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int39 = month37.compareTo((java.lang.Object) (byte) 0);
        int int40 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) month37);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month37, (double) (-1.0f), false);
        int int45 = month37.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year46 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month37, (double) 10L);
        long long49 = month37.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 24234L + "'", long49 == 24234L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
        double double7 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        try {
            java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "org.jfree.data.time.TimePeriodFormatException: hi!", "1-June-2019");
        java.lang.String str7 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 10);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries3.getDescription();
//        java.util.Collection collection14 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str19 = timeSeries18.getDescription();
//        timeSeries18.setRangeDescription("hi!");
//        timeSeries18.setDescription("");
//        timeSeries18.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1);
//        long long36 = fixedMillisecond33.getLastMillisecond();
//        int int37 = day28.compareTo((java.lang.Object) long36);
//        int int38 = day28.getDayOfMonth();
//        boolean boolean40 = day28.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean44 = year42.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) year42);
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, number46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day28.next();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183753606L + "'", long36 == 1560183753606L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        long long16 = month11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        boolean boolean19 = month11.equals((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod20, "", "org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class<?> wildcardClass12 = fixedMillisecond11.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond11.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        java.lang.Object obj9 = null;
//        int int10 = fixedMillisecond4.compareTo(obj9);
//        java.util.Date date11 = fixedMillisecond4.getTime();
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond4.peg(calendar12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond4.previous();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183753843L + "'", long7 == 1560183753843L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        java.util.List list18 = timeSeries9.getItems();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.util.Date date20 = month19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 10);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1560183740493L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond22.getMiddleMillisecond(calendar29);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond22.getMiddleMillisecond(calendar31);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1559372400000L + "'", long32 == 1559372400000L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        timeSeries3.clear();
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((-9999), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        java.lang.String str16 = timeSeries9.getRangeDescription();
//        timeSeries9.fireSeriesChanged();
//        timeSeries9.fireSeriesChanged();
//        timeSeries9.clear();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str24 = timeSeries23.getDescription();
//        timeSeries23.setRangeDescription("hi!");
//        timeSeries23.setDescription("");
//        timeSeries23.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries23.addPropertyChangeListener(propertyChangeListener31);
//        java.lang.String str33 = timeSeries23.getDescription();
//        java.lang.String str34 = timeSeries23.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 1);
//        long long42 = fixedMillisecond39.getSerialIndex();
//        java.util.Date date43 = fixedMillisecond39.getTime();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) (-9999), false);
//        timeSeries9.setKey((java.lang.Comparable) false);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560183754416L + "'", long42 == 1560183754416L);
//        org.junit.Assert.assertNotNull(date43);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=4]");
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        timeSeries17.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        java.lang.String str36 = timeSeries32.getDescription();
        int int37 = timeSeries32.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
        java.lang.String str39 = timeSeries32.getRangeDescription();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        timeSeries44.setDescription("");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560183730068L);
        long long60 = month50.getLastMillisecond();
        java.util.Date date61 = month50.getEnd();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date61);
        java.util.TimeZone timeZone63 = null;
        try {
            org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date61, timeZone63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1561964399999L + "'", long60 == 1561964399999L);
        org.junit.Assert.assertNotNull(date61);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str41 = timeSeries40.getDescription();
        boolean boolean42 = timeSeries40.getNotify();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str47 = timeSeries46.getDescription();
        timeSeries46.setRangeDescription("hi!");
        java.lang.String str50 = timeSeries46.getDescription();
        int int51 = timeSeries46.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries40.addAndOrUpdate(timeSeries46);
        java.lang.String str53 = timeSeries46.getRangeDescription();
        timeSeries46.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str59 = timeSeries58.getDescription();
        timeSeries58.setRangeDescription("hi!");
        timeSeries58.setDescription("");
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        int int66 = month64.compareTo((java.lang.Object) (byte) 0);
        int int67 = timeSeries58.getIndex((org.jfree.data.time.RegularTimePeriod) month64);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month64, (double) (-1.0f), false);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month71, 0.0d);
        boolean boolean74 = timeSeriesDataItem73.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = timeSeriesDataItem73.getPeriod();
        try {
            timeSeries9.add(timeSeriesDataItem73);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class<?> wildcardClass1 = fixedMillisecond0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183754975L + "'", long4 == 1560183754975L);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        long long8 = fixedMillisecond4.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond4.getLastMillisecond(calendar9);
//        boolean boolean12 = fixedMillisecond4.equals((java.lang.Object) 1560183737345L);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183755128L + "'", long7 == 1560183755128L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183755128L + "'", long8 == 1560183755128L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183755128L + "'", long10 == 1560183755128L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        int int4 = day0.compareTo((java.lang.Object) (byte) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 4);
//        boolean boolean7 = day0.equals((java.lang.Object) 4);
//        long long8 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setValue((java.lang.Number) 1560183728830L);
        java.lang.Object obj39 = timeSeriesDataItem36.clone();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str44 = timeSeries43.getDescription();
        timeSeries43.setRangeDescription("hi!");
        timeSeries43.setDescription("");
        timeSeries43.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener51);
        java.lang.String str53 = timeSeries43.getDescription();
        java.util.Collection collection54 = timeSeries43.getTimePeriods();
        int int55 = timeSeriesDataItem36.compareTo((java.lang.Object) timeSeries43);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeries43.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.lang.String str11 = timeSeries3.getDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) 'a');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond4.next();
//        java.util.Date date12 = fixedMillisecond4.getStart();
//        java.util.TimeZone timeZone13 = null;
//        try {
//            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183755286L + "'", long7 == 1560183755286L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        java.util.List list18 = timeSeries9.getItems();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.util.Date date20 = month19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 10);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1560183740493L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond22.getLastMillisecond(calendar29);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        long long2 = year1.getLastMillisecond();
        java.util.Date date3 = year1.getStart();
        int int4 = year1.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-60494745600001L) + "'", long2 == (-60494745600001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo9);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = seriesChangeEvent10.getSummary();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(seriesChangeInfo11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int18 = year16.compareTo((java.lang.Object) 0L);
        int int19 = year16.getYear();
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        long long21 = year16.getSerialIndex();
        java.lang.String str22 = year16.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
//        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1);
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        java.util.Date date12 = fixedMillisecond8.getTime();
//        int int13 = year1.compareTo((java.lang.Object) fixedMillisecond8);
//        long long14 = year1.getFirstMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year1);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = seriesChangeEvent15.getSummary();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = seriesChangeEvent15.getSummary();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183755483L + "'", long11 == 1560183755483L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60526368000000L) + "'", long14 == (-60526368000000L));
//        org.junit.Assert.assertNull(seriesChangeInfo16);
//        org.junit.Assert.assertNull(seriesChangeInfo17);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str5 = timeSeries4.getDescription();
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setDescription("");
        double double10 = timeSeries4.getMinY();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.util.Date date12 = month11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        java.lang.Number number14 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 100, year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str12 = timeSeries11.getDescription();
        timeSeries11.setRangeDescription("hi!");
        timeSeries11.setDescription("");
        timeSeries11.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month19, (double) (byte) 1, true);
        java.lang.Number number24 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        double double25 = timeSeries3.getMinY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException6.toString();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        seriesException10.addSuppressed((java.lang.Throwable) seriesException12);
        java.lang.String str14 = seriesException12.toString();
        seriesException6.addSuppressed((java.lang.Throwable) seriesException12);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str14 = timeSeries13.getDescription();
//        boolean boolean15 = timeSeries13.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str20 = timeSeries19.getDescription();
//        timeSeries19.setRangeDescription("hi!");
//        java.lang.String str23 = timeSeries19.getDescription();
//        int int24 = timeSeries19.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
//        int int26 = timeSeries19.getMaximumItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener27);
//        boolean boolean29 = fixedMillisecond6.equals((java.lang.Object) timeSeries19);
//        java.util.Date date30 = fixedMillisecond6.getStart();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond6.getFirstMillisecond(calendar31);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560183755911L + "'", long32 == 1560183755911L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
        int int21 = year19.compareTo((java.lang.Object) (-1.0f));
        int int22 = year19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (short) -1);
        boolean boolean25 = timeSeries9.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries26 = null;
        try {
            java.util.Collection collection27 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        double double9 = timeSeries3.getMinY();
        java.lang.String str10 = timeSeries3.getRangeDescription();
        timeSeries3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        long long8 = fixedMillisecond4.getFirstMillisecond();
//        long long9 = fixedMillisecond4.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond4.getFirstMillisecond(calendar10);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183756088L + "'", long7 == 1560183756088L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183756088L + "'", long8 == 1560183756088L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183756088L + "'", long9 == 1560183756088L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183756088L + "'", long11 == 1560183756088L);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        java.lang.Object obj5 = null;
        boolean boolean6 = month4.equals(obj5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setSelected(false);
        java.lang.Number number39 = timeSeriesDataItem36.getValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, "hi!", "hi!");
        int int8 = month3.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        timeSeries18.setDescription("");
        timeSeries18.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
        boolean boolean28 = timeSeries18.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        timeSeries32.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str42 = timeSeries41.getDescription();
        boolean boolean43 = timeSeries41.getNotify();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        timeSeries47.setRangeDescription("hi!");
        java.lang.String str51 = timeSeries47.getDescription();
        int int52 = timeSeries47.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries41.addAndOrUpdate(timeSeries47);
        java.lang.String str54 = timeSeries47.getRangeDescription();
        timeSeries47.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str60 = timeSeries59.getDescription();
        timeSeries59.setRangeDescription("hi!");
        timeSeries59.setDescription("");
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        int int67 = month65.compareTo((java.lang.Object) (byte) 0);
        int int68 = timeSeries59.getIndex((org.jfree.data.time.RegularTimePeriod) month65);
        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month65, (double) (-1.0f), false);
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) month65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) 1560183730068L);
        long long75 = month65.getLastMillisecond();
        java.util.Date date76 = month65.getEnd();
        java.util.TimeZone timeZone77 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date76, timeZone77);
        java.util.TimeZone timeZone79 = null;
        java.util.Locale locale80 = null;
        try {
            org.jfree.data.time.Month month81 = new org.jfree.data.time.Month(date76, timeZone79, locale80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1561964399999L + "'", long75 == 1561964399999L);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNull(regularTimePeriod78);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 10);
        long long6 = fixedMillisecond3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, "Value", "Value");
//        timeSeries8.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=4]");
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) '4');
//        int int14 = year12.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1);
//        long long22 = fixedMillisecond19.getLastMillisecond();
//        java.util.Date date23 = fixedMillisecond19.getTime();
//        int int24 = year12.compareTo((java.lang.Object) fixedMillisecond19);
//        long long25 = year12.getFirstMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) year12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = null;
//        try {
//            timeSeries8.add(timeSeriesDataItem28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560183756732L + "'", long22 == 1560183756732L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-60526368000000L) + "'", long25 == (-60526368000000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "", "");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        timeSeries9.setDescription("");
        timeSeries9.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month17, (double) (byte) 1, true);
        long long22 = month17.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) 1.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        int int9 = year4.compareTo((java.lang.Object) day8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        int int14 = day13.getDayOfMonth();
        boolean boolean15 = year4.equals((java.lang.Object) day13);
        java.lang.String str16 = day13.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1-June-2019" + "'", str16.equals("1-June-2019"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setSelected(true);
        java.lang.Object obj39 = null;
        int int40 = timeSeriesDataItem36.compareTo(obj39);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
        int int4 = year1.getYear();
        long long5 = year1.getFirstMillisecond();
        boolean boolean7 = year1.equals((java.lang.Object) 1560183733792L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526368000000L) + "'", long5 == (-60526368000000L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int2 = year1.getYear();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        boolean boolean20 = timeSeries18.getNotify();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str25 = timeSeries24.getDescription();
        timeSeries24.setRangeDescription("hi!");
        java.lang.String str28 = timeSeries24.getDescription();
        int int29 = timeSeries24.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries18.addAndOrUpdate(timeSeries24);
        int int31 = timeSeries24.getMaximumItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries24.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = fixedMillisecond11.equals((java.lang.Object) timeSeries24);
        timeSeries24.removeAgedItems(1560183733911L, true);
        boolean boolean38 = year1.equals((java.lang.Object) 1560183733911L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int2 = month0.getMonth();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str7 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("hi!");
        timeSeries6.setDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int14 = month12.compareTo((java.lang.Object) (byte) 0);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        timeSeries6.removeAgedItems((long) (byte) 10, true);
        boolean boolean19 = month0.equals((java.lang.Object) (byte) 10);
        long long20 = month0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        double double2 = timeSeries1.getMaxY();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 4);
        java.lang.Object obj6 = seriesChangeEvent5.getSource();
        java.lang.String str7 = seriesChangeEvent5.toString();
        boolean boolean8 = month0.equals((java.lang.Object) seriesChangeEvent5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 4 + "'", obj6.equals(4));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=4]" + "'", str7.equals("org.jfree.data.event.SeriesChangeEvent[source=4]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560183744574L, "Overwritten values from: 100.0", "org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
        timeSeries3.setMaximumItemCount((int) (short) 1);
        boolean boolean9 = timeSeries3.getNotify();
        try {
            java.lang.Number number11 = timeSeries3.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        java.util.Date date21 = month16.getEnd();
        java.util.Calendar calendar22 = null;
        try {
            month16.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries3.getDescription();
//        java.util.Collection collection14 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str19 = timeSeries18.getDescription();
//        timeSeries18.setRangeDescription("hi!");
//        timeSeries18.setDescription("");
//        timeSeries18.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1);
//        long long36 = fixedMillisecond33.getLastMillisecond();
//        int int37 = day28.compareTo((java.lang.Object) long36);
//        int int38 = day28.getDayOfMonth();
//        boolean boolean40 = day28.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean44 = year42.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) year42);
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, number46);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 1);
//        long long55 = fixedMillisecond52.getSerialIndex();
//        java.util.Date date56 = fixedMillisecond52.getTime();
//        boolean boolean58 = fixedMillisecond52.equals((java.lang.Object) 'a');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond52.next();
//        java.util.Date date60 = fixedMillisecond52.getStart();
//        long long61 = fixedMillisecond52.getLastMillisecond();
//        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 1.0d);
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond52.getLastMillisecond(calendar64);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183757863L + "'", long36 == 1560183757863L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560183757865L + "'", long55 == 1560183757865L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560183757865L + "'", long61 == 1560183757865L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560183757865L + "'", long65 == 1560183757865L);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries3.getDescription();
//        java.util.Collection collection14 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str19 = timeSeries18.getDescription();
//        timeSeries18.setRangeDescription("hi!");
//        timeSeries18.setDescription("");
//        timeSeries18.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1);
//        long long36 = fixedMillisecond33.getLastMillisecond();
//        int int37 = day28.compareTo((java.lang.Object) long36);
//        int int38 = day28.getDayOfMonth();
//        boolean boolean40 = day28.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean44 = year42.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) year42);
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, number46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day28.previous();
//        int int49 = day28.getMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183758150L + "'", long36 == 1560183758150L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) (short) 1);
        java.lang.String str15 = month12.toString();
        java.util.Calendar calendar16 = null;
        try {
            month12.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        int int62 = year57.getYear();
        long long63 = year57.getFirstMillisecond();
        int int64 = year57.getYear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1546329600000L + "'", long63 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        timeSeries12.setRangeDescription("hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries12.removeChangeListener(seriesChangeListener16);
        long long18 = timeSeries12.getMaximumItemAge();
        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, 0.0d);
        java.lang.Class class27 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str32 = timeSeries31.getDescription();
        timeSeries31.setRangeDescription("hi!");
        timeSeries31.setDescription("");
        timeSeries31.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener39);
        boolean boolean41 = timeSeries31.getNotify();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str46 = timeSeries45.getDescription();
        timeSeries45.setRangeDescription("hi!");
        timeSeries45.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str55 = timeSeries54.getDescription();
        boolean boolean56 = timeSeries54.getNotify();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str61 = timeSeries60.getDescription();
        timeSeries60.setRangeDescription("hi!");
        java.lang.String str64 = timeSeries60.getDescription();
        int int65 = timeSeries60.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries54.addAndOrUpdate(timeSeries60);
        java.lang.String str67 = timeSeries60.getRangeDescription();
        timeSeries60.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str73 = timeSeries72.getDescription();
        timeSeries72.setRangeDescription("hi!");
        timeSeries72.setDescription("");
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month();
        int int80 = month78.compareTo((java.lang.Object) (byte) 0);
        int int81 = timeSeries72.getIndex((org.jfree.data.time.RegularTimePeriod) month78);
        timeSeries60.add((org.jfree.data.time.RegularTimePeriod) month78, (double) (-1.0f), false);
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) month78);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month78, (java.lang.Number) 1560183730068L);
        long long88 = month78.getLastMillisecond();
        java.util.Date date89 = month78.getEnd();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent90 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date89);
        java.util.TimeZone timeZone91 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date89, timeZone91);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem87);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1561964399999L + "'", long88 == 1561964399999L);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNull(regularTimePeriod92);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        timeSeries26.setRangeDescription("hi!");
        timeSeries26.setDescription("");
        double double32 = timeSeries26.getMinY();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        java.util.Date date34 = month33.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        java.lang.Number number36 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) year35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.util.Date date38 = month37.getStart();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38);
        long long41 = day40.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day40);
        timeSeries42.setDomainDescription("June 2019");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43617L + "'", long41 == 43617L);
        org.junit.Assert.assertNotNull(timeSeries42);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class<?> wildcardClass1 = fixedMillisecond0.getClass();
        java.util.Calendar calendar2 = null;
        fixedMillisecond0.peg(calendar2);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        timeSeries3.removeAgedItems((long) 9, true);
        java.lang.Object obj65 = timeSeries3.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(obj65);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.util.Date date35 = month34.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month34);
        boolean boolean38 = month34.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.lang.Number number9 = timeSeries3.getValue(regularTimePeriod8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        int int12 = month10.getMonth();
        long long13 = month10.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month10, (double) 1560183736455L);
        long long16 = month10.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo9);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        java.lang.String str12 = seriesChangeEvent10.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 6);
        org.jfree.data.time.Year year3 = month2.getYear();
        long long4 = month2.getFirstMillisecond();
        long long5 = month2.getSerialIndex();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61951708800000L) + "'", long4 == (-61951708800000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 83L + "'", long5 == 83L);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        java.lang.Object obj6 = timeSeries3.clone();
//        timeSeries3.removeAgedItems(false);
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        long long13 = day11.getLastMillisecond();
//        int int15 = day11.compareTo((java.lang.Object) (byte) -1);
//        int int16 = day11.getYear();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day11);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.removeAgedItems(43617L, true);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        boolean boolean22 = timeSeries3.equals((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = null;
        try {
            timeSeries3.add(timeSeriesDataItem23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 6, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        int int14 = timeSeries3.getMaximumItemCount();
        boolean boolean15 = timeSeries3.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(regularTimePeriod16, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond4.getFirstMillisecond(calendar8);
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond4.peg(calendar10);
//        long long12 = fixedMillisecond4.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183760453L + "'", long7 == 1560183760453L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183760453L + "'", long9 == 1560183760453L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183760453L + "'", long12 == 1560183760453L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class<?> wildcardClass1 = fixedMillisecond0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183760525L + "'", long4 == 1560183760525L);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str23 = timeSeries22.getDescription();
        boolean boolean24 = timeSeries22.getNotify();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str29 = timeSeries28.getDescription();
        timeSeries28.setRangeDescription("hi!");
        java.lang.String str32 = timeSeries28.getDescription();
        int int33 = timeSeries28.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries22.addAndOrUpdate(timeSeries28);
        java.lang.String str35 = timeSeries28.getRangeDescription();
        timeSeries28.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str41 = timeSeries40.getDescription();
        timeSeries40.setRangeDescription("hi!");
        timeSeries40.setDescription("");
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        int int48 = month46.compareTo((java.lang.Object) (byte) 0);
        int int49 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) month46);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month46, (double) (-1.0f), false);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month53, 0.0d);
        timeSeriesDataItem55.setValue((java.lang.Number) 1560183728830L);
        java.lang.Object obj58 = timeSeriesDataItem55.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries9.addOrUpdate(timeSeriesDataItem55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeries9.getNextTimePeriod();
        boolean boolean61 = timeSeries9.getNotify();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str14 = timeSeries13.getDescription();
        boolean boolean15 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str20 = timeSeries19.getDescription();
        timeSeries19.setRangeDescription("hi!");
        java.lang.String str23 = timeSeries19.getDescription();
        int int24 = timeSeries19.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.lang.String str26 = timeSeries19.getRangeDescription();
        timeSeries19.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str32 = timeSeries31.getDescription();
        timeSeries31.setRangeDescription("hi!");
        timeSeries31.setDescription("");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int39 = month37.compareTo((java.lang.Object) (byte) 0);
        int int40 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) month37);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month37, (double) (-1.0f), false);
        int int45 = month37.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year46 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month37, (double) 10L);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str53 = timeSeries52.getDescription();
        boolean boolean54 = timeSeries52.getNotify();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str59 = timeSeries58.getDescription();
        timeSeries58.setRangeDescription("hi!");
        java.lang.String str62 = timeSeries58.getDescription();
        int int63 = timeSeries58.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries52.addAndOrUpdate(timeSeries58);
        java.lang.String str65 = timeSeries58.getRangeDescription();
        timeSeries58.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str71 = timeSeries70.getDescription();
        timeSeries70.setRangeDescription("hi!");
        timeSeries70.setDescription("");
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
        int int78 = month76.compareTo((java.lang.Object) (byte) 0);
        int int79 = timeSeries70.getIndex((org.jfree.data.time.RegularTimePeriod) month76);
        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) month76, (double) (-1.0f), false);
        org.jfree.data.time.Month month83 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month83, 0.0d);
        java.lang.Object obj86 = timeSeriesDataItem85.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries3.addOrUpdate(timeSeriesDataItem85);
        timeSeriesDataItem87.setValue((java.lang.Number) 1560183753475L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "hi!" + "'", str65.equals("hi!"));
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem85);
        org.junit.Assert.assertNotNull(obj86);
        org.junit.Assert.assertNotNull(timeSeriesDataItem87);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "org.jfree.data.time.TimePeriodFormatException: hi!", "1-June-2019");
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, (java.lang.Number) 100.0d);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.util.Date date16 = month15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries6.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) year20);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries21.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        java.lang.String str44 = month36.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone9 = null;
//        java.util.Locale locale10 = null;
//        try {
//            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone9, locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183760996L + "'", long7 == 1560183760996L);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.addOrUpdate(timeSeriesDataItem2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        long long2 = year1.getLastMillisecond();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-60494745600001L) + "'", long2 == (-60494745600001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        timeSeries12.setRangeDescription("hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries12.removeChangeListener(seriesChangeListener16);
        long long18 = timeSeries12.getMaximumItemAge();
        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, 0.0d);
        java.lang.Class class27 = timeSeries12.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries30 = timeSeries12.createCopy((-9999), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(class27);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        java.util.Collection collection62 = timeSeries61.getTimePeriods();
        timeSeries61.setDomainDescription("org.jfree.data.general.SeriesException: ");
        java.util.Collection collection65 = timeSeries61.getTimePeriods();
        timeSeries61.setMaximumItemCount(12);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(collection62);
        org.junit.Assert.assertNotNull(collection65);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str8 = timeSeries7.getDescription();
//        timeSeries7.setRangeDescription("hi!");
//        timeSeries7.setDescription("");
//        timeSeries7.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener15);
//        java.lang.String str17 = timeSeries7.getDescription();
//        java.lang.String str18 = timeSeries7.getDomainDescription();
//        boolean boolean19 = day0.equals((java.lang.Object) timeSeries7);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str34 = timeSeries33.getDescription();
//        boolean boolean35 = timeSeries33.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str40 = timeSeries39.getDescription();
//        timeSeries39.setRangeDescription("hi!");
//        java.lang.String str43 = timeSeries39.getDescription();
//        int int44 = timeSeries39.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries33.addAndOrUpdate(timeSeries39);
//        int int46 = timeSeries39.getMaximumItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
//        timeSeries39.removeChangeListener(seriesChangeListener47);
//        boolean boolean49 = fixedMillisecond26.equals((java.lang.Object) timeSeries39);
//        int int50 = day0.compareTo((java.lang.Object) boolean49);
//        int int51 = day0.getDayOfMonth();
//        java.util.Calendar calendar52 = null;
//        try {
//            day0.peg(calendar52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2147483647 + "'", int46 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries3.getDescription();
//        java.lang.String str14 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1);
//        long long22 = fixedMillisecond19.getSerialIndex();
//        java.util.Date date23 = fixedMillisecond19.getTime();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (-9999), false);
//        long long27 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 1);
//        boolean boolean35 = fixedMillisecond19.equals((java.lang.Object) 1);
//        long long36 = fixedMillisecond19.getMiddleMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560183761798L + "'", long22 == 1560183761798L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183761798L + "'", long27 == 1560183761798L);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183761798L + "'", long36 == 1560183761798L);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            int int10 = timeSeries3.getIndex(regularTimePeriod9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        java.lang.Object obj9 = null;
//        int int10 = fixedMillisecond4.compareTo(obj9);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond4.peg(calendar11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond4.getFirstMillisecond(calendar13);
//        long long15 = fixedMillisecond4.getFirstMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183761969L + "'", long7 == 1560183761969L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560183761969L + "'", long14 == 1560183761969L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560183761969L + "'", long15 == 1560183761969L);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1);
//        long long10 = fixedMillisecond7.getLastMillisecond();
//        int int11 = day0.compareTo((java.lang.Object) fixedMillisecond7);
//        long long12 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183761985L + "'", long10 == 1560183761985L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        boolean boolean16 = timeSeries15.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries15.removeChangeListener(seriesChangeListener17);
        timeSeries15.setRangeDescription("June 2019");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries15.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.util.Date date22 = month21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        int int25 = year23.compareTo((java.lang.Object) 0L);
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 1560183728885L);
        java.lang.Object obj28 = null;
        int int29 = year23.compareTo(obj28);
        java.util.Calendar calendar30 = null;
        try {
            year23.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        java.lang.String str16 = timeSeries3.getDomainDescription();
        try {
            java.lang.Number number18 = timeSeries3.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries61.createCopy(0, 2019);
        try {
            timeSeries64.update((-1), (java.lang.Number) 1560183728885L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(timeSeries64);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str8 = timeSeries7.getDescription();
//        timeSeries7.setRangeDescription("hi!");
//        timeSeries7.setDescription("");
//        timeSeries7.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener15);
//        java.lang.String str17 = timeSeries7.getDescription();
//        java.lang.String str18 = timeSeries7.getDomainDescription();
//        boolean boolean19 = day0.equals((java.lang.Object) timeSeries7);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener20);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        long long2 = year1.getLastMillisecond();
        java.util.Date date3 = year1.getStart();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-60494745600001L) + "'", long2 == (-60494745600001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day9.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone9 = null;
//        java.util.Locale locale10 = null;
//        try {
//            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date8, timeZone9, locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183762671L + "'", long7 == 1560183762671L);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone9 = null;
//        try {
//            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8, timeZone9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183762704L + "'", long7 == 1560183762704L);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
//        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries3.getDescription();
//        double double17 = timeSeries3.getMaxY();
//        double double18 = timeSeries3.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 1);
//        long long26 = fixedMillisecond23.getLastMillisecond();
//        java.util.Date date27 = fixedMillisecond23.getTime();
//        java.lang.Object obj28 = null;
//        int int29 = fixedMillisecond23.compareTo(obj28);
//        java.util.Date date30 = fixedMillisecond23.getTime();
//        int int31 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond23.getLastMillisecond(calendar32);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond23.getLastMillisecond(calendar34);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183762882L + "'", long26 == 1560183762882L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560183762882L + "'", long33 == 1560183762882L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560183762882L + "'", long35 == 1560183762882L);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        int int6 = day3.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        int int4 = day0.compareTo((java.lang.Object) (byte) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 4);
//        boolean boolean7 = day0.equals((java.lang.Object) 4);
//        java.lang.String str8 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) 'a');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond4.next();
//        long long12 = fixedMillisecond4.getSerialIndex();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183762966L + "'", long7 == 1560183762966L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183762966L + "'", long12 == 1560183762966L);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        try {
            timeSeries3.update((int) '4', (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day0.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183763180L + "'", long8 == 1560183763180L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        long long8 = fixedMillisecond4.getFirstMillisecond();
//        long long9 = fixedMillisecond4.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str14 = timeSeries13.getDescription();
//        boolean boolean15 = timeSeries13.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str20 = timeSeries19.getDescription();
//        timeSeries19.setRangeDescription("hi!");
//        java.lang.String str23 = timeSeries19.getDescription();
//        int int24 = timeSeries19.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        timeSeries25.removeAgedItems(1560183739976L, false);
//        boolean boolean30 = fixedMillisecond4.equals((java.lang.Object) 1560183739976L);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183763264L + "'", long7 == 1560183763264L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183763264L + "'", long8 == 1560183763264L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183763264L + "'", long9 == 1560183763264L);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1);
        java.lang.String str6 = year5.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        boolean boolean22 = timeSeries3.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date24);
        java.lang.String str28 = month27.toString();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 12, true);
        java.lang.Object obj32 = null;
        boolean boolean33 = timeSeries3.equals(obj32);
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183748396L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        boolean boolean22 = timeSeries3.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date24);
        java.lang.String str28 = month27.toString();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 12, true);
        java.lang.Object obj32 = null;
        boolean boolean33 = timeSeries3.equals(obj32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str38 = timeSeries37.getDescription();
        boolean boolean39 = timeSeries37.getNotify();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str44 = timeSeries43.getDescription();
        timeSeries43.setRangeDescription("hi!");
        java.lang.String str47 = timeSeries43.getDescription();
        int int48 = timeSeries43.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries37.addAndOrUpdate(timeSeries43);
        java.lang.String str50 = timeSeries43.getRangeDescription();
        timeSeries43.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str56 = timeSeries55.getDescription();
        timeSeries55.setRangeDescription("hi!");
        timeSeries55.setDescription("");
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
        int int63 = month61.compareTo((java.lang.Object) (byte) 0);
        int int64 = timeSeries55.getIndex((org.jfree.data.time.RegularTimePeriod) month61);
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) month61, (double) (-1.0f), false);
        int int69 = month61.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month61, (double) 12);
        try {
            timeSeries3.add(timeSeriesDataItem71, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1);
//        long long27 = fixedMillisecond24.getLastMillisecond();
//        int int28 = day19.compareTo((java.lang.Object) long27);
//        int int29 = day19.getDayOfMonth();
//        boolean boolean31 = day19.equals((java.lang.Object) (short) 100);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 'a', true);
//        int int35 = day19.getDayOfMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183764176L + "'", long27 == 1560183764176L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        try {
            timeSeries3.delete((int) (short) -1, (int) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        java.lang.Object obj37 = timeSeriesDataItem36.clone();
        boolean boolean38 = timeSeriesDataItem36.isSelected();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        double double5 = timeSeries4.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        boolean boolean11 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str16 = timeSeries15.getDescription();
        timeSeries15.setRangeDescription("hi!");
        java.lang.String str19 = timeSeries15.getDescription();
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries9.addAndOrUpdate(timeSeries15);
        java.lang.String str22 = timeSeries15.getRangeDescription();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        timeSeries27.setDescription("");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int35 = month33.compareTo((java.lang.Object) (byte) 0);
        int int36 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month33, (double) (-1.0f), false);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 9223372036854775807L, false);
        java.util.Collection collection43 = timeSeries4.getTimePeriods();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries4.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(collection43);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 6);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) (short) 1);
        boolean boolean15 = timeSeries3.getNotify();
        timeSeries3.clear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
        long long2 = year1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
//        int int21 = year19.compareTo((java.lang.Object) (-1.0f));
//        int int22 = year19.getYear();
//        long long23 = year19.getFirstMillisecond();
//        long long24 = year19.getLastMillisecond();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560183728885L, false);
//        int int28 = timeSeries15.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str33 = timeSeries32.getDescription();
//        timeSeries32.setRangeDescription("hi!");
//        timeSeries32.setDescription("");
//        timeSeries32.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener40);
//        java.lang.String str42 = timeSeries32.getDescription();
//        java.lang.String str43 = timeSeries32.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 1);
//        long long51 = fixedMillisecond48.getSerialIndex();
//        java.util.Date date52 = fixedMillisecond48.getTime();
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) (-9999), false);
//        long long56 = fixedMillisecond48.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) 1);
//        boolean boolean64 = fixedMillisecond48.equals((java.lang.Object) 1);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 1560183736829L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60526368000000L) + "'", long23 == (-60526368000000L));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60494745600001L) + "'", long24 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560183764438L + "'", long51 == 1560183764438L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560183764438L + "'", long56 == 1560183764438L);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "June 2019", "");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135740800000L) + "'", long2 == (-62135740800000L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str25 = timeSeries24.getDescription();
        boolean boolean26 = timeSeries24.getNotify();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        java.lang.String str34 = timeSeries30.getDescription();
        int int35 = timeSeries30.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries24.addAndOrUpdate(timeSeries30);
        boolean boolean37 = timeSeries30.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries9.addAndOrUpdate(timeSeries30);
        double double39 = timeSeries38.getMinY();
        try {
            timeSeries38.delete(4, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException14);
        java.lang.String str16 = seriesException14.toString();
        java.lang.String str17 = seriesException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        seriesException14.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.String str25 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str16.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        int int10 = day0.getDayOfMonth();
//        long long11 = day0.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183764739L + "'", long8 == 1560183764739L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) 'a');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond4.next();
//        java.util.Date date12 = fixedMillisecond4.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183764776L + "'", long7 == 1560183764776L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560183764776L + "'", long15 == 1560183764776L);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        boolean boolean16 = timeSeries15.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries15.removeChangeListener(seriesChangeListener17);
        timeSeries15.setRangeDescription("June 2019");
        timeSeries15.fireSeriesChanged();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "hi!", "hi!");
        int int18 = month13.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month13.next();
        boolean boolean20 = timeSeries3.equals((java.lang.Object) regularTimePeriod19);
        timeSeries3.setRangeDescription("10-June-2019");
        java.lang.Comparable comparable23 = timeSeries3.getKey();
        java.lang.Object obj24 = timeSeries3.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 100.0d + "'", comparable23.equals(100.0d));
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries4, seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent9.getSummary();
        java.lang.String str11 = seriesChangeEvent9.toString();
        java.lang.Object obj12 = seriesChangeEvent9.getSource();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(seriesChangeInfo10);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.lang.Number number9 = timeSeries3.getValue(regularTimePeriod8);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy((int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        timeSeries12.setRangeDescription("hi!");
        timeSeries12.setDescription("");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int20 = month18.compareTo((java.lang.Object) (byte) 0);
        int int21 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        java.util.List list22 = timeSeries12.getItems();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        int int27 = year25.compareTo((java.lang.Object) 0L);
        int int28 = year25.getYear();
        java.lang.Number number29 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) year25);
        boolean boolean30 = year8.equals((java.lang.Object) timeSeries12);
        java.lang.String str31 = year8.toString();
        java.util.Date date32 = year8.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        java.util.Date date34 = month33.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
        int int38 = year8.compareTo((java.lang.Object) month36);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
        timeSeries3.setMaximumItemCount((int) (short) 1);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries3.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str13 = timeSeries12.getDescription();
//        timeSeries12.setRangeDescription("hi!");
//        timeSeries12.setDescription("");
//        timeSeries12.setKey((java.lang.Comparable) 10);
//        java.util.Collection collection20 = timeSeries12.getTimePeriods();
//        boolean boolean21 = fixedMillisecond4.equals((java.lang.Object) timeSeries12);
//        java.lang.String str22 = timeSeries12.getDescription();
//        timeSeries12.setRangeDescription("");
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183765397L + "'", long7 == 1560183765397L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        int int9 = year4.compareTo((java.lang.Object) day8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        int int14 = day13.getDayOfMonth();
        boolean boolean15 = year4.equals((java.lang.Object) day13);
        java.util.Calendar calendar16 = null;
        try {
            day13.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str7 = timeSeries6.getDescription();
//        boolean boolean8 = timeSeries6.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str13 = timeSeries12.getDescription();
//        timeSeries12.setRangeDescription("hi!");
//        java.lang.String str16 = timeSeries12.getDescription();
//        int int17 = timeSeries12.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries6.addAndOrUpdate(timeSeries12);
//        boolean boolean19 = timeSeries18.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 1);
//        long long30 = fixedMillisecond27.getLastMillisecond();
//        int int31 = day22.compareTo((java.lang.Object) long30);
//        int int32 = day22.getDayOfMonth();
//        boolean boolean34 = day22.equals((java.lang.Object) (short) 100);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day22, (double) 'a', true);
//        timeSeries18.removeAgedItems(1560183733746L, false);
//        double double41 = timeSeries18.getMinY();
//        java.lang.Comparable comparable42 = timeSeries18.getKey();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str47 = timeSeries46.getDescription();
//        timeSeries46.setRangeDescription("hi!");
//        timeSeries46.setDescription("");
//        timeSeries46.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener54 = null;
//        timeSeries46.addPropertyChangeListener(propertyChangeListener54);
//        java.lang.String str56 = timeSeries46.getDescription();
//        java.util.Collection collection57 = timeSeries46.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str62 = timeSeries61.getDescription();
//        timeSeries61.setRangeDescription("hi!");
//        timeSeries61.setDescription("");
//        timeSeries61.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timeSeries61.addPropertyChangeListener(propertyChangeListener69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries75.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, (double) 1);
//        long long79 = fixedMillisecond76.getLastMillisecond();
//        int int80 = day71.compareTo((java.lang.Object) long79);
//        int int81 = day71.getDayOfMonth();
//        boolean boolean83 = day71.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean87 = year85.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries61.createCopy((org.jfree.data.time.RegularTimePeriod) day71, (org.jfree.data.time.RegularTimePeriod) year85);
//        java.lang.Number number89 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day71, number89);
//        int int91 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) day71);
//        int int92 = day0.compareTo((java.lang.Object) day71);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560183765438L + "'", long30 == 1560183765438L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 97.0d + "'", double41 == 97.0d);
//        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + "Overwritten values from: 100.0" + "'", comparable42.equals("Overwritten values from: 100.0"));
//        org.junit.Assert.assertNull(str47);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "" + "'", str56.equals(""));
//        org.junit.Assert.assertNotNull(collection57);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertNull(timeSeriesDataItem78);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560183765442L + "'", long79 == 1560183765442L);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 10 + "'", int81 == 10);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(timeSeries88);
//        org.junit.Assert.assertNull(timeSeriesDataItem90);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str17 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("hi!");
        timeSeries16.setDescription("");
        timeSeries16.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timeSeries16.getDescription();
        java.util.Collection collection27 = timeSeries16.getTimePeriods();
        java.util.Collection collection28 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo29);
        timeSeries3.setMaximumItemAge(1560183756746L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(collection28);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.util.TimeZone timeZone10 = null;
//        try {
//            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183765756L + "'", long7 == 1560183765756L);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        java.util.Calendar calendar9 = null;
//        try {
//            day0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        java.lang.String str16 = timeSeries3.getDomainDescription();
        try {
            timeSeries3.delete(4, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date2, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str25 = timeSeries24.getDescription();
        boolean boolean26 = timeSeries24.getNotify();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        java.lang.String str34 = timeSeries30.getDescription();
        int int35 = timeSeries30.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries24.addAndOrUpdate(timeSeries30);
        boolean boolean37 = timeSeries30.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries9.addAndOrUpdate(timeSeries30);
        timeSeries30.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
//        long long16 = month11.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        boolean boolean19 = month11.equals((java.lang.Object) fixedMillisecond18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1);
//        long long28 = fixedMillisecond25.getLastMillisecond();
//        int int29 = day20.compareTo((java.lang.Object) long28);
//        int int30 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day20.getSerialDate();
//        boolean boolean32 = fixedMillisecond18.equals((java.lang.Object) day20);
//        int int33 = day20.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day20.previous();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560183766262L + "'", long28 == 1560183766262L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        int int8 = timeSeries3.getItemCount();
        timeSeries3.removeAgedItems(false);
        long long11 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setSelected(true);
        java.lang.Number number39 = timeSeriesDataItem36.getValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        java.lang.String str16 = timeSeries3.getRangeDescription();
        try {
            timeSeries3.delete((int) (short) 100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond4.getMiddleMillisecond(calendar8);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183767250L + "'", long7 == 1560183767250L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183767250L + "'", long9 == 1560183767250L);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.Number number13 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        long long15 = year12.getLastMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener62 = null;
        timeSeries3.addChangeListener(seriesChangeListener62);
        timeSeries3.setMaximumItemCount(0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        java.lang.String str16 = timeSeries9.getRangeDescription();
//        timeSeries9.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str22 = timeSeries21.getDescription();
//        timeSeries21.setRangeDescription("hi!");
//        timeSeries21.setDescription("");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
//        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 1);
//        long long44 = fixedMillisecond41.getSerialIndex();
//        long long45 = fixedMillisecond41.getFirstMillisecond();
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond41.getLastMillisecond(calendar46);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 1560183740249L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560183767495L + "'", long44 == 1560183767495L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560183767495L + "'", long45 == 1560183767495L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560183767495L + "'", long47 == 1560183767495L);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
//        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries3.getDescription();
//        double double17 = timeSeries3.getMaxY();
//        double double18 = timeSeries3.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 1);
//        long long26 = fixedMillisecond23.getLastMillisecond();
//        java.util.Date date27 = fixedMillisecond23.getTime();
//        java.lang.Object obj28 = null;
//        int int29 = fixedMillisecond23.compareTo(obj28);
//        java.util.Date date30 = fixedMillisecond23.getTime();
//        int int31 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str36 = timeSeries35.getDescription();
//        long long37 = timeSeries35.getMaximumItemAge();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        timeSeries35.removeAgedItems((long) (byte) 100, false);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries3.addAndOrUpdate(timeSeries35);
//        timeSeries44.removeAgedItems(true);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183767515L + "'", long26 == 1560183767515L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(timeSeries44);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183731186L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
        timeSeries3.setMaximumItemCount((int) (short) 1);
        boolean boolean9 = timeSeries3.getNotify();
        java.lang.Comparable comparable10 = timeSeries3.getKey();
        timeSeries3.setMaximumItemCount(52);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 100.0d + "'", comparable10.equals(100.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = collection8.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) collection8, seriesChangeInfo10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        int int14 = timeSeries3.getMaximumItemCount();
        boolean boolean15 = timeSeries3.isEmpty();
        int int16 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        long long10 = year9.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getDayOfMonth();
        java.util.Calendar calendar5 = null;
        try {
            day3.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
//        int int2 = year1.getYear();
//        java.lang.Number number3 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1);
//        long long12 = fixedMillisecond9.getSerialIndex();
//        java.util.Date date13 = fixedMillisecond9.getTime();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str18 = timeSeries17.getDescription();
//        timeSeries17.setRangeDescription("hi!");
//        timeSeries17.setDescription("");
//        timeSeries17.setKey((java.lang.Comparable) 10);
//        java.util.Collection collection25 = timeSeries17.getTimePeriods();
//        boolean boolean26 = fixedMillisecond9.equals((java.lang.Object) timeSeries17);
//        int int27 = timeSeriesDataItem4.compareTo((java.lang.Object) boolean26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem4, "org.jfree.data.time.TimePeriodFormatException: hi!", "hi!");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183768431L + "'", long12 == 1560183768431L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str17 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("hi!");
        timeSeries16.setDescription("");
        timeSeries16.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timeSeries16.getDescription();
        java.util.Collection collection27 = timeSeries16.getTimePeriods();
        java.util.Collection collection28 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries3.setDomainDescription("June 2019");
        java.lang.Class class31 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(class31);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) '4');
//        long long13 = year12.getLastMillisecond();
//        boolean boolean14 = fixedMillisecond4.equals((java.lang.Object) year12);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str19 = timeSeries18.getDescription();
//        timeSeries18.setRangeDescription("hi!");
//        timeSeries18.setDescription("");
//        timeSeries18.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1);
//        long long36 = fixedMillisecond33.getLastMillisecond();
//        int int37 = day28.compareTo((java.lang.Object) long36);
//        int int38 = day28.getDayOfMonth();
//        boolean boolean40 = day28.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean44 = year42.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) year42);
//        boolean boolean46 = year12.equals((java.lang.Object) year42);
//        long long47 = year42.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183768588L + "'", long7 == 1560183768588L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60494745600001L) + "'", long13 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183768591L + "'", long36 == 1560183768591L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-60494745600001L) + "'", long47 == (-60494745600001L));
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        boolean boolean7 = timeSeries3.getNotify();
//        boolean boolean8 = timeSeries3.getNotify();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        long long11 = day9.getLastMillisecond();
//        int int13 = day9.compareTo((java.lang.Object) (byte) -1);
//        int int14 = day9.getYear();
//        long long15 = day9.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "hi!", "hi!");
        timeSeries18.setDescription("");
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        try {
            java.lang.Number number24 = timeSeries22.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        double double2 = timeSeries1.getMaxY();
        java.util.Collection collection3 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        boolean boolean19 = timeSeries9.isEmpty();
        try {
            timeSeries9.delete((-2013), (int) (byte) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2013");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=4]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        int int10 = day0.getDayOfMonth();
//        int int11 = day0.getYear();
//        long long12 = day0.getLastMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183769075L + "'", long8 == 1560183769075L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        boolean boolean10 = timeSeries1.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries1.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 1);
//        long long20 = fixedMillisecond17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond17.previous();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str28 = timeSeries27.getDescription();
//        timeSeries27.setRangeDescription("hi!");
//        timeSeries27.setDescription("");
//        timeSeries27.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries27.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str41 = timeSeries40.getDescription();
//        timeSeries40.setRangeDescription("hi!");
//        timeSeries40.setDescription("");
//        timeSeries40.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener48 = null;
//        timeSeries40.addPropertyChangeListener(propertyChangeListener48);
//        java.lang.String str50 = timeSeries40.getDescription();
//        java.util.Collection collection51 = timeSeries40.getTimePeriods();
//        java.util.Collection collection52 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        timeSeries27.setDomainDescription("June 2019");
//        int int55 = year23.compareTo((java.lang.Object) timeSeries27);
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) year23);
//        try {
//            timeSeries1.update((int) (short) 10, (java.lang.Number) 1560183740314L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560183769099L + "'", long20 == 1560183769099L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(timeSeries56);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        int int9 = year4.compareTo((java.lang.Object) day8);
        int int10 = day8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        long long8 = fixedMillisecond4.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183769243L + "'", long7 == 1560183769243L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183769243L + "'", long8 == 1560183769243L);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
        long long2 = year1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62119972800001L) + "'", long2 == (-62119972800001L));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        long long7 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        long long8 = fixedMillisecond4.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond4.getLastMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond4.getMiddleMillisecond(calendar11);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183769337L + "'", long7 == 1560183769337L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183769337L + "'", long8 == 1560183769337L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183769337L + "'", long10 == 1560183769337L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183769337L + "'", long12 == 1560183769337L);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        try {
            timeSeries3.update(10, (java.lang.Number) 1560183739976L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        timeSeries3.removeAgedItems((long) 9, true);
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str69 = timeSeries68.getDescription();
        boolean boolean70 = timeSeries68.getNotify();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str75 = timeSeries74.getDescription();
        timeSeries74.setRangeDescription("hi!");
        java.lang.String str78 = timeSeries74.getDescription();
        int int79 = timeSeries74.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries68.addAndOrUpdate(timeSeries74);
        java.lang.String str81 = timeSeries74.getRangeDescription();
        timeSeries74.fireSeriesChanged();
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year((int) '4');
        int int86 = year84.compareTo((java.lang.Object) (-1.0f));
        int int87 = year84.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year84, (double) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year84);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener91 = null;
        timeSeries3.removeChangeListener(seriesChangeListener91);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "hi!" + "'", str81.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 52 + "'", int87 == 52);
        org.junit.Assert.assertNull(timeSeriesDataItem89);
        org.junit.Assert.assertNull(timeSeriesDataItem90);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.lang.String str16 = timeSeries3.getDescription();
        double double17 = timeSeries3.getMaxY();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        int int21 = month19.getMonth();
        long long22 = month19.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19, "org.jfree.data.time.TimePeriodFormatException: hi!", "1-June-2019");
        java.lang.String str26 = timeSeries25.getDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        boolean boolean32 = timeSeries30.getNotify();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str37 = timeSeries36.getDescription();
        timeSeries36.setRangeDescription("hi!");
        java.lang.String str40 = timeSeries36.getDescription();
        int int41 = timeSeries36.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries30.addAndOrUpdate(timeSeries36);
        java.lang.String str43 = timeSeries36.getRangeDescription();
        timeSeries36.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str49 = timeSeries48.getDescription();
        timeSeries48.setRangeDescription("hi!");
        timeSeries48.setDescription("");
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        int int56 = month54.compareTo((java.lang.Object) (byte) 0);
        int int57 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) month54);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month54, (double) (-1.0f), false);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month61, 0.0d);
        timeSeriesDataItem63.setValue((java.lang.Number) 1560183728830L);
        boolean boolean66 = timeSeriesDataItem63.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries25.addOrUpdate(timeSeriesDataItem63);
        timeSeries3.add(timeSeriesDataItem63);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
        java.util.Date date70 = month69.getStart();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date70);
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(date70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month72.next();
        java.lang.Number number74 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month72);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 1560183728830L + "'", number74.equals(1560183728830L));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        java.lang.String str16 = month11.toString();
        long long17 = month11.getLastMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month11.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str6 = timeSeries5.getDescription();
        timeSeries5.setRangeDescription("hi!");
        timeSeries5.setDescription("");
        timeSeries5.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        timeSeries18.setDescription("");
        timeSeries18.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
        java.lang.String str28 = timeSeries18.getDescription();
        java.util.Collection collection29 = timeSeries18.getTimePeriods();
        java.util.Collection collection30 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        timeSeries5.setDomainDescription("June 2019");
        int int33 = year1.compareTo((java.lang.Object) timeSeries5);
        int int34 = timeSeries5.getItemCount();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        long long2 = year1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-60494745600001L) + "'", long2 == (-60494745600001L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setValue((java.lang.Number) 1560183728830L);
        java.lang.Object obj39 = timeSeriesDataItem36.clone();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str44 = timeSeries43.getDescription();
        timeSeries43.setRangeDescription("hi!");
        timeSeries43.setDescription("");
        timeSeries43.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener51);
        java.lang.String str53 = timeSeries43.getDescription();
        java.util.Collection collection54 = timeSeries43.getTimePeriods();
        int int55 = timeSeriesDataItem36.compareTo((java.lang.Object) timeSeries43);
        java.util.Collection collection56 = timeSeries43.getTimePeriods();
        boolean boolean57 = timeSeries43.getNotify();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        boolean boolean22 = timeSeries3.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date24);
        java.lang.String str28 = month27.toString();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 12, true);
        java.lang.String str32 = month27.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183770562L + "'", long7 == 1560183770562L);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        timeSeries3.removeAgedItems(1560183753135L, true);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
        timeSeries3.setKey((java.lang.Comparable) month20);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener23);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        java.lang.String str11 = day0.toString();
//        int int12 = day0.getMonth();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183770680L + "'", long8 == 1560183770680L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries9.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str21 = timeSeries20.getDescription();
//        boolean boolean22 = timeSeries20.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str27 = timeSeries26.getDescription();
//        timeSeries26.setRangeDescription("hi!");
//        java.lang.String str30 = timeSeries26.getDescription();
//        int int31 = timeSeries26.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries20.addAndOrUpdate(timeSeries26);
//        java.lang.String str33 = timeSeries26.getRangeDescription();
//        timeSeries26.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str39 = timeSeries38.getDescription();
//        timeSeries38.setRangeDescription("hi!");
//        timeSeries38.setDescription("");
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        int int46 = month44.compareTo((java.lang.Object) (byte) 0);
//        int int47 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month44);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month44, (double) (-1.0f), false);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month51, 0.0d);
//        timeSeriesDataItem53.setValue((java.lang.Number) 1560183728830L);
//        boolean boolean56 = timeSeriesDataItem53.isSelected();
//        timeSeries9.add(timeSeriesDataItem53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeries9.getNextTimePeriod();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (double) 1);
//        long long66 = fixedMillisecond63.getLastMillisecond();
//        java.util.Date date67 = fixedMillisecond63.getTime();
//        java.lang.Object obj68 = null;
//        int int69 = fixedMillisecond63.compareTo(obj68);
//        java.util.Date date70 = fixedMillisecond63.getTime();
//        long long71 = fixedMillisecond63.getLastMillisecond();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (double) (-62135740800000L));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560183770703L + "'", long66 == 1560183770703L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560183770703L + "'", long71 == 1560183770703L);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) '4');
//        long long13 = year12.getLastMillisecond();
//        boolean boolean14 = fixedMillisecond4.equals((java.lang.Object) year12);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1);
//        long long22 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond19.previous();
//        int int24 = year12.compareTo((java.lang.Object) fixedMillisecond19);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo25 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year12, seriesChangeInfo25);
//        java.lang.Object obj27 = seriesChangeEvent26.getSource();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183770881L + "'", long7 == 1560183770881L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60494745600001L) + "'", long13 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560183770883L + "'", long22 == 1560183770883L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(obj27);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "hi!", "hi!");
        int int12 = month7.getYearValue();
        timeSeries4.setKey((java.lang.Comparable) month7);
        long long14 = month7.getSerialIndex();
        java.lang.String str15 = month7.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        boolean boolean20 = timeSeries18.getNotify();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str25 = timeSeries24.getDescription();
        timeSeries24.setRangeDescription("hi!");
        java.lang.String str28 = timeSeries24.getDescription();
        int int29 = timeSeries24.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries18.addAndOrUpdate(timeSeries24);
        java.lang.String str31 = timeSeries24.getRangeDescription();
        timeSeries24.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str37 = timeSeries36.getDescription();
        timeSeries36.setRangeDescription("hi!");
        timeSeries36.setDescription("");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        int int44 = month42.compareTo((java.lang.Object) (byte) 0);
        int int45 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-1.0f), false);
        java.lang.Number number49 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month42, (double) 11);
        java.util.Calendar calendar52 = null;
        try {
            long long53 = month42.getFirstMillisecond(calendar52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(number49);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
//        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries3.getDescription();
//        double double17 = timeSeries3.getMaxY();
//        double double18 = timeSeries3.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 1);
//        long long26 = fixedMillisecond23.getLastMillisecond();
//        java.util.Date date27 = fixedMillisecond23.getTime();
//        java.lang.Object obj28 = null;
//        int int29 = fixedMillisecond23.compareTo(obj28);
//        java.util.Date date30 = fixedMillisecond23.getTime();
//        int int31 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) '4');
//        int int37 = year35.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) 1);
//        long long45 = fixedMillisecond42.getLastMillisecond();
//        java.util.Date date46 = fixedMillisecond42.getTime();
//        int int47 = year35.compareTo((java.lang.Object) fixedMillisecond42);
//        long long48 = year35.getFirstMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 1560183749075L);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries55.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (double) 1);
//        long long59 = fixedMillisecond56.getSerialIndex();
//        java.util.Date date60 = fixedMillisecond56.getTime();
//        long long61 = fixedMillisecond56.getLastMillisecond();
//        int int62 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        long long63 = fixedMillisecond56.getMiddleMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183771054L + "'", long26 == 1560183771054L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560183771056L + "'", long45 == 1560183771056L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-60526368000000L) + "'", long48 == (-60526368000000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560183771058L + "'", long59 == 1560183771058L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560183771058L + "'", long61 == 1560183771058L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560183771058L + "'", long63 == 1560183771058L);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        timeSeries12.setRangeDescription("hi!");
        timeSeries12.setDescription("");
        timeSeries12.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener20);
        java.lang.String str22 = timeSeries12.getDescription();
        java.lang.String str23 = timeSeries12.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        boolean boolean31 = timeSeries12.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.util.Date date33 = month32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date33);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date33);
        java.lang.String str37 = month36.toString();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month36, (double) 12, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month36, (double) 1560183740493L);
        long long43 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        boolean boolean13 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str18 = timeSeries17.getDescription();
//        timeSeries17.setRangeDescription("hi!");
//        timeSeries17.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str27 = timeSeries26.getDescription();
//        boolean boolean28 = timeSeries26.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str33 = timeSeries32.getDescription();
//        timeSeries32.setRangeDescription("hi!");
//        java.lang.String str36 = timeSeries32.getDescription();
//        int int37 = timeSeries32.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
//        java.lang.String str39 = timeSeries32.getRangeDescription();
//        timeSeries32.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str45 = timeSeries44.getDescription();
//        timeSeries44.setRangeDescription("hi!");
//        timeSeries44.setDescription("");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
//        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month50);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560183730068L);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        java.lang.String str62 = day61.toString();
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str67 = timeSeries66.getDescription();
//        timeSeries66.setRangeDescription("hi!");
//        boolean boolean70 = timeSeries66.getNotify();
//        timeSeries66.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo72 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent73 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries66, seriesChangeInfo72);
//        java.lang.String str74 = seriesChangeEvent73.toString();
//        int int75 = day61.compareTo((java.lang.Object) str74);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) 1560183744702L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "10-June-2019" + "'", str62.equals("10-June-2019"));
//        org.junit.Assert.assertNull(str67);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond5, seriesChangeInfo6);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        int int16 = timeSeries3.getItemCount();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) '4');
        boolean boolean20 = year18.equals((java.lang.Object) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) 1560183751792L);
        int int23 = timeSeries3.getMaximumItemCount();
        timeSeries3.setMaximumItemCount(8);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        java.util.Date date21 = month16.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        java.util.TimeZone timeZone23 = null;
        try {
            org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date21, timeZone23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        timeSeries3.removeAgedItems((long) 9, true);
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str69 = timeSeries68.getDescription();
        boolean boolean70 = timeSeries68.getNotify();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str75 = timeSeries74.getDescription();
        timeSeries74.setRangeDescription("hi!");
        java.lang.String str78 = timeSeries74.getDescription();
        int int79 = timeSeries74.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries68.addAndOrUpdate(timeSeries74);
        java.lang.String str81 = timeSeries74.getRangeDescription();
        timeSeries74.fireSeriesChanged();
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year((int) '4');
        int int86 = year84.compareTo((java.lang.Object) (-1.0f));
        int int87 = year84.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year84, (double) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year84);
        java.util.Collection collection91 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "hi!" + "'", str81.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 52 + "'", int87 == 52);
        org.junit.Assert.assertNull(timeSeriesDataItem89);
        org.junit.Assert.assertNull(timeSeriesDataItem90);
        org.junit.Assert.assertNotNull(collection91);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
        int int21 = year19.compareTo((java.lang.Object) (-1.0f));
        int int22 = year19.getYear();
        long long23 = year19.getFirstMillisecond();
        long long24 = year19.getLastMillisecond();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560183728885L, false);
        java.lang.String str28 = year19.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60526368000000L) + "'", long23 == (-60526368000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60494745600001L) + "'", long24 == (-60494745600001L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("52");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        boolean boolean22 = timeSeries3.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date24);
        java.lang.String str28 = month27.toString();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 12, true);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.util.Date date33 = month32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date33);
        boolean boolean37 = fixedMillisecond35.equals((java.lang.Object) 10);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 1560183733792L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries3.getDescription();
//        java.util.Collection collection14 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str19 = timeSeries18.getDescription();
//        timeSeries18.setRangeDescription("hi!");
//        timeSeries18.setDescription("");
//        timeSeries18.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1);
//        long long36 = fixedMillisecond33.getLastMillisecond();
//        int int37 = day28.compareTo((java.lang.Object) long36);
//        int int38 = day28.getDayOfMonth();
//        boolean boolean40 = day28.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean44 = year42.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) year42);
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, number46);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 1);
//        long long55 = fixedMillisecond52.getSerialIndex();
//        java.util.Date date56 = fixedMillisecond52.getTime();
//        boolean boolean58 = fixedMillisecond52.equals((java.lang.Object) 'a');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond52.next();
//        java.util.Date date60 = fixedMillisecond52.getStart();
//        long long61 = fixedMillisecond52.getLastMillisecond();
//        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 1.0d);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries66 = timeSeries3.createCopy((int) (byte) -1, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183771995L + "'", long36 == 1560183771995L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560183772000L + "'", long55 == 1560183772000L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560183772000L + "'", long61 == 1560183772000L);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        int int4 = year2.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 1560183741337L);
        long long7 = year2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
//        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries3.getDescription();
//        double double17 = timeSeries3.getMaxY();
//        double double18 = timeSeries3.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 1);
//        long long26 = fixedMillisecond23.getLastMillisecond();
//        java.util.Date date27 = fixedMillisecond23.getTime();
//        java.lang.Object obj28 = null;
//        int int29 = fixedMillisecond23.compareTo(obj28);
//        java.util.Date date30 = fixedMillisecond23.getTime();
//        int int31 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str36 = timeSeries35.getDescription();
//        long long37 = timeSeries35.getMaximumItemAge();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        timeSeries35.removeAgedItems((long) (byte) 100, false);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries3.addAndOrUpdate(timeSeries35);
//        int int45 = timeSeries3.getItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener46);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183772239L + "'", long26 == 1560183772239L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str17 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("hi!");
        timeSeries16.setDescription("");
        timeSeries16.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timeSeries16.getDescription();
        java.util.Collection collection27 = timeSeries16.getTimePeriods();
        java.util.Collection collection28 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.util.Date date32 = month31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date32);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 1560183770562L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        int int9 = timeSeries3.getItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int10 = year8.compareTo((java.lang.Object) 1560183734727L);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560183734727L, "Overwritten values from: 100.0", "org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        long long9 = fixedMillisecond6.getSerialIndex();
//        long long10 = fixedMillisecond6.getFirstMillisecond();
//        java.lang.Object obj11 = null;
//        int int12 = fixedMillisecond6.compareTo(obj11);
//        long long13 = fixedMillisecond6.getFirstMillisecond();
//        boolean boolean14 = month0.equals((java.lang.Object) fixedMillisecond6);
//        long long15 = month0.getSerialIndex();
//        int int16 = month0.getYearValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183772615L + "'", long9 == 1560183772615L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183772615L + "'", long10 == 1560183772615L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183772615L + "'", long13 == 1560183772615L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-2013), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
        int int4 = year1.getYear();
        java.lang.String str5 = year1.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "52" + "'", str5.equals("52"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str9 = timeSeries8.getDescription();
        boolean boolean10 = timeSeries8.getNotify();
        java.lang.String str11 = timeSeries8.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.previous();
        java.lang.Number number14 = timeSeries8.getValue(regularTimePeriod13);
        boolean boolean15 = month4.equals((java.lang.Object) regularTimePeriod13);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month4.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
//        long long16 = month11.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        boolean boolean19 = month11.equals((java.lang.Object) fixedMillisecond18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1);
//        long long28 = fixedMillisecond25.getLastMillisecond();
//        int int29 = day20.compareTo((java.lang.Object) long28);
//        int int30 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day20.getSerialDate();
//        boolean boolean32 = fixedMillisecond18.equals((java.lang.Object) day20);
//        int int33 = day20.getMonth();
//        java.util.Date date34 = day20.getEnd();
//        java.util.TimeZone timeZone35 = null;
//        try {
//            org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34, timeZone35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560183772826L + "'", long28 == 1560183772826L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(date34);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.previous();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        java.util.Date date39 = month38.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date39);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date39);
        int int44 = month34.compareTo((java.lang.Object) month43);
        long long45 = month43.getMiddleMillisecond();
        long long46 = month43.getLastMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560668399999L + "'", long45 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1561964399999L + "'", long46 == 1561964399999L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("1-June-2019");
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
//        long long16 = month11.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        boolean boolean19 = month11.equals((java.lang.Object) fixedMillisecond18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1);
//        long long28 = fixedMillisecond25.getLastMillisecond();
//        int int29 = day20.compareTo((java.lang.Object) long28);
//        int int30 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day20.getSerialDate();
//        boolean boolean32 = fixedMillisecond18.equals((java.lang.Object) day20);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "org.jfree.data.event.SeriesChangeEvent[source=4]");
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560183773025L + "'", long28 == 1560183773025L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        boolean boolean3 = year1.equals((java.lang.Object) 0);
        long long4 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60526368000000L) + "'", long4 == (-60526368000000L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        long long62 = year54.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 2019L + "'", long62 == 2019L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        timeSeries17.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        java.lang.String str36 = timeSeries32.getDescription();
        int int37 = timeSeries32.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
        java.lang.String str39 = timeSeries32.getRangeDescription();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        timeSeries44.setDescription("");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560183730068L);
        timeSeries3.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeries3.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem59);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries3.getDescription();
//        java.util.Collection collection14 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str19 = timeSeries18.getDescription();
//        timeSeries18.setRangeDescription("hi!");
//        timeSeries18.setDescription("");
//        timeSeries18.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1);
//        long long36 = fixedMillisecond33.getLastMillisecond();
//        int int37 = day28.compareTo((java.lang.Object) long36);
//        int int38 = day28.getDayOfMonth();
//        boolean boolean40 = day28.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean44 = year42.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) year42);
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, number46);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 1);
//        long long55 = fixedMillisecond52.getSerialIndex();
//        java.util.Date date56 = fixedMillisecond52.getTime();
//        boolean boolean58 = fixedMillisecond52.equals((java.lang.Object) 'a');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond52.next();
//        java.util.Date date60 = fixedMillisecond52.getStart();
//        long long61 = fixedMillisecond52.getLastMillisecond();
//        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 1.0d);
//        java.util.Date date64 = fixedMillisecond52.getTime();
//        java.util.Calendar calendar65 = null;
//        fixedMillisecond52.peg(calendar65);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183773296L + "'", long36 == 1560183773296L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560183773298L + "'", long55 == 1560183773298L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560183773298L + "'", long61 == 1560183773298L);
//        org.junit.Assert.assertNotNull(date64);
//    }
//}

