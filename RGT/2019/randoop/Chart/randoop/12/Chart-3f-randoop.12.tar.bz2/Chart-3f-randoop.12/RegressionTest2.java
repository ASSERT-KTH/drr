import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year57.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year57.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test002");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.util.Collection collection11 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.util.Date date13 = month12.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
//        boolean boolean20 = timeSeriesDataItem18.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
//        java.lang.Object obj22 = timeSeriesDataItem18.clone();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) '4');
//        int int26 = year24.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 1);
//        long long34 = fixedMillisecond31.getLastMillisecond();
//        java.util.Date date35 = fixedMillisecond31.getTime();
//        int int36 = year24.compareTo((java.lang.Object) fixedMillisecond31);
//        long long37 = year24.getFirstMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year24);
//        boolean boolean39 = timeSeriesDataItem18.equals((java.lang.Object) seriesChangeEvent38);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560183809594L + "'", long34 == 1560183809594L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-60526368000000L) + "'", long37 == (-60526368000000L));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException6.toString();
        java.lang.String str9 = seriesException6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        seriesException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("52");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) seriesException17);
        java.lang.String str19 = timePeriodFormatException13.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str9.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.lang.Number number9 = timeSeries3.getValue(regularTimePeriod8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        int int12 = month10.getMonth();
        long long13 = month10.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month10, (double) 1560183736455L);
        int int16 = timeSeries3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, "hi!", "hi!");
        int int8 = month3.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.util.Date date16 = month15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date16);
        java.util.TimeZone timeZone23 = null;
        try {
            org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date16, timeZone23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        double double18 = timeSeries9.getMinY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries9.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 4);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 4 + "'", obj2.equals(4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=4]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=4]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=4]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=4]"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("1-June-2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("10-June-2019");
        java.lang.String str10 = seriesException9.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException9);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: 10-June-2019" + "'", str10.equals("org.jfree.data.general.SeriesException: 10-June-2019"));
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 1);
//        long long23 = fixedMillisecond20.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        java.util.Date date27 = month26.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) day32);
//        java.util.Calendar calendar34 = null;
//        try {
//            day32.peg(calendar34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560183809834L + "'", long23 == 1560183809834L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560183809834L + "'", long25 == 1560183809834L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(timeSeries33);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test010");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        int int10 = month9.getYearValue();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183809847L + "'", long7 == 1560183809847L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test011");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(11, 6);
//        org.jfree.data.time.Year year9 = month8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str15 = timeSeries14.getDescription();
//        timeSeries14.setRangeDescription("hi!");
//        timeSeries14.setDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        int int22 = month20.compareTo((java.lang.Object) (byte) 0);
//        int int23 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) month20);
//        double double24 = timeSeries14.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener25);
//        java.lang.String str27 = timeSeries14.getDescription();
//        double double28 = timeSeries14.getMaxY();
//        double double29 = timeSeries14.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 1);
//        long long37 = fixedMillisecond34.getLastMillisecond();
//        java.util.Date date38 = fixedMillisecond34.getTime();
//        java.lang.Object obj39 = null;
//        int int40 = fixedMillisecond34.compareTo(obj39);
//        java.util.Date date41 = fixedMillisecond34.getTime();
//        int int42 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries3.createCopy(regularTimePeriod10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy((int) (short) 10, (-2013));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
//        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560183809870L + "'", long37 == 1560183809870L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries43);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str12 = timeSeries11.getDescription();
        timeSeries11.setRangeDescription("hi!");
        timeSeries11.setDescription("");
        timeSeries11.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month19, (double) (byte) 1, true);
        java.lang.Number number24 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        double double25 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries3.addChangeListener(seriesChangeListener26);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test015");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        java.lang.Object obj9 = null;
//        int int10 = fixedMillisecond4.compareTo(obj9);
//        java.util.Date date11 = fixedMillisecond4.getTime();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        java.lang.String str14 = day12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.next();
//        long long16 = day12.getFirstMillisecond();
//        boolean boolean17 = fixedMillisecond4.equals((java.lang.Object) day12);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.util.Date date19 = month18.getStart();
//        int int20 = month18.getMonth();
//        long long21 = month18.getFirstMillisecond();
//        boolean boolean22 = fixedMillisecond4.equals((java.lang.Object) long21);
//        long long23 = fixedMillisecond4.getFirstMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183810003L + "'", long7 == 1560183810003L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1559372400000L + "'", long21 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560183810003L + "'", long23 == 1560183810003L);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, "hi!", "hi!");
        int int8 = month3.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, "hi!", "52");
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str20 = timeSeries19.getDescription();
        timeSeries19.setRangeDescription("hi!");
        timeSeries19.setDescription("");
        double double25 = timeSeries19.getMinY();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.util.Date date27 = month26.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        java.lang.Number number29 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
        long long31 = year28.getSerialIndex();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate(regularTimePeriod33, (java.lang.Number) 1560183806297L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        timeSeries9.clear();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener20);
        java.lang.String str22 = timeSeries9.getDomainDescription();
        double double23 = timeSeries9.getMaxY();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.util.Date date7 = month6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "10-June-2019", seriesChangeInfo11);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        boolean boolean15 = day9.equals((java.lang.Object) seriesChangeEvent12);
        int int16 = year1.compareTo((java.lang.Object) day9);
        int int17 = day9.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
//        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int12);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries13.removeChangeListener(seriesChangeListener14);
//        timeSeries13.setMaximumItemAge((long) 4);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.util.Date date19 = month18.getStart();
//        int int20 = month18.getMonth();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 1);
//        long long30 = fixedMillisecond27.getSerialIndex();
//        long long31 = fixedMillisecond27.getFirstMillisecond();
//        java.lang.Object obj32 = null;
//        int int33 = fixedMillisecond27.compareTo(obj32);
//        long long34 = fixedMillisecond27.getFirstMillisecond();
//        boolean boolean35 = month21.equals((java.lang.Object) fixedMillisecond27);
//        long long36 = fixedMillisecond27.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Calendar calendar38 = null;
//        try {
//            long long39 = month18.getFirstMillisecond(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560183810132L + "'", long30 == 1560183810132L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560183810132L + "'", long31 == 1560183810132L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560183810132L + "'", long34 == 1560183810132L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183810132L + "'", long36 == 1560183810132L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test020");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        boolean boolean13 = timeSeries3.getNotify();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.util.Date date15 = month14.getStart();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "hi!", "hi!");
//        timeSeries18.setDescription("");
//        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
//        java.util.Collection collection23 = timeSeries18.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1);
//        long long31 = fixedMillisecond28.getLastMillisecond();
//        long long32 = fixedMillisecond28.getFirstMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getLastMillisecond(calendar33);
//        java.lang.Number number35 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries18.removePropertyChangeListener(propertyChangeListener36);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener38);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeries18.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560183810157L + "'", long31 == 1560183810157L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560183810157L + "'", long32 == 1560183810157L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560183810157L + "'", long34 == 1560183810157L);
//        org.junit.Assert.assertNull(number35);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        boolean boolean4 = day0.equals((java.lang.Object) 100L);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str25 = timeSeries24.getDescription();
        boolean boolean26 = timeSeries24.getNotify();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        java.lang.String str34 = timeSeries30.getDescription();
        int int35 = timeSeries30.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries24.addAndOrUpdate(timeSeries30);
        boolean boolean37 = timeSeries30.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries9.addAndOrUpdate(timeSeries30);
        timeSeries9.setMaximumItemCount(7);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        java.util.Date date42 = month41.getStart();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day44, (double) 1560183760040L, false);
        java.lang.String str49 = day44.toString();
        java.util.Calendar calendar50 = null;
        try {
            long long51 = day44.getFirstMillisecond(calendar50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1-June-2019" + "'", str49.equals("1-June-2019"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        timeSeries3.setNotify(false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        timeSeries15.removeAgedItems(1560183739976L, false);
        java.lang.String str20 = timeSeries15.getRangeDescription();
        try {
            java.lang.Number number22 = timeSeries15.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "hi!", "hi!");
        int int18 = month13.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month13.next();
        boolean boolean20 = timeSeries3.equals((java.lang.Object) regularTimePeriod19);
        timeSeries3.setRangeDescription("10-June-2019");
        java.lang.Comparable comparable23 = timeSeries3.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries3.removeChangeListener(seriesChangeListener24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str30 = timeSeries29.getDescription();
        boolean boolean31 = timeSeries29.getNotify();
        java.lang.Object obj32 = timeSeries29.clone();
        timeSeries29.removeAgedItems(false);
        timeSeries29.setKey((java.lang.Comparable) "1-June-2019");
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries3.addAndOrUpdate(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str42 = timeSeries41.getDescription();
        boolean boolean43 = timeSeries41.getNotify();
        java.lang.Object obj44 = timeSeries41.clone();
        timeSeries41.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str51 = timeSeries50.getDescription();
        timeSeries50.setRangeDescription("hi!");
        timeSeries50.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str60 = timeSeries59.getDescription();
        boolean boolean61 = timeSeries59.getNotify();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str66 = timeSeries65.getDescription();
        timeSeries65.setRangeDescription("hi!");
        java.lang.String str69 = timeSeries65.getDescription();
        int int70 = timeSeries65.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries59.addAndOrUpdate(timeSeries65);
        java.lang.String str72 = timeSeries65.getRangeDescription();
        timeSeries65.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str78 = timeSeries77.getDescription();
        timeSeries77.setRangeDescription("hi!");
        timeSeries77.setDescription("");
        org.jfree.data.time.Month month83 = new org.jfree.data.time.Month();
        int int85 = month83.compareTo((java.lang.Object) (byte) 0);
        int int86 = timeSeries77.getIndex((org.jfree.data.time.RegularTimePeriod) month83);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) month83, (double) (-1.0f), false);
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) month83);
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) month83, (double) 1560183727081L, false);
        org.jfree.data.time.Year year95 = new org.jfree.data.time.Year((int) '4');
        long long96 = year95.getLastMillisecond();
        int int97 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) year95);
        int int98 = year95.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem99 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year95);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 100.0d + "'", comparable23.equals(100.0d));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "hi!" + "'", str72.equals("hi!"));
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + (-60494745600001L) + "'", long96 == (-60494745600001L));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 52 + "'", int98 == 52);
        org.junit.Assert.assertNull(timeSeriesDataItem99);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        boolean boolean14 = day3.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        java.util.Date date21 = month16.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        java.lang.String str23 = day22.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "30-June-2019" + "'", str23.equals("30-June-2019"));
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test028");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, "Value", "Value");
//        timeSeries8.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=4]");
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) '4');
//        int int14 = year12.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1);
//        long long22 = fixedMillisecond19.getLastMillisecond();
//        java.util.Date date23 = fixedMillisecond19.getTime();
//        int int24 = year12.compareTo((java.lang.Object) fixedMillisecond19);
//        long long25 = year12.getFirstMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) year12);
//        timeSeries8.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560183810652L + "'", long22 == 1560183810652L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-60526368000000L) + "'", long25 == (-60526368000000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        boolean boolean16 = timeSeries15.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries15.removeChangeListener(seriesChangeListener17);
        timeSeries15.removeAgedItems(false);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.util.Date date22 = month21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date22);
        java.lang.Object obj26 = null;
        boolean boolean27 = month25.equals(obj26);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) (short) 100);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        java.util.Date date31 = month30.getStart();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str39 = timeSeries38.getDescription();
        boolean boolean40 = timeSeries38.getNotify();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        java.lang.String str48 = timeSeries44.getDescription();
        int int49 = timeSeries44.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries38.addAndOrUpdate(timeSeries44);
        java.lang.String str51 = timeSeries44.getRangeDescription();
        timeSeries44.fireSeriesChanged();
        timeSeries44.fireSeriesChanged();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getSerialIndex();
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) 1560150000000L);
        java.util.List list58 = timeSeries44.getItems();
        boolean boolean59 = year34.equals((java.lang.Object) timeSeries44);
        java.lang.Number number60 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) year34);
        java.util.List list61 = timeSeries15.getItems();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (short) 100 + "'", number60.equals((short) 100));
        org.junit.Assert.assertNotNull(list61);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test030");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        int int10 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        long long14 = day12.getSerialIndex();
//        int int15 = day12.getYear();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183811219L + "'", long8 == 1560183811219L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("53");
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        int int14 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        boolean boolean20 = timeSeries18.getNotify();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str25 = timeSeries24.getDescription();
        timeSeries24.setRangeDescription("hi!");
        java.lang.String str28 = timeSeries24.getDescription();
        int int29 = timeSeries24.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries18.addAndOrUpdate(timeSeries24);
        java.lang.String str31 = timeSeries24.getRangeDescription();
        timeSeries24.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str37 = timeSeries36.getDescription();
        timeSeries36.setRangeDescription("hi!");
        timeSeries36.setDescription("");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        int int44 = month42.compareTo((java.lang.Object) (byte) 0);
        int int45 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-1.0f), false);
        java.lang.Number number49 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month42.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month42.next();
        long long52 = month42.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1559372400000L + "'", long52 == 1559372400000L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183806191L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.lang.Object obj8 = timeSeries3.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "52", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        boolean boolean16 = timeSeries15.isEmpty();
        java.lang.String str17 = timeSeries15.getRangeDescription();
        java.lang.String str18 = timeSeries15.getRangeDescription();
        timeSeries15.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str25 = timeSeries24.getDescription();
        boolean boolean26 = timeSeries24.getNotify();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        java.lang.String str34 = timeSeries30.getDescription();
        int int35 = timeSeries30.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries24.addAndOrUpdate(timeSeries30);
        java.lang.String str37 = timeSeries30.getRangeDescription();
        timeSeries30.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str43 = timeSeries42.getDescription();
        timeSeries42.setRangeDescription("hi!");
        timeSeries42.setDescription("");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        int int50 = month48.compareTo((java.lang.Object) (byte) 0);
        int int51 = timeSeries42.getIndex((org.jfree.data.time.RegularTimePeriod) month48);
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) month48, (double) (-1.0f), false);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month55, 0.0d);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        java.util.Date date59 = month58.getStart();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(date59);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date59);
        boolean boolean63 = timeSeriesDataItem57.equals((java.lang.Object) date59);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str68 = timeSeries67.getDescription();
        boolean boolean69 = timeSeries67.getNotify();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str74 = timeSeries73.getDescription();
        timeSeries73.setRangeDescription("hi!");
        java.lang.String str77 = timeSeries73.getDescription();
        int int78 = timeSeries73.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries67.addAndOrUpdate(timeSeries73);
        java.lang.String str80 = timeSeries73.getRangeDescription();
        timeSeries73.fireSeriesChanged();
        java.util.List list82 = timeSeries73.getItems();
        int int83 = timeSeriesDataItem57.compareTo((java.lang.Object) timeSeries73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries15.addOrUpdate(timeSeriesDataItem57);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(timeSeries79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "hi!" + "'", str80.equals("hi!"));
        org.junit.Assert.assertNotNull(list82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem84);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        int int62 = timeSeries3.getMaximumItemCount();
        timeSeries3.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=4]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "hi!", "hi!");
        timeSeries18.setDescription("");
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries3.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        boolean boolean22 = timeSeries3.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date24);
        java.lang.String str28 = month27.toString();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 12, true);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) '4');
        int int36 = year34.compareTo((java.lang.Object) (-1.0f));
        int int37 = year34.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year34.next();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(6, year34);
        long long40 = month39.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate(regularTimePeriod41, (java.lang.Number) 1560183784158L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 52 + "'", int37 == 52);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-60513235200000L) + "'", long40 == (-60513235200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        java.util.Date date62 = year57.getStart();
        java.util.TimeZone timeZone63 = null;
        java.util.Locale locale64 = null;
        try {
            org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date62, timeZone63, locale64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(date62);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test042");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        timeSeries3.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries3.getDescription();
//        java.util.Collection collection14 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str19 = timeSeries18.getDescription();
//        timeSeries18.setRangeDescription("hi!");
//        timeSeries18.setDescription("");
//        timeSeries18.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1);
//        long long36 = fixedMillisecond33.getLastMillisecond();
//        int int37 = day28.compareTo((java.lang.Object) long36);
//        int int38 = day28.getDayOfMonth();
//        boolean boolean40 = day28.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean44 = year42.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) year42);
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, number46);
//        java.beans.PropertyChangeListener propertyChangeListener48 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener48);
//        java.lang.String str50 = timeSeries3.getRangeDescription();
//        java.lang.Comparable comparable51 = timeSeries3.getKey();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183812266L + "'", long36 == 1560183812266L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + comparable51 + "' != '" + 10 + "'", comparable51.equals(10));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int2 = year1.getYear();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560183758150L);
        timeSeriesDataItem6.setSelected(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        timeSeries12.setRangeDescription("hi!");
        timeSeries12.setDescription("");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int20 = month18.compareTo((java.lang.Object) (byte) 0);
        int int21 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.util.Date date23 = month22.getStart();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "hi!", "hi!");
        int int27 = month22.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month22.next();
        boolean boolean29 = timeSeries12.equals((java.lang.Object) regularTimePeriod28);
        java.lang.String str30 = timeSeries12.getDescription();
        double double31 = timeSeries12.getMinY();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str36 = timeSeries35.getDescription();
        boolean boolean37 = timeSeries35.getNotify();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str42 = timeSeries41.getDescription();
        timeSeries41.setRangeDescription("hi!");
        java.lang.String str45 = timeSeries41.getDescription();
        int int46 = timeSeries41.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries35.addAndOrUpdate(timeSeries41);
        java.lang.String str48 = timeSeries41.getRangeDescription();
        timeSeries41.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        timeSeries53.setDescription("");
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        int int61 = month59.compareTo((java.lang.Object) (byte) 0);
        int int62 = timeSeries53.getIndex((org.jfree.data.time.RegularTimePeriod) month59);
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) month59, (double) (-1.0f), false);
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month66, 0.0d);
        boolean boolean69 = timeSeriesDataItem68.isSelected();
        timeSeriesDataItem68.setValue((java.lang.Number) 1560183737262L);
        timeSeries12.add(timeSeriesDataItem68, false);
        boolean boolean74 = timeSeriesDataItem6.equals((java.lang.Object) timeSeries12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int2 = year1.getYear();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560183758150L);
        long long7 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: 10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test046");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183812658L + "'", long7 == 1560183812658L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183812658L + "'", long11 == 1560183812658L);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate10);
//        long long13 = day12.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183812683L + "'", long8 == 1560183812683L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 3);
        int int4 = month2.compareTo((java.lang.Object) 1560183771054L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str14 = timeSeries13.getDescription();
//        boolean boolean15 = timeSeries13.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str20 = timeSeries19.getDescription();
//        timeSeries19.setRangeDescription("hi!");
//        java.lang.String str23 = timeSeries19.getDescription();
//        int int24 = timeSeries19.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
//        int int26 = timeSeries19.getMaximumItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener27);
//        boolean boolean29 = fixedMillisecond6.equals((java.lang.Object) timeSeries19);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 1);
//        long long37 = fixedMillisecond34.getLastMillisecond();
//        java.util.Date date38 = fixedMillisecond34.getTime();
//        java.lang.Object obj39 = null;
//        int int40 = fixedMillisecond34.compareTo(obj39);
//        java.util.Date date41 = fixedMillisecond34.getTime();
//        java.util.Calendar calendar42 = null;
//        fixedMillisecond34.peg(calendar42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, 0.0d);
//        int int46 = timeSeries19.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries19.removePropertyChangeListener(propertyChangeListener47);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560183812735L + "'", long37 == 1560183812735L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2147483647 + "'", int46 == 2147483647);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (java.lang.Number) 100.0d);
//        boolean boolean7 = timeSeriesDataItem6.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1);
//        long long15 = fixedMillisecond12.getSerialIndex();
//        java.util.Date date16 = fixedMillisecond12.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
//        boolean boolean19 = timeSeriesDataItem6.equals((java.lang.Object) month18);
//        org.jfree.data.time.Year year20 = month18.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560183812819L + "'", long15 == 1560183812819L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(year20);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str6 = timeSeries5.getDescription();
        timeSeries5.setRangeDescription("hi!");
        timeSeries5.setDescription("");
        timeSeries5.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        timeSeries18.setDescription("");
        timeSeries18.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener26);
        java.lang.String str28 = timeSeries18.getDescription();
        java.util.Collection collection29 = timeSeries18.getTimePeriods();
        java.util.Collection collection30 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        timeSeries5.setDomainDescription("June 2019");
        int int33 = year1.compareTo((java.lang.Object) timeSeries5);
        long long34 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year1.previous();
        java.lang.Number number37 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod36, number37);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        timeSeries17.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        java.lang.String str36 = timeSeries32.getDescription();
        int int37 = timeSeries32.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
        java.lang.String str39 = timeSeries32.getRangeDescription();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        timeSeries44.setDescription("");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560183730068L);
        long long60 = month50.getLastMillisecond();
        long long61 = month50.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1561964399999L + "'", long60 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1559372400000L + "'", long61 == 1559372400000L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.util.Date date22 = month21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        int int25 = year23.compareTo((java.lang.Object) 0L);
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 1560183728885L);
        java.lang.Object obj28 = null;
        int int29 = year23.compareTo(obj28);
        long long30 = year23.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("53");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "hi!", "hi!");
        timeSeries18.setDescription("");
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        timeSeries26.setRangeDescription("hi!");
        timeSeries26.setDescription("");
        double double32 = timeSeries26.getMinY();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        java.util.Date date34 = month33.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        java.lang.Number number36 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) year35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year35, (double) (-61951708800000L));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        int int16 = timeSeries3.getItemCount();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) '4');
        boolean boolean20 = year18.equals((java.lang.Object) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) 1560183751792L);
        long long23 = year18.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60526368000000L) + "'", long23 == (-60526368000000L));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test057");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
//        int int2 = year1.getYear();
//        java.lang.Number number3 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1);
//        long long12 = fixedMillisecond9.getSerialIndex();
//        java.util.Date date13 = fixedMillisecond9.getTime();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str18 = timeSeries17.getDescription();
//        timeSeries17.setRangeDescription("hi!");
//        timeSeries17.setDescription("");
//        timeSeries17.setKey((java.lang.Comparable) 10);
//        java.util.Collection collection25 = timeSeries17.getTimePeriods();
//        boolean boolean26 = fixedMillisecond9.equals((java.lang.Object) timeSeries17);
//        int int27 = timeSeriesDataItem4.compareTo((java.lang.Object) boolean26);
//        timeSeriesDataItem4.setSelected(false);
//        java.lang.Class<?> wildcardClass30 = timeSeriesDataItem4.getClass();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183813364L + "'", long12 == 1560183813364L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test058");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        long long8 = fixedMillisecond4.getFirstMillisecond();
//        long long9 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str14 = timeSeries13.getDescription();
//        boolean boolean15 = timeSeries13.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str20 = timeSeries19.getDescription();
//        timeSeries19.setRangeDescription("hi!");
//        java.lang.String str23 = timeSeries19.getDescription();
//        int int24 = timeSeries19.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
//        boolean boolean26 = timeSeries19.isEmpty();
//        java.lang.String str27 = timeSeries19.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str32 = timeSeries31.getDescription();
//        timeSeries31.setRangeDescription("hi!");
//        timeSeries31.setDescription("");
//        timeSeries31.setKey((java.lang.Comparable) 10);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month39.next();
//        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month39, (double) (byte) 1, true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) month39);
//        int int45 = fixedMillisecond4.compareTo((java.lang.Object) timeSeriesDataItem44);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183813432L + "'", long7 == 1560183813432L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183813432L + "'", long8 == 1560183813432L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183813432L + "'", long9 == 1560183813432L);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("53");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test060");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        long long5 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.util.Date date7 = month6.getStart();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeriesDataItem12.setSelected(true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 1);
//        long long23 = fixedMillisecond20.getSerialIndex();
//        java.util.Date date24 = fixedMillisecond20.getTime();
//        boolean boolean26 = fixedMillisecond20.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) '4');
//        long long29 = year28.getLastMillisecond();
//        boolean boolean30 = fixedMillisecond20.equals((java.lang.Object) year28);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 1);
//        long long38 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond35.previous();
//        int int40 = year28.compareTo((java.lang.Object) fixedMillisecond35);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year28, seriesChangeInfo41);
//        int int43 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560183813512L + "'", long23 == 1560183813512L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-60494745600001L) + "'", long29 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560183813514L + "'", long38 == 1560183813514L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, "Value", "Value");
        java.lang.String str9 = day3.toString();
        long long10 = day3.getSerialIndex();
        long long11 = day3.getSerialIndex();
        int int12 = day3.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1-June-2019" + "'", str9.equals("1-June-2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43617L + "'", long10 == 43617L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43617L + "'", long11 == 43617L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int2 = month0.getMonth();
        long long3 = month0.getFirstMillisecond();
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        java.lang.Object obj15 = timeSeries3.clone();
        try {
            timeSeries3.delete((int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(obj15);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test064");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        java.lang.String str16 = timeSeries9.getRangeDescription();
//        timeSeries9.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str22 = timeSeries21.getDescription();
//        timeSeries21.setRangeDescription("hi!");
//        timeSeries21.setDescription("");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
//        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
//        timeSeriesDataItem36.setValue((java.lang.Number) 1560183728830L);
//        boolean boolean39 = timeSeriesDataItem36.isSelected();
//        java.lang.Object obj40 = timeSeriesDataItem36.clone();
//        timeSeriesDataItem36.setSelected(false);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.String str44 = day43.toString();
//        long long45 = day43.getLastMillisecond();
//        java.lang.String str46 = day43.toString();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str51 = timeSeries50.getDescription();
//        timeSeries50.setRangeDescription("hi!");
//        timeSeries50.setDescription("");
//        timeSeries50.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener58 = null;
//        timeSeries50.addPropertyChangeListener(propertyChangeListener58);
//        java.lang.String str60 = timeSeries50.getDescription();
//        java.lang.String str61 = timeSeries50.getDomainDescription();
//        boolean boolean62 = day43.equals((java.lang.Object) timeSeries50);
//        java.lang.String str63 = timeSeries50.getRangeDescription();
//        int int64 = timeSeriesDataItem36.compareTo((java.lang.Object) timeSeries50);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year((int) (byte) 1);
//        long long67 = year66.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year66.previous();
//        java.lang.Number number69 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) year66);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(obj40);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertNull(str51);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1L + "'", long67 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(number69);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        java.lang.String str6 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1);
//        long long15 = fixedMillisecond12.getLastMillisecond();
//        int int16 = day7.compareTo((java.lang.Object) long15);
//        int int17 = day7.getDayOfMonth();
//        int int18 = day7.getYear();
//        long long19 = day7.getLastMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (-1));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str26 = timeSeries25.getDescription();
//        timeSeries25.removeAgedItems(true);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        java.util.Date date30 = month29.getStart();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date30);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date30);
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month34, (double) (short) 1);
//        boolean boolean37 = timeSeries25.getNotify();
//        java.util.Collection collection38 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        java.lang.String str39 = timeSeries3.getRangeDescription();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560183814060L + "'", long15 == 1560183814060L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        timeSeries3.setMaximumItemCount((int) (short) 1);
//        boolean boolean9 = timeSeries3.getNotify();
//        java.lang.Comparable comparable10 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1);
//        long long18 = fixedMillisecond15.getSerialIndex();
//        java.util.Date date19 = fixedMillisecond15.getTime();
//        boolean boolean21 = fixedMillisecond15.equals((java.lang.Object) 'a');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond15.next();
//        java.util.Date date23 = fixedMillisecond15.getStart();
//        long long24 = fixedMillisecond15.getLastMillisecond();
//        long long25 = fixedMillisecond15.getLastMillisecond();
//        long long26 = fixedMillisecond15.getMiddleMillisecond();
//        int int27 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 100.0d + "'", comparable10.equals(100.0d));
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560183814121L + "'", long18 == 1560183814121L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183814121L + "'", long24 == 1560183814121L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560183814121L + "'", long25 == 1560183814121L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183814121L + "'", long26 == 1560183814121L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2) + "'", int27 == (-2));
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 1);
//        long long23 = fixedMillisecond20.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        java.util.Date date27 = month26.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 1);
//        long long41 = fixedMillisecond38.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond38.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str48 = timeSeries47.getDescription();
//        boolean boolean49 = timeSeries47.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str54 = timeSeries53.getDescription();
//        timeSeries53.setRangeDescription("hi!");
//        java.lang.String str57 = timeSeries53.getDescription();
//        int int58 = timeSeries53.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
//        java.lang.String str60 = timeSeries53.getRangeDescription();
//        timeSeries53.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str66 = timeSeries65.getDescription();
//        timeSeries65.setRangeDescription("hi!");
//        timeSeries65.setDescription("");
//        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
//        int int73 = month71.compareTo((java.lang.Object) (byte) 0);
//        int int74 = timeSeries65.getIndex((org.jfree.data.time.RegularTimePeriod) month71);
//        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) month71, (double) (-1.0f), false);
//        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries53.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month78, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = month78.previous();
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month();
//        java.util.Date date83 = month82.getStart();
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date83);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond(date83);
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date83);
//        org.jfree.data.time.Month month87 = new org.jfree.data.time.Month(date83);
//        int int88 = month78.compareTo((java.lang.Object) month87);
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month78, (java.lang.Number) 7);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560183814167L + "'", long23 == 1560183814167L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560183814167L + "'", long25 == 1560183814167L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560183814170L + "'", long41 == 1560183814170L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNull(str54);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
//        org.junit.Assert.assertNull(str66);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem80);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1);
        long long6 = month5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "10-June-2019", seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent6.setSummary(seriesChangeInfo7);
        boolean boolean9 = day3.equals((java.lang.Object) seriesChangeEvent6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent6.getSummary();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(seriesChangeInfo10);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 1);
//        long long24 = fixedMillisecond21.getSerialIndex();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        long long26 = fixedMillisecond21.getLastMillisecond();
//        java.util.Date date27 = fixedMillisecond21.getTime();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183814985L + "'", long24 == 1560183814985L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183814985L + "'", long26 == 1560183814985L);
//        org.junit.Assert.assertNotNull(date27);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test071");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int18 = month16.compareTo((java.lang.Object) (byte) 0);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 100L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries3.addChangeListener(seriesChangeListener21);
//        java.lang.String str23 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str28 = timeSeries27.getDescription();
//        boolean boolean29 = timeSeries27.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str34 = timeSeries33.getDescription();
//        timeSeries33.setRangeDescription("hi!");
//        java.lang.String str37 = timeSeries33.getDescription();
//        int int38 = timeSeries33.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries27.addAndOrUpdate(timeSeries33);
//        boolean boolean40 = timeSeries39.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries39.removeChangeListener(seriesChangeListener41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 1);
//        long long51 = fixedMillisecond48.getLastMillisecond();
//        int int52 = day43.compareTo((java.lang.Object) long51);
//        int int53 = day43.getDayOfMonth();
//        boolean boolean55 = day43.equals((java.lang.Object) (short) 100);
//        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 'a', true);
//        int int59 = day43.getMonth();
//        int int60 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560183815073L + "'", long51 == 1560183815073L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.removeChangeListener(seriesChangeListener19);
        java.lang.Object obj21 = timeSeries9.clone();
        double double22 = timeSeries9.getMaxY();
        timeSeries9.removeAgedItems(1560183748396L, true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries9.addChangeListener(seriesChangeListener26);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) 1, true);
        java.lang.String str16 = month11.toString();
        long long17 = month11.getLastMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            month11.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        double double5 = timeSeries4.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        boolean boolean11 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str16 = timeSeries15.getDescription();
        timeSeries15.setRangeDescription("hi!");
        java.lang.String str19 = timeSeries15.getDescription();
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries9.addAndOrUpdate(timeSeries15);
        java.lang.String str22 = timeSeries15.getRangeDescription();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        timeSeries27.setDescription("");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int35 = month33.compareTo((java.lang.Object) (byte) 0);
        int int36 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month33, (double) (-1.0f), false);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 9223372036854775807L, false);
        java.util.Collection collection43 = timeSeries4.getTimePeriods();
        java.lang.Class<?> wildcardClass44 = timeSeries4.getClass();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) '4');
        long long47 = year46.getLastMillisecond();
        java.util.Date date48 = year46.getStart();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year46, (double) 1560183801398L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(collection43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-60494745600001L) + "'", long47 == (-60494745600001L));
        org.junit.Assert.assertNotNull(date48);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 6);
        org.jfree.data.time.Year year3 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) 1560183772427L);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test076");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.util.Date date4 = month3.getStart();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, "hi!", "hi!");
//        int int8 = month3.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
//        java.util.Date date10 = regularTimePeriod9.getStart();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) '4');
//        long long17 = year16.getLastMillisecond();
//        java.util.Date date18 = year16.getStart();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date18, timeZone19);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        java.util.Date date22 = month21.getStart();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date22);
//        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 10);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond24.getLastMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond24.getTime();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date29, timeZone30);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1);
//        long long39 = fixedMillisecond36.getSerialIndex();
//        java.util.Date date40 = fixedMillisecond36.getTime();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date40, timeZone41);
//        java.util.TimeZone timeZone43 = null;
//        try {
//            org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date40, timeZone43);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-60494745600001L) + "'", long17 == (-60494745600001L));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183815330L + "'", long39 == 1560183815330L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
        int int4 = year1.getYear();
        long long5 = year1.getFirstMillisecond();
        long long6 = year1.getLastMillisecond();
        long long7 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526368000000L) + "'", long5 == (-60526368000000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60494745600001L) + "'", long6 == (-60494745600001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60494745600001L) + "'", long7 == (-60494745600001L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(1, year2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str8 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("hi!");
        boolean boolean11 = timeSeries7.getNotify();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str16 = timeSeries15.getDescription();
        timeSeries15.setRangeDescription("hi!");
        timeSeries15.setDescription("");
        timeSeries15.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (byte) 1, true);
        java.lang.Number number28 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        double double29 = timeSeries7.getMinY();
        int int30 = year2.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year2.next();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test079");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        int int4 = day0.compareTo((java.lang.Object) (byte) -1);
//        int int5 = day0.getYear();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        java.lang.String str9 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1);
        java.lang.Object obj6 = null;
        boolean boolean7 = year5.equals(obj6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.addChangeListener(seriesChangeListener9);
        try {
            timeSeries3.delete((int) (short) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems(1L, false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) '4');
        int int13 = year11.compareTo((java.lang.Object) (-1.0f));
        int int14 = year11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.next();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(6, year11);
        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str23 = timeSeries22.getDescription();
        boolean boolean24 = timeSeries22.getNotify();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str29 = timeSeries28.getDescription();
        timeSeries28.setRangeDescription("hi!");
        java.lang.String str32 = timeSeries28.getDescription();
        int int33 = timeSeries28.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries22.addAndOrUpdate(timeSeries28);
        java.util.Collection collection35 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        java.lang.String str36 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183815772L + "'", long8 == 1560183815772L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "June 2019", "June 2019");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries13.removeChangeListener(seriesChangeListener14);
//        java.lang.Class class16 = timeSeries13.getTimePeriodClass();
//        timeSeries13.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183815847L + "'", long8 == 1560183815847L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNull(class16);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test086");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1);
//        long long10 = fixedMillisecond7.getLastMillisecond();
//        int int11 = day0.compareTo((java.lang.Object) fixedMillisecond7);
//        long long12 = fixedMillisecond7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183815872L + "'", long10 == 1560183815872L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183815872L + "'", long12 == 1560183815872L);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        java.lang.String str7 = timeSeries3.getDescription();
//        double double8 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str13 = timeSeries12.getDescription();
//        timeSeries12.setRangeDescription("hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener16);
//        long long18 = timeSeries12.getMaximumItemAge();
//        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = day20.toString();
//        long long22 = day20.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 1);
//        long long30 = fixedMillisecond27.getLastMillisecond();
//        int int31 = day20.compareTo((java.lang.Object) fixedMillisecond27);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day20);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560183815943L + "'", long30 == 1560183815943L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
//        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries3.getDescription();
//        double double17 = timeSeries3.getMaxY();
//        double double18 = timeSeries3.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 1);
//        long long26 = fixedMillisecond23.getLastMillisecond();
//        java.util.Date date27 = fixedMillisecond23.getTime();
//        java.lang.Object obj28 = null;
//        int int29 = fixedMillisecond23.compareTo(obj28);
//        java.util.Date date30 = fixedMillisecond23.getTime();
//        int int31 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str36 = timeSeries35.getDescription();
//        long long37 = timeSeries35.getMaximumItemAge();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        timeSeries35.removeAgedItems((long) (byte) 100, false);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries3.addAndOrUpdate(timeSeries35);
//        timeSeries35.setMaximumItemAge(1560183739372L);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183815971L + "'", long26 == 1560183815971L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(timeSeries44);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1);
        long long6 = year5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        int int4 = year2.compareTo((java.lang.Object) 0L);
        int int5 = year2.getYear();
        java.lang.Object obj6 = null;
        int int7 = year2.compareTo(obj6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1560183776804L);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str25 = timeSeries24.getDescription();
        boolean boolean26 = timeSeries24.getNotify();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        java.lang.String str34 = timeSeries30.getDescription();
        int int35 = timeSeries30.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries24.addAndOrUpdate(timeSeries30);
        boolean boolean37 = timeSeries30.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries9.addAndOrUpdate(timeSeries30);
        timeSeries9.setMaximumItemCount(7);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        java.util.Date date42 = month41.getStart();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day44, (double) 1560183760040L, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeries9.getNextTimePeriod();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
        int int21 = year19.compareTo((java.lang.Object) (-1.0f));
        int int22 = year19.getYear();
        long long23 = year19.getFirstMillisecond();
        long long24 = year19.getLastMillisecond();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560183728885L, false);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.util.Date date29 = month28.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        timeSeries15.setKey((java.lang.Comparable) year30);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60526368000000L) + "'", long23 == (-60526368000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60494745600001L) + "'", long24 == (-60494745600001L));
        org.junit.Assert.assertNotNull(date29);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test096");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
//        int int2 = year1.getYear();
//        java.lang.Number number3 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1);
//        long long12 = fixedMillisecond9.getSerialIndex();
//        java.util.Date date13 = fixedMillisecond9.getTime();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str18 = timeSeries17.getDescription();
//        timeSeries17.setRangeDescription("hi!");
//        timeSeries17.setDescription("");
//        timeSeries17.setKey((java.lang.Comparable) 10);
//        java.util.Collection collection25 = timeSeries17.getTimePeriods();
//        boolean boolean26 = fixedMillisecond9.equals((java.lang.Object) timeSeries17);
//        int int27 = timeSeriesDataItem4.compareTo((java.lang.Object) boolean26);
//        java.lang.Object obj28 = timeSeriesDataItem4.clone();
//        java.lang.Number number29 = timeSeriesDataItem4.getValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183816300L + "'", long12 == 1560183816300L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNull(number29);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        int int10 = day0.getDayOfMonth();
//        int int11 = day0.getYear();
//        long long12 = day0.getLastMillisecond();
//        long long13 = day0.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183816345L + "'", long8 == 1560183816345L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test098");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str13 = timeSeries12.getDescription();
//        timeSeries12.setRangeDescription("hi!");
//        timeSeries12.setDescription("");
//        timeSeries12.setKey((java.lang.Comparable) 10);
//        java.util.Collection collection20 = timeSeries12.getTimePeriods();
//        boolean boolean21 = fixedMillisecond4.equals((java.lang.Object) timeSeries12);
//        java.lang.Class<?> wildcardClass22 = fixedMillisecond4.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183816360L + "'", long7 == 1560183816360L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(class24);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.setRangeDescription("hi!");
        timeSeries17.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        java.lang.String str36 = timeSeries32.getDescription();
        int int37 = timeSeries32.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
        java.lang.String str39 = timeSeries32.getRangeDescription();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        timeSeries44.setDescription("");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560183730068L);
        long long60 = month50.getLastMillisecond();
        java.util.Date date61 = month50.getEnd();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year63.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1561964399999L + "'", long60 == 1561964399999L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        int int4 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test101");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str14 = timeSeries13.getDescription();
//        boolean boolean15 = timeSeries13.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str20 = timeSeries19.getDescription();
//        timeSeries19.setRangeDescription("hi!");
//        java.lang.String str23 = timeSeries19.getDescription();
//        int int24 = timeSeries19.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
//        int int26 = timeSeries19.getMaximumItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener27);
//        boolean boolean29 = fixedMillisecond6.equals((java.lang.Object) timeSeries19);
//        java.lang.Object obj30 = null;
//        boolean boolean31 = fixedMillisecond6.equals(obj30);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(11, 6);
//        org.jfree.data.time.Year year35 = month34.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
//        int int37 = fixedMillisecond6.compareTo((java.lang.Object) regularTimePeriod36);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond6.getLastMillisecond(calendar38);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183816484L + "'", long39 == 1560183816484L);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        long long17 = timeSeries9.getMaximumItemAge();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        timeSeries4.setDescription("");
        try {
            timeSeries4.update(11, (java.lang.Number) 1560183766262L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (-2013));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1);
//        long long10 = fixedMillisecond7.getLastMillisecond();
//        int int11 = day0.compareTo((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str16 = timeSeries15.getDescription();
//        timeSeries15.setRangeDescription("hi!");
//        timeSeries15.setDescription("");
//        timeSeries15.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries15.getDescription();
//        java.util.Collection collection26 = timeSeries15.getTimePeriods();
//        timeSeries15.removeAgedItems((long) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str34 = timeSeries33.getDescription();
//        boolean boolean35 = timeSeries33.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str40 = timeSeries39.getDescription();
//        timeSeries39.setRangeDescription("hi!");
//        java.lang.String str43 = timeSeries39.getDescription();
//        int int44 = timeSeries39.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries33.addAndOrUpdate(timeSeries39);
//        java.lang.String str46 = timeSeries39.getRangeDescription();
//        timeSeries39.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str52 = timeSeries51.getDescription();
//        timeSeries51.setRangeDescription("hi!");
//        timeSeries51.setDescription("");
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        int int59 = month57.compareTo((java.lang.Object) (byte) 0);
//        int int60 = timeSeries51.getIndex((org.jfree.data.time.RegularTimePeriod) month57);
//        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) month57, (double) (-1.0f), false);
//        int int65 = month57.compareTo((java.lang.Object) (byte) 100);
//        org.jfree.data.time.Year year66 = month57.getYear();
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
//        java.util.Date date68 = month67.getStart();
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date68);
//        int int71 = year69.compareTo((java.lang.Object) 0L);
//        int int72 = year69.getYear();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year66, (org.jfree.data.time.RegularTimePeriod) year69);
//        java.util.Collection collection74 = timeSeries73.getTimePeriods();
//        java.util.List list75 = timeSeries73.getItems();
//        timeSeries73.setRangeDescription("");
//        boolean boolean78 = day0.equals((java.lang.Object) timeSeries73);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183816568L + "'", long10 == 1560183816568L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
//        org.junit.Assert.assertNull(str52);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertNotNull(collection74);
//        org.junit.Assert.assertNotNull(list75);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 10.0d);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "hi!", "hi!");
        int int12 = month7.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month7.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        boolean boolean15 = timeSeriesDataItem6.equals((java.lang.Object) regularTimePeriod13);
        boolean boolean16 = timeSeriesDataItem6.isSelected();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test108");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (java.lang.Number) 100.0d);
//        boolean boolean7 = timeSeriesDataItem6.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1);
//        long long15 = fixedMillisecond12.getSerialIndex();
//        java.util.Date date16 = fixedMillisecond12.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
//        boolean boolean19 = timeSeriesDataItem6.equals((java.lang.Object) month18);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str24 = timeSeries23.getDescription();
//        boolean boolean25 = timeSeries23.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str30 = timeSeries29.getDescription();
//        timeSeries29.setRangeDescription("hi!");
//        java.lang.String str33 = timeSeries29.getDescription();
//        int int34 = timeSeries29.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries23.addAndOrUpdate(timeSeries29);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month36, (double) 100L);
//        java.util.Date date41 = month36.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        boolean boolean43 = month18.equals((java.lang.Object) day42);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560183816831L + "'", long15 == 1560183816831L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        java.lang.Comparable comparable37 = timeSeries9.getKey();
        java.lang.String str38 = timeSeries9.getDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries3.getDescription();
        double double8 = timeSeries3.getMinY();
        boolean boolean9 = timeSeries3.isEmpty();
        int int10 = timeSeries3.getItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        int int35 = month27.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year36 = month27.getYear();
        long long37 = month27.getLastMillisecond();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = month27.getLastMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1561964399999L + "'", long37 == 1561964399999L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("0");
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "hi!", "hi!");
        int int18 = month13.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month13.next();
        boolean boolean20 = timeSeries3.equals((java.lang.Object) regularTimePeriod19);
        java.lang.String str21 = timeSeries3.getDescription();
        double double22 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str33 = timeSeries32.getDescription();
        timeSeries32.setRangeDescription("hi!");
        java.lang.String str36 = timeSeries32.getDescription();
        int int37 = timeSeries32.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries26.addAndOrUpdate(timeSeries32);
        java.lang.String str39 = timeSeries32.getRangeDescription();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str45 = timeSeries44.getDescription();
        timeSeries44.setRangeDescription("hi!");
        timeSeries44.setDescription("");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int52 = month50.compareTo((java.lang.Object) (byte) 0);
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-1.0f), false);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month57, 0.0d);
        boolean boolean60 = timeSeriesDataItem59.isSelected();
        timeSeriesDataItem59.setValue((java.lang.Number) 1560183737262L);
        timeSeries3.add(timeSeriesDataItem59, false);
        timeSeriesDataItem59.setSelected(false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183788230L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183808096L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener23);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries9.addChangeListener(seriesChangeListener25);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '4');
        int int4 = year2.compareTo((java.lang.Object) (-1.0f));
        int int5 = year2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(6, year2);
        long long8 = month7.getFirstMillisecond();
        int int9 = month7.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60513235200000L) + "'", long8 == (-60513235200000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        boolean boolean3 = year1.equals((java.lang.Object) 0);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 0);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesChangeEvent4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        int int35 = month27.compareTo((java.lang.Object) (byte) 100);
        java.lang.String str36 = month27.toString();
        org.jfree.data.time.Year year37 = month27.getYear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNotNull(year37);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int2 = year1.getYear();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560183758150L);
        java.lang.String str7 = year1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str23 = timeSeries22.getDescription();
        boolean boolean24 = timeSeries22.getNotify();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str29 = timeSeries28.getDescription();
        timeSeries28.setRangeDescription("hi!");
        java.lang.String str32 = timeSeries28.getDescription();
        int int33 = timeSeries28.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries22.addAndOrUpdate(timeSeries28);
        java.lang.String str35 = timeSeries28.getRangeDescription();
        timeSeries28.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str41 = timeSeries40.getDescription();
        timeSeries40.setRangeDescription("hi!");
        timeSeries40.setDescription("");
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        int int48 = month46.compareTo((java.lang.Object) (byte) 0);
        int int49 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) month46);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month46, (double) (-1.0f), false);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month53, 0.0d);
        timeSeriesDataItem55.setValue((java.lang.Number) 1560183728830L);
        java.lang.Object obj58 = timeSeriesDataItem55.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries9.addOrUpdate(timeSeriesDataItem55);
        try {
            timeSeries9.delete(2147483647, (int) (byte) 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "hi!", "");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str8 = timeSeries7.getDescription();
//        boolean boolean9 = timeSeries7.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str14 = timeSeries13.getDescription();
//        timeSeries13.setRangeDescription("hi!");
//        java.lang.String str17 = timeSeries13.getDescription();
//        int int18 = timeSeries13.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries7.addAndOrUpdate(timeSeries13);
//        boolean boolean20 = timeSeries19.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1);
//        long long28 = fixedMillisecond25.getSerialIndex();
//        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        java.lang.Number number30 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number30);
//        java.util.List list32 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560183817349L + "'", long28 == 1560183817349L);
//        org.junit.Assert.assertNotNull(list32);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        boolean boolean16 = timeSeries9.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str21 = timeSeries20.getDescription();
        boolean boolean22 = timeSeries20.getNotify();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str27 = timeSeries26.getDescription();
        timeSeries26.setRangeDescription("hi!");
        java.lang.String str30 = timeSeries26.getDescription();
        int int31 = timeSeries26.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries20.addAndOrUpdate(timeSeries26);
        java.lang.String str33 = timeSeries26.getRangeDescription();
        timeSeries26.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str39 = timeSeries38.getDescription();
        timeSeries38.setRangeDescription("hi!");
        timeSeries38.setDescription("");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        int int46 = month44.compareTo((java.lang.Object) (byte) 0);
        int int47 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month44);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month44, (double) (-1.0f), false);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month51, 0.0d);
        timeSeriesDataItem53.setValue((java.lang.Number) 1560183728830L);
        boolean boolean56 = timeSeriesDataItem53.isSelected();
        timeSeries9.add(timeSeriesDataItem53);
        java.lang.String str58 = timeSeries9.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener59);
        timeSeries9.removeAgedItems(0L, false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        int int37 = timeSeries9.getItemCount();
        java.util.Collection collection38 = timeSeries9.getTimePeriods();
        java.lang.String str39 = timeSeries9.getRangeDescription();
        try {
            timeSeries9.update(10, (java.lang.Number) 1560183728885L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        timeSeries3.setMaximumItemAge(1560183760040L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "org.jfree.data.time.TimePeriodFormatException: hi!", "1-June-2019");
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, (java.lang.Number) 100.0d);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.util.Date date16 = month15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries6.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Comparable comparable22 = timeSeries6.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries6.removeChangeListener(seriesChangeListener23);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(comparable22);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test129");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
//        int int3 = year1.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1);
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        java.util.Date date12 = fixedMillisecond8.getTime();
//        int int13 = year1.compareTo((java.lang.Object) fixedMillisecond8);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond8.getLastMillisecond(calendar14);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183817598L + "'", long11 == 1560183817598L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560183817598L + "'", long15 == 1560183817598L);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str9 = timeSeries8.getDescription();
//        boolean boolean10 = timeSeries8.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str15 = timeSeries14.getDescription();
//        timeSeries14.setRangeDescription("hi!");
//        java.lang.String str18 = timeSeries14.getDescription();
//        int int19 = timeSeries14.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries8.addAndOrUpdate(timeSeries14);
//        java.lang.String str21 = timeSeries14.getRangeDescription();
//        timeSeries14.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str27 = timeSeries26.getDescription();
//        timeSeries26.setRangeDescription("hi!");
//        timeSeries26.setDescription("");
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        int int34 = month32.compareTo((java.lang.Object) (byte) 0);
//        int int35 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month32, (double) (-1.0f), false);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, 0.0d);
//        timeSeriesDataItem41.setValue((java.lang.Number) 1560183728830L);
//        boolean boolean44 = timeSeriesDataItem41.isSelected();
//        java.lang.Object obj45 = timeSeriesDataItem41.clone();
//        int int46 = day0.compareTo(obj45);
//        java.util.Calendar calendar47 = null;
//        try {
//            long long48 = day0.getMiddleMillisecond(calendar47);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(obj45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(1, year2);
        org.jfree.data.time.Year year4 = month3.getYear();
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int18 = year16.compareTo((java.lang.Object) 0L);
        int int19 = year16.getYear();
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Date date21 = year16.getStart();
        long long22 = year16.getLastMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "June 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "hi!", "hi!");
        int int18 = month13.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month13.next();
        boolean boolean20 = timeSeries3.equals((java.lang.Object) regularTimePeriod19);
        timeSeries3.setRangeDescription("10-June-2019");
        double double23 = timeSeries3.getMinY();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test135");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        timeSeries3.setMaximumItemCount((int) (short) 1);
//        boolean boolean9 = timeSeries3.getNotify();
//        java.lang.Comparable comparable10 = timeSeries3.getKey();
//        timeSeries3.setMaximumItemCount(52);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries3.addChangeListener(seriesChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener15);
//        java.lang.String str17 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        long long20 = day18.getLastMillisecond();
//        int int22 = day18.compareTo((java.lang.Object) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day18.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.getDataItem(regularTimePeriod23);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 100.0d + "'", comparable10.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("30-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test137");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        long long9 = fixedMillisecond6.getSerialIndex();
//        java.util.Date date10 = fixedMillisecond6.getTime();
//        boolean boolean12 = fixedMillisecond6.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) '4');
//        long long15 = year14.getLastMillisecond();
//        boolean boolean16 = fixedMillisecond6.equals((java.lang.Object) year14);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 1);
//        long long24 = fixedMillisecond21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond21.previous();
//        int int26 = year14.compareTo((java.lang.Object) fixedMillisecond21);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year14, seriesChangeInfo27);
//        java.lang.String str29 = seriesChangeEvent28.toString();
//        boolean boolean30 = year0.equals((java.lang.Object) seriesChangeEvent28);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183818874L + "'", long9 == 1560183818874L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60494745600001L) + "'", long15 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183818876L + "'", long24 == 1560183818876L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=52]" + "'", str29.equals("org.jfree.data.event.SeriesChangeEvent[source=52]"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183731309L);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getLastMillisecond();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        java.lang.Object obj9 = null;
//        int int10 = fixedMillisecond4.compareTo(obj9);
//        java.util.Date date11 = fixedMillisecond4.getTime();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183818951L + "'", long7 == 1560183818951L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        boolean boolean19 = timeSeries9.isEmpty();
        boolean boolean20 = timeSeries9.getNotify();
        timeSeries9.setRangeDescription("org.jfree.data.general.SeriesException: ");
        java.lang.Class<?> wildcardClass23 = timeSeries9.getClass();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.lang.String str16 = timeSeries3.getDescription();
        double double17 = timeSeries3.getMaxY();
        java.lang.String str18 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.util.Date date20 = month19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 10.0d);
        java.lang.Number number26 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries3.clear();
        boolean boolean28 = timeSeries3.isEmpty();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.util.Date date30 = month29.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
        boolean boolean34 = fixedMillisecond32.equals((java.lang.Object) 10);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond32.getFirstMillisecond(calendar35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond32.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries3.addOrUpdate(regularTimePeriod37, (java.lang.Number) 1560183761798L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1559372400000L + "'", long36 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 52");
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        java.lang.Class class8 = null;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10);
        boolean boolean15 = timeSeriesDataItem6.equals((java.lang.Object) year14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.util.Collection collection13 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(collection13);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        java.lang.Class class17 = timeSeries15.getTimePeriodClass();
        timeSeries15.clear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(class17);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
        int int3 = year1.compareTo((java.lang.Object) 1560183761113L);
        long long4 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62072668800000L) + "'", long4 == (-62072668800000L));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        timeSeriesDataItem36.setValue((java.lang.Number) 1560183728830L);
        java.lang.Object obj39 = timeSeriesDataItem36.clone();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        int int41 = day40.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day40.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day40.previous();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "hi!", "");
        int int48 = day40.compareTo((java.lang.Object) "");
        boolean boolean49 = timeSeriesDataItem36.equals((java.lang.Object) int48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem36.getPeriod();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, (double) 1560183775765L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, "hi!", "hi!");
        int int8 = month3.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.util.Date date16 = month15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (-62104204800001L));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        boolean boolean16 = timeSeries15.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries15.removeChangeListener(seriesChangeListener17);
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str24 = timeSeries23.getDescription();
        boolean boolean25 = timeSeries23.getNotify();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str30 = timeSeries29.getDescription();
        timeSeries29.setRangeDescription("hi!");
        java.lang.String str33 = timeSeries29.getDescription();
        int int34 = timeSeries29.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries23.addAndOrUpdate(timeSeries29);
        java.lang.String str36 = timeSeries29.getRangeDescription();
        timeSeries29.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str42 = timeSeries41.getDescription();
        timeSeries41.setRangeDescription("hi!");
        timeSeries41.setDescription("");
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int49 = month47.compareTo((java.lang.Object) (byte) 0);
        int int50 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) month47);
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month47, (double) (-1.0f), false);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month54, 0.0d);
        timeSeriesDataItem56.setValue((java.lang.Number) 1560183728830L);
        boolean boolean59 = timeSeriesDataItem56.isSelected();
        java.lang.Object obj60 = timeSeriesDataItem56.clone();
        timeSeriesDataItem56.setSelected(false);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str67 = timeSeries66.getDescription();
        boolean boolean68 = timeSeries66.getNotify();
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str73 = timeSeries72.getDescription();
        timeSeries72.setRangeDescription("hi!");
        java.lang.String str76 = timeSeries72.getDescription();
        int int77 = timeSeries72.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries66.addAndOrUpdate(timeSeries72);
        java.lang.String str79 = timeSeries72.getRangeDescription();
        timeSeries72.fireSeriesChanged();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year((int) '4');
        int int84 = year82.compareTo((java.lang.Object) (-1.0f));
        int int85 = year82.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries72.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year82, (double) (short) -1);
        long long88 = year82.getSerialIndex();
        int int89 = timeSeriesDataItem56.compareTo((java.lang.Object) year82);
        timeSeriesDataItem56.setValue((java.lang.Number) 1560183744574L);
        timeSeries15.add(timeSeriesDataItem56);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "hi!" + "'", str79.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 52 + "'", int85 == 52);
        org.junit.Assert.assertNull(timeSeriesDataItem87);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 52L + "'", long88 == 52L);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test153");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) 'a');
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond4.getMiddleMillisecond(calendar11);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str17 = timeSeries16.getDescription();
//        timeSeries16.setRangeDescription("hi!");
//        timeSeries16.setDescription("");
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        int int24 = month22.compareTo((java.lang.Object) (byte) 0);
//        int int25 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) month22);
//        double double26 = timeSeries16.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener27);
//        java.lang.String str29 = timeSeries16.getDescription();
//        timeSeries16.setDomainDescription("hi!");
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) 1);
//        long long40 = fixedMillisecond37.getLastMillisecond();
//        int int41 = day32.compareTo((java.lang.Object) long40);
//        int int42 = day32.getDayOfMonth();
//        boolean boolean44 = day32.equals((java.lang.Object) (short) 100);
//        int int45 = day32.getMonth();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 100.0d);
//        int int48 = fixedMillisecond4.compareTo((java.lang.Object) timeSeries16);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183819912L + "'", long7 == 1560183819912L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183819912L + "'", long12 == 1560183819912L);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560183819915L + "'", long40 == 1560183819915L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 1);
//        long long24 = fixedMillisecond21.getSerialIndex();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        long long26 = fixedMillisecond21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str31 = timeSeries30.getDescription();
//        boolean boolean32 = timeSeries30.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str37 = timeSeries36.getDescription();
//        timeSeries36.setRangeDescription("hi!");
//        java.lang.String str40 = timeSeries36.getDescription();
//        int int41 = timeSeries36.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries30.addAndOrUpdate(timeSeries36);
//        boolean boolean43 = timeSeries42.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries42.removeChangeListener(seriesChangeListener44);
//        timeSeries42.setRangeDescription("June 2019");
//        int int48 = fixedMillisecond21.compareTo((java.lang.Object) timeSeries42);
//        timeSeries42.clear();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183819961L + "'", long24 == 1560183819961L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183819961L + "'", long26 == 1560183819961L);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "hi!", "hi!");
        int int19 = month14.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month14.next();
        java.util.Date date21 = regularTimePeriod20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 1560183749154L, false);
        int int27 = day23.getYear();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str32 = timeSeries31.getDescription();
        boolean boolean33 = timeSeries31.getNotify();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str38 = timeSeries37.getDescription();
        timeSeries37.setRangeDescription("hi!");
        java.lang.String str41 = timeSeries37.getDescription();
        int int42 = timeSeries37.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries31.addAndOrUpdate(timeSeries37);
        java.lang.String str44 = timeSeries37.getRangeDescription();
        int int45 = day23.compareTo((java.lang.Object) str44);
        int int46 = day23.getDayOfMonth();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test156");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str14 = timeSeries13.getDescription();
//        boolean boolean15 = timeSeries13.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str20 = timeSeries19.getDescription();
//        timeSeries19.setRangeDescription("hi!");
//        java.lang.String str23 = timeSeries19.getDescription();
//        int int24 = timeSeries19.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
//        int int26 = timeSeries19.getMaximumItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener27);
//        boolean boolean29 = fixedMillisecond6.equals((java.lang.Object) timeSeries19);
//        java.util.Date date30 = fixedMillisecond6.getStart();
//        long long31 = fixedMillisecond6.getSerialIndex();
//        long long32 = fixedMillisecond6.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560183820097L + "'", long31 == 1560183820097L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560183820097L + "'", long32 == 1560183820097L);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test157");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getSerialIndex();
//        java.util.Date date9 = fixedMillisecond5.getTime();
//        boolean boolean11 = fixedMillisecond5.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) '4');
//        long long14 = year13.getLastMillisecond();
//        boolean boolean15 = fixedMillisecond5.equals((java.lang.Object) year13);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str20 = timeSeries19.getDescription();
//        timeSeries19.setRangeDescription("hi!");
//        timeSeries19.setDescription("");
//        timeSeries19.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries19.addPropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 1);
//        long long37 = fixedMillisecond34.getLastMillisecond();
//        int int38 = day29.compareTo((java.lang.Object) long37);
//        int int39 = day29.getDayOfMonth();
//        boolean boolean41 = day29.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean45 = year43.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) day29, (org.jfree.data.time.RegularTimePeriod) year43);
//        boolean boolean47 = year13.equals((java.lang.Object) year43);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(10, year43);
//        int int49 = year43.getYear();
//        int int50 = year43.getYear();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183820129L + "'", long8 == 1560183820129L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60494745600001L) + "'", long14 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560183820132L + "'", long37 == 1560183820132L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 52 + "'", int49 == 52);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 52 + "'", int50 == 52);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str14 = timeSeries13.getDescription();
        boolean boolean15 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str20 = timeSeries19.getDescription();
        timeSeries19.setRangeDescription("hi!");
        java.lang.String str23 = timeSeries19.getDescription();
        int int24 = timeSeries19.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.lang.String str26 = timeSeries19.getRangeDescription();
        timeSeries19.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str32 = timeSeries31.getDescription();
        timeSeries31.setRangeDescription("hi!");
        timeSeries31.setDescription("");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int39 = month37.compareTo((java.lang.Object) (byte) 0);
        int int40 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) month37);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month37, (double) (-1.0f), false);
        int int45 = month37.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year46 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month37, (double) 10L);
        boolean boolean49 = timeSeries3.isEmpty();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year((int) '4');
        long long53 = year52.getLastMillisecond();
        java.util.Date date54 = year52.getStart();
        int int55 = year52.getYear();
        java.lang.Number number56 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year52);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str61 = timeSeries60.getDescription();
        timeSeries60.setRangeDescription("hi!");
        timeSeries60.setDescription("");
        timeSeries60.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month68.next();
        timeSeries60.add((org.jfree.data.time.RegularTimePeriod) month68, (double) (byte) 1, true);
        long long73 = month68.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        boolean boolean76 = month68.equals((java.lang.Object) fixedMillisecond75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = fixedMillisecond75.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (double) 1560183731800L);
        timeSeriesDataItem79.setValue((java.lang.Number) 1577865599999L);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries3.addOrUpdate(timeSeriesDataItem79);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-60494745600001L) + "'", long53 == (-60494745600001L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 10.0d + "'", number56.equals(10.0d));
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1561964399999L + "'", long73 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        boolean boolean14 = timeSeries12.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str19 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("hi!");
        java.lang.String str22 = timeSeries18.getDescription();
        int int23 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.lang.String str25 = timeSeries18.getRangeDescription();
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str31 = timeSeries30.getDescription();
        timeSeries30.setRangeDescription("hi!");
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int38 = month36.compareTo((java.lang.Object) (byte) 0);
        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1.0f), false);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str54 = timeSeries53.getDescription();
        timeSeries53.setRangeDescription("hi!");
        java.lang.String str57 = timeSeries53.getDescription();
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries47.addAndOrUpdate(timeSeries53);
        int int60 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries53);
        timeSeries61.setNotify(false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test160");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        int int7 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test161");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        java.lang.String str16 = timeSeries9.getRangeDescription();
//        timeSeries9.fireSeriesChanged();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries9.addChangeListener(seriesChangeListener18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) '4');
//        int int23 = year21.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.util.Date date25 = month24.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod28, (java.lang.Number) 100.0d);
//        boolean boolean31 = timeSeriesDataItem30.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1);
//        long long39 = fixedMillisecond36.getSerialIndex();
//        java.util.Date date40 = fixedMillisecond36.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
//        boolean boolean43 = timeSeriesDataItem30.equals((java.lang.Object) month42);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) month42);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183820351L + "'", long39 == 1560183820351L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(timeSeries44);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62041132800000L) + "'", long2 == (-62041132800000L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int2 = month0.getMonth();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str7 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("hi!");
        timeSeries6.setDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int14 = month12.compareTo((java.lang.Object) (byte) 0);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        timeSeries6.removeAgedItems((long) (byte) 10, true);
        boolean boolean19 = month0.equals((java.lang.Object) (byte) 10);
        java.util.Date date20 = month0.getEnd();
        java.util.Calendar calendar21 = null;
        try {
            month0.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.util.Collection collection11 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems(0L, true);
        timeSeries3.setDomainDescription("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        timeSeries21.setRangeDescription("hi!");
        timeSeries21.setDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
        int int35 = month27.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) 12);
        timeSeriesDataItem37.setValue((java.lang.Number) 1561964399999L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy(0, (int) '4');
        double double17 = timeSeries3.getMinY();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        double double5 = timeSeries4.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        boolean boolean11 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str16 = timeSeries15.getDescription();
        timeSeries15.setRangeDescription("hi!");
        java.lang.String str19 = timeSeries15.getDescription();
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries9.addAndOrUpdate(timeSeries15);
        java.lang.String str22 = timeSeries15.getRangeDescription();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        timeSeries27.setDescription("");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int35 = month33.compareTo((java.lang.Object) (byte) 0);
        int int36 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month33, (double) (-1.0f), false);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 9223372036854775807L, false);
        java.util.Collection collection43 = timeSeries4.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeries4.getTimePeriod((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(collection43);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test168");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        timeSeries12.setRangeDescription("hi!");
        timeSeries12.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month45, (double) 1560183727081L, false);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str60 = timeSeries59.getDescription();
        timeSeries59.setRangeDescription("hi!");
        timeSeries59.setDescription("");
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        int int67 = month65.compareTo((java.lang.Object) (byte) 0);
        int int68 = timeSeries59.getIndex((org.jfree.data.time.RegularTimePeriod) month65);
        double double69 = timeSeries59.getMinY();
        timeSeries59.clear();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries3.addAndOrUpdate(timeSeries59);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries71);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.Number number13 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        long long15 = year12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int2 = month0.getMonth();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str7 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("hi!");
        timeSeries6.setDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int14 = month12.compareTo((java.lang.Object) (byte) 0);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        timeSeries6.removeAgedItems((long) (byte) 10, true);
        boolean boolean19 = month0.equals((java.lang.Object) (byte) 10);
        long long20 = month0.getFirstMillisecond();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month0.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 6);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str7 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("hi!");
        timeSeries6.setDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int14 = month12.compareTo((java.lang.Object) (byte) 0);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month12.next();
        long long17 = month12.getFirstMillisecond();
        int int18 = month2.compareTo((java.lang.Object) month12);
        org.jfree.data.time.Year year19 = month12.getYear();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "30-June-2019", "53");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries22.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2013) + "'", int18 == (-2013));
        org.junit.Assert.assertNotNull(year19);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test173");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        java.lang.String str16 = timeSeries9.getRangeDescription();
//        timeSeries9.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str22 = timeSeries21.getDescription();
//        timeSeries21.setRangeDescription("hi!");
//        timeSeries21.setDescription("");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        int int29 = month27.compareTo((java.lang.Object) (byte) 0);
//        int int30 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1.0f), false);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 1);
//        long long41 = fixedMillisecond38.getSerialIndex();
//        java.util.Date date42 = fixedMillisecond38.getTime();
//        boolean boolean44 = fixedMillisecond38.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) '4');
//        long long47 = year46.getLastMillisecond();
//        boolean boolean48 = fixedMillisecond38.equals((java.lang.Object) year46);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond38.getMiddleMillisecond(calendar49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond38.next();
//        java.lang.Object obj52 = null;
//        boolean boolean53 = fixedMillisecond38.equals(obj52);
//        try {
//            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 1560183792533L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560183820969L + "'", long41 == 1560183820969L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-60494745600001L) + "'", long47 == (-60494745600001L));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560183820969L + "'", long50 == 1560183820969L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        double double5 = timeSeries4.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        boolean boolean11 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str16 = timeSeries15.getDescription();
        timeSeries15.setRangeDescription("hi!");
        java.lang.String str19 = timeSeries15.getDescription();
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries9.addAndOrUpdate(timeSeries15);
        java.lang.String str22 = timeSeries15.getRangeDescription();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        timeSeries27.setDescription("");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int35 = month33.compareTo((java.lang.Object) (byte) 0);
        int int36 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month33, (double) (-1.0f), false);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 9223372036854775807L, false);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.util.Date date44 = month43.getStart();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month43, "hi!", "hi!");
        timeSeries47.clear();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries47);
        int int50 = month33.compareTo((java.lang.Object) timeSeries47);
        java.util.Calendar calendar51 = null;
        try {
            long long52 = month33.getFirstMillisecond(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "10-June-2019", seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent6.setSummary(seriesChangeInfo7);
        boolean boolean9 = day3.equals((java.lang.Object) seriesChangeEvent6);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day3.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        timeSeries12.setRangeDescription("hi!");
        timeSeries12.setDescription("");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int20 = month18.compareTo((java.lang.Object) (byte) 0);
        int int21 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        java.util.List list22 = timeSeries12.getItems();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        int int27 = year25.compareTo((java.lang.Object) 0L);
        int int28 = year25.getYear();
        java.lang.Number number29 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) year25);
        boolean boolean30 = year8.equals((java.lang.Object) timeSeries12);
        java.lang.String str31 = year8.toString();
        java.util.Date date32 = year8.getEnd();
        java.util.TimeZone timeZone33 = null;
        java.util.Locale locale34 = null;
        try {
            org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32, timeZone33, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        boolean boolean8 = timeSeries3.getNotify();
        int int9 = timeSeries3.getItemCount();
        timeSeries3.setKey((java.lang.Comparable) 1560183727020L);
        java.lang.Comparable comparable12 = timeSeries3.getKey();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560183727020L + "'", comparable12.equals(1560183727020L));
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test178");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        long long19 = day17.getLastMillisecond();
//        java.lang.String str20 = day17.toString();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day17, (double) 7);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str27 = timeSeries26.getDescription();
//        timeSeries26.setRangeDescription("hi!");
//        timeSeries26.setDescription("");
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        int int34 = month32.compareTo((java.lang.Object) (byte) 0);
//        int int35 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.util.Date date37 = month36.getStart();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "hi!", "hi!");
//        int int41 = month36.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month36.next();
//        boolean boolean43 = timeSeries26.equals((java.lang.Object) regularTimePeriod42);
//        java.lang.String str44 = timeSeries26.getDescription();
//        double double45 = timeSeries26.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str50 = timeSeries49.getDescription();
//        boolean boolean51 = timeSeries49.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str56 = timeSeries55.getDescription();
//        timeSeries55.setRangeDescription("hi!");
//        java.lang.String str59 = timeSeries55.getDescription();
//        int int60 = timeSeries55.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries49.addAndOrUpdate(timeSeries55);
//        java.lang.String str62 = timeSeries55.getRangeDescription();
//        timeSeries55.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str68 = timeSeries67.getDescription();
//        timeSeries67.setRangeDescription("hi!");
//        timeSeries67.setDescription("");
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
//        int int75 = month73.compareTo((java.lang.Object) (byte) 0);
//        int int76 = timeSeries67.getIndex((org.jfree.data.time.RegularTimePeriod) month73);
//        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) month73, (double) (-1.0f), false);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries55.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month80, 0.0d);
//        boolean boolean83 = timeSeriesDataItem82.isSelected();
//        timeSeriesDataItem82.setValue((java.lang.Number) 1560183737262L);
//        timeSeries26.add(timeSeriesDataItem82, false);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries15.addOrUpdate(timeSeriesDataItem82);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertNull(str50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNull(str56);
//        org.junit.Assert.assertNull(str59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
//        org.junit.Assert.assertNull(str68);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        boolean boolean14 = day3.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = day3.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        boolean boolean7 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str12 = timeSeries11.getDescription();
        timeSeries11.setRangeDescription("hi!");
        timeSeries11.setDescription("");
        timeSeries11.setKey((java.lang.Comparable) 10);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month19, (double) (byte) 1, true);
        java.lang.Number number24 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        try {
            timeSeries3.delete(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(number24);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        boolean boolean5 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.String str13 = timeSeries9.getDescription();
//        int int14 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
//        boolean boolean16 = timeSeries15.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1);
//        long long27 = fixedMillisecond24.getLastMillisecond();
//        int int28 = day19.compareTo((java.lang.Object) long27);
//        int int29 = day19.getDayOfMonth();
//        boolean boolean31 = day19.equals((java.lang.Object) (short) 100);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 'a', true);
//        timeSeries15.removeAgedItems(1560183733746L, false);
//        java.lang.Comparable comparable38 = timeSeries15.getKey();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        java.util.Date date40 = month39.getStart();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month42, (double) 1560183745559L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183821345L + "'", long27 == 1560183821345L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + comparable38 + "' != '" + "Overwritten values from: 100.0" + "'", comparable38.equals("Overwritten values from: 100.0"));
//        org.junit.Assert.assertNotNull(date40);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        timeSeries3.removeAgedItems((long) (byte) 10, true);
        try {
            timeSeries3.delete((int) (byte) 1, (int) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries3.getNotify();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "hi!", "hi!");
        timeSeries18.setDescription("");
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        boolean boolean23 = timeSeries22.getNotify();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        int int2 = year1.getYear();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560183758150L);
        timeSeriesDataItem6.setSelected(false);
        java.lang.Number number9 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1560183758150L + "'", number9.equals(1560183758150L));
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test185");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        boolean boolean10 = timeSeries1.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries1.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 1);
//        long long20 = fixedMillisecond17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond17.previous();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str28 = timeSeries27.getDescription();
//        timeSeries27.setRangeDescription("hi!");
//        timeSeries27.setDescription("");
//        timeSeries27.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries27.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str41 = timeSeries40.getDescription();
//        timeSeries40.setRangeDescription("hi!");
//        timeSeries40.setDescription("");
//        timeSeries40.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener48 = null;
//        timeSeries40.addPropertyChangeListener(propertyChangeListener48);
//        java.lang.String str50 = timeSeries40.getDescription();
//        java.util.Collection collection51 = timeSeries40.getTimePeriods();
//        java.util.Collection collection52 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        timeSeries27.setDomainDescription("June 2019");
//        int int55 = year23.compareTo((java.lang.Object) timeSeries27);
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) year23);
//        timeSeries1.setMaximumItemCount(11);
//        try {
//            java.lang.Number number60 = timeSeries1.getValue(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560183821417L + "'", long20 == 1560183821417L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(timeSeries56);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "hi!", "hi!");
        int int5 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        int int11 = day9.getYear();
        long long12 = day9.getFirstMillisecond();
        java.util.Date date13 = day9.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964400000L + "'", long12 == 1561964400000L);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1);
//        long long8 = fixedMillisecond5.getLastMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate10);
//        int int13 = day12.getDayOfMonth();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183821513L + "'", long8 == 1560183821513L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("0");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1560183768591L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        boolean boolean4 = day0.equals((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str11 = timeSeries10.getDescription();
        timeSeries10.setRangeDescription("hi!");
        timeSeries10.setDescription("");
        timeSeries10.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str24 = timeSeries23.getDescription();
        timeSeries23.setRangeDescription("hi!");
        timeSeries23.setDescription("");
        timeSeries23.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener31);
        java.lang.String str33 = timeSeries23.getDescription();
        java.util.Collection collection34 = timeSeries23.getTimePeriods();
        java.util.Collection collection35 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        timeSeries10.setDomainDescription("June 2019");
        int int38 = year6.compareTo((java.lang.Object) timeSeries10);
        long long39 = year6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year6.previous();
        int int42 = day0.compareTo((java.lang.Object) year6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "org.jfree.data.time.TimePeriodFormatException: hi!", "1-June-2019");
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, (java.lang.Number) 100.0d);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.util.Date date16 = month15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries6.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Number number22 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, number22);
        boolean boolean24 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.util.Date date26 = month25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem31.getPeriod();
        boolean boolean33 = timeSeriesDataItem23.equals((java.lang.Object) regularTimePeriod32);
        timeSeriesDataItem23.setValue((java.lang.Number) 1560183785375L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        timeSeries3.setDomainDescription("June 52");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "hi!", "hi!");
        int int18 = month13.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month13.next();
        boolean boolean20 = timeSeries3.equals((java.lang.Object) regularTimePeriod19);
        java.lang.Comparable comparable21 = timeSeries3.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean33 = timeSeries24.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries24.addChangeListener(seriesChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) 1560183782707L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond37.getMiddleMillisecond(calendar40);
        try {
            org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy(regularTimePeriod22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1L + "'", long41 == 1L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        timeSeries9.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.removeChangeListener(seriesChangeListener19);
        java.lang.Object obj21 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str26 = timeSeries25.getDescription();
        boolean boolean27 = timeSeries25.getNotify();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str32 = timeSeries31.getDescription();
        timeSeries31.setRangeDescription("hi!");
        java.lang.String str35 = timeSeries31.getDescription();
        int int36 = timeSeries31.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries25.addAndOrUpdate(timeSeries31);
        java.lang.String str38 = timeSeries31.getRangeDescription();
        timeSeries31.fireSeriesChanged();
        java.util.List list40 = timeSeries31.getItems();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        java.util.Date date42 = month41.getStart();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date42);
        boolean boolean46 = fixedMillisecond44.equals((java.lang.Object) 10);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond44.getLastMillisecond(calendar47);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 1560183740493L);
        long long51 = fixedMillisecond44.getLastMillisecond();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 1560183802788L, false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1559372400000L + "'", long48 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        java.lang.String str62 = year57.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test196");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str4 = timeSeries3.getDescription();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int11 = month9.compareTo((java.lang.Object) (byte) 0);
//        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries3.getDescription();
//        double double17 = timeSeries3.getMaxY();
//        java.lang.String str18 = timeSeries3.getRangeDescription();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        java.util.Date date20 = month19.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 10.0d);
//        java.lang.Number number26 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str41 = timeSeries40.getDescription();
//        boolean boolean42 = timeSeries40.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str47 = timeSeries46.getDescription();
//        timeSeries46.setRangeDescription("hi!");
//        java.lang.String str50 = timeSeries46.getDescription();
//        int int51 = timeSeries46.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries40.addAndOrUpdate(timeSeries46);
//        int int53 = timeSeries46.getMaximumItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener54 = null;
//        timeSeries46.removeChangeListener(seriesChangeListener54);
//        boolean boolean56 = fixedMillisecond33.equals((java.lang.Object) timeSeries46);
//        java.util.Date date57 = fixedMillisecond33.getStart();
//        long long58 = fixedMillisecond33.getSerialIndex();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
//        timeSeries3.removeAgedItems(false);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNull(str47);
//        org.junit.Assert.assertNull(str50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2147483647 + "'", int53 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560183822534L + "'", long58 == 1560183822534L);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test197");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str8 = timeSeries7.getDescription();
//        timeSeries7.setRangeDescription("hi!");
//        timeSeries7.setDescription("");
//        timeSeries7.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener15);
//        java.lang.String str17 = timeSeries7.getDescription();
//        java.lang.String str18 = timeSeries7.getDomainDescription();
//        boolean boolean19 = day0.equals((java.lang.Object) timeSeries7);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str8 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("hi!");
        timeSeries7.setDescription("");
        timeSeries7.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener15);
        timeSeries7.setNotify(true);
        boolean boolean19 = day3.equals((java.lang.Object) true);
        long long20 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559458799999L + "'", long20 == 1559458799999L);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test199");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1);
//        long long7 = fixedMillisecond4.getSerialIndex();
//        java.util.Date date8 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str15 = timeSeries14.getDescription();
//        timeSeries14.setRangeDescription("hi!");
//        timeSeries14.setDescription("");
//        timeSeries14.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries14.addPropertyChangeListener(propertyChangeListener22);
//        java.lang.String str24 = timeSeries14.getDescription();
//        java.util.Collection collection25 = timeSeries14.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        java.lang.String str30 = timeSeries29.getDescription();
//        timeSeries29.setRangeDescription("hi!");
//        timeSeries29.setDescription("");
//        timeSeries29.setKey((java.lang.Comparable) 10);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries29.addPropertyChangeListener(propertyChangeListener37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 1);
//        long long47 = fixedMillisecond44.getLastMillisecond();
//        int int48 = day39.compareTo((java.lang.Object) long47);
//        int int49 = day39.getDayOfMonth();
//        boolean boolean51 = day39.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) '4');
//        boolean boolean55 = year53.equals((java.lang.Object) 0);
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) day39, (org.jfree.data.time.RegularTimePeriod) year53);
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, number57);
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (double) 1);
//        long long66 = fixedMillisecond63.getSerialIndex();
//        java.util.Date date67 = fixedMillisecond63.getTime();
//        boolean boolean69 = fixedMillisecond63.equals((java.lang.Object) 'a');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond63.next();
//        java.util.Date date71 = fixedMillisecond63.getStart();
//        long long72 = fixedMillisecond63.getLastMillisecond();
//        timeSeries14.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (java.lang.Number) 1.0d);
//        java.util.Date date75 = fixedMillisecond63.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond63.previous();
//        boolean boolean77 = month10.equals((java.lang.Object) fixedMillisecond63);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183822770L + "'", long7 == 1560183822770L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560183822777L + "'", long47 == 1560183822777L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560183822779L + "'", long66 == 1560183822779L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560183822779L + "'", long72 == 1560183822779L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.setDescription("");
        timeSeries3.setKey((java.lang.Comparable) 10);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries3.getDescription();
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) 9999, false);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        int int53 = month45.compareTo((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year54 = month45.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.util.Date date56 = month55.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int59 = year57.compareTo((java.lang.Object) 0L);
        int int60 = year57.getYear();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) year57);
        int int62 = year57.getYear();
        long long63 = year57.getFirstMillisecond();
        long long64 = year57.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1546329600000L + "'", long63 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1546329600000L + "'", long64 == 1546329600000L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str13 = timeSeries12.getDescription();
        timeSeries12.setRangeDescription("hi!");
        timeSeries12.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str22 = timeSeries21.getDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.setRangeDescription("hi!");
        java.lang.String str31 = timeSeries27.getDescription();
        int int32 = timeSeries27.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries27);
        java.lang.String str34 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str40 = timeSeries39.getDescription();
        timeSeries39.setRangeDescription("hi!");
        timeSeries39.setDescription("");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int47 = month45.compareTo((java.lang.Object) (byte) 0);
        int int48 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1.0f), false);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month45);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month45, (double) 1560183727081L, false);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year((int) '4');
        long long58 = year57.getLastMillisecond();
        int int59 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year57);
        int int60 = year57.getYear();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year((int) '4');
        boolean boolean64 = year62.equals((java.lang.Object) 0);
        int int65 = year57.compareTo((java.lang.Object) boolean64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year57.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-60494745600001L) + "'", long58 == (-60494745600001L));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 52 + "'", int60 == 52);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        int int9 = year4.compareTo((java.lang.Object) day8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        int int14 = day13.getDayOfMonth();
        boolean boolean15 = year4.equals((java.lang.Object) day13);
        java.util.Calendar calendar16 = null;
        try {
            year4.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str4 = timeSeries3.getDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "", "hi!");
        java.lang.String str10 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("hi!");
        java.lang.String str13 = timeSeries9.getDescription();
        int int14 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries9);
        boolean boolean16 = timeSeries15.isEmpty();
        java.lang.String str17 = timeSeries15.getRangeDescription();
        java.lang.String str18 = timeSeries15.getRangeDescription();
        timeSeries15.removeAgedItems(true);
        timeSeries15.setRangeDescription("30-June-2019");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
    }
}

