import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo2.getPlotInfo();
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer6);
        boolean boolean8 = plotRenderingInfo1.equals((java.lang.Object) seriesChangeEvent7);
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.awt.Paint paint7 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        combinedRangeXYPlot1.mapDatasetToRangeAxis((int) (byte) 0, 4);
        java.awt.Stroke stroke11 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = polarPlot0.getDataRange(valueAxis3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepAreaRenderer8.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYStepAreaRenderer8.setBaseToolTipGenerator(xYToolTipGenerator13, false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYStepAreaRenderer8.initialise(graphics2D16, rectangle2D17, xYPlot18, xYDataset19, plotRenderingInfo20);
        java.awt.Paint paint23 = xYStepAreaRenderer8.getSeriesPaint((int) (short) 100);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer8.setSeriesItemLabelFont((int) (short) 10, font25, false);
        polarPlot0.setAngleLabelFont(font25);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color31 = java.awt.Color.getColor("", color30);
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color31);
        boolean boolean33 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis7.setPlot((org.jfree.chart.plot.Plot) waferMapPlot8);
        java.awt.Paint paint10 = categoryAxis7.getTickMarkPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Paint paint16 = xYStepAreaRenderer12.getItemOutlinePaint((int) (byte) -1, 5, false);
        boolean boolean17 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint16);
        xYStepAreaRenderer1.setSeriesPaint(11, paint10, false);
        xYStepAreaRenderer1.setBaseSeriesVisibleInLegend(true, false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.lookupLegendTextPaint(13);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        java.lang.Comparable comparable4 = null;
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, comparable4, 0.0d, 7);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot1.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color22 = java.awt.Color.RED;
        xYStepAreaRenderer16.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color22, false);
        categoryAxis12.setTickLabelPaint((java.awt.Paint) color22);
        java.awt.Paint paint26 = categoryAxis12.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = combinedRangeXYPlot28.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke31 = combinedRangeXYPlot28.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint26, stroke31);
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker32, layer33);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        double double41 = dateRange40.getLength();
        double double42 = dateRange40.getLowerBound();
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange40);
        boolean boolean44 = layer39.equals((java.lang.Object) dateRange43);
        combinedRangeXYPlot1.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38, layer39);
        combinedRangeXYPlot1.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint2 = ringPlot0.getOutlinePaint();
        java.awt.Color color3 = java.awt.Color.GRAY;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = ringPlot0.getSimpleLabelOffset();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesShapesVisible((int) (byte) 10, false);
        xYStepRenderer2.setBaseLinesVisible(true);
        double double8 = xYStepRenderer2.getItemLabelAnchorOffset();
        boolean boolean9 = xYStepRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = xYStepRenderer2.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0.5f, font4);
        double double8 = categoryAxis0.getLabelAngle();
        double double9 = categoryAxis0.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke14 = combinedRangeXYPlot11.getDomainGridlineStroke();
        combinedRangeXYPlot11.setRangePannable(true);
        java.awt.Stroke stroke17 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        categoryAxis0.setTickMarkStroke(stroke17);
        java.lang.String str19 = categoryAxis0.getLabel();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat4.setMaximumIntegerDigits((-1));
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat11.setParseIntegerOnly(true);
        boolean boolean15 = logFormat11.equals((java.lang.Object) 2);
        java.lang.String str17 = logFormat11.format(10L);
        java.lang.Object obj18 = null;
        boolean boolean19 = logFormat11.equals(obj18);
        java.text.DateFormat dateFormat20 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat11, dateFormat20);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RectangleAnchor.LEFT", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "^-0.0" + "'", str17.equals("^-0.0"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic8.setOutlineStroke(stroke10);
        legendGraphic8.setShapeFilled(true);
        java.lang.Object obj14 = legendGraphic8.clone();
        boolean boolean15 = legendGraphic8.isShapeFilled();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("SeriesRenderingOrder.FORWARD", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) xYAreaRenderer2);
        boolean boolean5 = xYAreaRenderer2.getPlotArea();
        java.awt.Shape shape6 = xYAreaRenderer2.getBaseShape();
        xYAreaRenderer2.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYStepAreaRenderer3.setBaseURLGenerator(xYURLGenerator11, true);
        java.awt.Font font17 = xYStepAreaRenderer3.getItemLabelFont((int) (short) 1, (int) ' ', true);
        java.awt.Font font19 = xYStepAreaRenderer3.getLegendTextFont(5);
        boolean boolean23 = xYStepAreaRenderer3.isItemLabelVisible(13, (int) '#', false);
        boolean boolean24 = xYStepAreaRenderer3.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        org.jfree.data.UnknownKeyException unknownKeyException6 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException8 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException6.addSuppressed((java.lang.Throwable) unknownKeyException8);
        java.lang.Throwable[] throwableArray10 = unknownKeyException8.getSuppressed();
        java.lang.String str11 = unknownKeyException8.toString();
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str11.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setSectionOutlinesVisible(true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 13, (float) (short) 10);
        org.jfree.chart.axis.Axis axis3 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity5 = new org.jfree.chart.entity.AxisEntity(shape2, axis3, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = polarPlot0.getDataRange(valueAxis3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setAutoPopulateSeriesPaint(true);
        double double8 = xYAreaRenderer5.getItemLabelAnchorOffset();
        boolean boolean9 = xYAreaRenderer5.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedRangeXYPlot14.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot12.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset18 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot12.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator23, xYURLGenerator24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color31 = java.awt.Color.RED;
        xYStepAreaRenderer25.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color31, false);
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color31);
        java.awt.Paint paint35 = categoryAxis21.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = combinedRangeXYPlot37.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke40 = combinedRangeXYPlot37.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint35, stroke40);
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = combinedRangeXYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker41, layer42);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke49 = null;
        xYAreaRenderer5.drawRangeLine(graphics2D10, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis45, rectangle2D46, (double) 60000L, paint48, stroke49);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot51 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.data.Range range52 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = null;
        dateAxis45.setTickUnit(dateTickUnit54, false, false);
        dateAxis45.resizeRange((double) 15);
        org.jfree.chart.axis.TickUnitSource tickUnitSource60 = dateAxis45.getStandardTickUnits();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(tickUnitSource60);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible(2);
        java.awt.Color color6 = java.awt.Color.green;
        xYStepRenderer2.setSeriesOutlinePaint(2958465, (java.awt.Paint) color6, false);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYStepRenderer2.setSeriesOutlineStroke(3, stroke10);
        xYStepRenderer2.setAutoPopulateSeriesShape(false);
        java.awt.Stroke stroke15 = xYStepRenderer2.lookupSeriesStroke(5);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle5.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo11.getDataArea();
        textTitle5.draw(graphics2D9, rectangle2D12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        textTitle15.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle15.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle15.getBounds();
        textTitle5.draw(graphics2D14, rectangle2D19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = ringPlot21.getToolTipGenerator();
        java.lang.Object obj23 = ringPlot21.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = null;
        ringPlot21.setURLGenerator(pieURLGenerator24);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator26 = null;
        ringPlot21.setToolTipGenerator(pieToolTipGenerator26);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator29, xYURLGenerator30);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = xYStepAreaRenderer31.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color37 = java.awt.Color.RED;
        xYStepAreaRenderer31.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color37, false);
        ringPlot21.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.title.LegendGraphic legendGraphic41 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D19, (java.awt.Paint) color37);
        try {
            barRenderer3D0.drawOutline(graphics2D3, categoryPlot4, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNull(pieToolTipGenerator22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer9.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYStepAreaRenderer9.setBaseToolTipGenerator(xYToolTipGenerator14, false);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState22 = xYStepAreaRenderer9.initialise(graphics2D17, rectangle2D18, xYPlot19, xYDataset20, plotRenderingInfo21);
        java.awt.Paint paint24 = xYStepAreaRenderer9.getSeriesPaint((int) (short) 100);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer9.setSeriesItemLabelFont((int) (short) 10, font26, false);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("", font26, (java.awt.Paint) color29);
        java.awt.Color color31 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot35.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot33.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot35);
        java.awt.geom.Point2D point2D39 = combinedRangeXYPlot35.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = combinedRangeXYPlot35.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("100", font26, (java.awt.Paint) color31, rectangleEdge40, horizontalAlignment41, verticalAlignment42, rectangleInsets43);
        double double46 = rectangleInsets43.calculateRightInset((double) (-457));
        textTitle0.setPadding(rectangleInsets43);
        java.awt.Color color48 = java.awt.Color.YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color48);
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder49);
        double double51 = textTitle0.getWidth();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(xYItemRendererState22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(point2D39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        double double9 = timeSeries4.getMaxY();
        long long10 = timeSeries4.getMaximumItemAge();
        timeSeries4.setDescription("LegendItemEntity: seriesKey=11, dataset=null");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.awt.Paint paint9 = null;
        combinedRangeXYPlot1.setBackgroundPaint(paint9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo2.getPlotInfo();
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo3);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = plotRenderingInfo3.getSubplotInfo(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        int int3 = xYSeries1.indexOf((java.lang.Number) 0.5f);
        java.lang.Object obj4 = xYSeries1.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.updateCrosshairY((double) 2, 6);
        double double5 = crosshairState1.getAnchorX();
        int int6 = crosshairState1.getRangeAxisIndex();
        crosshairState1.setDatasetIndex(9);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = polarPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(polarItemRenderer2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot2.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4);
        java.awt.Paint paint8 = combinedRangeXYPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        dateAxis11.setInverted(true);
        combinedRangeXYPlot2.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone15 = dateAxis11.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone15);
        dateAxis16.setLowerMargin((double) 3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears(12, serialDate3);
        serialDate3.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate3);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = serialDate3.getEndOfCurrentMonth(serialDate11);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset17 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset17.validateObject();
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset17);
        xYItemRendererState16.endSeriesPass((org.jfree.data.xy.XYDataset) defaultXYDataset17, (int) (byte) 1, 4, 1, 6, (int) ' ');
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot2.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4);
        java.awt.Paint paint8 = combinedRangeXYPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        dateAxis11.setInverted(true);
        combinedRangeXYPlot2.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone15 = dateAxis11.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone15);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean24 = segmentedTimeline21.containsDomainRange((long) '4', (long) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getDomainGridlineStroke();
        java.util.List list30 = combinedRangeXYPlot26.getAnnotations();
        segmentedTimeline21.addExceptions(list30);
        org.jfree.data.Range range33 = timeSeriesCollection17.getDomainBounds(list30, false);
        try {
            boolean boolean36 = timeSeriesCollection17.isSelected(12, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (12).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = ringPlot1.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = ringPlot1.getLabelDistributor();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = ringPlot6.getToolTipGenerator();
        java.awt.Paint paint8 = ringPlot6.getOutlinePaint();
        java.awt.Color color9 = java.awt.Color.GRAY;
        ringPlot6.setBaseSectionPaint((java.awt.Paint) color9);
        org.jfree.chart.util.Rotation rotation11 = ringPlot6.getDirection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot1.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 0, plotRenderingInfo14);
        ringPlot6.setLabelLinksVisible(false);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleAnchor.LEFT", (org.jfree.chart.plot.Plot) ringPlot6);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Stroke stroke23 = xYAreaRenderer21.getSeriesOutlineStroke(0);
        xYAreaRenderer21.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = xYAreaRenderer21.getSeriesPositiveItemLabelPosition(13);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator29 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer21.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot35.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot33.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot35);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset39 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot33.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo43 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str44 = projectInfo43.getLicenceText();
        java.util.List list45 = projectInfo43.getContributors();
        combinedRangeXYPlot33.drawRangeTickBands(graphics2D41, rectangle2D42, list45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.setInverted(true);
        dateAxis48.setMinorTickMarkOutsideLength(0.0f);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle();
        textTitle53.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment56 = textTitle53.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
        java.awt.geom.Rectangle2D rectangle2D60 = plotRenderingInfo59.getDataArea();
        textTitle53.draw(graphics2D57, rectangle2D60);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.title.TextTitle textTitle63 = new org.jfree.chart.title.TextTitle();
        textTitle63.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment66 = textTitle63.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle63.getBounds();
        textTitle53.draw(graphics2D62, rectangle2D67);
        xYAreaRenderer21.fillRangeGridBand(graphics2D31, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot33, (org.jfree.chart.axis.ValueAxis) dateAxis48, rectangle2D67, 1.0d, 100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo72 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = chartRenderingInfo72.getPlotInfo();
        org.jfree.chart.RenderingSource renderingSource74 = null;
        chartRenderingInfo72.setRenderingSource(renderingSource74);
        try {
            jFreeChart18.draw(graphics2D19, rectangle2D67, chartRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(projectInfo43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "{0}" + "'", str44.equals("{0}"));
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(horizontalAlignment56);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(horizontalAlignment66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(plotRenderingInfo73);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("hi!", font3, (java.awt.Paint) color4);
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) color4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("100", "100");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) double3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        java.util.List list14 = jFreeChart10.getSubtitles();
        org.jfree.chart.plot.Plot plot15 = jFreeChart10.getPlot();
        int int16 = jFreeChart10.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart10.getLegend((int) ' ');
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNull(legendTitle18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-1L), (float) 60000L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) '#');
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (byte) 100);
        java.awt.Shape shape4 = null;
        shapeList0.setShape((int) '4', shape4);
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color10 = java.awt.Color.RED;
        xYStepAreaRenderer4.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color10, false);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setTickMarkInsideLength(0.5f);
        categoryAxis0.setLabelURL("1.2.0-pre");
        categoryAxis0.setCategoryLabelPositionOffset(7);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, 11, (int) (byte) 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("hi!", font3, (java.awt.Paint) color4);
        xYAreaRenderer1.setBaseFillPaint((java.awt.Paint) color4, false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer10.setAutoPopulateSeriesPaint(true);
        double double13 = xYAreaRenderer10.getItemLabelAnchorOffset();
        boolean boolean14 = xYAreaRenderer10.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = combinedRangeXYPlot19.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot17.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot17.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator28, xYURLGenerator29);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = xYStepAreaRenderer30.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color36 = java.awt.Color.RED;
        xYStepAreaRenderer30.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color36, false);
        categoryAxis26.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint40 = categoryAxis26.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis41);
        org.jfree.chart.axis.AxisLocation axisLocation44 = combinedRangeXYPlot42.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke45 = combinedRangeXYPlot42.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint40, stroke45);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = combinedRangeXYPlot17.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker46, layer47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.awt.Paint paint53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke54 = null;
        xYAreaRenderer10.drawRangeLine(graphics2D15, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D51, (double) 60000L, paint53, stroke54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        xYAreaRenderer1.drawDomainGridLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D56, (double) (short) -1);
        java.awt.Font font59 = dateAxis50.getTickLabelFont();
        double double60 = dateAxis50.getLabelAngle();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) -1, (float) 10);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = polarPlot3.getDataRange(valueAxis6);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer8.setAutoPopulateSeriesPaint(true);
        double double11 = xYAreaRenderer8.getItemLabelAnchorOffset();
        boolean boolean12 = xYAreaRenderer8.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot15.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot15.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator26, xYURLGenerator27);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = xYStepAreaRenderer28.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color34 = java.awt.Color.RED;
        xYStepAreaRenderer28.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color34, false);
        categoryAxis24.setTickLabelPaint((java.awt.Paint) color34);
        java.awt.Paint paint38 = categoryAxis24.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = combinedRangeXYPlot40.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke43 = combinedRangeXYPlot40.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint38, stroke43);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = combinedRangeXYPlot15.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker44, layer45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke52 = null;
        xYAreaRenderer8.drawRangeLine(graphics2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) dateAxis48, rectangle2D49, (double) 60000L, paint51, stroke52);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot54 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.data.Range range55 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = null;
        dateAxis48.setTickUnit(dateTickUnit57, false, false);
        org.jfree.chart.entity.AxisEntity axisEntity63 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) dateAxis48, "-3,-3,3,3", "index.html");
        java.lang.Object obj64 = axisEntity63.clone();
        java.lang.String str65 = axisEntity63.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "AxisEntity: tooltip = -3,-3,3,3" + "'", str65.equals("AxisEntity: tooltip = -3,-3,3,3"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic8.setOutlineStroke(stroke10);
        java.lang.Object obj12 = legendGraphic8.clone();
        legendGraphic8.setHeight((double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendGraphic8.getShapeAnchor();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke8 = xYStepRenderer2.getItemStroke(15, (int) '4', true);
        java.awt.Shape shape9 = null;
        try {
            xYStepRenderer2.setLegendLine(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setDomainAxis(100, valueAxis3, true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot15.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17);
        java.awt.geom.Point2D point2D21 = combinedRangeXYPlot17.getQuadrantOrigin();
        combinedRangeXYPlot7.zoomRangeAxes((double) 43629L, (double) (short) 100, plotRenderingInfo13, point2D21);
        combinedRangeXYPlot1.setQuadrantOrigin(point2D21);
        combinedRangeXYPlot1.setNotify(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = combinedRangeXYPlot1.getDomainAxisEdge((-2236514));
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo30.getDataArea();
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = chartRenderingInfo34.getPlotInfo();
        try {
            combinedRangeXYPlot1.draw(graphics2D28, rectangle2D31, point2D32, plotState33, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(plotRenderingInfo35);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer2.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean8 = xYLineAndShapeRenderer2.getItemLineVisible(0, 3);
        java.lang.Class<?> wildcardClass9 = xYLineAndShapeRenderer2.getClass();
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("1.2.0-pre", (java.lang.Class) wildcardClass9);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("^-0.0", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 2, "JFreeChart", "1.2.0-pre", true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) -1, (float) 10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Stroke stroke6 = xYAreaRenderer4.getSeriesOutlineStroke(0);
        xYAreaRenderer4.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer4.getSeriesPositiveItemLabelPosition(13);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator12 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = combinedRangeXYPlot18.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot16.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset22 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot16.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo26 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str27 = projectInfo26.getLicenceText();
        java.util.List list28 = projectInfo26.getContributors();
        combinedRangeXYPlot16.drawRangeTickBands(graphics2D24, rectangle2D25, list28);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        dateAxis31.setInverted(true);
        dateAxis31.setMinorTickMarkOutsideLength(0.0f);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        textTitle36.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = textTitle36.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo42.getDataArea();
        textTitle36.draw(graphics2D40, rectangle2D43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        textTitle46.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = textTitle46.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D50 = textTitle46.getBounds();
        textTitle36.draw(graphics2D45, rectangle2D50);
        xYAreaRenderer4.fillRangeGridBand(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16, (org.jfree.chart.axis.ValueAxis) dateAxis31, rectangle2D50, 1.0d, 100.0d);
        org.jfree.chart.entity.PlotEntity plotEntity55 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(projectInfo26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{0}" + "'", str27.equals("{0}"));
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(horizontalAlignment49);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.addOrUpdate(xYDataItem4);
        xYSeries1.add((java.lang.Number) 5, (java.lang.Number) 86400000L);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        boolean boolean21 = xYSeries1.equals((java.lang.Object) false);
        boolean boolean22 = xYSeries1.getNotify();
        try {
            xYSeries1.update((java.lang.Number) 0.5d, (java.lang.Number) 0.5d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 0.5");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 2958465;
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset2 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset2.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset2, (java.lang.Comparable) 1.0f);
        defaultPieDataset2.insertValue(0, (java.lang.Comparable) 10, (double) ' ');
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(attributedString7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart10.getXYPlot();
        int int15 = jFreeChart10.getBackgroundImageAlignment();
        jFreeChart10.fireChartChanged();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("item", "index.html", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        xYStepAreaRenderer5.setBaseToolTipGenerator(xYToolTipGenerator10, false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYStepAreaRenderer5.initialise(graphics2D13, rectangle2D14, xYPlot15, xYDataset16, plotRenderingInfo17);
        java.awt.Paint paint20 = xYStepAreaRenderer5.getSeriesPaint((int) (short) 100);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer5.setSeriesItemLabelFont((int) (short) 10, font22, false);
        java.awt.Color color25 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("", font22, (java.awt.Paint) color25);
        java.awt.Color color27 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = combinedRangeXYPlot31.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot29.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot31);
        java.awt.geom.Point2D point2D35 = combinedRangeXYPlot31.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = combinedRangeXYPlot31.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("100", font22, (java.awt.Paint) color27, rectangleEdge36, horizontalAlignment37, verticalAlignment38, rectangleInsets39);
        double double42 = rectangleInsets39.calculateRightInset((double) (-457));
        double double44 = rectangleInsets39.calculateLeftInset((double) (-2236514));
        double double45 = rectangleInsets39.getLeft();
        double double47 = rectangleInsets39.extendHeight(1.0E-8d);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.00000001d + "'", double47 == 2.00000001d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYStepAreaRenderer3.getItemLabelGenerator((int) 'a', (-65536), true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4);
        boolean boolean6 = dateAxis1.isAutoRange();
        org.jfree.data.Range range7 = dateAxis1.getRange();
        dateAxis1.setAutoTickUnitSelection(true, false);
        double double11 = dateAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Paint paint5 = xYStepAreaRenderer1.getItemOutlinePaint((int) (byte) -1, 5, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot7.getRangeAxisLocation();
        xYStepAreaRenderer1.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot7);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("org.jfree.data.UnknownKeyException: hi!");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke10 = combinedRangeXYPlot7.getDomainGridlineStroke();
        combinedRangeXYPlot7.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent16 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset3, jFreeChart13, (int) ' ', 9999);
        java.util.List list17 = jFreeChart13.getSubtitles();
        org.jfree.chart.plot.Plot plot18 = jFreeChart13.getPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = rendererChangeEvent20.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) axisChangeEvent2, jFreeChart13, chartChangeEventType21);
        java.lang.Object obj23 = jFreeChart13.clone();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        textTitle8.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle8.getHorizontalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener12 = null;
        textTitle8.removeChangeListener(titleChangeListener12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle8.getTextAlignment();
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) textTitle8);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(10);
        int int2 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.distributeLabels(0.0d, 0.0d);
        pieLabelDistributor1.distributeLabels(0.0d, (double) (-61062825600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        boolean boolean3 = categoryAxis0.isAxisLineVisible();
        boolean boolean4 = categoryAxis0.isAxisLineVisible();
        org.jfree.chart.axis.AxisState axisState6 = new org.jfree.chart.axis.AxisState();
        java.util.List list7 = axisState6.getTicks();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Stroke stroke11 = xYAreaRenderer9.getSeriesOutlineStroke(0);
        xYAreaRenderer9.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYAreaRenderer9.getSeriesPositiveItemLabelPosition(13);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator17 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer9.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedRangeXYPlot23.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot23);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset27 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot21.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo31 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str32 = projectInfo31.getLicenceText();
        java.util.List list33 = projectInfo31.getContributors();
        combinedRangeXYPlot21.drawRangeTickBands(graphics2D29, rectangle2D30, list33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setInverted(true);
        dateAxis36.setMinorTickMarkOutsideLength(0.0f);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle();
        textTitle41.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = textTitle41.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        java.awt.geom.Rectangle2D rectangle2D48 = plotRenderingInfo47.getDataArea();
        textTitle41.draw(graphics2D45, rectangle2D48);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        textTitle51.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = textTitle51.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle51.getBounds();
        textTitle41.draw(graphics2D50, rectangle2D55);
        xYAreaRenderer9.fillRangeGridBand(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot21, (org.jfree.chart.axis.ValueAxis) dateAxis36, rectangle2D55, 1.0d, 100.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        try {
            double double61 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) 12, list7, rectangle2D55, rectangleEdge60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(projectInfo31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{0}" + "'", str32.equals("{0}"));
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = ringPlot2.getToolTipGenerator();
        boolean boolean5 = ringPlot2.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape6 = ringPlot2.getLegendItemShape();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator7 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset8 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset8);
        java.lang.Object obj11 = defaultXYDataset8.clone();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset8, false);
        java.lang.String str16 = standardXYURLGenerator7.generateURL((org.jfree.data.xy.XYDataset) defaultXYDataset8, (int) (short) -1, 0);
        org.jfree.chart.entity.XYItemEntity xYItemEntity21 = new org.jfree.chart.entity.XYItemEntity(shape6, (org.jfree.data.xy.XYDataset) defaultXYDataset8, (int) 'a', 0, "TimePeriodAnchor.END", "RectangleAnchor.LEFT");
        xYItemEntity21.setSeriesIndex((int) 'a');
        int int24 = xYItemEntity21.getItem();
        java.lang.String str25 = xYItemEntity21.toString();
        xYItemEntity21.setURLText("{0}");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset28 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset28.validateObject();
        xYItemEntity21.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset28);
        xYItemRendererState1.endSeriesPass((org.jfree.data.xy.XYDataset) defaultXYDataset28, 13, 7, 0, 0, 30);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "index.html?series=-1&amp;item=0" + "'", str16.equals("index.html?series=-1&amp;item=0"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getDomainGridlineStroke();
        java.util.List list7 = combinedRangeXYPlot3.getAnnotations();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer9);
        java.awt.Font font11 = xYAreaRenderer9.getBaseItemLabelFont();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!", font14, (java.awt.Paint) color15);
        xYAreaRenderer9.setSeriesPaint(2958465, (java.awt.Paint) color15);
        combinedRangeXYPlot3.setRangeTickBandPaint((java.awt.Paint) color15);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color15);
        java.lang.Object obj20 = multiplePiePlot1.clone();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape28 = xYStepAreaRenderer24.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape28, "", "JFreeChart");
        boolean boolean33 = org.jfree.chart.util.ShapeUtilities.equal(shape22, shape28);
        multiplePiePlot1.setLegendItemShape(shape22);
        org.jfree.chart.util.TableOrder tableOrder35 = multiplePiePlot1.getDataExtractOrder();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(tableOrder35);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setInverted(true);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        polarPlot4.removeCornerTextItem("");
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot4);
        dateAxis1.setInverted(false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.width;
        java.lang.Object obj2 = null;
        boolean boolean3 = size2D0.equals(obj2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getMaximumExplodePercent();
        java.awt.Paint paint4 = ringPlot0.getLabelBackgroundPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepAreaRenderer8.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color14 = java.awt.Color.RED;
        xYStepAreaRenderer8.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color14, false);
        java.awt.Stroke stroke18 = xYStepAreaRenderer8.getSeriesStroke(3);
        java.awt.Stroke stroke20 = xYStepAreaRenderer8.lookupSeriesOutlineStroke(4);
        ringPlot0.setLabelLinkStroke(stroke20);
        java.awt.Paint paint22 = null;
        ringPlot0.setLabelBackgroundPaint(paint22);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) -1, (float) 10);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = polarPlot3.getDataRange(valueAxis6);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer8.setAutoPopulateSeriesPaint(true);
        double double11 = xYAreaRenderer8.getItemLabelAnchorOffset();
        boolean boolean12 = xYAreaRenderer8.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot15.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot15.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator26, xYURLGenerator27);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = xYStepAreaRenderer28.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color34 = java.awt.Color.RED;
        xYStepAreaRenderer28.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color34, false);
        categoryAxis24.setTickLabelPaint((java.awt.Paint) color34);
        java.awt.Paint paint38 = categoryAxis24.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = combinedRangeXYPlot40.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke43 = combinedRangeXYPlot40.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint38, stroke43);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = combinedRangeXYPlot15.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker44, layer45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke52 = null;
        xYAreaRenderer8.drawRangeLine(graphics2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) dateAxis48, rectangle2D49, (double) 60000L, paint51, stroke52);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot54 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.data.Range range55 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = null;
        dateAxis48.setTickUnit(dateTickUnit57, false, false);
        org.jfree.chart.entity.AxisEntity axisEntity63 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) dateAxis48, "-3,-3,3,3", "index.html");
        java.lang.Object obj64 = axisEntity63.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator65 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator66 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer67 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator65, xYURLGenerator66);
        xYStepRenderer67.setSeriesShapesVisible((int) (byte) 10, false);
        xYStepRenderer67.setBaseLinesVisible(true);
        double double73 = xYStepRenderer67.getItemLabelAnchorOffset();
        boolean boolean74 = axisEntity63.equals((java.lang.Object) xYStepRenderer67);
        java.lang.String str75 = axisEntity63.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 2.0d + "'", double73 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "AxisEntity: tooltip = -3,-3,3,3" + "'", str75.equals("AxisEntity: tooltip = -3,-3,3,3"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("org.jfree.data.UnknownKeyException: hi!");
        standardChartTheme1.setShadowVisible(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator5, xYURLGenerator6);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer7.setSeriesItemLabelFont((int) '4', font9);
        xYStepAreaRenderer7.setSeriesVisibleInLegend(9999, (java.lang.Boolean) false);
        xYStepAreaRenderer7.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = combinedRangeXYPlot21.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot19.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot21);
        java.awt.Paint paint25 = combinedRangeXYPlot19.getRangeMinorGridlinePaint();
        xYStepAreaRenderer7.setSeriesPaint(9999, paint25, false);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 1, 10.0f);
        xYStepAreaRenderer7.setSeriesShape(5, shape31, false);
        java.awt.Font font35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color36 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("hi!", font35, (java.awt.Paint) color36);
        xYStepAreaRenderer7.setBaseItemLabelFont(font35);
        standardChartTheme1.setLargeFont(font35);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer2.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean8 = xYLineAndShapeRenderer2.getItemLineVisible(0, 3);
        java.lang.Class<?> wildcardClass9 = xYLineAndShapeRenderer2.getClass();
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TimePeriodAnchor.END", (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("java.awt.Color[r=255,g=200,b=0]", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNull(uRL11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        java.awt.Paint paint13 = barRenderer3D0.getShadowPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        int int7 = combinedRangeXYPlot1.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke13 = combinedRangeXYPlot10.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        combinedRangeXYPlot10.setFixedRangeAxisSpace(axisSpace14, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot10.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator23, xYURLGenerator24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color31 = java.awt.Color.RED;
        xYStepAreaRenderer25.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color31, false);
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color31);
        java.awt.Paint paint35 = categoryAxis21.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = combinedRangeXYPlot37.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke40 = combinedRangeXYPlot37.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint35, stroke40);
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = combinedRangeXYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker41, layer42);
        java.awt.Paint paint46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange49 = new org.jfree.data.time.DateRange();
        double double50 = dateRange49.getLength();
        double double51 = dateRange49.getLowerBound();
        org.jfree.data.time.DateRange dateRange52 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange49);
        boolean boolean53 = layer48.equals((java.lang.Object) dateRange52);
        combinedRangeXYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker47, layer48);
        java.util.Collection collection55 = combinedRangeXYPlot1.getDomainMarkers(12, layer48);
        combinedRangeXYPlot1.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(collection55);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        timeSeries4.setMaximumItemCount(3);
        java.util.List list7 = timeSeries4.getItems();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (byte) 10);
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        combinedRangeXYPlot12.setDomainAxis(100, valueAxis14, true);
        java.awt.Stroke stroke17 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        int int18 = year9.compareTo((java.lang.Object) stroke17);
        long long19 = year9.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61851744000000L) + "'", long19 == (-61851744000000L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot2.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4);
        java.awt.Paint paint8 = combinedRangeXYPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        dateAxis11.setInverted(true);
        combinedRangeXYPlot2.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone15 = dateAxis11.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone15);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean24 = segmentedTimeline21.containsDomainRange((long) '4', (long) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getDomainGridlineStroke();
        java.util.List list30 = combinedRangeXYPlot26.getAnnotations();
        segmentedTimeline21.addExceptions(list30);
        org.jfree.data.Range range33 = timeSeriesCollection17.getDomainBounds(list30, false);
        double double35 = timeSeriesCollection17.getDomainUpperBound(false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth(0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight((double) 0);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = ringPlot5.getToolTipGenerator();
        java.awt.Paint paint7 = ringPlot5.getOutlinePaint();
        java.awt.Color color8 = java.awt.Color.GRAY;
        ringPlot5.setBaseSectionPaint((java.awt.Paint) color8);
        org.jfree.chart.util.Rotation rotation10 = ringPlot5.getDirection();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange13, lengthConstraintType14, (double) 12, (org.jfree.data.Range) dateRange16, lengthConstraintType17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange11, (org.jfree.data.Range) dateRange13);
        boolean boolean20 = rotation10.equals((java.lang.Object) dateRange11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint4.toRangeWidth((org.jfree.data.Range) dateRange11);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset2 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset2.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset2, (java.lang.Comparable) 1.0f);
        java.text.NumberFormat numberFormat8 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(attributedString7);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String[] strArray2 = org.jfree.data.time.SerialDate.getMonths(true);
        org.jfree.chart.axis.SymbolAxis symbolAxis3 = new org.jfree.chart.axis.SymbolAxis("^-0.0", strArray2);
        org.jfree.data.RangeType rangeType4 = symbolAxis3.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock8.setWidth((double) (byte) -1);
        int int11 = numberTickUnit6.compareTo((java.lang.Object) (byte) -1);
        java.lang.String str13 = numberTickUnit6.valueToString((double) 100L);
        double double14 = numberTickUnit6.getSize();
        symbolAxis3.setTickUnit(numberTickUnit6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset6 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset6);
        java.lang.Object obj9 = defaultXYDataset6.clone();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset6, false);
        java.lang.String str14 = standardXYURLGenerator5.generateURL((org.jfree.data.xy.XYDataset) defaultXYDataset6, (int) (short) -1, 0);
        org.jfree.chart.entity.XYItemEntity xYItemEntity19 = new org.jfree.chart.entity.XYItemEntity(shape4, (org.jfree.data.xy.XYDataset) defaultXYDataset6, (int) 'a', 0, "TimePeriodAnchor.END", "RectangleAnchor.LEFT");
        java.lang.Object obj20 = xYItemEntity19.clone();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "index.html?series=-1&amp;item=0" + "'", str14.equals("index.html?series=-1&amp;item=0"));
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot2.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4);
        java.awt.Paint paint8 = combinedRangeXYPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        dateAxis11.setInverted(true);
        combinedRangeXYPlot2.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone15 = dateAxis11.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone15);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean24 = segmentedTimeline21.containsDomainRange((long) '4', (long) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getDomainGridlineStroke();
        java.util.List list30 = combinedRangeXYPlot26.getAnnotations();
        segmentedTimeline21.addExceptions(list30);
        org.jfree.data.Range range33 = timeSeriesCollection17.getDomainBounds(list30, false);
        java.util.List list34 = timeSeriesCollection17.getSeries();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (-2208960000000L), "1.2.0-pre", "index.html?series=-1&amp;item=0", false);
        java.lang.String str6 = logFormat4.format(0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "�" + "'", str6.equals("�"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getMaximumExplodePercent();
        java.awt.Paint paint4 = ringPlot0.getLabelBackgroundPaint();
        java.awt.Font font5 = ringPlot0.getLabelFont();
        ringPlot0.setStartAngle((double) (byte) 10);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer9.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYStepAreaRenderer9.setBaseToolTipGenerator(xYToolTipGenerator14, false);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState22 = xYStepAreaRenderer9.initialise(graphics2D17, rectangle2D18, xYPlot19, xYDataset20, plotRenderingInfo21);
        java.awt.Paint paint24 = xYStepAreaRenderer9.getSeriesPaint((int) (short) 100);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer9.setSeriesItemLabelFont((int) (short) 10, font26, false);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("", font26, (java.awt.Paint) color29);
        java.awt.Color color31 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot35.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot33.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot35);
        java.awt.geom.Point2D point2D39 = combinedRangeXYPlot35.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = combinedRangeXYPlot35.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("100", font26, (java.awt.Paint) color31, rectangleEdge40, horizontalAlignment41, verticalAlignment42, rectangleInsets43);
        double double46 = rectangleInsets43.calculateRightInset((double) (-457));
        textTitle0.setPadding(rectangleInsets43);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer49 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color52 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock53 = new org.jfree.chart.block.LabelBlock("hi!", font51, (java.awt.Paint) color52);
        xYAreaRenderer49.setBaseFillPaint((java.awt.Paint) color52, false);
        int int56 = color52.getGreen();
        textTitle0.setBackgroundPaint((java.awt.Paint) color52);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(xYItemRendererState22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(point2D39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 255 + "'", int56 == 255);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        barRenderer3D0.setDrawBarOutline(true);
        double[][] doubleArray17 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "JFreeChart", doubleArray17);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset18);
        org.jfree.data.Range range21 = barRenderer3D0.findRangeBounds(categoryDataset18, true);
        java.awt.Paint paint22 = barRenderer3D0.getWallPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer3D0.getSeriesToolTipGenerator((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer3D0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        int int3 = dateTickUnitType2.getCalendarField();
        java.text.DateFormat dateFormat5 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 10, dateTickUnitType2, 100, dateFormat5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, (java.awt.Paint) color2);
        java.awt.geom.Rectangle2D rectangle2D4 = labelBlock3.getBounds();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape10 = xYStepAreaRenderer6.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color12);
        java.lang.Object obj14 = legendGraphic13.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendGraphic13.getFillPaintTransformer();
        intervalMarker4.setGradientPaintTransformer(gradientPaintTransformer15);
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer15);
        org.jfree.chart.LegendItem legendItem20 = xYBarRenderer0.getLegendItem(6, (int) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = xYBarRenderer0.getGradientPaintTransformer();
        boolean boolean23 = xYBarRenderer0.isSeriesVisibleInLegend((int) (byte) 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day9, "", "hi!");
        timeSeries13.setMaximumItemCount(3);
        java.util.List list16 = timeSeries13.getItems();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 10);
        int int19 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        long long21 = year18.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61820208000001L) + "'", long21 == (-61820208000001L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        segmentedTimeline3.addException((long) 2, 10L);
        long long7 = segmentedTimeline3.getSegmentsGroupSize();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        dateAxis9.setInverted(true);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline3.getSegment(date12);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10700L + "'", long7 == 10700L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(segment13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String[] strArray2 = org.jfree.data.time.SerialDate.getMonths(true);
        org.jfree.chart.axis.SymbolAxis symbolAxis3 = new org.jfree.chart.axis.SymbolAxis("^-0.0", strArray2);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle5.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo11.getDataArea();
        textTitle5.draw(graphics2D9, rectangle2D12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        textTitle15.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle15.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle15.getBounds();
        textTitle5.draw(graphics2D14, rectangle2D19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = ringPlot21.getToolTipGenerator();
        java.lang.Object obj23 = ringPlot21.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = null;
        ringPlot21.setURLGenerator(pieURLGenerator24);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator26 = null;
        ringPlot21.setToolTipGenerator(pieToolTipGenerator26);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator29, xYURLGenerator30);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = xYStepAreaRenderer31.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color37 = java.awt.Color.RED;
        xYStepAreaRenderer31.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color37, false);
        ringPlot21.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.title.LegendGraphic legendGraphic41 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D19, (java.awt.Paint) color37);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis44);
        org.jfree.chart.axis.AxisLocation axisLocation47 = combinedRangeXYPlot45.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot43.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot45);
        java.awt.geom.Point2D point2D49 = combinedRangeXYPlot45.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = combinedRangeXYPlot45.getRangeAxisEdge();
        double double51 = symbolAxis3.java2DToValue(0.05d, rectangle2D19, rectangleEdge50);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNull(pieToolTipGenerator22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        int int15 = defaultXYDataset0.indexOf((java.lang.Comparable) "LegendItemEntity: seriesKey=11, dataset=null");
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Stroke stroke3 = xYAreaRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYAreaRenderer1.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.addOrUpdate(xYDataItem4);
        xYSeries1.add((java.lang.Number) 5, (java.lang.Number) 86400000L);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        boolean boolean21 = xYSeries1.equals((java.lang.Object) false);
        boolean boolean22 = xYSeries1.getNotify();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset23.validateObject();
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset23);
        try {
            double double28 = defaultXYDataset23.getYValue(0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) xYAreaRenderer2);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYAreaRenderer2.setUseFillPaint(false);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape10 = xYStepAreaRenderer6.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color12);
        java.lang.Object obj14 = legendGraphic13.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendGraphic13.getFillPaintTransformer();
        intervalMarker4.setGradientPaintTransformer(gradientPaintTransformer15);
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer15);
        org.jfree.chart.LegendItem legendItem20 = xYBarRenderer0.getLegendItem(6, (int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator22 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator22, xYURLGenerator23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = xYStepAreaRenderer24.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer24.getBasePositiveItemLabelPosition();
        xYBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition29);
        boolean boolean31 = xYBarRenderer0.getShadowsVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis48);
        boolean boolean53 = dateAxis48.isAxisLineVisible();
        boolean boolean54 = dateAxis48.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer6.getBaseNegativeItemLabelPosition();
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        boolean boolean11 = itemLabelPosition7.equals((java.lang.Object) combinedRangeXYPlot10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot13.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedRangeXYPlot13.getRangeAxisLocation();
        combinedRangeXYPlot10.setRangeAxisLocation(axisLocation16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot2.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4);
        java.awt.Paint paint8 = combinedRangeXYPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        dateAxis11.setInverted(true);
        combinedRangeXYPlot2.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone15 = dateAxis11.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone15);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.data.DomainOrder domainOrder18 = timeSeriesCollection17.getDomainOrder();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(domainOrder18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer3.setSeriesItemLabelFont((int) (short) 10, font20, false);
        xYStepAreaRenderer3.setBaseCreateEntities(false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot2.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4);
        java.awt.Paint paint8 = combinedRangeXYPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        dateAxis11.setInverted(true);
        combinedRangeXYPlot2.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone15 = dateAxis11.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone15);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor18 = org.jfree.data.time.TimePeriodAnchor.END;
        timeSeriesCollection17.setXPosition(timePeriodAnchor18);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer22);
        boolean boolean24 = textAnchor20.equals((java.lang.Object) xYAreaRenderer22);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator26 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer22.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator26);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator31 = xYAreaRenderer22.getToolTipGenerator(15, (int) (short) 10, true);
        boolean boolean32 = timePeriodAnchor18.equals((java.lang.Object) xYToolTipGenerator31);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timePeriodAnchor18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) 4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = combinedRangeXYPlot53.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation56 = combinedRangeXYPlot53.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        combinedRangeXYPlot53.setFixedRangeAxisSpace(axisSpace57);
        combinedDomainXYPlot46.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot53, 100);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle();
        textTitle62.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment65 = textTitle62.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D66 = textTitle62.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot68 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis67);
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot70 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis69);
        org.jfree.chart.axis.AxisLocation axisLocation72 = combinedRangeXYPlot70.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot68.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot70);
        java.awt.geom.Point2D point2D74 = combinedRangeXYPlot70.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState75 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo76 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = chartRenderingInfo76.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo78 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = chartRenderingInfo78.getPlotInfo();
        plotRenderingInfo77.addSubplotInfo(plotRenderingInfo79);
        try {
            combinedRangeXYPlot53.draw(graphics2D61, rectangle2D66, point2D74, plotState75, plotRenderingInfo77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(horizontalAlignment65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(point2D74);
        org.junit.Assert.assertNotNull(plotRenderingInfo77);
        org.junit.Assert.assertNotNull(plotRenderingInfo79);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic8.setOutlineStroke(stroke10);
        legendGraphic8.setShapeFilled(true);
        java.awt.Stroke stroke14 = legendGraphic8.getLineStroke();
        boolean boolean15 = legendGraphic8.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseItemLabelsVisible();
        boolean boolean2 = xYLineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = combinedRangeXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot9.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11);
        java.awt.Paint paint15 = combinedRangeXYPlot9.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot9.getDomainAxisLocation(9999);
        combinedRangeXYPlot1.setRangeAxisLocation(axisLocation17, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        java.lang.Number number9 = xYDataItem4.getX();
        xYSeries1.add(xYDataItem4, false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 0 + "'", number9.equals((short) 0));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("^-0.0", "{0}: ({1}, {2})");
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        java.awt.Paint paint5 = combinedRangeXYPlot1.getRangeTickBandPaint();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot7.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = combinedRangeXYPlot7.getFixedLegendItems();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        combinedRangeXYPlot7.drawAnnotations(graphics2D12, rectangle2D13, plotRenderingInfo14);
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = polarPlot3.getDataRange(valueAxis6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator9, xYURLGenerator10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYStepAreaRenderer11.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        xYStepAreaRenderer11.setBaseToolTipGenerator(xYToolTipGenerator16, false);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = xYStepAreaRenderer11.initialise(graphics2D19, rectangle2D20, xYPlot21, xYDataset22, plotRenderingInfo23);
        java.awt.Paint paint26 = xYStepAreaRenderer11.getSeriesPaint((int) (short) 100);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer11.setSeriesItemLabelFont((int) (short) 10, font28, false);
        polarPlot3.setAngleLabelFont(font28);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = combinedRangeXYPlot33.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke36 = combinedRangeXYPlot33.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        combinedRangeXYPlot33.setFixedRangeAxisSpace(axisSpace37, false);
        java.awt.Paint paint40 = combinedRangeXYPlot33.getDomainGridlinePaint();
        textBlock0.addLine("index.html?series=-1&amp;item=0", font28, paint40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = textBlock0.getLineAlignment();
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(xYItemRendererState24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(100);
        serialDate1.setDescription("java.awt.Color[r=255,g=0,b=0]");
        java.lang.String str4 = serialDate1.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate1.getNearestDayOfWeek((-2236514));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str4.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("org.jfree.data.UnknownKeyException: hi!");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = ringPlot2.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = ringPlot2.getLabelDistributor();
        double double5 = ringPlot2.getMaximumExplodePercent();
        java.awt.Paint paint6 = ringPlot2.getLabelBackgroundPaint();
        java.awt.Font font7 = ringPlot2.getLabelFont();
        standardChartTheme1.setSmallFont(font7);
        java.awt.Font font9 = standardChartTheme1.getSmallFont();
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 10.0d, (float) (byte) 1, (float) 2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        int int6 = xYStepAreaRenderer1.getPassCount();
        java.awt.Paint paint10 = xYStepAreaRenderer1.getItemOutlinePaint(6, 4, false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle4.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getDataArea();
        textTitle4.draw(graphics2D8, rectangle2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.configure();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle17.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle17.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = combinedRangeXYPlot23.getDomainAxisForDataset(0);
        java.awt.Paint paint26 = combinedRangeXYPlot23.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement28 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot23, (org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.chart.block.Arrangement) borderArrangement28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle29.getItemLabelPadding();
        java.lang.Object obj31 = legendTitle29.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = legendTitle29.getLegendItemGraphicEdge();
        double double33 = categoryAxis13.getCategoryStart(10, 4, rectangle2D21, rectangleEdge32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis36);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = combinedRangeXYPlot39.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot37.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot39);
        java.awt.Paint paint43 = combinedRangeXYPlot37.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        dateAxis46.setInverted(true);
        combinedRangeXYPlot37.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis46);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
        java.util.Date date52 = day50.getEnd();
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle();
        textTitle53.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment56 = textTitle53.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D57 = textTitle53.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot59 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis58);
        org.jfree.chart.axis.AxisLocation axisLocation61 = combinedRangeXYPlot59.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = combinedRangeXYPlot59.getDomainAxisEdge();
        boolean boolean63 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge62);
        double double64 = dateAxis46.dateToJava2D(date52, rectangle2D57, rectangleEdge62);
        axisSpace34.ensureAtLeast((double) (short) -1, rectangleEdge62);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo();
        chartRenderingInfo66.clear();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = chartRenderingInfo66.getPlotInfo();
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState69 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo68);
        try {
            org.jfree.chart.axis.AxisState axisState70 = categoryAxis3D0.draw(graphics2D2, 2.00000001d, rectangle2D11, rectangle2D21, rectangleEdge62, plotRenderingInfo68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(horizontalAlignment56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(plotRenderingInfo68);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.addOrUpdate(xYDataItem4);
        xYSeries1.add((java.lang.Number) 5, (java.lang.Number) 86400000L);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        boolean boolean21 = xYSeries1.equals((java.lang.Object) false);
        boolean boolean22 = xYSeries1.getNotify();
        boolean boolean23 = xYSeries1.isEmpty();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }
}

