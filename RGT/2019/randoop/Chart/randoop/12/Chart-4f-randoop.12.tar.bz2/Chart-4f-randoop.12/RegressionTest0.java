import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) ' ', numberFormat1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Object obj1 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10L, obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 1, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.CYAN;
        java.awt.Stroke stroke6 = null;
        java.awt.Color color7 = java.awt.Color.CYAN;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", shape4, (java.awt.Paint) color5, stroke6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, 0.0f, 0.0f, textAnchor4, (double) (-1.0f), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) (-1L), 0.0f, 10.0d, (float) (byte) 0, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = java.awt.Color.CYAN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("hi!", font15, (java.awt.Paint) color16);
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", true, shape5, false, (java.awt.Paint) color7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timePeriodAnchor0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        try {
            xYStepAreaRenderer3.setSeriesVisibleInLegend((int) (short) -1, (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Shape shape0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        java.util.Date date4 = null;
        try {
            long long5 = segmentedTimeline3.toTimelineValue(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setCursor((double) 9999);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = labelBlock1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 10, (double) (-1L), rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        xYStepAreaRenderer3.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            xYStepAreaRenderer3.fillDomainGridBand(graphics2D19, xYPlot20, valueAxis21, rectangle2D22, 10.0d, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState17 = xYItemRendererState16.getSelectionState();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(xYDatasetSelectionState17);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            labelBlock3.setPadding(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (int) '#');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj8 = xYStepAreaRenderer3.clone();
        java.awt.Shape shape10 = xYStepAreaRenderer3.getSeriesShape(100);
        java.awt.Shape shape11 = null;
        xYStepAreaRenderer3.setBaseLegendShape(shape11);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(shape10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Shape shape0 = null;
        java.awt.Paint paint1 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (short) -1;
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) xYAreaRenderer2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.Color color10 = java.awt.Color.GRAY;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            xYAreaRenderer2.drawRangeLine(graphics2D5, xYPlot6, valueAxis7, rectangle2D8, 0.0d, (java.awt.Paint) color10, stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { 2958465, 9999, (short) 100, (-1), (-1) };
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { 10.0f, 3, (-1), '4', "JFreeChart" };
        double[][] doubleArray12 = new double[][] {};
        try {
            org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray11, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'rowKeys'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.KeyedValues keyedValues0 = null;
        try {
            org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset(keyedValues0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Shape shape2 = null;
        try {
            xYAreaRenderer1.setBaseShape(shape2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis0.getCategorySeriesMiddle(10, 0, (int) (byte) 0, 0, 0.0d, rectangle2D7, rectangleEdge8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("hi!", font2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!", font2, paint5, 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        boolean boolean2 = xYAreaRenderer1.getPlotLines();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        try {
            xYAreaRenderer1.setGradientTransformer(gradientPaintTransformer3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color9 = java.awt.Color.RED;
        xYStepAreaRenderer3.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepAreaRenderer3.setBaseOutlineStroke(stroke12, false);
        java.awt.Shape shape16 = null;
        try {
            xYStepAreaRenderer3.setSeriesShape((int) (byte) -1, shape16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.GRAY;
        xYStepAreaRenderer3.setBaseOutlinePaint((java.awt.Paint) color20);
        java.awt.Shape shape23 = xYStepAreaRenderer3.getSeriesShape((int) ' ');
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(shape23);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        double double8 = itemLabelPosition7.getAngle();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (-1L), range1, lengthConstraintType2, (double) 2, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMaximumIntegerDigits((-1));
        boolean boolean6 = logFormat3.isGroupingUsed();
        try {
            java.lang.Object obj8 = logFormat3.parseObject("");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str2 = projectInfo1.getLicenceText();
        java.util.List list3 = projectInfo1.getContributors();
        try {
            org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Paint paint9 = xYStepAreaRenderer3.getLegendTextPaint((int) '4');
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj8 = xYStepAreaRenderer3.clone();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = xYStepAreaRenderer3.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("JFreeChart", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "JFreeChart", "");
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10, (-1), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = color2.getColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Color color1 = java.awt.Color.GRAY;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        boolean boolean20 = xYStepAreaRenderer3.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            int int3 = defaultXYDataset0.getItemCount(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            int[] intArray4 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) defaultXYDataset0, (int) (short) 0, (double) (byte) 1, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.plot.Marker marker2 = null;
        try {
            boolean boolean3 = combinedRangeXYPlot1.removeRangeMarker(marker2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        try {
            combinedRangeXYPlot1.setRangeAxis((int) (byte) -1, valueAxis5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMaximumIntegerDigits((-1));
        java.lang.String str7 = logFormat3.format((double) 100L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "^-0.0" + "'", str7.equals("^-0.0"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) xYAreaRenderer2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = xYAreaRenderer2.getDrawingSupplier();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(drawingSupplier5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Paint paint4 = null;
        try {
            xYStepAreaRenderer3.setBaseOutlinePaint(paint4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        try {
            java.awt.Paint paint8 = combinedRangeXYPlot1.getQuadrantPaint(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (12) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        boolean boolean2 = xYAreaRenderer1.getPlotLines();
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer5);
        boolean boolean7 = textAnchor3.equals((java.lang.Object) xYAreaRenderer5);
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) boolean2, (java.lang.Object) textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str2 = projectInfo1.getLicenceText();
        java.util.List list3 = projectInfo1.getContributors();
        org.jfree.data.Range range4 = null;
        try {
            org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(xYDataset0, list3, range4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        try {
            boolean boolean6 = segmentedTimeline3.containsDomainRange(100L, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (3) < domainValueStart (100)");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer3.setSeriesItemLabelFont((int) '4', font5);
        xYStepAreaRenderer3.setSeriesVisibleInLegend(9999, (java.lang.Boolean) false);
        java.awt.Paint paint11 = null;
        xYStepAreaRenderer3.setLegendTextPaint(0, paint11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis17 = combinedRangeXYPlot15.getDomainAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            xYStepAreaRenderer3.fillRangeGridBand(graphics2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, valueAxis18, rectangle2D19, (double) (byte) -1, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot6.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getDomainGridlineStroke();
        java.awt.Color color10 = java.awt.Color.CYAN;
        try {
            org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "java.awt.Color[r=255,g=0,b=0]", "JFreeChart", shape4, stroke9, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            combinedRangeXYPlot1.addDomainMarker(marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        java.math.RoundingMode roundingMode4 = null;
        try {
            logFormat3.setRoundingMode(roundingMode4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Shape shape0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.visible = true;
        boolean boolean4 = textTitle1.isVisible();
        try {
            org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) textTitle1, "JFreeChart", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setDomainAxis(100, valueAxis3, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            boolean boolean7 = combinedRangeXYPlot1.removeAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer6);
        boolean boolean8 = textAnchor4.equals((java.lang.Object) xYAreaRenderer6);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("^-0.0", graphics2D1, (float) (short) 1, 100.0f, textAnchor4, (double) (-1L), (float) '4', (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(100L, (int) 'a', (int) '4');
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMaximumIntegerDigits((-1));
        boolean boolean6 = logFormat3.isGroupingUsed();
        java.text.NumberFormat numberFormat7 = null;
        try {
            logFormat3.setExponentFormat(numberFormat7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'format' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Shape shape0 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset1 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset1);
        try {
            org.jfree.chart.entity.XYItemEntity xYItemEntity7 = new org.jfree.chart.entity.XYItemEntity(shape0, (org.jfree.data.xy.XYDataset) defaultXYDataset1, 100, 1, "^-0.0", "JFreeChart");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        try {
            timeSeries4.delete(9999, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMinimumIntegerDigits(0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer7);
        java.awt.Font font9 = xYAreaRenderer7.getBaseItemLabelFont();
        java.lang.StringBuffer stringBuffer10 = null;
        java.text.FieldPosition fieldPosition11 = null;
        try {
            java.lang.StringBuffer stringBuffer12 = logFormat3.format((java.lang.Object) xYAreaRenderer7, stringBuffer10, fieldPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        double double3 = categoryAxis0.getLowerMargin();
        boolean boolean4 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            combinedRangeXYPlot1.addAnnotation(xYAnnotation5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer6);
        boolean boolean8 = textAnchor4.equals((java.lang.Object) xYAreaRenderer6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator10, xYURLGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYStepAreaRenderer12.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color18 = java.awt.Color.RED;
        xYStepAreaRenderer12.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepAreaRenderer12.setBaseOutlineStroke(stroke21, false);
        boolean boolean24 = textAnchor4.equals((java.lang.Object) xYStepAreaRenderer12);
        try {
            java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, 0.5f, (float) 1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle0.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = null;
        xYStepAreaRenderer3.setSeriesItemLabelGenerator((int) ' ', xYItemLabelGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.GRAY;
        xYStepAreaRenderer3.setBaseOutlinePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYStepAreaRenderer3.setSeriesOutlineStroke(12, stroke23, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer3.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            double double4 = defaultXYDataset0.getXValue((int) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        waferMapPlot1.setNoDataMessage("");
        java.awt.Stroke stroke6 = waferMapPlot1.getOutlineStroke();
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        waferMapPlot1.setOutlinePaint(paint7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font2);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "JFreeChart", categoryDataset3, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        int int8 = combinedRangeXYPlot1.getDomainAxisCount();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        java.lang.Object obj2 = rendererChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "" + "'", obj2.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Shape shape0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean2 = categoryAxis1.isVisible();
        categoryAxis1.setTickMarksVisible(false);
        try {
            org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis1, "JFreeChart", "java.awt.Color[r=255,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=0,b=0]", "^-0.0", "hi!", "^-0.0", shape4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer3.setSeriesItemLabelFont((int) (short) 10, font20, false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator25 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) 'a', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator25, xYURLGenerator26);
        try {
            xYStepAreaRenderer3.setSeriesToolTipGenerator((int) (short) -1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Shape shape0 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset1 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset1);
        try {
            org.jfree.chart.entity.XYItemEntity xYItemEntity8 = new org.jfree.chart.entity.XYItemEntity(shape0, (org.jfree.data.xy.XYDataset) defaultXYDataset1, (int) ' ', 0, "", "JFreeChart");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setWidth((double) (byte) -1);
        labelBlock1.setToolTipText("100");
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        combinedRangeXYPlot3.setFixedRangeAxisSpace(axisSpace7, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot3.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator16, xYURLGenerator17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepAreaRenderer18.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color24 = java.awt.Color.RED;
        xYStepAreaRenderer18.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color24, false);
        categoryAxis14.setTickLabelPaint((java.awt.Paint) color24);
        java.awt.Paint paint28 = categoryAxis14.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = combinedRangeXYPlot30.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke33 = combinedRangeXYPlot30.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint28, stroke33);
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = combinedRangeXYPlot3.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34, layer35);
        org.jfree.chart.util.Layer layer37 = null;
        try {
            combinedRangeXYPlot1.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker34, layer37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setDomainAxis(100, valueAxis3, true);
        org.jfree.chart.plot.Marker marker6 = null;
        try {
            boolean boolean7 = combinedRangeXYPlot1.removeRangeMarker(marker6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        java.util.List list2 = projectInfo0.getContributors();
//        java.lang.String str3 = projectInfo0.getName();
//        java.lang.String str4 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JFreeChart" + "'", str3.equals("JFreeChart"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2.0-pre" + "'", str4.equals("1.2.0-pre"));
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        waferMapPlot1.setNoDataMessage("");
        java.awt.Stroke stroke6 = waferMapPlot1.getOutlineStroke();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            waferMapPlot1.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("JFreeChart");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("100", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isVisible();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        axisState3.cursorUp(0.0d);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot8.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot10);
        java.awt.geom.Point2D point2D14 = combinedRangeXYPlot10.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = combinedRangeXYPlot10.getRangeAxisEdge();
        try {
            java.util.List list16 = categoryAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D6, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 0L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) 'a', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedRangeXYPlot5.getDomainAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedRangeXYPlot12.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot10.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot10.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset16);
        combinedRangeXYPlot5.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset16);
        try {
            java.lang.String str21 = standardXYToolTipGenerator1.generateLabelString((org.jfree.data.xy.XYDataset) defaultXYDataset16, (int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (-457), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        float float7 = combinedRangeXYPlot1.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke14 = combinedRangeXYPlot11.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        combinedRangeXYPlot11.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot11.rendererChanged(rendererChangeEvent19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator24, xYURLGenerator25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYStepAreaRenderer26.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color32 = java.awt.Color.RED;
        xYStepAreaRenderer26.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color32, false);
        categoryAxis22.setTickLabelPaint((java.awt.Paint) color32);
        java.awt.Paint paint36 = categoryAxis22.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = combinedRangeXYPlot38.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke41 = combinedRangeXYPlot38.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint36, stroke41);
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = combinedRangeXYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker42, layer43);
        org.jfree.chart.util.Layer layer45 = null;
        try {
            combinedRangeXYPlot1.addDomainMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker42, layer45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-457), (int) (byte) 100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        boolean boolean2 = combinedRangeXYPlot1.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setLabelToolTip("100");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot8.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot10);
        java.awt.geom.Point2D point2D14 = combinedRangeXYPlot10.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = combinedRangeXYPlot10.getRangeAxisEdge();
        try {
            double double16 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor3, (int) '4', 3, rectangle2D6, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.LEFT" + "'", str1.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.Throwable[] throwableArray5 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        xYStepAreaRenderer5.setBaseToolTipGenerator(xYToolTipGenerator10, false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYStepAreaRenderer5.initialise(graphics2D13, rectangle2D14, xYPlot15, xYDataset16, plotRenderingInfo17);
        java.awt.Paint paint20 = xYStepAreaRenderer5.getSeriesPaint((int) (short) 100);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer5.setSeriesItemLabelFont((int) (short) 10, font22, false);
        java.awt.Color color25 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("", font22, (java.awt.Paint) color25);
        java.awt.Color color27 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("hi!", font22, (java.awt.Paint) color27);
        float float29 = textFragment28.getBaselineOffset();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            float float32 = textFragment28.calculateBaselineOffset(graphics2D30, textAnchor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor31);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-1), 12, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Date date4 = day2.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        java.util.Date date7 = day5.getEnd();
        try {
            dateAxis1.setRange(date4, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isVisible();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 10.0f, "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.plot.Plot plot4 = categoryAxis1.getPlot();
        boolean boolean5 = dateTickMarkPosition0.equals((java.lang.Object) plot4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockBorder1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend2 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, valueAxis1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 100, 10, (int) (byte) 100);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        timeSeries4.setMaximumItemCount(3);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isVisible();
        java.lang.String str2 = categoryAxis0.getLabelURL();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator9, xYURLGenerator10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYStepAreaRenderer11.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        xYStepAreaRenderer11.setBaseToolTipGenerator(xYToolTipGenerator16, false);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = xYStepAreaRenderer11.initialise(graphics2D19, rectangle2D20, xYPlot21, xYDataset22, plotRenderingInfo23);
        java.awt.Paint paint26 = xYStepAreaRenderer11.getSeriesPaint((int) (short) 100);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer11.setSeriesItemLabelFont((int) (short) 10, font28, false);
        java.awt.Color color31 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("", font28, (java.awt.Paint) color31);
        java.awt.Color color33 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = combinedRangeXYPlot37.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot35.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot37);
        java.awt.geom.Point2D point2D41 = combinedRangeXYPlot37.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = combinedRangeXYPlot37.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("100", font28, (java.awt.Paint) color33, rectangleEdge42, horizontalAlignment43, verticalAlignment44, rectangleInsets45);
        try {
            double double47 = categoryAxis0.getCategoryStart((int) (short) 10, (int) (short) 100, rectangle2D5, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(xYItemRendererState24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = textFragment1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (byte) 1, true);
        java.awt.Stroke stroke7 = null;
        try {
            combinedRangeXYPlot1.setDomainZeroBaselineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        int int4 = waferMapPlot1.getBackgroundImageAlignment();
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot1.setDataset(waferMapDataset5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape9 = xYStepAreaRenderer5.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedRangeXYPlot14.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot12.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14);
        java.awt.Stroke stroke18 = combinedRangeXYPlot14.getDomainZeroBaselineStroke();
        java.awt.Color color20 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "RectangleAnchor.LEFT", "Combined Range XYPlot", "RectangleAnchor.LEFT", shape9, stroke18, (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("hi!", font3, (java.awt.Paint) color4);
        xYAreaRenderer1.setBaseFillPaint((java.awt.Paint) color4, false);
        java.awt.Stroke stroke9 = xYAreaRenderer1.getSeriesStroke(0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot6.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot6.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        combinedRangeXYPlot1.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double15 = combinedRangeXYPlot1.getRangeCrosshairValue();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setRangePannable(true);
        java.awt.Stroke stroke7 = combinedRangeXYPlot1.getDomainZeroBaselineStroke();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis9 = combinedRangeXYPlot1.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        boolean boolean3 = categoryAxis0.isAxisLineVisible();
        java.awt.Paint paint4 = categoryAxis0.getAxisLinePaint();
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.util.TimeZone timeZone0 = null;
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        textTitle7.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle7.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle7.draw(graphics2D11, rectangle2D12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle7, "Combined Range XYPlot");
        java.lang.Object obj16 = titleEntity15.clone();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        dateAxis1.setMinorTickCount((int) (byte) -1);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        java.util.Date date11 = day9.getEnd();
        try {
            dateAxis1.setRange(date8, date11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("RectangleAnchor.LEFT");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = xYStepAreaRenderer3.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(xYURLGenerator9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMaximumIntegerDigits((-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator8, xYURLGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYStepAreaRenderer10.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color16 = java.awt.Color.RED;
        xYStepAreaRenderer10.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color16, false);
        categoryAxis6.setTickLabelPaint((java.awt.Paint) color16);
        java.awt.Paint paint20 = categoryAxis6.getTickMarkPaint();
        try {
            java.lang.String str21 = logFormat3.format((java.lang.Object) categoryAxis6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isVisible();
        java.lang.String str2 = categoryAxis0.getLabelURL();
        categoryAxis0.setTickMarksVisible(true);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        boolean boolean3 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = (short) -1;
        double double3 = size2D0.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("hi!", font3, (java.awt.Paint) color4);
        xYAreaRenderer1.setBaseFillPaint((java.awt.Paint) color4, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        boolean boolean9 = xYAreaRenderer1.removeAnnotation(xYAnnotation8);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("^-0.0", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock4.setWidth((double) (byte) -1);
        int int7 = numberTickUnit2.compareTo((java.lang.Object) (byte) -1);
        try {
            org.jfree.chart.axis.TickUnit tickUnit8 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity2 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = combinedRangeXYPlot18.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot16.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18);
        java.awt.geom.Point2D point2D22 = combinedRangeXYPlot18.getQuadrantOrigin();
        combinedRangeXYPlot8.zoomRangeAxes((double) 43629L, (double) (short) 100, plotRenderingInfo14, point2D22);
        try {
            combinedRangeXYPlot1.zoomDomainAxes((double) (-1L), plotRenderingInfo6, point2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(point2D22);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 60000L, (double) 15, (double) (-1.0f), (double) (-1.0f));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        try {
            intervalXYDelegate3.setIntervalPositionFactor((double) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot1.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        rendererChangeEvent9.setChart(jFreeChart11);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("JFreeChart", graphics2D1, (float) 1, (float) (-457), 0.0d, 0.0f, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMaximumIntegerDigits((-1));
        java.lang.StringBuffer stringBuffer7 = null;
        java.text.FieldPosition fieldPosition8 = null;
        java.lang.StringBuffer stringBuffer9 = logFormat3.format((double) (-457), stringBuffer7, fieldPosition8);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = ringPlot10.getToolTipGenerator();
        java.lang.Object obj12 = ringPlot10.clone();
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator13 = logFormat3.formatToCharacterIterator(obj12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stringBuffer9);
        org.junit.Assert.assertNull(pieToolTipGenerator11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        boolean boolean2 = xYStepAreaRenderer1.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean6 = segmentedTimeline3.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list7 = segmentedTimeline3.getExceptionSegments();
        long long9 = segmentedTimeline3.getTimeFromLong((long) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYStepAreaRenderer4.setBaseToolTipGenerator(xYToolTipGenerator9, false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = xYStepAreaRenderer4.initialise(graphics2D12, rectangle2D13, xYPlot14, xYDataset15, plotRenderingInfo16);
        java.awt.Paint paint19 = xYStepAreaRenderer4.getSeriesPaint((int) (short) 100);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer4.setSeriesItemLabelFont((int) (short) 10, font21, false);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color24);
        labelBlock25.setToolTipText("Combined Range XYPlot");
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(xYItemRendererState17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 0L);
        java.lang.Object obj3 = strokeMap0.clone();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj8 = xYStepAreaRenderer3.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis9.setPlot((org.jfree.chart.plot.Plot) waferMapPlot10);
        xYStepAreaRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot10);
        xYStepAreaRenderer3.setSeriesItemLabelsVisible((int) '4', false);
        java.awt.Shape shape16 = xYStepAreaRenderer3.getBaseLegendShape();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesLinesVisible((int) ' ', false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        try {
            xYStepRenderer2.setSeriesItemLabelGenerator((int) (short) -1, xYItemLabelGenerator7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((-457), serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer1);
        java.awt.Font font3 = xYAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        try {
            xYAreaRenderer1.setLegendItemLabelGenerator(xYSeriesLabelGenerator4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(10);
        int int2 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.sort();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        try {
            java.lang.Number number6 = intervalXYDelegate3.getStartX(12, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, range2);
        boolean boolean4 = dateTickUnitType0.equals((java.lang.Object) range1);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        double double9 = timeSeries4.getMaxY();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = null;
        try {
            timeSeries4.add(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        double double3 = categoryAxis0.getLowerMargin();
        java.lang.String str4 = categoryAxis0.getLabel();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setSeparatorsVisible(false);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0.5f, font4);
        java.lang.Object obj8 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = polarPlot0.getDataRange(valueAxis3);
        try {
            java.lang.Class<?> wildcardClass5 = range4.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke8 = xYStepRenderer2.getItemStroke(15, (int) '4', true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYStepRenderer2.getBaseItemLabelGenerator();
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Object obj3 = defaultXYDataset0.clone();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        int int7 = defaultXYDataset0.indexOf((java.lang.Comparable) "");
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Color color1 = java.awt.Color.getColor("TimePeriodAnchor.END");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color9 = java.awt.Color.RED;
        xYStepAreaRenderer3.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color9, false);
        java.awt.Stroke stroke13 = xYStepAreaRenderer3.getSeriesStroke(3);
        java.lang.Boolean boolean15 = xYStepAreaRenderer3.getSeriesVisibleInLegend(4);
        boolean boolean16 = xYStepAreaRenderer3.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot1.getFixedLegendItems();
        java.awt.Stroke stroke6 = combinedRangeXYPlot1.getOutlineStroke();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        timeSeries4.setMaximumItemCount(3);
        try {
            timeSeries4.delete(0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Color color1 = java.awt.Color.blue;
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.LEFT", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer4);
        boolean boolean6 = textAnchor2.equals((java.lang.Object) xYAreaRenderer4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator8, xYURLGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYStepAreaRenderer10.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color16 = java.awt.Color.RED;
        xYStepAreaRenderer10.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color16, false);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepAreaRenderer10.setBaseOutlineStroke(stroke19, false);
        boolean boolean22 = textAnchor2.equals((java.lang.Object) xYStepAreaRenderer10);
        boolean boolean23 = dateRange1.equals((java.lang.Object) textAnchor2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.lang.Object obj9 = defaultXYDataset7.clone();
        try {
            int int13 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) defaultXYDataset7, (int) (byte) -1, (double) (byte) 0, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator11, xYURLGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepAreaRenderer13.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color19 = java.awt.Color.RED;
        xYStepAreaRenderer13.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color19, false);
        categoryAxis9.setTickLabelPaint((java.awt.Paint) color19);
        java.awt.Paint paint23 = categoryAxis9.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = combinedRangeXYPlot25.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke28 = combinedRangeXYPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint23, stroke28);
        boolean boolean30 = combinedRangeXYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker29);
        java.lang.String str31 = combinedRangeXYPlot1.getPlotType();
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = null;
        try {
            combinedRangeXYPlot1.setOrientation(plotOrientation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Combined Range XYPlot" + "'", str31.equals("Combined Range XYPlot"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator10, xYURLGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYStepAreaRenderer12.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYStepAreaRenderer12.setBaseToolTipGenerator(xYToolTipGenerator17, false);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState25 = xYStepAreaRenderer12.initialise(graphics2D20, rectangle2D21, xYPlot22, xYDataset23, plotRenderingInfo24);
        java.awt.Paint paint27 = xYStepAreaRenderer12.getSeriesPaint((int) (short) 100);
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer12.setSeriesItemLabelFont((int) (short) 10, font29, false);
        java.awt.Color color32 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("", font29, (java.awt.Paint) color32);
        java.awt.Color color34 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = combinedRangeXYPlot38.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot36.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot38);
        java.awt.geom.Point2D point2D42 = combinedRangeXYPlot38.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = combinedRangeXYPlot38.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("100", font29, (java.awt.Paint) color34, rectangleEdge43, horizontalAlignment44, verticalAlignment45, rectangleInsets46);
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, barRenderer2, 0, 100, true, rectangularShape6, rectangleEdge43, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(xYItemRendererState25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape9 = xYStepAreaRenderer5.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle11.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        textTitle11.draw(graphics2D15, rectangle2D16);
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle11, "Combined Range XYPlot");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle20, "Combined Range XYPlot", "java.awt.Color[r=255,g=0,b=0]");
        dateAxis1.setDownArrow(shape9);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape9 = xYStepAreaRenderer5.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle11.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        textTitle11.draw(graphics2D15, rectangle2D16);
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle11, "Combined Range XYPlot");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle20, "Combined Range XYPlot", "java.awt.Color[r=255,g=0,b=0]");
        dateAxis1.setDownArrow(shape9);
        dateAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.awt.Shape shape0 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator4, xYURLGenerator5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer6.setBaseToolTipGenerator(xYToolTipGenerator11, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = xYStepAreaRenderer6.initialise(graphics2D14, rectangle2D15, xYPlot16, xYDataset17, plotRenderingInfo18);
        java.awt.Paint paint21 = xYStepAreaRenderer6.getSeriesPaint((int) (short) 100);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer6.setSeriesItemLabelFont((int) (short) 10, font23, false);
        java.awt.Color color26 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("", font23, (java.awt.Paint) color26);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis29);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot30.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot32);
        java.awt.geom.Point2D point2D36 = combinedRangeXYPlot32.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = combinedRangeXYPlot32.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("100", font23, (java.awt.Paint) color28, rectangleEdge37, horizontalAlignment38, verticalAlignment39, rectangleInsets40);
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(xYItemRendererState19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        textTitle0.setText("");
        textTitle0.setToolTipText("ERROR : Relative To String");
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Color color5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        combinedRangeXYPlot1.setDomainZeroBaselinePaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        java.awt.Stroke stroke7 = null;
        try {
            combinedRangeXYPlot1.setRangeZeroBaselineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        xYDataItem2.setY((java.lang.Number) (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "^-0.0", "RectangleAnchor.LEFT", "hi!");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer4.setSeriesItemLabelFont((int) '4', font6);
        xYStepAreaRenderer4.setSeriesVisibleInLegend(9999, (java.lang.Boolean) false);
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) xYStepAreaRenderer4);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        ringPlot0.setLabelLinkMargin((double) 6);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot1.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color22 = java.awt.Color.RED;
        xYStepAreaRenderer16.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color22, false);
        categoryAxis12.setTickLabelPaint((java.awt.Paint) color22);
        java.awt.Paint paint26 = categoryAxis12.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = combinedRangeXYPlot28.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke31 = combinedRangeXYPlot28.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint26, stroke31);
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker32, layer33);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation35 = null;
        try {
            boolean boolean36 = combinedRangeXYPlot1.removeAnnotation(xYAnnotation35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("100", graphics2D1, (double) 43629L, (float) 2, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        boolean boolean5 = ringPlot0.getIgnoreZeroValues();
        ringPlot0.clearSectionOutlineStrokes(false);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            lineBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.visible = true;
        boolean boolean4 = textTitle1.isVisible();
        boolean boolean5 = rangeType0.equals((java.lang.Object) boolean4);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color7.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setRangeAxis((int) '4', valueAxis3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            combinedRangeXYPlot1.drawBackground(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        combinedRangeXYPlot1.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedRangeXYPlot1.getFixedLegendItems();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            boolean boolean11 = combinedRangeXYPlot1.removeAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemLineVisible(0, 3);
        boolean boolean7 = xYLineAndShapeRenderer0.getDrawOutlines();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYLineAndShapeRenderer0.setBaseOutlineStroke(stroke8, true);
        java.awt.Shape shape11 = xYLineAndShapeRenderer0.getBaseLegendShape();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            defaultPieDataset0.insertValue(9999, (java.lang.Comparable) 0.0d, (java.lang.Number) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator12, xYURLGenerator13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer14.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color20 = java.awt.Color.RED;
        xYStepAreaRenderer14.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color20, false);
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color20);
        java.awt.Paint paint24 = categoryAxis10.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint24, stroke29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker30, layer31);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (byte) 1, false);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            combinedRangeXYPlot1.drawBackground(graphics2D36, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape10 = xYStepAreaRenderer6.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone(shape10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        textTitle12.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle12.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        textTitle12.draw(graphics2D16, rectangle2D17);
        org.jfree.chart.entity.TitleEntity titleEntity20 = new org.jfree.chart.entity.TitleEntity(shape10, (org.jfree.chart.title.Title) textTitle12, "Combined Range XYPlot");
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.clone(shape10);
        java.awt.Paint paint23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint paint25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = combinedRangeXYPlot29.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot27.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot29);
        java.awt.Stroke stroke33 = combinedRangeXYPlot29.getDomainZeroBaselineStroke();
        java.awt.Shape shape35 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer36.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean42 = xYLineAndShapeRenderer36.getItemLineVisible(0, 3);
        boolean boolean43 = xYLineAndShapeRenderer36.getDrawOutlines();
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYLineAndShapeRenderer36.setBaseOutlineStroke(stroke44, true);
        java.awt.Color color47 = java.awt.Color.YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder48 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color47);
        try {
            org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem(attributedString0, "^-0.0", "", "1.2.0-pre", true, shape21, false, paint23, true, paint25, stroke33, true, shape35, stroke44, (java.awt.Paint) color47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color47);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer3.setSeriesItemLabelFont((int) '4', font5);
        xYStepAreaRenderer3.setSeriesVisibleInLegend(9999, (java.lang.Boolean) false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedRangeXYPlot12.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke15 = combinedRangeXYPlot12.getDomainGridlineStroke();
        java.util.List list16 = combinedRangeXYPlot12.getAnnotations();
        java.awt.Paint paint17 = combinedRangeXYPlot12.getDomainMinorGridlinePaint();
        xYStepAreaRenderer3.setSeriesFillPaint(3, paint17);
        java.lang.Boolean boolean20 = xYStepAreaRenderer3.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(boolean20);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        try {
            java.util.Date date5 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer3.setSeriesItemLabelFont((int) '4', font5);
        xYStepAreaRenderer3.setSeriesVisibleInLegend(9999, (java.lang.Boolean) false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedRangeXYPlot12.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke15 = combinedRangeXYPlot12.getDomainGridlineStroke();
        java.util.List list16 = combinedRangeXYPlot12.getAnnotations();
        java.awt.Paint paint17 = combinedRangeXYPlot12.getDomainMinorGridlinePaint();
        xYStepAreaRenderer3.setSeriesFillPaint(3, paint17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedRangeXYPlot23.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot23);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator32 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator32, xYURLGenerator33);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = xYStepAreaRenderer34.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator39 = null;
        xYStepAreaRenderer34.setBaseToolTipGenerator(xYToolTipGenerator39, false);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState47 = xYStepAreaRenderer34.initialise(graphics2D42, rectangle2D43, xYPlot44, xYDataset45, plotRenderingInfo46);
        java.awt.Paint paint49 = xYStepAreaRenderer34.getSeriesPaint((int) (short) 100);
        java.awt.Font font51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer34.setSeriesItemLabelFont((int) (short) 10, font51, false);
        java.awt.Color color54 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock55 = new org.jfree.chart.block.LabelBlock("", font51, (java.awt.Paint) color54);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis56);
        org.jfree.chart.axis.ValueAxis valueAxis59 = combinedRangeXYPlot57.getDomainAxisForDataset(0);
        java.awt.Stroke stroke60 = combinedRangeXYPlot57.getDomainMinorGridlineStroke();
        try {
            xYStepAreaRenderer3.drawDomainLine(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot21, valueAxis27, rectangle2D28, (double) 0.5f, (java.awt.Paint) color54, stroke60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(xYItemRendererState47);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNull(valueAxis59);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries4.add(regularTimePeriod5, (double) (short) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = polarPlot0.getDataRange(valueAxis3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepAreaRenderer8.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYStepAreaRenderer8.setBaseToolTipGenerator(xYToolTipGenerator13, false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYStepAreaRenderer8.initialise(graphics2D16, rectangle2D17, xYPlot18, xYDataset19, plotRenderingInfo20);
        java.awt.Paint paint23 = xYStepAreaRenderer8.getSeriesPaint((int) (short) 100);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer8.setSeriesItemLabelFont((int) (short) 10, font25, false);
        polarPlot0.setAngleLabelFont(font25);
        try {
            polarPlot0.zoom((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Paint paint4 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(1.0d, (double) (short) 100, 0.0d, (double) 1, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke12 = combinedRangeXYPlot9.getDomainGridlineStroke();
        java.util.List list13 = combinedRangeXYPlot9.getAnnotations();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer15);
        java.awt.Font font17 = xYAreaRenderer15.getBaseItemLabelFont();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("hi!", font20, (java.awt.Paint) color21);
        xYAreaRenderer15.setSeriesPaint(2958465, (java.awt.Paint) color21);
        combinedRangeXYPlot9.setRangeTickBandPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator26 = ringPlot25.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor27 = ringPlot25.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = null;
        ringPlot25.setLegendLabelToolTipGenerator(pieSectionLabelGenerator28);
        java.awt.Paint paint30 = ringPlot25.getLabelShadowPaint();
        combinedRangeXYPlot9.setRangeMinorGridlinePaint(paint30);
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot9);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(pieToolTipGenerator26);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor27);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        crosshairState1.updateCrosshairPoint((double) 60000L, (double) 0.0f, (double) 10.0f, (double) 1, plotOrientation6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Paint paint5 = ringPlot0.getLabelShadowPaint();
        try {
            ringPlot0.setInteriorGap((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(10);
        int int2 = pieLabelDistributor1.getItemCount();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        dateAxis40.setUpperMargin((double) (short) 10);
        dateAxis40.setMinorTickCount((int) (short) 1);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.axis.AxisState axisState51 = new org.jfree.chart.axis.AxisState();
        axisState51.cursorUp(0.0d);
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle();
        textTitle55.visible = true;
        textTitle55.setText("");
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot61 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = combinedRangeXYPlot61.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = combinedRangeXYPlot61.getDomainAxisEdge();
        textTitle55.setPosition(rectangleEdge64);
        try {
            java.util.List list66 = dateAxis40.refreshTicks(graphics2D50, axisState51, rectangle2D54, rectangleEdge64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color9 = java.awt.Color.RED;
        xYStepAreaRenderer3.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color9, false);
        boolean boolean12 = xYStepAreaRenderer3.getPlotArea();
        xYStepAreaRenderer3.setBaseCreateEntities(true, true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape9 = xYStepAreaRenderer5.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle11.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        textTitle11.draw(graphics2D15, rectangle2D16);
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle11, "Combined Range XYPlot");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle20, "Combined Range XYPlot", "java.awt.Color[r=255,g=0,b=0]");
        dateAxis1.setDownArrow(shape9);
        dateAxis1.setNegativeArrowVisible(true);
        dateAxis1.setFixedAutoRange((double) (short) -1);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setInverted(true);
        try {
            dateAxis1.setRange((double) 11, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.awt.Paint paint3 = ringPlot0.getLabelShadowPaint();
        java.lang.Comparable comparable4 = null;
        try {
            java.awt.Paint paint5 = ringPlot0.getSectionPaint(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        xYSeries1.add((java.lang.Number) 0.0f, (java.lang.Number) 0.5f, false);
        double double6 = xYSeries1.getMaxX();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape9 = xYStepAreaRenderer5.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke12 = null;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem(attributedString0, "TimePeriodAnchor.END", "^-0.0", "TimePeriodAnchor.END", shape10, (java.awt.Paint) color11, stroke12, paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        boolean boolean6 = xYStepAreaRenderer1.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.setKey((java.lang.Comparable) 0);
        try {
            timeSeries4.update((-1), (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedRangeXYPlot1.getDomainAxisEdge();
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYStepAreaRenderer3.setBaseURLGenerator(xYURLGenerator11, true);
        java.awt.Font font17 = xYStepAreaRenderer3.getItemLabelFont((int) (short) 1, (int) ' ', true);
        java.awt.Font font19 = xYStepAreaRenderer3.getLegendTextFont(5);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = xYStepAreaRenderer3.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertNull(xYToolTipGenerator20);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0.5f, font4);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) 0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        legendGraphic8.setShapeVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        try {
            legendGraphic8.setShapeAnchor(rectangleAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setNotify(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer7.setAutoPopulateSeriesPaint(true);
        double double10 = xYAreaRenderer7.getItemLabelAnchorOffset();
        boolean boolean11 = xYAreaRenderer7.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot16.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot14.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot14.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator25, xYURLGenerator26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYStepAreaRenderer27.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color33 = java.awt.Color.RED;
        xYStepAreaRenderer27.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color33, false);
        categoryAxis23.setTickLabelPaint((java.awt.Paint) color33);
        java.awt.Paint paint37 = categoryAxis23.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = combinedRangeXYPlot39.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke42 = combinedRangeXYPlot39.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint37, stroke42);
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = combinedRangeXYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker43, layer44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke51 = null;
        xYAreaRenderer7.drawRangeLine(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, (org.jfree.chart.axis.ValueAxis) dateAxis47, rectangle2D48, (double) 60000L, paint50, stroke51);
        combinedRangeXYPlot1.setRangeZeroBaselinePaint(paint50);
        java.awt.Paint paint54 = null;
        try {
            combinedRangeXYPlot1.setRangeGridlinePaint(paint54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.setKey((java.lang.Comparable) 0);
        java.lang.String str11 = timeSeries4.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color11 = java.awt.Color.RED;
        xYStepAreaRenderer5.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color11, false);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color11);
        java.awt.Paint paint15 = categoryAxis1.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint15, stroke20);
        boolean boolean23 = valueMarker21.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        java.awt.Font font4 = xYAreaRenderer0.lookupLegendTextFont((-457));
        org.junit.Assert.assertNull(font4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke8 = xYStepRenderer2.getItemStroke(15, (int) '4', true);
        double double9 = xYStepRenderer2.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = ringPlot4.getToolTipGenerator();
        boolean boolean7 = ringPlot4.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        java.awt.Paint paint9 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator11, xYURLGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepAreaRenderer13.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color19 = java.awt.Color.RED;
        xYStepAreaRenderer13.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color19, false);
        java.awt.Stroke stroke23 = xYStepAreaRenderer13.getSeriesStroke(3);
        java.awt.Stroke stroke25 = xYStepAreaRenderer13.lookupSeriesOutlineStroke(4);
        java.awt.Paint paint26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("hi!", "Combined Range XYPlot", "1.2.0-pre", "rect", shape8, paint9, stroke25, paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        java.lang.Object obj4 = intervalXYDelegate3.clone();
        try {
            double double7 = intervalXYDelegate3.getEndXValue(255, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        combinedDomainXYPlot46.setFixedRangeAxisSpace(axisSpace47);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot1.setDataset(waferMapDataset3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset0.validateObject();
        org.jfree.data.DomainOrder domainOrder2 = defaultXYDataset0.getDomainOrder();
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean4 = defaultXYDataset0.equals((java.lang.Object) strokeArray3);
        org.junit.Assert.assertNotNull(domainOrder2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        dateAxis1.setMinorTickCount((int) (byte) -1);
        dateAxis1.setAutoRange(false);
        try {
            dateAxis1.setRange((double) 11, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj8 = xYStepAreaRenderer3.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis9.setPlot((org.jfree.chart.plot.Plot) waferMapPlot10);
        xYStepAreaRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot10);
        xYStepAreaRenderer3.setSeriesItemLabelsVisible((int) '4', false);
        xYStepAreaRenderer3.setShapesFilled(true);
        boolean boolean18 = xYStepAreaRenderer3.isOutline();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) (short) 100, true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        java.awt.Font font7 = xYAreaRenderer0.getItemLabelFont(0, 3, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYAreaRenderer8.initialise(graphics2D9, rectangle2D10, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, (org.jfree.data.xy.XYDataset) defaultXYDataset13, plotRenderingInfo15);
        boolean boolean17 = xYAreaRenderer0.equals((java.lang.Object) rectangle2D10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot1.getFixedLegendItems();
        combinedRangeXYPlot1.setWeight((int) (byte) 100);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!");
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        int int2 = defaultXYDataset0.indexOf((java.lang.Comparable) Double.NaN);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createOutsetRectangle(rectangle2D2, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainMinorGridlineStroke();
        double double5 = combinedRangeXYPlot1.getGap();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.0d + "'", double5 == 5.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("hi!", font3, (java.awt.Paint) color4);
        xYAreaRenderer1.setBaseFillPaint((java.awt.Paint) color4, false);
        int int8 = color4.getGreen();
        java.awt.color.ColorSpace colorSpace9 = null;
        float[] floatArray11 = new float[] { 0L };
        try {
            float[] floatArray12 = color4.getColorComponents(colorSpace9, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth(0.0d);
        org.jfree.chart.util.Size2D size2D5 = blockContainer0.arrange(graphics2D1, rectangleConstraint4);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("hi!");
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = ringPlot8.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = ringPlot8.getLabelDistributor();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = ringPlot13.getToolTipGenerator();
        java.awt.Paint paint15 = ringPlot13.getOutlinePaint();
        java.awt.Color color16 = java.awt.Color.GRAY;
        ringPlot13.setBaseSectionPaint((java.awt.Paint) color16);
        org.jfree.chart.util.Rotation rotation18 = ringPlot13.getDirection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo20.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState22 = ringPlot8.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.PiePlot) ringPlot13, (java.lang.Integer) 0, plotRenderingInfo21);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) labelBlock7, (java.lang.Object) ringPlot8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.RingPlot cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
        org.junit.Assert.assertNull(pieToolTipGenerator14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rotation18);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState22);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        java.awt.Paint paint8 = combinedRangeXYPlot1.getDomainGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot1, jFreeChart9, chartChangeEventType10);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean4 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 10, 0);
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: baseTimeline.getSegmentSize() is smaller than segmentSize");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = java.awt.Color.CYAN;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color0, (java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, 1.0f, 1.0f, (double) (short) 0, (float) 2958465, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Object obj3 = defaultXYDataset0.clone();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = null;
        defaultXYDataset0.setSelectionState(xYDatasetSelectionState4);
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "JFreeChart", doubleArray9);
        try {
            defaultXYDataset0.addSeries((java.lang.Comparable) 9999.0d, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'data' array must have length == 2.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 3, 0.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        float float1 = waferMapPlot0.getBackgroundImageAlpha();
        java.awt.Paint paint2 = waferMapPlot0.getOutlinePaint();
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.5f + "'", float1 == 0.5f);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getHorizontalAlignment();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle1);
        textTitle1.setID("^-0.0");
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            legendTitle7.setItemLabelPadding(rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic8.setOutlineStroke(stroke10);
        double double12 = legendGraphic8.getContentYOffset();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMinimumIntegerDigits(0);
        boolean boolean6 = logFormat3.isParseIntegerOnly();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        java.awt.Stroke stroke5 = ringPlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        java.lang.Object obj2 = rendererChangeEvent1.getRenderer();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "" + "'", obj2.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator20 = ringPlot19.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor21 = ringPlot19.getLabelDistributor();
        double double22 = ringPlot19.getMaximumExplodePercent();
        java.awt.Paint paint23 = ringPlot19.getLabelBackgroundPaint();
        xYStepAreaRenderer3.setBaseFillPaint(paint23);
        java.lang.Boolean boolean26 = xYStepAreaRenderer3.getSeriesVisibleInLegend(15);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(pieToolTipGenerator20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(boolean26);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (byte) 100);
        shapeList0.clear();
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays(1, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray5 = new float[] { 2, 11, 12 };
        try {
            float[] floatArray6 = color0.getComponents(colorSpace1, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean4 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean11 = segmentedTimeline8.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list12 = segmentedTimeline8.getExceptionSegments();
        segmentedTimeline3.setBaseTimeline(segmentedTimeline8);
        long long15 = segmentedTimeline3.getTimeFromLong((long) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        java.awt.Paint paint8 = combinedRangeXYPlot1.getDomainGridlinePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator10, xYURLGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYStepAreaRenderer12.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYStepAreaRenderer12.setBaseToolTipGenerator(xYToolTipGenerator17, false);
        xYStepAreaRenderer12.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer25 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator23, xYURLGenerator24);
        java.lang.Boolean boolean27 = xYStepRenderer25.getSeriesLinesVisible(2);
        java.awt.Stroke stroke31 = xYStepRenderer25.getItemStroke(15, (int) '4', true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator32 = xYStepRenderer25.getBaseItemLabelGenerator();
        xYStepRenderer25.setDrawSeriesLineAsPath(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator36 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator36, xYURLGenerator37);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator39 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator40 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer41 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator39, xYURLGenerator40);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray42 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYStepAreaRenderer12, xYStepRenderer25, xYStepAreaRenderer38, xYStepRenderer41 };
        combinedRangeXYPlot1.setRenderers(xYItemRendererArray42);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(xYItemLabelGenerator32);
        org.junit.Assert.assertNotNull(xYItemRendererArray42);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = ringPlot0.getLabelLinkStyle();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj8 = xYStepAreaRenderer3.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis9.setPlot((org.jfree.chart.plot.Plot) waferMapPlot10);
        xYStepAreaRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot10);
        xYStepAreaRenderer3.setSeriesItemLabelsVisible((int) '4', false);
        xYStepAreaRenderer3.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint2 = ringPlot0.getOutlinePaint();
        java.awt.Color color3 = java.awt.Color.GRAY;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape11 = xYStepAreaRenderer7.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle13.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape11, (org.jfree.chart.title.Title) textTitle13, "Combined Range XYPlot");
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        ringPlot0.setLegendItemShape(shape11);
        ringPlot0.setStartAngle((double) 3);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        xYStepAreaRenderer5.setBaseToolTipGenerator(xYToolTipGenerator10, false);
        java.awt.Shape shape14 = null;
        xYStepAreaRenderer5.setSeriesShape((int) '4', shape14);
        int int16 = year1.compareTo((java.lang.Object) xYStepAreaRenderer5);
        try {
            xYStepAreaRenderer5.setSeriesItemLabelsVisible((-457), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        double double1 = dateRange0.getLength();
        double double2 = dateRange0.getLowerBound();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        double double4 = dateRange3.getLength();
        double double5 = dateRange3.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange3);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke11 = combinedRangeXYPlot8.getDomainGridlineStroke();
        java.util.List list12 = combinedRangeXYPlot8.getAnnotations();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer14);
        java.awt.Font font16 = xYAreaRenderer14.getBaseItemLabelFont();
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color20 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("hi!", font19, (java.awt.Paint) color20);
        xYAreaRenderer14.setSeriesPaint(2958465, (java.awt.Paint) color20);
        combinedRangeXYPlot8.setRangeTickBandPaint((java.awt.Paint) color20);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator25 = ringPlot24.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor26 = ringPlot24.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = null;
        ringPlot24.setLegendLabelToolTipGenerator(pieSectionLabelGenerator27);
        java.awt.Paint paint29 = ringPlot24.getLabelShadowPaint();
        combinedRangeXYPlot8.setRangeMinorGridlinePaint(paint29);
        float float31 = combinedRangeXYPlot8.getForegroundAlpha();
        boolean boolean32 = dateRange3.equals((java.lang.Object) combinedRangeXYPlot8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(pieToolTipGenerator25);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        timeSeries4.setMaximumItemCount(3);
        int int7 = timeSeries4.getMaximumItemCount();
        int int8 = timeSeries4.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth(0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight((double) 0);
        org.jfree.data.Range range5 = rectangleConstraint4.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("index.html?series=-1&amp;item=0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        java.lang.Object obj4 = intervalXYDelegate3.clone();
        try {
            intervalXYDelegate3.setIntervalPositionFactor((double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(0.0d);
        java.util.List list3 = axisState0.getTicks();
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.awt.Paint paint9 = null;
        combinedRangeXYPlot1.setBackgroundPaint(paint9);
        boolean boolean11 = combinedRangeXYPlot1.isSubplot();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.setKey((java.lang.Comparable) 0);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        ringPlot0.setNoDataMessage("hi!");
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible(2);
        java.awt.Color color6 = java.awt.Color.green;
        xYStepRenderer2.setSeriesOutlinePaint(2958465, (java.awt.Paint) color6, false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        boolean boolean11 = combinedRangeXYPlot10.canSelectByPoint();
        xYStepRenderer2.setPlot((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot10);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        timeSeries4.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (short) 0;
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape9 = xYStepAreaRenderer5.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle11.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        textTitle11.draw(graphics2D15, rectangle2D16);
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle11, "Combined Range XYPlot");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle20, "Combined Range XYPlot", "java.awt.Color[r=255,g=0,b=0]");
        dateAxis1.setDownArrow(shape9);
        try {
            dateAxis1.zoomRange((double) 100.0f, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (196.0) <= upper (95.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getHorizontalAlignment();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener6 = null;
        textTitle1.removeChangeListener(titleChangeListener6);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        boolean boolean4 = lineBorder2.equals((java.lang.Object) "JFreeChart");
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        boolean boolean6 = lineBorder2.equals((java.lang.Object) size2D5);
        org.jfree.chart.util.Size2D size2D7 = rectangleConstraint1.calculateConstrainedSize(size2D5);
        double double8 = size2D5.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getDomainGridlineStroke();
        java.util.List list7 = combinedRangeXYPlot3.getAnnotations();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer9);
        java.awt.Font font11 = xYAreaRenderer9.getBaseItemLabelFont();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!", font14, (java.awt.Paint) color15);
        xYAreaRenderer9.setSeriesPaint(2958465, (java.awt.Paint) color15);
        combinedRangeXYPlot3.setRangeTickBandPaint((java.awt.Paint) color15);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color15);
        org.jfree.chart.util.TableOrder tableOrder20 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = polarPlot0.getDataRange(valueAxis3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepAreaRenderer8.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYStepAreaRenderer8.setBaseToolTipGenerator(xYToolTipGenerator13, false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYStepAreaRenderer8.initialise(graphics2D16, rectangle2D17, xYPlot18, xYDataset19, plotRenderingInfo20);
        java.awt.Paint paint23 = xYStepAreaRenderer8.getSeriesPaint((int) (short) 100);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer8.setSeriesItemLabelFont((int) (short) 10, font25, false);
        polarPlot0.setAngleLabelFont(font25);
        org.jfree.chart.axis.TickUnit tickUnit29 = polarPlot0.getAngleTickUnit();
        boolean boolean30 = polarPlot0.isRangeZoomable();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(tickUnit29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, (java.awt.Paint) color2);
        java.awt.Color color4 = color2.brighter();
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace9);
        combinedRangeXYPlot1.clearAnnotations();
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.lang.Object obj2 = dateAxis1.clone();
        java.awt.Shape shape3 = dateAxis1.getLeftArrow();
        boolean boolean5 = dateAxis1.isHiddenValue((long) (-1));
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 11, (double) 12, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.GRAY;
        xYStepAreaRenderer3.setBaseOutlinePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYStepAreaRenderer3.setSeriesOutlineStroke(12, stroke23, false);
        xYStepAreaRenderer3.clearSeriesPaints(false);
        java.lang.Boolean boolean29 = xYStepAreaRenderer3.getSeriesVisible(0);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator31 = xYStepAreaRenderer3.getSeriesItemLabelGenerator((int) '4');
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertNull(xYItemLabelGenerator31);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.awt.geom.Point2D point2D7 = combinedRangeXYPlot3.getQuadrantOrigin();
        combinedRangeXYPlot3.clearDomainMarkers();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(point2D7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 10);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 100, (float) 100, (float) 255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2236514) + "'", int3 == (-2236514));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer1.getBaseNegativeItemLabelPosition();
        xYAreaRenderer1.clearSeriesStrokes(false);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        int int6 = xYStepAreaRenderer1.getPassCount();
        xYStepAreaRenderer1.setDefaultEntityRadius((int) (byte) -1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.addOrUpdate(xYDataItem4);
        org.jfree.data.xy.XYDataItem xYDataItem12 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj13 = xYDataItem12.clone();
        double double14 = xYDataItem12.getXValue();
        org.jfree.data.xy.XYDataItem xYDataItem15 = xYSeries1.addOrUpdate(xYDataItem12);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem15);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.updateCrosshairY((double) 12, 4);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot9.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11);
        java.awt.geom.Point2D point2D15 = combinedRangeXYPlot11.getQuadrantOrigin();
        combinedRangeXYPlot1.zoomRangeAxes((double) 43629L, (double) (short) 100, plotRenderingInfo7, point2D15);
        java.io.ObjectOutputStream objectOutputStream17 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D15, objectOutputStream17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(point2D15);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMaximumIntegerDigits((-1));
        int int6 = logFormat3.getMinimumIntegerDigits();
        logFormat3.setMaximumFractionDigits(15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day9, "", "hi!");
        timeSeries13.setMaximumItemCount(3);
        java.util.List list16 = timeSeries13.getItems();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 10);
        int int19 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType21 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        int int22 = year18.compareTo((java.lang.Object) dateTickUnitType21);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(dateTickUnitType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.plot.XYPlot xYPlot52 = null;
        try {
            combinedDomainXYPlot46.remove(xYPlot52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message:  Null 'subplot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        boolean boolean1 = logFormat0.isGroupingUsed();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth(0.0d);
        org.jfree.chart.util.Size2D size2D5 = blockContainer0.arrange(graphics2D1, rectangleConstraint4);
        java.util.List list6 = blockContainer0.getBlocks();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            blockContainer0.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = waferMapPlot1.getDatasetGroup();
        org.junit.Assert.assertNull(datasetGroup3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYStepAreaRenderer3.setBaseURLGenerator(xYURLGenerator11, true);
        java.awt.Font font17 = xYStepAreaRenderer3.getItemLabelFont((int) (short) 1, (int) ' ', true);
        java.awt.Font font19 = xYStepAreaRenderer3.getLegendTextFont(5);
        java.lang.Object obj20 = xYStepAreaRenderer3.clone();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = datasetRenderingOrder0.equals((java.lang.Object) seriesChangeEvent3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.addOrUpdate(xYDataItem4);
        try {
            java.lang.Number number10 = xYDataItem9.getY();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isVisible();
        java.lang.String str2 = categoryAxis0.getLabelURL();
        categoryAxis0.setTickMarksVisible(true);
        java.awt.Paint paint5 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        xYStepAreaRenderer3.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis14.setPlot((org.jfree.chart.plot.Plot) waferMapPlot15);
        xYStepAreaRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot15);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection18 = waferMapPlot15.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Object obj3 = defaultXYDataset0.clone();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = null;
        defaultXYDataset0.setSelectionState(xYDatasetSelectionState4);
        try {
            double double8 = defaultXYDataset0.getYValue((int) (short) 100, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ERROR : Relative To String");
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint2 = ringPlot0.getOutlinePaint();
        java.awt.Color color3 = java.awt.Color.GRAY;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape11 = xYStepAreaRenderer7.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle13.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape11, (org.jfree.chart.title.Title) textTitle13, "Combined Range XYPlot");
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        ringPlot0.setLegendItemShape(shape11);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.axis.Axis axis25 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape11, axis25, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isVisible();
        java.lang.String str2 = categoryAxis0.getLabelURL();
        categoryAxis0.setTickMarksVisible(true);
        categoryAxis0.setLabelToolTip("hi!");
        java.awt.Font font8 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (-2236514));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        try {
            java.lang.Object obj5 = logFormat3.parseObject("100");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.plot.Plot plot11 = combinedRangeXYPlot1.getRootPlot();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic8.setOutlineStroke(stroke10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle13.getBounds();
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat21.setMaximumIntegerDigits((-1));
        int int24 = logFormat21.getMinimumIntegerDigits();
        try {
            java.lang.Object obj25 = legendGraphic8.draw(graphics2D12, rectangle2D17, (java.lang.Object) int24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        xYStepAreaRenderer3.setAutoPopulateSeriesOutlineStroke(false);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        int int4 = waferMapPlot1.getBackgroundImageAlignment();
        org.jfree.chart.plot.Plot plot5 = waferMapPlot1.getRootPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = waferMapPlot1.getDataset();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNull(waferMapDataset6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        timeSeries4.setMaximumItemCount(3);
        java.util.List list7 = timeSeries4.getItems();
        try {
            java.util.Collection collection8 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list7);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.awt.Paint paint7 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot1.getDomainAxisLocation(9999);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        combinedRangeXYPlot1.setAxisOffset(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        polarPlot0.setAngleGridlinesVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot0.datasetChanged(datasetChangeEvent5);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) ' ', (float) 255, (float) 13);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape12 = xYStepAreaRenderer8.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.visible = true;
        boolean boolean16 = textTitle13.isVisible();
        textTitle13.setExpandToFitSpace(false);
        org.jfree.chart.entity.TitleEntity titleEntity20 = new org.jfree.chart.entity.TitleEntity(shape12, (org.jfree.chart.title.Title) textTitle13, "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.entity.TitleEntity titleEntity22 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle13, "RectangleAnchor.LEFT");
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultPieDataset0.sortByKeys(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("java.awt.Color[r=255,g=0,b=0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot1.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.RenderingSource renderingSource9 = null;
        combinedRangeXYPlot1.select(100.0d, 0.0d, rectangle2D8, renderingSource9);
        java.awt.Stroke stroke11 = combinedRangeXYPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot1.getLegendItems();
        java.lang.Object obj13 = legendItemCollection12.clone();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(6, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("index.html?series=-1&amp;item=0");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setHeight((double) (byte) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = labelBlock1.getContentAlignmentPoint();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        int int4 = waferMapPlot1.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis5.setPlot((org.jfree.chart.plot.Plot) waferMapPlot6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator9, xYURLGenerator10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYStepAreaRenderer11.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color17 = java.awt.Color.RED;
        xYStepAreaRenderer11.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color17, false);
        categoryAxis5.setAxisLinePaint((java.awt.Paint) color17);
        waferMapPlot1.setOutlinePaint((java.awt.Paint) color17);
        int int22 = color17.getTransparency();
        java.awt.Color color23 = color17.brighter();
        try {
            java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot3.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset9 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot3.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str14 = projectInfo13.getLicenceText();
        java.util.List list15 = projectInfo13.getContributors();
        combinedRangeXYPlot3.drawRangeTickBands(graphics2D11, rectangle2D12, list15);
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        combinedRangeXYPlot3.setRangeTickBandPaint(paint18);
        java.awt.Paint paint20 = combinedRangeXYPlot3.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(projectInfo13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer3.setSeriesItemLabelFont((int) '4', font5);
        java.awt.Paint paint7 = xYStepAreaRenderer3.getBasePaint();
        java.awt.Stroke stroke9 = xYStepAreaRenderer3.getSeriesOutlineStroke((int) (short) 100);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer10.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean16 = xYLineAndShapeRenderer10.getItemLineVisible(0, 3);
        boolean boolean17 = xYLineAndShapeRenderer10.getDrawOutlines();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYLineAndShapeRenderer10.setBaseOutlineStroke(stroke18, true);
        xYStepAreaRenderer3.setBaseStroke(stroke18, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        java.awt.Paint paint8 = combinedRangeXYPlot1.getDomainMinorGridlinePaint();
        org.jfree.chart.plot.Plot plot9 = combinedRangeXYPlot1.getParent();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(plot9);
    }
}

