import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setHeight((double) (byte) 10);
        java.lang.Object obj4 = labelBlock1.clone();
        java.lang.String str5 = labelBlock1.getToolTipText();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', (double) 'a', (double) (byte) 1, (double) (byte) 100);
        double double5 = rectangleInsets4.getBottom();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        try {
            defaultPieDataset0.insertValue(100, (java.lang.Comparable) "{0}", (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = polarPlot0.getDataRange(valueAxis3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setAutoPopulateSeriesPaint(true);
        double double8 = xYAreaRenderer5.getItemLabelAnchorOffset();
        boolean boolean9 = xYAreaRenderer5.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedRangeXYPlot14.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot12.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset18 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot12.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator23, xYURLGenerator24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color31 = java.awt.Color.RED;
        xYStepAreaRenderer25.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color31, false);
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color31);
        java.awt.Paint paint35 = categoryAxis21.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = combinedRangeXYPlot37.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke40 = combinedRangeXYPlot37.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint35, stroke40);
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = combinedRangeXYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker41, layer42);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke49 = null;
        xYAreaRenderer5.drawRangeLine(graphics2D10, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis45, rectangle2D46, (double) 60000L, paint48, stroke49);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot51 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.data.Range range52 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.data.time.DateRange dateRange54 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType55 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange57 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType58 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange54, lengthConstraintType55, (double) 12, (org.jfree.data.Range) dateRange57, lengthConstraintType58);
        org.jfree.data.Range range61 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange57, (double) 12);
        dateAxis45.setRangeWithMargins(range61, false, false);
        org.jfree.data.Range range66 = org.jfree.data.Range.expandToInclude(range61, (double) (byte) 0);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(lengthConstraintType55);
        org.junit.Assert.assertNotNull(lengthConstraintType58);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(range66);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        java.awt.Paint paint46 = dateAxis40.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        combinedRangeXYPlot1.configureDomainAxes();
        combinedRangeXYPlot1.setDomainCrosshairValue(116.0d);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer0.getLegendItem(6, (int) (byte) -1);
        java.awt.Paint paint9 = null;
        xYAreaRenderer0.setLegendTextPaint((int) (short) 1, paint9);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        xYStepAreaRenderer5.setBaseToolTipGenerator(xYToolTipGenerator10, false);
        java.awt.Shape shape14 = null;
        xYStepAreaRenderer5.setSeriesShape((int) '4', shape14);
        int int16 = year1.compareTo((java.lang.Object) xYStepAreaRenderer5);
        long long17 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible(2);
        java.awt.Color color6 = java.awt.Color.green;
        xYStepRenderer2.setSeriesOutlinePaint(2958465, (java.awt.Paint) color6, false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedRangeXYPlot12.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot10.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot10.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset16);
        org.jfree.data.Range range18 = xYStepRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset16);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 100L, (double) 2, (double) (-457));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle9.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle9.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot15.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17);
        java.awt.geom.Point2D point2D21 = combinedRangeXYPlot17.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = combinedRangeXYPlot17.getRangeAxisEdge();
        try {
            gradientXYBarPainter3.paintBarShadow(graphics2D4, xYBarRenderer5, (-1), 3, true, (java.awt.geom.RectangularShape) rectangle2D13, rectangleEdge22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) 100.0f);
        java.lang.Object obj4 = ringPlot0.clone();
        ringPlot0.setAutoPopulateSectionPaint(false);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        combinedRangeXYPlot1.configureDomainAxes();
        int int8 = combinedRangeXYPlot1.getRangeAxisCount();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        int int3 = polarPlot0.getSeriesCount();
        polarPlot0.removeCornerTextItem("{0}: ({1}, {2})");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesShapesVisible(255, true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        int int1 = shapeList0.size();
        java.awt.Shape shape3 = shapeList0.getShape(2);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 1, 10.0f);
        shapeList0.setShape((int) (short) 0, shape7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 0.0d, 12.0d, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.awt.Paint paint7 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        dateAxis10.setInverted(true);
        combinedRangeXYPlot1.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        try {
            dateAxis10.setRange((double) '4', (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.lang.Object obj9 = defaultXYDataset7.clone();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset7, valueAxis10, polarItemRenderer11);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        polarPlot12.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
        polarPlot12.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit16);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator19 = ringPlot18.getToolTipGenerator();
        java.awt.Paint paint20 = ringPlot18.getOutlinePaint();
        java.awt.Color color21 = java.awt.Color.GRAY;
        ringPlot18.setBaseSectionPaint((java.awt.Paint) color21);
        org.jfree.chart.util.Rotation rotation23 = ringPlot18.getDirection();
        boolean boolean24 = numberTickUnit16.equals((java.lang.Object) rotation23);
        int int25 = numberTickUnit16.getMinorTickCount();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(pieToolTipGenerator19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rotation23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot1.setDomainAxes(valueAxisArray6);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = ringPlot8.getToolTipGenerator();
        java.lang.Object obj10 = ringPlot8.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        ringPlot8.setURLGenerator(pieURLGenerator11);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator13 = null;
        ringPlot8.setToolTipGenerator(pieToolTipGenerator13);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator16, xYURLGenerator17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepAreaRenderer18.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color24 = java.awt.Color.RED;
        xYStepAreaRenderer18.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color24, false);
        ringPlot8.setLabelPaint((java.awt.Paint) color24);
        combinedRangeXYPlot1.setRangeZeroBaselinePaint((java.awt.Paint) color24);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB(11, (int) (short) 1, 1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        combinedDomainXYPlot46.setGap((double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.axis.Axis axis3 = axisChangeEvent2.getAxis();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(axis3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        double double9 = timeSeries4.getMaxY();
        try {
            timeSeries4.delete(1, 9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator20 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        xYStepAreaRenderer3.setSeriesToolTipGenerator((int) 'a', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator20, true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator24 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYStepAreaRenderer3.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator24);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.lang.Object obj2 = null;
        boolean boolean3 = blockBorder0.equals(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer1.setAutoPopulateSeriesPaint(true);
        double double4 = xYAreaRenderer1.getItemLabelAnchorOffset();
        boolean boolean5 = xYAreaRenderer1.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot8.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot10);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset14 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot8.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator19 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator19, xYURLGenerator20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYStepAreaRenderer21.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color27 = java.awt.Color.RED;
        xYStepAreaRenderer21.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color27, false);
        categoryAxis17.setTickLabelPaint((java.awt.Paint) color27);
        java.awt.Paint paint31 = categoryAxis17.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = combinedRangeXYPlot33.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke36 = combinedRangeXYPlot33.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint31, stroke36);
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean39 = combinedRangeXYPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker37, layer38);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke45 = null;
        xYAreaRenderer1.drawRangeLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8, (org.jfree.chart.axis.ValueAxis) dateAxis41, rectangle2D42, (double) 60000L, paint44, stroke45);
        dateAxis41.setUpperMargin((double) (short) 10);
        dateAxis41.setMinorTickCount((int) (short) 1);
        java.awt.Shape shape51 = dateAxis41.getUpArrow();
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend52 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) dateAxis41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(shape51);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0, (double) 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        textTitle0.removeChangeListener(titleChangeListener4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle0.getTextAlignment();
        java.lang.Object obj7 = textTitle0.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint2 = ringPlot0.getOutlinePaint();
        java.awt.Color color3 = java.awt.Color.GRAY;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape11 = xYStepAreaRenderer7.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle13.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape11, (org.jfree.chart.title.Title) textTitle13, "Combined Range XYPlot");
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        ringPlot0.setLegendItemShape(shape11);
        ringPlot0.setStartAngle(0.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.RenderingSource renderingSource8 = null;
        combinedRangeXYPlot1.select(0.0d, (double) 0, rectangle2D7, renderingSource8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator11, xYURLGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepAreaRenderer13.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        xYStepAreaRenderer13.setBaseToolTipGenerator(xYToolTipGenerator18, false);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYStepAreaRenderer13.initialise(graphics2D21, rectangle2D22, xYPlot23, xYDataset24, plotRenderingInfo25);
        java.awt.Paint paint28 = xYStepAreaRenderer13.getSeriesPaint((int) (short) 100);
        combinedRangeXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer13);
        java.awt.Shape shape31 = xYStepAreaRenderer13.lookupSeriesShape((int) (byte) 10);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Stroke stroke3 = xYAreaRenderer1.getSeriesOutlineStroke(0);
        xYAreaRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer1.getSeriesPositiveItemLabelPosition(13);
        double double8 = itemLabelPosition7.getAngle();
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        boolean boolean4 = intervalXYDelegate3.isAutoWidth();
        double double5 = intervalXYDelegate3.getIntervalPositionFactor();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("{0}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name {0}, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot1.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.RenderingSource renderingSource9 = null;
        combinedRangeXYPlot1.select(100.0d, 0.0d, rectangle2D8, renderingSource9);
        java.awt.Stroke stroke11 = combinedRangeXYPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot1.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot16.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot14.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16);
        java.awt.Paint paint20 = combinedRangeXYPlot14.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = combinedRangeXYPlot22.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedRangeXYPlot22.getRangeAxisLocation();
        combinedRangeXYPlot14.setRangeAxisLocation(axisLocation25, false);
        combinedRangeXYPlot1.setDomainAxisLocation(axisLocation25, false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) 60000L, (double) 100L, (-457), (java.lang.Comparable) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemLineVisible(0, 3);
        boolean boolean7 = xYLineAndShapeRenderer0.getDrawOutlines();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYLineAndShapeRenderer0.setBaseOutlineStroke(stroke8, true);
        java.lang.Boolean boolean12 = xYLineAndShapeRenderer0.getSeriesShapesVisible(6);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator4, xYURLGenerator5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer6.setBaseToolTipGenerator(xYToolTipGenerator11, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = xYStepAreaRenderer6.initialise(graphics2D14, rectangle2D15, xYPlot16, xYDataset17, plotRenderingInfo18);
        java.awt.Paint paint21 = xYStepAreaRenderer6.getSeriesPaint((int) (short) 100);
        boolean boolean22 = xYStepAreaRenderer6.getBaseSeriesVisible();
        java.awt.Color color23 = java.awt.Color.GRAY;
        xYStepAreaRenderer6.setBaseOutlinePaint((java.awt.Paint) color23);
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYStepAreaRenderer6.setSeriesOutlineStroke(12, stroke26, false);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 1.0f, stroke26);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(xYItemRendererState19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 0.0d);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        double double6 = xYDataItem5.getYValue();
        java.awt.Stroke stroke7 = null;
        strokeMap0.put((java.lang.Comparable) double6, stroke7);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean10 = strokeMap0.equals((java.lang.Object) itemLabelAnchor9);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9999.0d + "'", double6 == 9999.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Paint paint10 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        combinedRangeXYPlot12.setDomainAxis(100, valueAxis14, true);
        java.awt.Stroke stroke17 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder(paint10, stroke17, rectangleInsets19);
        boolean boolean21 = legendGraphic8.equals((java.lang.Object) rectangleInsets19);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        double double2 = xYSeries1.getMinY();
        int int3 = xYSeries1.getItemCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getMaximumExplodePercent();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        ringPlot0.setOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator6, xYURLGenerator7);
        java.lang.Boolean boolean10 = xYStepRenderer8.getSeriesLinesVisible(2);
        java.awt.Color color12 = java.awt.Color.green;
        xYStepRenderer8.setSeriesOutlinePaint(2958465, (java.awt.Paint) color12, false);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYStepRenderer8.setSeriesOutlineStroke(3, stroke16);
        ringPlot0.setBaseSectionOutlineStroke(stroke16);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        boolean boolean3 = ringPlot0.getLabelLinksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = ringPlot0.getSimpleLabelOffset();
        double double6 = rectangleInsets4.trimHeight((double) '4');
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 33.28d + "'", double6 == 33.28d);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        java.util.List list2 = projectInfo0.getContributors();
//        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
//        projectInfo0.setLicenceName("");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(libraryArray3);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat4.setParseIntegerOnly(true);
        boolean boolean8 = logFormat4.equals((java.lang.Object) 2);
        java.lang.String str10 = logFormat4.format(10L);
        java.lang.Object obj11 = null;
        boolean boolean12 = logFormat4.equals(obj11);
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat4, dateFormat13);
        java.text.DateFormat dateFormat15 = standardXYToolTipGenerator14.getXDateFormat();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "^-0.0" + "'", str10.equals("^-0.0"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(dateFormat15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.title.Title title8 = null;
        try {
            jFreeChart7.addSubtitle(title8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot1.rendererChanged(rendererChangeEvent9);
        boolean boolean11 = combinedRangeXYPlot1.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot1.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.RenderingSource renderingSource9 = null;
        combinedRangeXYPlot1.select(100.0d, 0.0d, rectangle2D8, renderingSource9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = combinedRangeXYPlot1.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', (double) (short) 1);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        boolean boolean2 = standardXYToolTipGenerator0.equals((java.lang.Object) "100");
        java.text.DateFormat dateFormat3 = standardXYToolTipGenerator0.getYDateFormat();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.awt.geom.Point2D point2D7 = combinedRangeXYPlot3.getQuadrantOrigin();
        combinedRangeXYPlot3.mapDatasetToRangeAxis((int) (byte) 10, (int) (short) 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(point2D7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setNotify(false);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator7 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset8 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset8);
        java.lang.Object obj11 = defaultXYDataset8.clone();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset8, false);
        java.lang.String str16 = standardXYURLGenerator7.generateURL((org.jfree.data.xy.XYDataset) defaultXYDataset8, (int) (short) -1, 0);
        int int17 = combinedRangeXYPlot1.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset8);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "index.html?series=-1&amp;item=0" + "'", str16.equals("index.html?series=-1&amp;item=0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        java.lang.String str2 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str2.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        int int7 = combinedRangeXYPlot1.getRangeAxisCount();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        java.awt.Paint paint20 = xYStepAreaRenderer3.getLegendTextPaint((int) (byte) 10);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getDomainGridlineStroke();
        java.util.List list7 = combinedRangeXYPlot3.getAnnotations();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer9);
        java.awt.Font font11 = xYAreaRenderer9.getBaseItemLabelFont();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!", font14, (java.awt.Paint) color15);
        xYAreaRenderer9.setSeriesPaint(2958465, (java.awt.Paint) color15);
        combinedRangeXYPlot3.setRangeTickBandPaint((java.awt.Paint) color15);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color15);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = combinedRangeXYPlot24.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke27 = combinedRangeXYPlot24.getDomainGridlineStroke();
        combinedRangeXYPlot24.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot24);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent33 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset20, jFreeChart30, (int) ' ', 9999);
        try {
            multiplePiePlot1.setPieChart(jFreeChart30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        java.util.List list5 = combinedRangeXYPlot1.getAnnotations();
        java.awt.Paint paint6 = combinedRangeXYPlot1.getDomainMinorGridlinePaint();
        boolean boolean7 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        combinedRangeXYPlot1.setBackgroundImageAlpha((float) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.removeAgedItems((long) 'a', true);
        java.lang.String str12 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean6 = segmentedTimeline3.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list7 = segmentedTimeline3.getExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = segmentedTimeline3.getBaseTimeline();
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline8.getSegment((long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(segmentedTimeline8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(10);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        int int17 = xYItemRendererState16.getFirstItemIndex();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        ringPlot0.setShadowXOffset((double) (byte) 10);
        boolean boolean7 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 10700L);
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        xYItemRendererState1.setProcessVisibleItemsOnly(true);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset4 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke11 = combinedRangeXYPlot8.getDomainGridlineStroke();
        combinedRangeXYPlot8.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset4, jFreeChart14, (int) ' ', 9999);
        xYItemRendererState1.endSeriesPass((org.jfree.data.xy.XYDataset) defaultXYDataset4, (int) (short) 100, 13, 11, 255, 3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = polarPlot0.getDataRange(valueAxis3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepAreaRenderer8.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYStepAreaRenderer8.setBaseToolTipGenerator(xYToolTipGenerator13, false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYStepAreaRenderer8.initialise(graphics2D16, rectangle2D17, xYPlot18, xYDataset19, plotRenderingInfo20);
        java.awt.Paint paint23 = xYStepAreaRenderer8.getSeriesPaint((int) (short) 100);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer8.setSeriesItemLabelFont((int) (short) 10, font25, false);
        polarPlot0.setAngleLabelFont(font25);
        int int29 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer1.getBaseNegativeItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYAreaRenderer1.getPositiveItemLabelPosition(4, (int) '#', true);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Stroke stroke5 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = ringPlot0.getLegendItems();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset6 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset6);
        java.lang.Object obj9 = defaultXYDataset6.clone();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset6, false);
        java.lang.String str14 = standardXYURLGenerator5.generateURL((org.jfree.data.xy.XYDataset) defaultXYDataset6, (int) (short) -1, 0);
        org.jfree.chart.entity.XYItemEntity xYItemEntity19 = new org.jfree.chart.entity.XYItemEntity(shape4, (org.jfree.data.xy.XYDataset) defaultXYDataset6, (int) 'a', 0, "TimePeriodAnchor.END", "RectangleAnchor.LEFT");
        xYItemEntity19.setSeriesIndex((int) 'a');
        java.lang.String str22 = xYItemEntity19.toString();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "index.html?series=-1&amp;item=0" + "'", str14.equals("index.html?series=-1&amp;item=0"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.Comparable[] comparableArray0 = null;
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem8 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj9 = xYDataItem8.clone();
        double double10 = xYDataItem8.getXValue();
        xYDataItem8.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem13 = xYSeries5.addOrUpdate(xYDataItem8);
        org.jfree.data.xy.XYDataItem xYDataItem16 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj17 = xYDataItem16.clone();
        double double18 = xYDataItem16.getXValue();
        org.jfree.data.xy.XYDataItem xYDataItem19 = xYSeries5.addOrUpdate(xYDataItem16);
        java.lang.Comparable[] comparableArray20 = new java.lang.Comparable[] { 0.2d, (-1L), 64, xYDataItem19 };
        double[][] doubleArray23 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "JFreeChart", doubleArray23);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray20, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem19);
        org.junit.Assert.assertNotNull(comparableArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(axisSpace9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        segmentedTimeline3.addException((long) 2, 10L);
        long long7 = segmentedTimeline3.getSegmentsGroupSize();
        boolean boolean8 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10700L + "'", long7 == 10700L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setParseIntegerOnly(true);
        java.util.Currency currency6 = null;
        try {
            logFormat3.setCurrency(currency6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        xYStepAreaRenderer3.setBaseItemLabelsVisible(false, false);
        java.lang.Boolean boolean15 = xYStepAreaRenderer3.getSeriesItemLabelsVisible((int) (byte) -1);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        java.lang.String str2 = projectInfo0.getLicenceText();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange1, lengthConstraintType2, (double) 12, (org.jfree.data.Range) dateRange4, lengthConstraintType5);
        org.jfree.data.Range range7 = rectangleConstraint6.getHeightRange();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer4);
        java.awt.Font font6 = xYAreaRenderer4.getBaseItemLabelFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.configure();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color13 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("hi!", font12, (java.awt.Paint) color13);
        categoryAxis8.setTickLabelFont((java.lang.Comparable) 0.5f, font12);
        xYAreaRenderer4.setSeriesItemLabelFont((int) (short) 100, font12);
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        textBlock0.addLine("PieLabelLinkStyle.QUAD_CURVE", font12, (java.awt.Paint) color17);
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot9.getLegendItems();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.RenderingSource renderingSource16 = null;
        combinedRangeXYPlot9.select(0.0d, (double) 0, rectangle2D15, renderingSource16);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator19 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator19, xYURLGenerator20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYStepAreaRenderer21.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYStepAreaRenderer21.setBaseToolTipGenerator(xYToolTipGenerator26, false);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState34 = xYStepAreaRenderer21.initialise(graphics2D29, rectangle2D30, xYPlot31, xYDataset32, plotRenderingInfo33);
        java.awt.Paint paint36 = xYStepAreaRenderer21.getSeriesPaint((int) (short) 100);
        combinedRangeXYPlot9.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        xYStepAreaRenderer21.setPlotArea(true);
        java.awt.Paint paint40 = xYStepAreaRenderer21.getBasePaint();
        combinedRangeXYPlot1.setOutlinePaint(paint40);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(xYItemRendererState34);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYStepAreaRenderer4.setBaseToolTipGenerator(xYToolTipGenerator9, false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = xYStepAreaRenderer4.initialise(graphics2D12, rectangle2D13, xYPlot14, xYDataset15, plotRenderingInfo16);
        java.awt.Paint paint19 = xYStepAreaRenderer4.getSeriesPaint((int) (short) 100);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer4.setSeriesItemLabelFont((int) (short) 10, font21, false);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color24);
        java.lang.String str26 = color24.toString();
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(xYItemRendererState17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str26.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        axisState0.moveCursor((double) 1L, rectangleEdge2);
        axisState0.setCursor((double) '4');
        java.util.List list6 = axisState0.getTicks();
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.GRAY;
        xYStepAreaRenderer3.setBaseOutlinePaint((java.awt.Paint) color20);
        xYStepAreaRenderer3.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        double double28 = ringPlot27.getSectionDepth();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = combinedRangeXYPlot30.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke33 = combinedRangeXYPlot30.getDomainGridlineStroke();
        combinedRangeXYPlot30.setRangePannable(true);
        java.awt.Stroke stroke36 = combinedRangeXYPlot30.getDomainZeroBaselineStroke();
        ringPlot27.setLabelLinkStroke(stroke36);
        xYStepAreaRenderer3.setBaseOutlineStroke(stroke36);
        boolean boolean39 = xYStepAreaRenderer3.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setWidth((double) (byte) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer9.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYStepAreaRenderer9.setBaseToolTipGenerator(xYToolTipGenerator14, false);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState22 = xYStepAreaRenderer9.initialise(graphics2D17, rectangle2D18, xYPlot19, xYDataset20, plotRenderingInfo21);
        java.awt.Paint paint24 = xYStepAreaRenderer9.getSeriesPaint((int) (short) 100);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer9.setSeriesItemLabelFont((int) (short) 10, font26, false);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("", font26, (java.awt.Paint) color29);
        java.awt.Color color31 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("hi!", font26, (java.awt.Paint) color31);
        labelBlock1.setFont(font26);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(xYItemRendererState22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator4, xYURLGenerator5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color12 = java.awt.Color.RED;
        xYStepAreaRenderer6.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color12, false);
        categoryAxis2.setTickLabelPaint((java.awt.Paint) color12);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = combinedRangeXYPlot18.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke21 = combinedRangeXYPlot18.getDomainGridlineStroke();
        combinedRangeXYPlot18.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        try {
            multiplePiePlot1.setPieChart(jFreeChart24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) 'a', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
        xYStepAreaRenderer3.setPlotArea(false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getMaximumExplodePercent();
        java.awt.Paint paint4 = ringPlot0.getLabelBackgroundPaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = ringPlot7.getToolTipGenerator();
        boolean boolean10 = ringPlot7.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape11 = ringPlot7.getLegendItemShape();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo15.getPlotInfo();
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo16);
        org.jfree.chart.plot.PiePlotState piePlotState18 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) ringPlot7, (java.lang.Integer) 4, plotRenderingInfo14);
        ringPlot7.setStartAngle((-1.0d));
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertNotNull(piePlotState18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        java.awt.Paint paint6 = xYAreaRenderer0.getItemLabelPaint(15, 2, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator8, xYURLGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYStepAreaRenderer10.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj15 = xYStepAreaRenderer10.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis16.setPlot((org.jfree.chart.plot.Plot) waferMapPlot17);
        xYStepAreaRenderer10.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot17);
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot17);
        xYAreaRenderer0.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot1.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color22 = java.awt.Color.RED;
        xYStepAreaRenderer16.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color22, false);
        categoryAxis12.setTickLabelPaint((java.awt.Paint) color22);
        java.awt.Paint paint26 = categoryAxis12.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = combinedRangeXYPlot28.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke31 = combinedRangeXYPlot28.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint26, stroke31);
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker32, layer33);
        boolean boolean35 = combinedRangeXYPlot1.canSelectByRegion();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        java.lang.Object obj4 = intervalXYDelegate3.clone();
        try {
            double double7 = intervalXYDelegate3.getEndXValue((int) (byte) -1, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        double double9 = timeSeries4.getMaxY();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day10);
        long long13 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection14 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setDomainAxis(100, valueAxis3, true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot7.getRangeAxisLocation();
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, 9999);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedRangeXYPlot1.getRangeAxis((int) (short) 1);
        java.awt.Paint paint9 = combinedRangeXYPlot1.getDomainGridlinePaint();
        boolean boolean10 = combinedRangeXYPlot1.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        boolean boolean3 = categoryAxis0.isAxisLineVisible();
        java.awt.Paint paint4 = categoryAxis0.getAxisLinePaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.configure();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle11.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle11.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = combinedRangeXYPlot17.getDomainAxisForDataset(0);
        java.awt.Paint paint20 = combinedRangeXYPlot17.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement22 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot17, (org.jfree.chart.block.Arrangement) columnArrangement21, (org.jfree.chart.block.Arrangement) borderArrangement22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle23.getItemLabelPadding();
        java.lang.Object obj25 = legendTitle23.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = legendTitle23.getLegendItemGraphicEdge();
        double double27 = categoryAxis7.getCategoryStart(10, 4, rectangle2D15, rectangleEdge26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = combinedRangeXYPlot31.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot29.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot31);
        java.awt.Paint paint35 = combinedRangeXYPlot29.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setInverted(true);
        combinedRangeXYPlot29.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.previous();
        java.util.Date date44 = day42.getEnd();
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        textTitle45.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = textTitle45.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle45.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot51 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = combinedRangeXYPlot51.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = combinedRangeXYPlot51.getDomainAxisEdge();
        boolean boolean55 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge54);
        double double56 = dateAxis38.dateToJava2D(date44, rectangle2D49, rectangleEdge54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot58 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis57);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot60 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis59);
        org.jfree.chart.axis.AxisLocation axisLocation62 = combinedRangeXYPlot60.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot58.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot60);
        java.awt.Paint paint64 = combinedRangeXYPlot58.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("");
        dateAxis67.setInverted(true);
        combinedRangeXYPlot58.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis67);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
        java.util.Date date73 = day71.getEnd();
        org.jfree.chart.title.TextTitle textTitle74 = new org.jfree.chart.title.TextTitle();
        textTitle74.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment77 = textTitle74.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D78 = textTitle74.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis79 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot80 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = combinedRangeXYPlot80.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = combinedRangeXYPlot80.getDomainAxisEdge();
        boolean boolean84 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge83);
        double double85 = dateAxis67.dateToJava2D(date73, rectangle2D78, rectangleEdge83);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo86 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = chartRenderingInfo86.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo88 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo89 = chartRenderingInfo88.getPlotInfo();
        plotRenderingInfo87.addSubplotInfo(plotRenderingInfo89);
        try {
            org.jfree.chart.axis.AxisState axisState91 = categoryAxis0.draw(graphics2D5, (double) 43629L, rectangle2D15, rectangle2D49, rectangleEdge83, plotRenderingInfo87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(horizontalAlignment77);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(plotRenderingInfo87);
        org.junit.Assert.assertNotNull(plotRenderingInfo89);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(10);
        pieLabelDistributor1.distributeLabels(0.0d, 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.awt.Paint paint9 = null;
        combinedRangeXYPlot1.setBackgroundPaint(paint9);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            combinedRangeXYPlot1.addAnnotation(xYAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 100, 0.0d, (double) (byte) -1, (double) 10700L, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint2 = ringPlot0.getOutlinePaint();
        java.awt.Color color3 = java.awt.Color.GRAY;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape11 = xYStepAreaRenderer7.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle13.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape11, (org.jfree.chart.title.Title) textTitle13, "Combined Range XYPlot");
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        ringPlot0.setLegendItemShape(shape11);
        java.awt.Stroke stroke24 = ringPlot0.getBaseSectionOutlineStroke();
        double double25 = ringPlot0.getStartAngle();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset2 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset2.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset2, (java.lang.Comparable) 1.0f);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset8 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset8.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot15.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot13.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15);
        java.awt.Paint paint19 = combinedRangeXYPlot13.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        dateAxis22.setInverted(true);
        combinedRangeXYPlot13.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        java.util.Date date28 = day26.getEnd();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        textTitle29.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = textTitle29.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle29.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot35.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = combinedRangeXYPlot35.getDomainAxisEdge();
        boolean boolean39 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge38);
        double double40 = dateAxis22.dateToJava2D(date28, rectangle2D33, rectangleEdge38);
        try {
            java.lang.String str41 = standardPieSectionLabelGenerator0.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset8, (java.lang.Comparable) date28);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: Thu Jun 13 23:59:59 PDT 2019");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(attributedString7);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.Plot plot46 = dateAxis40.getPlot();
        dateAxis40.setInverted(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(plot46);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator12, xYURLGenerator13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer14.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color20 = java.awt.Color.RED;
        xYStepAreaRenderer14.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color20, false);
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color20);
        java.awt.Paint paint24 = categoryAxis10.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint24, stroke29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker30, layer31);
        java.awt.Stroke stroke33 = null;
        valueMarker30.setOutlineStroke(stroke33);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        legendItemEntity6.setSeriesKey((java.lang.Comparable) 255);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) '#');
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        long long5 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61062825600000L) + "'", long5 == (-61062825600000L));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("hi!", font3, (java.awt.Paint) color4);
        xYAreaRenderer1.setBaseFillPaint((java.awt.Paint) color4, false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer10.setAutoPopulateSeriesPaint(true);
        double double13 = xYAreaRenderer10.getItemLabelAnchorOffset();
        boolean boolean14 = xYAreaRenderer10.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = combinedRangeXYPlot19.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot17.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot17.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator28, xYURLGenerator29);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = xYStepAreaRenderer30.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color36 = java.awt.Color.RED;
        xYStepAreaRenderer30.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color36, false);
        categoryAxis26.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint40 = categoryAxis26.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis41);
        org.jfree.chart.axis.AxisLocation axisLocation44 = combinedRangeXYPlot42.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke45 = combinedRangeXYPlot42.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint40, stroke45);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = combinedRangeXYPlot17.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker46, layer47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.awt.Paint paint53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke54 = null;
        xYAreaRenderer10.drawRangeLine(graphics2D15, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D51, (double) 60000L, paint53, stroke54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        xYAreaRenderer1.drawDomainGridLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D56, (double) (short) -1);
        java.awt.Font font59 = dateAxis50.getTickLabelFont();
        org.jfree.chart.plot.PolarPlot polarPlot60 = new org.jfree.chart.plot.PolarPlot();
        polarPlot60.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.data.Range range64 = polarPlot60.getDataRange(valueAxis63);
        java.awt.Stroke stroke65 = polarPlot60.getRadiusGridlineStroke();
        dateAxis50.setTickMarkStroke(stroke65);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = labelBlock3.getTextAnchor();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint1.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setRangePannable(true);
        java.awt.Stroke stroke7 = combinedRangeXYPlot1.getDomainZeroBaselineStroke();
        java.awt.Paint paint8 = combinedRangeXYPlot1.getRangeCrosshairPaint();
        combinedRangeXYPlot1.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer0.getLegendItem(6, (int) (byte) -1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator((int) (short) 10, xYItemLabelGenerator9);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape16 = xYStepAreaRenderer12.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.clone(shape16);
        xYAreaRenderer0.setLegendArea(shape17);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Paint paint14 = xYAreaRenderer10.getItemLabelPaint(1, 100, false);
        combinedRangeXYPlot1.setDomainMinorGridlinePaint(paint14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            combinedRangeXYPlot1.drawOutline(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 2.0f, "^-0.0", true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears(12, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.getAttributedLabel(100);
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNull(attributedString4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        java.util.List list5 = combinedRangeXYPlot1.getAnnotations();
        java.awt.Paint paint6 = combinedRangeXYPlot1.getDomainMinorGridlinePaint();
        try {
            java.awt.Paint paint8 = combinedRangeXYPlot1.getQuadrantPaint(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (15) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getMaximumExplodePercent();
        java.awt.Paint paint4 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setOuterSeparatorExtension((double) (-1));
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean4 = segmentedTimeline3.getAdjustForDaylightSaving();
        int int5 = segmentedTimeline3.getSegmentsIncluded();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.visible = true;
        boolean boolean9 = textTitle6.isVisible();
        textTitle6.setExpandToFitSpace(false);
        org.jfree.chart.entity.TitleEntity titleEntity13 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle6, "java.awt.Color[r=255,g=0,b=0]");
        java.lang.Object obj14 = titleEntity13.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getDataArea();
        titleEntity13.setArea((java.awt.Shape) rectangle2D17);
        java.awt.Shape shape19 = titleEntity13.getArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, rectangleAnchor20, (double) (short) -1, (double) 'a');
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        int int6 = xYStepAreaRenderer1.getPassCount();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepAreaRenderer1.getSeriesItemLabelGenerator((int) (byte) 10);
        xYStepAreaRenderer1.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.LEFT", graphics2D1, (float) 1L, (float) 9999, 0.5d, 0.0f, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYStepAreaRenderer3.getPositiveItemLabelPosition(30, 11, false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        boolean boolean3 = ringPlot0.getAutoPopulateSectionPaint();
        double double4 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5, "", "hi!");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        boolean boolean12 = day10.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day10);
        java.awt.Paint paint14 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) day10);
        boolean boolean15 = ringPlot0.getSectionOutlinesVisible();
        boolean boolean16 = ringPlot0.getSectionOutlinesVisible();
        java.awt.Image image17 = null;
        ringPlot0.setBackgroundImage(image17);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        boolean boolean3 = ringPlot0.getAutoPopulateSectionPaint();
        double double4 = ringPlot0.getInnerSeparatorExtension();
        double double5 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = ringPlot0.getLabelDistributor();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color9 = java.awt.Color.RED;
        xYStepAreaRenderer3.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color9, false);
        boolean boolean12 = xYStepAreaRenderer3.getPlotArea();
        java.awt.Shape shape14 = null;
        xYStepAreaRenderer3.setSeriesShape((int) '4', shape14);
        java.awt.Shape shape19 = xYStepAreaRenderer3.getItemShape(0, (int) (byte) 100, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = combinedRangeXYPlot21.getDomainAxisForDataset(0);
        java.awt.Paint paint24 = combinedRangeXYPlot21.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement26 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot21, (org.jfree.chart.block.Arrangement) columnArrangement25, (org.jfree.chart.block.Arrangement) borderArrangement26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendTitle27.getLegendItemGraphicLocation();
        org.jfree.chart.entity.TitleEntity titleEntity30 = new org.jfree.chart.entity.TitleEntity(shape19, (org.jfree.chart.title.Title) legendTitle27, "ERROR : Relative To String");
        java.lang.String str31 = titleEntity30.getShapeCoords();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-3,-3,3,3" + "'", str31.equals("-3,-3,3,3"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot6.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot6.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        combinedRangeXYPlot1.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline19 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean22 = segmentedTimeline19.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list23 = segmentedTimeline19.getExceptionSegments();
        try {
            combinedRangeXYPlot1.mapDatasetToDomainAxes((int) (byte) -1, list23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setText("ERROR : Relative To String");
        java.lang.String str3 = textTitle0.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle0.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, (double) 0.5f, (double) 11);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("index.html", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        double double5 = ringPlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot4.getDomainAxisForDataset(0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainMinorGridlineStroke();
        waferMapPlot1.setOutlineStroke(stroke7);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TimePeriodAnchor.END", "", "", "index.html");
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean6 = segmentedTimeline3.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list7 = segmentedTimeline3.getExceptionSegments();
        long long9 = segmentedTimeline3.toTimelineValue((long) (short) 100);
        segmentedTimeline3.addException((long) 9, (long) 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        java.util.List list2 = projectInfo0.getContributors();
//        projectInfo0.setLicenceText("{0}");
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
//        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot6.getDomainAxisLocation((int) (byte) 0);
//        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getDomainGridlineStroke();
//        java.util.List list10 = combinedRangeXYPlot6.getAnnotations();
//        projectInfo0.setContributors(list10);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(axisLocation8);
//        org.junit.Assert.assertNotNull(stroke9);
//        org.junit.Assert.assertNotNull(list10);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        java.lang.Object obj9 = legendGraphic8.clone();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 13, (float) (short) 10);
        legendGraphic8.setLine(shape12);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) '#');
        int int3 = month2.getMonth();
        long long4 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61049779200000L) + "'", long4 == (-61049779200000L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.text.DateFormat dateFormat1 = standardXYToolTipGenerator0.getYDateFormat();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNull(dateFormat1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0.5f, font4);
        double double8 = categoryAxis0.getLabelAngle();
        java.awt.Font font10 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0, font10);
        int int12 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = ringPlot13.getToolTipGenerator();
        java.lang.Object obj15 = ringPlot13.clone();
        boolean boolean16 = ringPlot13.getAutoPopulateSectionPaint();
        double double17 = ringPlot13.getInnerSeparatorExtension();
        double double18 = ringPlot13.getOuterSeparatorExtension();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot13.setSeparatorStroke(stroke19);
        categoryAxis0.setAxisLineStroke(stroke19);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        float float24 = combinedRangeXYPlot23.getBackgroundAlpha();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = combinedRangeXYPlot27.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = combinedRangeXYPlot27.getDomainAxisEdge();
        boolean boolean31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace33 = categoryAxis0.reserveSpace(graphics2D22, (org.jfree.chart.plot.Plot) combinedRangeXYPlot23, rectangle2D25, rectangleEdge30, axisSpace32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(pieToolTipGenerator14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj8 = xYStepAreaRenderer3.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis9.setPlot((org.jfree.chart.plot.Plot) waferMapPlot10);
        xYStepAreaRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot10);
        xYStepAreaRenderer3.setSeriesItemLabelsVisible((int) '4', false);
        xYStepAreaRenderer3.setShapesFilled(true);
        xYStepAreaRenderer3.setAutoPopulateSeriesPaint(true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.GRAY;
        xYStepAreaRenderer3.setBaseOutlinePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYStepAreaRenderer3.setSeriesOutlineStroke(12, stroke23, false);
        xYStepAreaRenderer3.setBaseSeriesVisible(false);
        xYStepAreaRenderer3.setDefaultEntityRadius((int) 'a');
        boolean boolean30 = xYStepAreaRenderer3.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        boolean boolean3 = categoryAxis0.isAxisLineVisible();
        java.awt.Paint paint4 = categoryAxis0.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets((double) 'a', (double) 'a', (double) (byte) 1, (double) (byte) 100);
        categoryAxis0.setLabelInsets(rectangleInsets9, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        boolean boolean3 = textTitle0.isVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth(0.0d);
        org.jfree.chart.util.Size2D size2D10 = blockContainer5.arrange(graphics2D6, rectangleConstraint9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle0.arrange(graphics2D4, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint2);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape9 = xYStepAreaRenderer5.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        java.awt.Color color11 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic12 = new org.jfree.chart.title.LegendGraphic(shape9, (java.awt.Paint) color11);
        java.lang.Object obj13 = legendGraphic12.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = legendGraphic12.getFillPaintTransformer();
        intervalMarker3.setGradientPaintTransformer(gradientPaintTransformer14);
        double double16 = intervalMarker3.getEndValue();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.GRAY;
        xYStepAreaRenderer3.setBaseOutlinePaint((java.awt.Paint) color20);
        java.awt.Paint paint23 = xYStepAreaRenderer3.getLegendTextPaint(64);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 2958465, (org.jfree.data.KeyedValues) defaultPieDataset1);
        org.junit.Assert.assertNotNull(categoryDataset2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) '#');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj3 = xYDataItem2.clone();
        double double4 = xYDataItem2.getXValue();
        xYDataItem2.setY((java.lang.Number) 60000L);
        java.lang.Number number7 = xYDataItem2.getX();
        double[][] doubleArray10 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "JFreeChart", doubleArray10);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset11);
        int int13 = xYDataItem2.compareTo((java.lang.Object) categoryDataset11);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean6 = segmentedTimeline3.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list7 = segmentedTimeline3.getExceptionSegments();
        long long9 = segmentedTimeline3.toTimelineValue((long) (short) 100);
        java.util.Date date11 = segmentedTimeline3.getDate((long) 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        dateAxis48.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) xYAreaRenderer2);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        boolean boolean10 = day8.equals((java.lang.Object) (byte) 1);
        boolean boolean11 = standardXYSeriesLabelGenerator6.equals((java.lang.Object) boolean10);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        java.util.List list5 = combinedRangeXYPlot1.getAnnotations();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer7);
        java.awt.Font font9 = xYAreaRenderer7.getBaseItemLabelFont();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color13 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("hi!", font12, (java.awt.Paint) color13);
        xYAreaRenderer7.setSeriesPaint(2958465, (java.awt.Paint) color13);
        combinedRangeXYPlot1.setRangeTickBandPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator18 = ringPlot17.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor19 = ringPlot17.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = null;
        ringPlot17.setLegendLabelToolTipGenerator(pieSectionLabelGenerator20);
        java.awt.Paint paint22 = ringPlot17.getLabelShadowPaint();
        combinedRangeXYPlot1.setRangeMinorGridlinePaint(paint22);
        float float24 = combinedRangeXYPlot1.getForegroundAlpha();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day26, "", "hi!");
        timeSeries30.setMaximumItemCount(3);
        java.util.List list33 = timeSeries30.getItems();
        try {
            combinedRangeXYPlot1.mapDatasetToDomainAxes((-457), list33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(pieToolTipGenerator18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        java.util.List list5 = combinedRangeXYPlot1.getAnnotations();
        java.awt.Paint paint6 = combinedRangeXYPlot1.getDomainMinorGridlinePaint();
        boolean boolean7 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        combinedRangeXYPlot1.setWeight(10);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer6.getBaseNegativeItemLabelPosition();
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition7);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.util.Collection collection10 = xYAreaRenderer0.getAnnotations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        chartRenderingInfo0.clear();
        org.jfree.chart.RenderingSource renderingSource2 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible(2);
        boolean boolean5 = xYStepRenderer2.getBaseShapesVisible();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock8.setWidth((double) (byte) -1);
        java.lang.String str11 = labelBlock8.getToolTipText();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("hi!", font15, (java.awt.Paint) color16);
        xYAreaRenderer13.setBaseFillPaint((java.awt.Paint) color16, false);
        int int20 = color16.getGreen();
        labelBlock8.setPaint((java.awt.Paint) color16);
        xYStepRenderer2.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color16, false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        textTitle3.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo9.getDataArea();
        textTitle3.draw(graphics2D7, rectangle2D10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle13.getBounds();
        textTitle3.draw(graphics2D12, rectangle2D17);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator21 = ringPlot20.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = ringPlot20.getLabelDistributor();
        double double23 = ringPlot20.getMaximumExplodePercent();
        java.awt.Paint paint24 = ringPlot20.getLabelBackgroundPaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = combinedRangeXYPlot28.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot26.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot28);
        java.awt.Stroke stroke32 = combinedRangeXYPlot28.getDomainZeroBaselineStroke();
        try {
            barRenderer3D0.drawDomainLine(graphics2D1, categoryPlot2, rectangle2D17, 0.0d, paint24, stroke32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNull(pieToolTipGenerator21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.removeAgedItems((long) 'a', true);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.lang.Number number14 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate(regularTimePeriod13, number14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = combinedRangeXYPlot19.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot17.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot17.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset23);
        java.lang.Object obj25 = defaultXYDataset23.clone();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset23, valueAxis26, polarItemRenderer27);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset29 = new org.jfree.data.xy.DefaultXYDataset();
        polarPlot28.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset29);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
        polarPlot28.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot35.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = combinedRangeXYPlot35.getLegendItems();
        java.awt.Image image39 = null;
        combinedRangeXYPlot35.setBackgroundImage(image39);
        boolean boolean41 = numberTickUnit32.equals((java.lang.Object) combinedRangeXYPlot35);
        timeSeries4.setKey((java.lang.Comparable) boolean41);
        try {
            org.jfree.data.time.TimeSeries timeSeries45 = timeSeries4.createCopy(9, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        segmentedTimeline3.addException((long) 2, 10L);
        long long7 = segmentedTimeline3.getSegmentsGroupSize();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        projectInfo8.setCopyright("java.awt.Color[r=255,g=0,b=0]");
        java.util.List list11 = projectInfo8.getContributors();
        segmentedTimeline3.setExceptionSegments(list11);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10700L + "'", long7 == 10700L);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        textTitle7.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle7.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle7.draw(graphics2D11, rectangle2D12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle7, "Combined Range XYPlot");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle16, "Combined Range XYPlot", "java.awt.Color[r=255,g=0,b=0]");
        java.lang.String str20 = titleEntity19.getShapeType();
        org.jfree.chart.title.Title title21 = titleEntity19.getTitle();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertNotNull(title21);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 10, 0);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "", "hi!");
        timeSeries8.setMaximumItemCount(3);
        java.util.List list11 = timeSeries8.getItems();
        segmentedTimeline3.addExceptions(list11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "", "hi!");
        timeSeries17.setMaximumItemCount(3);
        java.util.List list20 = timeSeries17.getItems();
        segmentedTimeline3.setExceptionSegments(list20);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        boolean boolean2 = xYAreaRenderer1.getPlotLines();
        java.awt.Stroke stroke4 = xYAreaRenderer1.getSeriesOutlineStroke(6);
        java.awt.Paint paint5 = xYAreaRenderer1.getBaseItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setInverted(true);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        dateAxis1.pan((double) 13);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem3 = xYSeries1.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle9.getHorizontalAlignment();
        blockContainer8.add((org.jfree.chart.block.Block) textTitle9);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange();
        double double17 = dateRange16.getLength();
        double double18 = dateRange16.getLowerBound();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange();
        double double20 = dateRange19.getLength();
        double double21 = dateRange19.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange16, (org.jfree.data.Range) dateRange19);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange24, lengthConstraintType25, (double) 12, (org.jfree.data.Range) dateRange27, lengthConstraintType28);
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange32, lengthConstraintType33, (double) 12, (org.jfree.data.Range) dateRange35, lengthConstraintType36);
        org.jfree.data.Range range39 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange35, (double) 12);
        org.jfree.data.time.DateRange dateRange41 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange44 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType45 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange41, lengthConstraintType42, (double) 12, (org.jfree.data.Range) dateRange44, lengthConstraintType45);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator47 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator48 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer49 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator47, xYURLGenerator48);
        xYStepRenderer49.setSeriesShapesVisible((int) (byte) 10, false);
        xYStepRenderer49.setBaseLinesVisible(true);
        double double55 = xYStepRenderer49.getItemLabelAnchorOffset();
        java.awt.Shape shape56 = xYStepRenderer49.getLegendLine();
        boolean boolean57 = lengthConstraintType45.equals((java.lang.Object) xYStepRenderer49);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, (org.jfree.data.Range) dateRange19, lengthConstraintType25, (double) 2.0f, (org.jfree.data.Range) dateRange35, lengthConstraintType45);
        try {
            org.jfree.chart.util.Size2D size2D59 = columnArrangement5.arrange(blockContainer8, graphics2D14, rectangleConstraint58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertNotNull(lengthConstraintType45);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setDomainAxis(100, valueAxis3, true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot15.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17);
        java.awt.geom.Point2D point2D21 = combinedRangeXYPlot17.getQuadrantOrigin();
        combinedRangeXYPlot7.zoomRangeAxes((double) 43629L, (double) (short) 100, plotRenderingInfo13, point2D21);
        combinedRangeXYPlot1.setQuadrantOrigin(point2D21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.configure();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color29 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("hi!", font28, (java.awt.Paint) color29);
        categoryAxis24.setTickLabelFont((java.lang.Comparable) 0.5f, font28);
        double double32 = categoryAxis24.getLabelAngle();
        java.awt.Font font34 = null;
        categoryAxis24.setTickLabelFont((java.lang.Comparable) 0, font34);
        int int36 = categoryAxis24.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator38 = ringPlot37.getToolTipGenerator();
        java.lang.Object obj39 = ringPlot37.clone();
        boolean boolean40 = ringPlot37.getAutoPopulateSectionPaint();
        double double41 = ringPlot37.getInnerSeparatorExtension();
        double double42 = ringPlot37.getOuterSeparatorExtension();
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot37.setSeparatorStroke(stroke43);
        categoryAxis24.setAxisLineStroke(stroke43);
        combinedRangeXYPlot1.setDomainGridlineStroke(stroke43);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNull(pieToolTipGenerator38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.2d + "'", double41 == 0.2d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.2d + "'", double42 == 0.2d);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.util.List list2 = projectInfo0.getContributors();
        projectInfo0.setLicenceText("{0}");
        projectInfo0.setVersion("rect");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        textTitle15.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle15.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo21.getDataArea();
        textTitle15.draw(graphics2D19, rectangle2D22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        textTitle25.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = textTitle25.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle25.getBounds();
        textTitle15.draw(graphics2D24, rectangle2D29);
        try {
            barRenderer3D0.drawDomainGridline(graphics2D13, categoryPlot14, rectangle2D29, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.awt.Paint paint7 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        dateAxis10.setInverted(true);
        combinedRangeXYPlot1.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        combinedRangeXYPlot1.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedRangeXYPlot1.getRenderer(0);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(xYItemRenderer17);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart10.getXYPlot();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator15 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer18);
        boolean boolean20 = textAnchor16.equals((java.lang.Object) xYAreaRenderer18);
        boolean boolean21 = standardXYURLGenerator15.equals((java.lang.Object) textAnchor16);
        try {
            jFreeChart10.setTextAntiAlias((java.lang.Object) textAnchor16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TextAnchor.BOTTOM_CENTER incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 100L, (double) 2, (double) (-457));
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter3);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat6 = standardPieSectionLabelGenerator5.getPercentFormat();
        java.text.AttributedString attributedString8 = standardPieSectionLabelGenerator5.getAttributedLabel(100);
        boolean boolean9 = gradientXYBarPainter3.equals((java.lang.Object) 100);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot13.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot11.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13);
        boolean boolean17 = gradientXYBarPainter3.equals((java.lang.Object) combinedRangeXYPlot13);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNull(attributedString8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        long long5 = segmentedTimeline3.toMillisecond((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint2 = ringPlot0.getOutlinePaint();
        try {
            ringPlot0.setInteriorGap((double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (2.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getHorizontalAlignment();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle1);
        blockContainer0.clear();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(arrangement7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        segmentedTimeline3.addException((long) 2, 10L);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine();
        boolean boolean8 = segmentedTimeline3.equals((java.lang.Object) textLine7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean6 = segmentedTimeline3.containsDomainRange((long) '4', (long) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke11 = combinedRangeXYPlot8.getDomainGridlineStroke();
        java.util.List list12 = combinedRangeXYPlot8.getAnnotations();
        segmentedTimeline3.addExceptions(list12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean20 = segmentedTimeline17.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list21 = segmentedTimeline17.getExceptionSegments();
        long long23 = segmentedTimeline17.toTimelineValue((long) (short) 100);
        boolean boolean24 = segmentedTimeline3.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        java.awt.Paint paint6 = xYAreaRenderer0.getItemLabelPaint(15, 2, false);
        xYAreaRenderer0.setUseFillPaint(false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        try {
            dateAxis48.setAutoRangeMinimumSize((-1.0d), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        textTitle14.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle14.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo20.getDataArea();
        textTitle14.draw(graphics2D18, rectangle2D21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        textTitle24.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = textTitle24.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle24.getBounds();
        textTitle14.draw(graphics2D23, rectangle2D28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = null;
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator33 = ringPlot32.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor34 = ringPlot32.getLabelDistributor();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator38 = ringPlot37.getToolTipGenerator();
        java.awt.Paint paint39 = ringPlot37.getOutlinePaint();
        java.awt.Color color40 = java.awt.Color.GRAY;
        ringPlot37.setBaseSectionPaint((java.awt.Paint) color40);
        org.jfree.chart.util.Rotation rotation42 = ringPlot37.getDirection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState46 = ringPlot32.initialise(graphics2D35, rectangle2D36, (org.jfree.chart.plot.PiePlot) ringPlot37, (java.lang.Integer) 0, plotRenderingInfo45);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState47 = barRenderer3D0.initialise(graphics2D13, rectangle2D28, categoryPlot30, 0, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNull(pieToolTipGenerator33);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor34);
        org.junit.Assert.assertNull(pieToolTipGenerator38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rotation42);
        org.junit.Assert.assertNotNull(plotRenderingInfo45);
        org.junit.Assert.assertNotNull(piePlotState46);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        boolean boolean4 = lineBorder2.equals((java.lang.Object) "JFreeChart");
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        boolean boolean6 = lineBorder2.equals((java.lang.Object) size2D5);
        org.jfree.chart.util.Size2D size2D7 = rectangleConstraint1.calculateConstrainedSize(size2D5);
        java.lang.String str8 = size2D5.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str8.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        legendItemEntity6.setSeriesKey((java.lang.Comparable) (-2236514));
        java.lang.Object obj9 = legendItemEntity6.clone();
        legendItemEntity6.setSeriesKey((java.lang.Comparable) 11);
        java.lang.String str12 = legendItemEntity6.toString();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LegendItemEntity: seriesKey=11, dataset=null" + "'", str12.equals("LegendItemEntity: seriesKey=11, dataset=null"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer6.getBaseNegativeItemLabelPosition();
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        boolean boolean11 = itemLabelPosition7.equals((java.lang.Object) combinedRangeXYPlot10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str13 = seriesRenderingOrder12.toString();
        combinedRangeXYPlot10.setSeriesRenderingOrder(seriesRenderingOrder12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setInverted(true);
        dateAxis16.setMinorTickMarkOutsideLength(0.0f);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange();
        double double23 = dateRange22.getLength();
        double double24 = dateRange22.getLowerBound();
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange22);
        boolean boolean26 = layer21.equals((java.lang.Object) dateRange25);
        dateAxis16.setRangeWithMargins((org.jfree.data.Range) dateRange25, true, false);
        boolean boolean30 = seriesRenderingOrder12.equals((java.lang.Object) dateAxis16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str13.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isVisible();
        java.lang.String str2 = categoryAxis0.getLabelURL();
        categoryAxis0.setTickMarksVisible(true);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(6, (int) '#');
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 6, "index.html");
        float float10 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setInverted(true);
        dateAxis1.setMinorTickMarkOutsideLength(0.0f);
        java.lang.Object obj6 = dateAxis1.clone();
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat4.setParseIntegerOnly(true);
        boolean boolean8 = logFormat4.equals((java.lang.Object) 2);
        java.lang.String str10 = logFormat4.format(10L);
        java.lang.Object obj11 = null;
        boolean boolean12 = logFormat4.equals(obj11);
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat4, dateFormat13);
        java.lang.String str15 = standardXYToolTipGenerator14.getFormatString();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "^-0.0" + "'", str10.equals("^-0.0"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Combined Range XYPlot" + "'", str15.equals("Combined Range XYPlot"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator12, xYURLGenerator13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer14.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color20 = java.awt.Color.RED;
        xYStepAreaRenderer14.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color20, false);
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color20);
        java.awt.Paint paint24 = categoryAxis10.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint24, stroke29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker30, layer31);
        java.awt.Paint paint33 = valueMarker30.getLabelPaint();
        java.lang.Object obj34 = valueMarker30.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker30.setLabelAnchor(rectangleAnchor35);
        java.lang.String str37 = rectangleAnchor35.toString();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleAnchor.LEFT" + "'", str37.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer2.setAutoPopulateSeriesPaint(true);
        double double5 = xYAreaRenderer2.getItemLabelAnchorOffset();
        java.awt.Font font9 = xYAreaRenderer2.getItemLabelFont(0, 3, true);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("RectangleAnchor.LEFT", font9);
        org.jfree.chart.plot.Plot plot11 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("RectangleAnchor.LEFT", font9, plot11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape10 = xYStepAreaRenderer6.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color12);
        java.lang.Object obj14 = legendGraphic13.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendGraphic13.getFillPaintTransformer();
        intervalMarker4.setGradientPaintTransformer(gradientPaintTransformer15);
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer15);
        double double18 = xYBarRenderer0.getBarAlignmentFactor();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setCopyright("java.awt.Color[r=255,g=0,b=0]");
        java.lang.String str3 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str3.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SeriesRenderingOrder.FORWARD");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, 0.0d, (float) 1, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        combinedRangeXYPlot1.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color22 = java.awt.Color.RED;
        xYStepAreaRenderer16.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color22, false);
        categoryAxis12.setTickLabelPaint((java.awt.Paint) color22);
        java.awt.Paint paint26 = categoryAxis12.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = combinedRangeXYPlot28.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke31 = combinedRangeXYPlot28.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint26, stroke31);
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker32, layer33);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        double double41 = dateRange40.getLength();
        double double42 = dateRange40.getLowerBound();
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange40);
        boolean boolean44 = layer39.equals((java.lang.Object) dateRange43);
        combinedRangeXYPlot1.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38, layer39);
        intervalMarker38.setEndValue(0.05d);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.visible = true;
        boolean boolean9 = textTitle6.isVisible();
        textTitle6.setExpandToFitSpace(false);
        org.jfree.chart.entity.TitleEntity titleEntity13 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle6, "java.awt.Color[r=255,g=0,b=0]");
        java.lang.String str14 = titleEntity13.getShapeType();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "rect" + "'", str14.equals("rect"));
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
//        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator3, xYURLGenerator4);
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition(0, (int) 'a', false);
//        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
//        xYStepAreaRenderer5.setBaseToolTipGenerator(xYToolTipGenerator10, false);
//        boolean boolean13 = day0.equals((java.lang.Object) xYToolTipGenerator10);
//        int int14 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(itemLabelPosition9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("100");
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        java.util.List list14 = jFreeChart10.getSubtitles();
        java.awt.RenderingHints renderingHints15 = null;
        try {
            jFreeChart10.setRenderingHints(renderingHints15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        ringPlot0.setLabelGap((double) 1L);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        java.lang.String str1 = timePeriodAnchor0.toString();
        java.lang.String str2 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.END" + "'", str1.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TimePeriodAnchor.END" + "'", str2.equals("TimePeriodAnchor.END"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(10.0d, 100.0d, (double) 9223372036854775807L, (double) (byte) 0);
        double double5 = rectangleInsets4.getRight();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.setRangeAxisLocation((int) ' ', axisLocation9);
        combinedRangeXYPlot1.configureDomainAxes();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange();
        double double15 = dateRange14.getLength();
        double double16 = dateRange14.getLowerBound();
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange14);
        boolean boolean18 = layer13.equals((java.lang.Object) dateRange17);
        java.util.Collection collection19 = combinedRangeXYPlot1.getDomainMarkers(255, layer13);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot3.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset9 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot3.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str14 = projectInfo13.getLicenceText();
        java.util.List list15 = projectInfo13.getContributors();
        combinedRangeXYPlot3.drawRangeTickBands(graphics2D11, rectangle2D12, list15);
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        java.awt.Image image18 = combinedRangeXYPlot1.getBackgroundImage();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(projectInfo13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(image18);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator12, xYURLGenerator13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer14.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color20 = java.awt.Color.RED;
        xYStepAreaRenderer14.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color20, false);
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color20);
        java.awt.Paint paint24 = categoryAxis10.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint24, stroke29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker30, layer31);
        java.awt.geom.GeneralPath generalPath33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.configure();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        textTitle38.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = textTitle38.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle38.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis43);
        org.jfree.chart.axis.ValueAxis valueAxis46 = combinedRangeXYPlot44.getDomainAxisForDataset(0);
        java.awt.Paint paint47 = combinedRangeXYPlot44.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement48 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement49 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot44, (org.jfree.chart.block.Arrangement) columnArrangement48, (org.jfree.chart.block.Arrangement) borderArrangement49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = legendTitle50.getItemLabelPadding();
        java.lang.Object obj52 = legendTitle50.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = legendTitle50.getLegendItemGraphicEdge();
        double double54 = categoryAxis34.getCategoryStart(10, 4, rectangle2D42, rectangleEdge53);
        org.jfree.chart.RenderingSource renderingSource55 = null;
        try {
            combinedRangeXYPlot1.select(generalPath33, rectangle2D42, renderingSource55);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: null");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesShapesVisible((int) (byte) 10, false);
        java.awt.Stroke stroke7 = null;
        xYStepRenderer2.setSeriesStroke((int) ' ', stroke7);
        java.awt.Shape shape12 = xYStepRenderer2.getItemShape(10, (int) ' ', false);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("PieLabelLinkStyle.QUAD_CURVE");
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str2.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.String str5 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str5.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("java.awt.Color[r=255,g=200,b=0]");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setText("ERROR : Relative To String");
        java.lang.String str3 = textTitle0.getURLText();
        textTitle0.setToolTipText("java.awt.Color[r=255,g=0,b=0]");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(13);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.removeAgedItems((long) 'a', true);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.lang.Number number14 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate(regularTimePeriod13, number14);
        int int16 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        java.lang.Object obj9 = legendGraphic8.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendGraphic8.getFillPaintTransformer();
        java.awt.Shape shape11 = legendGraphic8.getLine();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer9.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color15 = java.awt.Color.RED;
        xYStepAreaRenderer9.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color15, false);
        categoryAxis5.setTickLabelPaint((java.awt.Paint) color15);
        java.awt.Paint paint19 = categoryAxis5.getTickMarkPaint();
        ringPlot0.setLabelPaint(paint19);
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        double double23 = ringPlot22.getSectionDepth();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = combinedRangeXYPlot25.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke28 = combinedRangeXYPlot25.getDomainGridlineStroke();
        combinedRangeXYPlot25.setRangePannable(true);
        java.awt.Stroke stroke31 = combinedRangeXYPlot25.getDomainZeroBaselineStroke();
        ringPlot22.setLabelLinkStroke(stroke31);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 0.0f, stroke31);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        dateAxis40.setLowerMargin((double) 86400000L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.5f, (float) 6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Shape shape2 = multiplePiePlot1.getLegendItemShape();
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot3.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5);
        java.awt.Paint paint9 = combinedRangeXYPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        dateAxis12.setInverted(true);
        combinedRangeXYPlot3.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.util.TimeZone timeZone16 = dateAxis12.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone16);
        java.util.Locale locale18 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("Size2D[width=0.0, height=0.0]", timeZone16, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset0.validateObject();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo6.getDataArea();
        textTitle0.draw(graphics2D4, rectangle2D7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle10.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle10.getBounds();
        textTitle0.draw(graphics2D9, rectangle2D14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle0.getVerticalAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(verticalAlignment16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L, "RectangleAnchor.LEFT", "java.awt.Color[r=255,g=200,b=0]");
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        int int13 = barRenderer3D0.getColumnCount();
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator4, xYURLGenerator5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color12 = java.awt.Color.RED;
        xYStepAreaRenderer6.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color12, false);
        categoryAxis2.setTickLabelPaint((java.awt.Paint) color12);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color12);
        double[][] doubleArray19 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "JFreeChart", doubleArray19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset20);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset20, (-457));
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset20, false);
        multiplePiePlot1.setDataset(categoryDataset20);
        double[][] doubleArray29 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "JFreeChart", doubleArray29);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset30);
        org.jfree.data.general.PieDataset pieDataset33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset30, (-457));
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset30, false);
        multiplePiePlot1.setDataset(categoryDataset30);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(pieDataset33);
        org.junit.Assert.assertNull(range35);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        int int14 = chartProgressEvent13.getPercent();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("hi!", (-1), 30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        boolean boolean3 = ringPlot0.getLabelLinksVisible();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot6.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedRangeAxisSpace(axisSpace10, false);
        java.awt.Paint paint13 = combinedRangeXYPlot6.getDomainMinorGridlinePaint();
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) "RectangleAnchor.LEFT", paint13);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat16 = standardPieSectionLabelGenerator15.getPercentFormat();
        ringPlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator15);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(numberFormat16);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean3 = categoryAxis2.isVisible();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        polarPlot4.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = polarPlot4.getDataRange(valueAxis7);
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot4);
        java.awt.Paint paint10 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        combinedRangeXYPlot12.setDomainAxis(100, valueAxis14, true);
        java.awt.Stroke stroke17 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder(paint10, stroke17, rectangleInsets19);
        categoryAxis2.setLabelInsets(rectangleInsets19, false);
        double double24 = rectangleInsets19.calculateLeftOutset((double) (-1.0f));
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo26.getDataArea();
        rectangleInsets19.trim(rectangle2D27);
        boolean boolean29 = org.jfree.chart.util.ShapeUtilities.isPointInRect(0.0d, (double) (byte) 1, rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        dateAxis40.setUpperMargin((double) (short) 10);
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        dateAxis40.setLabelPaint(paint48);
        dateAxis40.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot3.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset9 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot3.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str14 = projectInfo13.getLicenceText();
        java.util.List list15 = projectInfo13.getContributors();
        combinedRangeXYPlot3.drawRangeTickBands(graphics2D11, rectangle2D12, list15);
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        try {
            combinedRangeXYPlot3.add(xYPlot18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(projectInfo13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = combinedRangeXYPlot53.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation56 = combinedRangeXYPlot53.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        combinedRangeXYPlot53.setFixedRangeAxisSpace(axisSpace57);
        combinedDomainXYPlot46.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot53, 100);
        boolean boolean61 = combinedDomainXYPlot46.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("1.2.0-pre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(100);
        java.lang.String str2 = serialDate1.getDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Stroke stroke3 = xYAreaRenderer1.getSeriesOutlineStroke(0);
        xYAreaRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer1.getSeriesPositiveItemLabelPosition(13);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator9 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator9);
        java.lang.Object obj11 = xYAreaRenderer1.clone();
        xYAreaRenderer1.setUseFillPaint(true);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4);
        boolean boolean6 = dateAxis1.isAutoRange();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange8, lengthConstraintType9, (double) 12, (org.jfree.data.Range) dateRange11, lengthConstraintType12);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.awt.Paint paint9 = null;
        combinedRangeXYPlot1.setBackgroundPaint(paint9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedRangeXYPlot1.getRenderer(1);
        java.awt.Paint paint13 = combinedRangeXYPlot1.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.setKey((java.lang.Comparable) 0);
        timeSeries4.removeAgedItems(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setRangePannable(true);
        java.awt.Stroke stroke7 = combinedRangeXYPlot1.getDomainZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = combinedRangeXYPlot1.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = combinedRangeXYPlot1.getAxisOffset();
        double double11 = rectangleInsets9.trimHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7.0d) + "'", double11 == (-7.0d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer3.initialise(graphics2D11, rectangle2D12, xYPlot13, xYDataset14, plotRenderingInfo15);
        java.awt.Paint paint18 = xYStepAreaRenderer3.getSeriesPaint((int) (short) 100);
        boolean boolean19 = xYStepAreaRenderer3.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.GRAY;
        xYStepAreaRenderer3.setBaseOutlinePaint((java.awt.Paint) color20);
        xYStepAreaRenderer3.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false, false);
        java.awt.Shape shape27 = xYStepAreaRenderer3.getSeriesShape((int) '#');
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(shape27);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection2 = chartRenderingInfo1.getEntityCollection();
        boolean boolean3 = datasetGroup0.equals((java.lang.Object) chartRenderingInfo1);
        org.junit.Assert.assertNotNull(entityCollection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.Plot plot46 = dateAxis40.getPlot();
        dateAxis40.setRangeWithMargins((double) 2.0f, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(plot46);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape10 = xYStepAreaRenderer6.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color12);
        java.lang.Object obj14 = legendGraphic13.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendGraphic13.getFillPaintTransformer();
        intervalMarker4.setGradientPaintTransformer(gradientPaintTransformer15);
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer15);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYBarRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(legendItemCollection18);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        chartRenderingInfo0.clear();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo0.getPlotInfo();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator4, xYURLGenerator5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj11 = xYStepAreaRenderer6.clone();
        boolean boolean12 = chartRenderingInfo0.equals(obj11);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("hi!", font3, (java.awt.Paint) color4);
        xYAreaRenderer1.setBaseFillPaint((java.awt.Paint) color4, false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer10.setAutoPopulateSeriesPaint(true);
        double double13 = xYAreaRenderer10.getItemLabelAnchorOffset();
        boolean boolean14 = xYAreaRenderer10.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = combinedRangeXYPlot19.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot17.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot17.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator28, xYURLGenerator29);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = xYStepAreaRenderer30.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color36 = java.awt.Color.RED;
        xYStepAreaRenderer30.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color36, false);
        categoryAxis26.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint40 = categoryAxis26.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis41);
        org.jfree.chart.axis.AxisLocation axisLocation44 = combinedRangeXYPlot42.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke45 = combinedRangeXYPlot42.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint40, stroke45);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = combinedRangeXYPlot17.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker46, layer47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.awt.Paint paint53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke54 = null;
        xYAreaRenderer10.drawRangeLine(graphics2D15, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D51, (double) 60000L, paint53, stroke54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        xYAreaRenderer1.drawDomainGridLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D56, (double) (short) -1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor59 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor60 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor59, textAnchor60);
        xYAreaRenderer1.setBaseNegativeItemLabelPosition(itemLabelPosition61, false);
        boolean boolean64 = xYAreaRenderer1.getPlotShapes();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(itemLabelAnchor59);
        org.junit.Assert.assertNotNull(textAnchor60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0.5f, font4);
        categoryAxis0.setCategoryMargin(116.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = ringPlot2.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = ringPlot2.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = ringPlot7.getToolTipGenerator();
        java.awt.Paint paint9 = ringPlot7.getOutlinePaint();
        java.awt.Color color10 = java.awt.Color.GRAY;
        ringPlot7.setBaseSectionPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Rotation rotation12 = ringPlot7.getDirection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState16 = ringPlot2.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) ringPlot7, (java.lang.Integer) 0, plotRenderingInfo15);
        ringPlot7.setLabelLinksVisible(false);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleAnchor.LEFT", (org.jfree.chart.plot.Plot) ringPlot7);
        boolean boolean20 = month0.equals((java.lang.Object) "RectangleAnchor.LEFT");
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertNotNull(piePlotState16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries4.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        barRenderer3D0.setDrawBarOutline(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator15);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.axis.Axis axis7 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity8 = new org.jfree.chart.entity.AxisEntity(shape5, axis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.addOrUpdate(xYDataItem4);
        xYSeries1.add((java.lang.Number) 5, (java.lang.Number) 86400000L);
        org.jfree.data.xy.XYDataItem xYDataItem15 = xYSeries1.addOrUpdate(0.0d, 12.0d);
        org.jfree.data.xy.XYDataItem xYDataItem16 = null;
        try {
            xYSeries1.add(xYDataItem16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNull(xYDataItem15);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = (short) -1;
        double double3 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot1.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.RenderingSource renderingSource9 = null;
        combinedRangeXYPlot1.select(100.0d, 0.0d, rectangle2D8, renderingSource9);
        java.awt.Stroke stroke11 = combinedRangeXYPlot1.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot16.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot14.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16);
        java.awt.Paint paint20 = combinedRangeXYPlot14.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setInverted(true);
        combinedRangeXYPlot14.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        java.util.Date date29 = day27.getEnd();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        textTitle30.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = textTitle30.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle30.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = combinedRangeXYPlot36.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = combinedRangeXYPlot36.getDomainAxisEdge();
        boolean boolean40 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge39);
        double double41 = dateAxis23.dateToJava2D(date29, rectangle2D34, rectangleEdge39);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis42);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        combinedRangeXYPlot43.setDomainAxis(100, valueAxis45, true);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot49 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis48);
        org.jfree.chart.axis.AxisLocation axisLocation51 = combinedRangeXYPlot49.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection52 = combinedRangeXYPlot49.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis56);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot59 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis58);
        org.jfree.chart.axis.AxisLocation axisLocation61 = combinedRangeXYPlot59.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot57.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot59);
        java.awt.geom.Point2D point2D63 = combinedRangeXYPlot59.getQuadrantOrigin();
        combinedRangeXYPlot49.zoomRangeAxes((double) 43629L, (double) (short) 100, plotRenderingInfo55, point2D63);
        combinedRangeXYPlot43.setQuadrantOrigin(point2D63);
        org.jfree.chart.plot.PlotState plotState66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        try {
            combinedRangeXYPlot1.draw(graphics2D12, rectangle2D34, point2D63, plotState66, plotRenderingInfo67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(legendItemCollection52);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(point2D63);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        double double3 = barRenderer3D0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        textTitle0.setExpandToFitSpace(true);
        java.awt.Paint paint6 = textTitle0.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle0.setTextAlignment(horizontalAlignment7);
        textTitle0.setPadding((double) (-61062825600000L), (double) 15, (double) 10.0f, (double) 1L);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYStepAreaRenderer4.setBaseToolTipGenerator(xYToolTipGenerator9, false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = xYStepAreaRenderer4.initialise(graphics2D12, rectangle2D13, xYPlot14, xYDataset15, plotRenderingInfo16);
        java.awt.Paint paint19 = xYStepAreaRenderer4.getSeriesPaint((int) (short) 100);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer4.setSeriesItemLabelFont((int) (short) 10, font21, false);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color24);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = labelBlock25.getContentAlignmentPoint();
        java.lang.String str27 = labelBlock25.getID();
        java.awt.Graphics2D graphics2D28 = null;
        try {
            org.jfree.chart.util.Size2D size2D29 = labelBlock25.arrange(graphics2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(xYItemRendererState17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer3.setSeriesItemLabelFont((int) '4', font5);
        java.awt.Paint paint7 = xYStepAreaRenderer3.getBasePaint();
        xYStepAreaRenderer3.setBaseCreateEntities(false);
        boolean boolean10 = xYStepAreaRenderer3.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape11 = xYStepAreaRenderer3.getBaseLegendShape();
        xYStepAreaRenderer3.setSeriesVisibleInLegend(100, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesLinesVisible((int) ' ', false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        boolean boolean8 = xYStepAreaRenderer7.getShapesVisible();
        java.awt.Shape shape9 = xYStepAreaRenderer7.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        xYStepRenderer2.setBaseShape(shape9, false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) (-1), Double.NaN, 2147483647, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemLineVisible(0, 3);
        xYLineAndShapeRenderer0.setBaseShapesFilled(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot3.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset9 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot3.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str14 = projectInfo13.getLicenceText();
        java.util.List list15 = projectInfo13.getContributors();
        combinedRangeXYPlot3.drawRangeTickBands(graphics2D11, rectangle2D12, list15);
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        java.awt.Paint paint18 = combinedRangeXYPlot1.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(projectInfo13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.lang.Object obj2 = combinedRangeXYPlot1.clone();
        int int3 = combinedRangeXYPlot1.getRendererCount();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke5 = combinedRangeXYPlot2.getDomainGridlineStroke();
        combinedRangeXYPlot2.setRangePannable(true);
        java.awt.Stroke stroke8 = combinedRangeXYPlot2.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        dateAxis10.centerRange((double) 'a');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape18 = xYStepAreaRenderer14.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        textTitle20.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle20.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        textTitle20.draw(graphics2D24, rectangle2D25);
        org.jfree.chart.entity.TitleEntity titleEntity28 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) textTitle20, "Combined Range XYPlot");
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity32 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) textTitle29, "Combined Range XYPlot", "java.awt.Color[r=255,g=0,b=0]");
        dateAxis10.setDownArrow(shape18);
        dateAxis10.setNegativeArrowVisible(false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { dateAxis10 };
        combinedRangeXYPlot2.setRangeAxes(valueAxisArray36);
        boolean boolean38 = rangeType0.equals((java.lang.Object) valueAxisArray36);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getMaximumExplodePercent();
        java.awt.Paint paint4 = ringPlot0.getLabelBackgroundPaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = ringPlot7.getToolTipGenerator();
        boolean boolean10 = ringPlot7.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape11 = ringPlot7.getLegendItemShape();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo15.getPlotInfo();
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo16);
        org.jfree.chart.plot.PiePlotState piePlotState18 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) ringPlot7, (java.lang.Integer) 4, plotRenderingInfo14);
        ringPlot0.setLabelGap((double) 10L);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertNotNull(piePlotState18);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.removeAgedItems((long) 'a', true);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "", "hi!");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean20 = day18.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator25, xYURLGenerator26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYStepAreaRenderer27.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator32 = null;
        xYStepAreaRenderer27.setBaseToolTipGenerator(xYToolTipGenerator32, false);
        boolean boolean35 = day22.equals((java.lang.Object) xYToolTipGenerator32);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) (byte) -1);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 2147483647, true);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean9 = axisLocation7.equals((java.lang.Object) paintArray8);
        combinedRangeXYPlot1.setRangeAxisLocation(axisLocation7, false);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        boolean boolean13 = axisLocation7.equals((java.lang.Object) color12);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = ringPlot1.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = ringPlot1.getLabelDistributor();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = ringPlot6.getToolTipGenerator();
        java.awt.Paint paint8 = ringPlot6.getOutlinePaint();
        java.awt.Color color9 = java.awt.Color.GRAY;
        ringPlot6.setBaseSectionPaint((java.awt.Paint) color9);
        org.jfree.chart.util.Rotation rotation11 = ringPlot6.getDirection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot1.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 0, plotRenderingInfo14);
        boolean boolean16 = booleanList0.equals((java.lang.Object) ringPlot6);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) '#', (double) 10700L, (double) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setNotify(false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot1.getDomainAxisLocation(100);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesShapesVisible((int) (byte) 10, false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer6.setAutoPopulateSeriesPaint(true);
        double double9 = xYAreaRenderer6.getItemLabelAnchorOffset();
        boolean boolean10 = xYAreaRenderer6.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot15.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot13.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot13.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator24, xYURLGenerator25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYStepAreaRenderer26.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color32 = java.awt.Color.RED;
        xYStepAreaRenderer26.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color32, false);
        categoryAxis22.setTickLabelPaint((java.awt.Paint) color32);
        java.awt.Paint paint36 = categoryAxis22.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = combinedRangeXYPlot38.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke41 = combinedRangeXYPlot38.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint36, stroke41);
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = combinedRangeXYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker42, layer43);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke50 = null;
        xYAreaRenderer6.drawRangeLine(graphics2D11, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis46, rectangle2D47, (double) 60000L, paint49, stroke50);
        dateAxis46.setUpperMargin((double) (short) 10);
        dateAxis46.setMinorTickCount((int) (short) 1);
        java.awt.Shape shape56 = dateAxis46.getUpArrow();
        org.jfree.chart.plot.RingPlot ringPlot57 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator58 = ringPlot57.getToolTipGenerator();
        boolean boolean60 = ringPlot57.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape61 = ringPlot57.getLegendItemShape();
        dateAxis46.setUpArrow(shape61);
        xYStepRenderer2.setBaseLegendShape(shape61);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNull(pieToolTipGenerator58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(shape61);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape20 = xYStepAreaRenderer16.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        textTitle21.visible = true;
        boolean boolean24 = textTitle21.isVisible();
        textTitle21.setExpandToFitSpace(false);
        org.jfree.chart.entity.TitleEntity titleEntity28 = new org.jfree.chart.entity.TitleEntity(shape20, (org.jfree.chart.title.Title) textTitle21, "java.awt.Color[r=255,g=0,b=0]");
        java.lang.Object obj29 = titleEntity28.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo31.getDataArea();
        titleEntity28.setArea((java.awt.Shape) rectangle2D32);
        try {
            jFreeChart10.draw(graphics2D14, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = shapeList0.equals((java.lang.Object) (byte) 100);
        java.awt.Shape shape4 = shapeList0.getShape(11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color11 = java.awt.Color.RED;
        xYStepAreaRenderer5.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color11, false);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color11);
        java.awt.Paint paint15 = categoryAxis1.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint15, stroke20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker21.setLabelOffsetType(lengthAdjustmentType22);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.Object obj0 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset1 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getDomainGridlineStroke();
        combinedRangeXYPlot5.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset1, jFreeChart11, (int) ' ', 9999);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart11.getTitle();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = rendererChangeEvent17.getType();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart11, chartChangeEventType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(textTitle15);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint2 = ringPlot0.getOutlinePaint();
        java.awt.Color color3 = java.awt.Color.GRAY;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        double double6 = ringPlot0.getShadowXOffset();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.lang.Object obj9 = defaultXYDataset7.clone();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset7, valueAxis10, polarItemRenderer11);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        polarPlot12.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
        polarPlot12.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit16);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator19 = ringPlot18.getToolTipGenerator();
        java.awt.Paint paint20 = ringPlot18.getOutlinePaint();
        java.awt.Color color21 = java.awt.Color.GRAY;
        ringPlot18.setBaseSectionPaint((java.awt.Paint) color21);
        org.jfree.chart.util.Rotation rotation23 = ringPlot18.getDirection();
        boolean boolean24 = numberTickUnit16.equals((java.lang.Object) rotation23);
        double double25 = rotation23.getFactor();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(pieToolTipGenerator19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rotation23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic8.setOutlineStroke(stroke10);
        legendGraphic8.setShapeFilled(true);
        java.lang.Object obj14 = legendGraphic8.clone();
        legendGraphic8.setShapeOutlineVisible(true);
        java.awt.Paint paint17 = legendGraphic8.getFillPaint();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle7.getLegendItemGraphicLocation();
        java.awt.Paint paint9 = legendTitle7.getItemPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator10, xYURLGenerator11);
        java.lang.Boolean boolean14 = xYStepRenderer12.getSeriesLinesVisible(2);
        java.awt.Color color16 = java.awt.Color.green;
        xYStepRenderer12.setSeriesOutlinePaint(2958465, (java.awt.Paint) color16, false);
        legendTitle7.setItemPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.awt.Paint paint7 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot1.getDomainAxisLocation(9999);
        combinedRangeXYPlot1.setNotify(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot3.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5);
        java.awt.Paint paint9 = combinedRangeXYPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        dateAxis12.setInverted(true);
        combinedRangeXYPlot3.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        java.util.Date date18 = day16.getEnd();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        textTitle19.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle19.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle19.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = combinedRangeXYPlot25.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = combinedRangeXYPlot25.getDomainAxisEdge();
        boolean boolean29 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge28);
        double double30 = dateAxis12.dateToJava2D(date18, rectangle2D23, rectangleEdge28);
        boolean boolean31 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 9223372036854775807L, (double) (byte) -1, rectangle2D23);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0.5f, font4);
        double double8 = categoryAxis0.getLabelAngle();
        java.awt.Font font10 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0, font10);
        int int12 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = ringPlot13.getToolTipGenerator();
        java.lang.Object obj15 = ringPlot13.clone();
        boolean boolean16 = ringPlot13.getAutoPopulateSectionPaint();
        double double17 = ringPlot13.getInnerSeparatorExtension();
        double double18 = ringPlot13.getOuterSeparatorExtension();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot13.setSeparatorStroke(stroke19);
        categoryAxis0.setAxisLineStroke(stroke19);
        try {
            java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(pieToolTipGenerator14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        dateAxis40.setUpperMargin((double) (short) 10);
        dateAxis40.setMinorTickCount((int) (short) 1);
        java.awt.Shape shape50 = dateAxis40.getUpArrow();
        org.jfree.chart.plot.RingPlot ringPlot51 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator52 = ringPlot51.getToolTipGenerator();
        boolean boolean54 = ringPlot51.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape55 = ringPlot51.getLegendItemShape();
        dateAxis40.setUpArrow(shape55);
        dateAxis40.centerRange((double) (byte) 1);
        java.awt.Font font59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        dateAxis40.setTickLabelFont(font59);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNull(pieToolTipGenerator52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        double double2 = dateRange1.getLength();
        double double3 = dateRange1.getLowerBound();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (-61049779200000L), (org.jfree.data.Range) dateRange1);
        boolean boolean7 = dateRange1.contains((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        xYAreaRenderer2.setBaseFillPaint((java.awt.Paint) color5, false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer11.setAutoPopulateSeriesPaint(true);
        double double14 = xYAreaRenderer11.getItemLabelAnchorOffset();
        boolean boolean15 = xYAreaRenderer11.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = combinedRangeXYPlot20.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot18.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset24 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot18.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator29, xYURLGenerator30);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = xYStepAreaRenderer31.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color37 = java.awt.Color.RED;
        xYStepAreaRenderer31.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color37, false);
        categoryAxis27.setTickLabelPaint((java.awt.Paint) color37);
        java.awt.Paint paint41 = categoryAxis27.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = combinedRangeXYPlot43.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke46 = combinedRangeXYPlot43.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint41, stroke46);
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean49 = combinedRangeXYPlot18.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker47, layer48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        java.awt.Paint paint54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke55 = null;
        xYAreaRenderer11.drawRangeLine(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D52, (double) 60000L, paint54, stroke55);
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        xYAreaRenderer2.drawDomainGridLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D57, (double) (short) -1);
        java.awt.Font font60 = dateAxis51.getTickLabelFont();
        java.awt.Color color61 = java.awt.Color.pink;
        org.jfree.chart.text.TextBlock textBlock62 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=0,b=0]", font60, (java.awt.Paint) color61);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(textBlock62);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle7.getItemLabelPadding();
        java.lang.Object obj9 = null;
        boolean boolean10 = legendTitle7.equals(obj9);
        java.awt.Font font11 = legendTitle7.getItemFont();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        java.lang.String str6 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) xYDataItem4);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle9.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo15.getDataArea();
        textTitle9.draw(graphics2D13, rectangle2D16);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        combinedRangeXYPlot20.setDomainAxis(100, valueAxis22, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = combinedRangeXYPlot26.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis33);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = combinedRangeXYPlot36.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot34.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot36);
        java.awt.geom.Point2D point2D40 = combinedRangeXYPlot36.getQuadrantOrigin();
        combinedRangeXYPlot26.zoomRangeAxes((double) 43629L, (double) (short) 100, plotRenderingInfo32, point2D40);
        combinedRangeXYPlot20.setQuadrantOrigin(point2D40);
        combinedRangeXYPlot20.setNotify(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = combinedRangeXYPlot20.getDomainAxisEdge((-2236514));
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo47);
        java.awt.geom.Rectangle2D rectangle2D49 = plotRenderingInfo48.getDataArea();
        try {
            org.jfree.chart.axis.AxisState axisState50 = categoryAxis3D0.draw(graphics2D7, (double) 12, rectangle2D16, rectangle2D18, rectangleEdge46, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(point2D40);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(rectangle2D49);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setRangePannable(true);
        java.awt.Paint paint7 = combinedRangeXYPlot1.getRangeGridlinePaint();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        polarPlot8.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = polarPlot8.getDataRange(valueAxis11);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator21 = null;
        xYStepAreaRenderer16.setBaseToolTipGenerator(xYToolTipGenerator21, false);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState29 = xYStepAreaRenderer16.initialise(graphics2D24, rectangle2D25, xYPlot26, xYDataset27, plotRenderingInfo28);
        java.awt.Paint paint31 = xYStepAreaRenderer16.getSeriesPaint((int) (short) 100);
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer16.setSeriesItemLabelFont((int) (short) 10, font33, false);
        polarPlot8.setAngleLabelFont(font33);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = polarPlot8.getDrawingSupplier();
        combinedRangeXYPlot1.setDrawingSupplier(drawingSupplier37, true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(xYItemRendererState29);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(drawingSupplier37);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setParseIntegerOnly(true);
        boolean boolean7 = logFormat3.equals((java.lang.Object) 2);
        java.lang.String str9 = logFormat3.format(10L);
        java.awt.Stroke[] strokeArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean11 = logFormat3.equals((java.lang.Object) strokeArray10);
        java.lang.Object obj12 = logFormat3.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "^-0.0" + "'", str9.equals("^-0.0"));
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator4, xYURLGenerator5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYStepAreaRenderer6.getBasePositiveItemLabelPosition();
        barRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        textTitle18.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle18.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = plotRenderingInfo24.getDataArea();
        textTitle18.draw(graphics2D22, rectangle2D25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        textTitle28.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = textTitle28.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle28.getBounds();
        textTitle18.draw(graphics2D27, rectangle2D32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot35.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = combinedRangeXYPlot35.getDomainAxisEdge();
        try {
            gradientBarPainter0.paintBar(graphics2D1, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D2, (int) ' ', (int) (byte) 10, false, (java.awt.geom.RectangularShape) rectangle2D32, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        columnArrangement0.add(block1, (java.lang.Object) categoryAxis3D2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent52 = null;
        combinedDomainXYPlot46.plotChanged(plotChangeEvent52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer9);
        java.awt.Font font11 = xYAreaRenderer9.getBaseItemLabelFont();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!", font14, (java.awt.Paint) color15);
        xYAreaRenderer9.setSeriesPaint(2958465, (java.awt.Paint) color15);
        combinedRangeXYPlot1.setOutlinePaint((java.awt.Paint) color15);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible(2);
        boolean boolean5 = xYStepRenderer2.getUseFillPaint();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat4.setMaximumIntegerDigits((-1));
        int int7 = logFormat4.getMinimumIntegerDigits();
        boolean boolean8 = logFormat4.isGroupingUsed();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit(0.0d, (java.text.NumberFormat) logFormat4, 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        java.util.List list5 = blockContainer0.getBlocks();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesShapesVisible((int) (byte) 10, false);
        xYStepRenderer2.setBaseLinesVisible(true);
        double double8 = xYStepRenderer2.getItemLabelAnchorOffset();
        boolean boolean9 = xYStepRenderer2.getAutoPopulateSeriesOutlineStroke();
        java.lang.Object obj10 = xYStepRenderer2.clone();
        try {
            xYStepRenderer2.setSeriesShapesFilled((int) (byte) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) month1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle7.getItemLabelPadding();
        java.lang.Object obj9 = legendTitle7.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = legendTitle7.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle7.getLegendItemGraphicLocation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D12);
        org.jfree.data.xy.XYDataItem xYDataItem16 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj17 = xYDataItem16.clone();
        java.lang.String str18 = categoryAxis3D12.getCategoryLabelToolTip((java.lang.Comparable) xYDataItem16);
        boolean boolean19 = rectangleAnchor11.equals((java.lang.Object) xYDataItem16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        double double3 = categoryAxis0.getLowerMargin();
        java.lang.String str4 = categoryAxis0.getLabel();
        categoryAxis0.setCategoryLabelPositionOffset((int) ' ');
        java.lang.Comparable comparable7 = null;
        try {
            java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint(comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 11, 2.0f, 2.0d, 116.0d, 0.05d, 7 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 11, 2.0f, 2.0d, 116.0d, 0.05d, 7 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 11, 2.0f, 2.0d, 116.0d, 0.05d, 7 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 11, 2.0f, 2.0d, 116.0d, 0.05d, 7 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 11, 2.0f, 2.0d, 116.0d, 0.05d, 7 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 11, 2.0f, 2.0d, 116.0d, 0.05d, 7 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("index.html?series=-1&amp;item=0", "1.2.0-pre", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PieLabelLinkStyle.QUAD_CURVE", "", numberArray46);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart10.getXYPlot();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator16, xYURLGenerator17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepAreaRenderer18.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color24 = java.awt.Color.RED;
        xYStepAreaRenderer18.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color24, false);
        java.awt.Stroke stroke28 = xYStepAreaRenderer18.getSeriesStroke(3);
        java.awt.Stroke stroke30 = xYStepAreaRenderer18.lookupSeriesOutlineStroke(4);
        xYPlot14.setRangeCrosshairStroke(stroke30);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setRangePannable(true);
        java.awt.Stroke stroke7 = combinedRangeXYPlot1.getDomainZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = combinedRangeXYPlot1.getInsets();
        java.util.List list9 = combinedRangeXYPlot1.getAnnotations();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        double double3 = xYAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepAreaRenderer20.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color26 = java.awt.Color.RED;
        xYStepAreaRenderer20.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color26, false);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = categoryAxis16.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot32.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint30, stroke35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = combinedRangeXYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = null;
        xYAreaRenderer0.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D41, (double) 60000L, paint43, stroke44);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        dateAxis48.centerRange((double) 'a');
        org.jfree.data.Range range51 = combinedDomainXYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator54 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator55 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer56 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator54, xYURLGenerator55);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = xYStepAreaRenderer56.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Object obj61 = xYStepAreaRenderer56.clone();
        java.awt.Shape shape63 = xYStepAreaRenderer56.getSeriesShape(100);
        try {
            combinedDomainXYPlot46.setRenderer((int) (short) -1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer56, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(itemLabelPosition60);
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertNull(shape63);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.removeAgedItems((long) 'a', true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator12, xYURLGenerator13);
        java.lang.Boolean boolean16 = xYStepRenderer14.getSeriesLinesVisible(2);
        boolean boolean17 = xYStepRenderer14.getBaseShapesVisible();
        boolean boolean18 = timeSeries4.equals((java.lang.Object) boolean17);
        boolean boolean19 = timeSeries4.isEmpty();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange1, lengthConstraintType2, (double) 12, (org.jfree.data.Range) dateRange4, lengthConstraintType5);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, (double) 12);
        org.jfree.data.Range range10 = org.jfree.data.Range.scale(range8, (double) 2.0f);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setDomainAxis(100, valueAxis3, true);
        java.awt.Stroke stroke6 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace7, false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("java.awt.Color[r=255,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        double double6 = dateRange5.getLength();
        double double7 = dateRange5.getLowerBound();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        boolean boolean9 = layer4.equals((java.lang.Object) dateRange8);
        try {
            barRenderer3D0.addAnnotation(categoryAnnotation3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.lang.Object obj9 = defaultXYDataset7.clone();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset7, valueAxis10, polarItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = polarPlot12.getDataset();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(xYDataset13);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.Rotation rotation1 = ringPlot0.getDirection();
        org.junit.Assert.assertNotNull(rotation1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getCrosshairDistance();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.awt.Paint paint3 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint4 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        axisState0.moveCursor((double) 1L, rectangleEdge2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getDomainGridlineStroke();
        java.util.List list9 = combinedRangeXYPlot5.getAnnotations();
        axisState0.setTicks(list9);
        axisState0.cursorLeft((double) 2958465);
        axisState0.cursorRight((double) 10);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) '4', (org.jfree.data.Range) dateRange1, lengthConstraintType2, (double) 12, (org.jfree.data.Range) dateRange4, lengthConstraintType5);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, (double) 12);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke13 = combinedRangeXYPlot10.getDomainGridlineStroke();
        java.util.List list14 = combinedRangeXYPlot10.getAnnotations();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer16);
        java.awt.Font font18 = xYAreaRenderer16.getBaseItemLabelFont();
        java.awt.Font font21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color22 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("hi!", font21, (java.awt.Paint) color22);
        xYAreaRenderer16.setSeriesPaint(2958465, (java.awt.Paint) color22);
        combinedRangeXYPlot10.setRangeTickBandPaint((java.awt.Paint) color22);
        boolean boolean26 = dateRange4.equals((java.lang.Object) combinedRangeXYPlot10);
        java.awt.Stroke stroke27 = combinedRangeXYPlot10.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        int int7 = combinedRangeXYPlot1.getSeriesCount();
        java.awt.Stroke stroke8 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        legendGraphic8.setLineVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = legendGraphic8.getFillPaintTransformer();
        legendGraphic8.setWidth(1.0E-5d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle13.getBounds();
        try {
            barRenderer3D0.drawOutline(graphics2D11, categoryPlot12, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot2.getLegendItems();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.RenderingSource renderingSource9 = null;
        combinedRangeXYPlot2.select(0.0d, (double) 0, rectangle2D8, renderingSource9);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator12, xYURLGenerator13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer14.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator19 = null;
        xYStepAreaRenderer14.setBaseToolTipGenerator(xYToolTipGenerator19, false);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState27 = xYStepAreaRenderer14.initialise(graphics2D22, rectangle2D23, xYPlot24, xYDataset25, plotRenderingInfo26);
        java.awt.Paint paint29 = xYStepAreaRenderer14.getSeriesPaint((int) (short) 100);
        combinedRangeXYPlot2.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer14);
        xYStepAreaRenderer14.setPlotArea(true);
        org.jfree.chart.LegendItem legendItem35 = xYStepAreaRenderer14.getLegendItem((int) '#', 0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer38 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer38);
        java.awt.Font font40 = xYAreaRenderer38.getBaseItemLabelFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis42.configure();
        java.awt.Font font46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color47 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("hi!", font46, (java.awt.Paint) color47);
        categoryAxis42.setTickLabelFont((java.lang.Comparable) 0.5f, font46);
        xYAreaRenderer38.setSeriesItemLabelFont((int) (short) 100, font46);
        xYStepAreaRenderer14.setLegendTextFont(0, font46);
        org.jfree.chart.text.TextLine textLine52 = new org.jfree.chart.text.TextLine("", font46);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(xYItemRendererState27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(legendItem35);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(color47);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic8.setOutlineStroke(stroke10);
        legendGraphic8.setShapeFilled(true);
        java.lang.Object obj14 = legendGraphic8.clone();
        legendGraphic8.setShapeOutlineVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape22 = xYStepAreaRenderer18.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity23 = new org.jfree.chart.entity.LegendItemEntity(shape22);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color24);
        boolean boolean26 = legendGraphic25.isShapeFilled();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic25.setOutlineStroke(stroke27);
        legendGraphic25.setShapeFilled(true);
        java.lang.Object obj31 = legendGraphic25.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = legendGraphic25.getShapeLocation();
        legendGraphic8.setShapeLocation(rectangleAnchor32);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = polarPlot0.getDataRange(valueAxis3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setAutoPopulateSeriesPaint(true);
        double double8 = xYAreaRenderer5.getItemLabelAnchorOffset();
        boolean boolean9 = xYAreaRenderer5.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedRangeXYPlot14.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot12.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset18 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot12.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator23, xYURLGenerator24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color31 = java.awt.Color.RED;
        xYStepAreaRenderer25.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color31, false);
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color31);
        java.awt.Paint paint35 = categoryAxis21.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = combinedRangeXYPlot37.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke40 = combinedRangeXYPlot37.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint35, stroke40);
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = combinedRangeXYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker41, layer42);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke49 = null;
        xYAreaRenderer5.drawRangeLine(graphics2D10, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis45, rectangle2D46, (double) 60000L, paint48, stroke49);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot51 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.data.Range range52 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = null;
        dateAxis45.setTickUnit(dateTickUnit54, false, false);
        dateAxis45.resizeRange((double) 15);
        dateAxis45.setMinorTickCount((int) (short) 0);
        org.jfree.chart.axis.Timeline timeline62 = dateAxis45.getTimeline();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(timeline62);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setParseIntegerOnly(true);
        boolean boolean7 = logFormat3.equals((java.lang.Object) 2);
        java.lang.String str9 = logFormat3.format(10L);
        java.lang.Object obj10 = null;
        boolean boolean11 = logFormat3.equals(obj10);
        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
        projectInfo12.setCopyright("java.awt.Color[r=255,g=0,b=0]");
        java.util.List list15 = projectInfo12.getContributors();
        try {
            java.lang.String str16 = logFormat3.format((java.lang.Object) projectInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "^-0.0" + "'", str9.equals("^-0.0"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(projectInfo12);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator0 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer3);
        boolean boolean5 = textAnchor1.equals((java.lang.Object) xYAreaRenderer3);
        boolean boolean6 = standardXYURLGenerator0.equals((java.lang.Object) textAnchor1);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        java.lang.String str10 = standardXYURLGenerator0.generateURL(xYDataset7, (int) (short) 100, (int) 'a');
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "index.html?series=100&amp;item=97" + "'", str10.equals("index.html?series=100&amp;item=97"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle7.getItemLabelPadding();
        java.lang.Object obj9 = legendTitle7.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = legendTitle7.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle7.getLegendItemGraphicLocation();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator13 = ringPlot12.getToolTipGenerator();
        java.lang.Object obj14 = ringPlot12.clone();
        boolean boolean15 = ringPlot12.getAutoPopulateSectionPaint();
        double double16 = ringPlot12.getInnerSeparatorExtension();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day17, "", "hi!");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        boolean boolean24 = day22.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day22);
        java.awt.Paint paint26 = ringPlot12.getSectionOutlinePaint((java.lang.Comparable) day22);
        boolean boolean27 = ringPlot12.getSectionOutlinesVisible();
        boolean boolean28 = legendTitle7.equals((java.lang.Object) ringPlot12);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(pieToolTipGenerator13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(12, serialDate6);
        serialDate6.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate11 = serialDate1.getEndOfCurrentMonth(serialDate10);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer4.setSeriesItemLabelFont((int) '4', font6);
        xYStepAreaRenderer4.setSeriesVisibleInLegend(9999, (java.lang.Boolean) false);
        xYStepAreaRenderer4.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = combinedRangeXYPlot18.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot16.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18);
        java.awt.Paint paint22 = combinedRangeXYPlot16.getRangeMinorGridlinePaint();
        xYStepAreaRenderer4.setSeriesPaint(9999, paint22, false);
        boolean boolean25 = textBlockAnchor0.equals((java.lang.Object) xYStepAreaRenderer4);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator12, xYURLGenerator13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer14.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color20 = java.awt.Color.RED;
        xYStepAreaRenderer14.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color20, false);
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color20);
        java.awt.Paint paint24 = categoryAxis10.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = combinedRangeXYPlot26.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint24, stroke29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = combinedRangeXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker30, layer31);
        java.awt.Paint paint33 = valueMarker30.getLabelPaint();
        java.lang.Object obj34 = valueMarker30.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker30.setLabelAnchor(rectangleAnchor35);
        java.awt.Stroke stroke37 = valueMarker30.getStroke();
        double double38 = valueMarker30.getValue();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.visible = true;
        boolean boolean9 = textTitle6.isVisible();
        textTitle6.setExpandToFitSpace(false);
        org.jfree.chart.entity.TitleEntity titleEntity13 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle6, "java.awt.Color[r=255,g=0,b=0]");
        java.lang.Object obj14 = titleEntity13.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getDataArea();
        titleEntity13.setArea((java.awt.Shape) rectangle2D17);
        java.awt.Shape shape19 = titleEntity13.getArea();
        java.lang.String str20 = titleEntity13.getShapeType();
        java.lang.Object obj21 = titleEntity13.clone();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day9, "", "hi!");
        timeSeries13.setMaximumItemCount(3);
        java.util.List list16 = timeSeries13.getItems();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 10);
        int int19 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year18.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.addOrUpdate(xYDataItem4);
        xYSeries1.add((java.lang.Number) 5, (java.lang.Number) 86400000L);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        boolean boolean21 = xYSeries1.equals((java.lang.Object) false);
        boolean boolean22 = xYSeries1.getNotify();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset23.validateObject();
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset23);
        xYSeries1.add(0.0d, 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        double double1 = dateRange0.getLength();
        double double2 = dateRange0.getLowerBound();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        double double4 = dateRange3.getLength();
        double double5 = dateRange3.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange3);
        long long7 = dateRange3.getUpperMillis();
        double double8 = dateRange3.getLength();
        java.lang.String str9 = dateRange3.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str9.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemLineVisible(0, 3);
        boolean boolean7 = xYLineAndShapeRenderer0.getDrawOutlines();
        xYLineAndShapeRenderer0.setDefaultEntityRadius(2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj3 = xYDataItem2.clone();
        xYDataItem2.setY(0.0d);
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "JFreeChart", doubleArray8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset9, (-457));
        double double13 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) xYDataItem2, (org.jfree.data.KeyedValues) pieDataset12);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(categoryDataset14);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepAreaRenderer3.setSeriesItemLabelFont((int) '4', font5);
        xYStepAreaRenderer3.setSeriesVisibleInLegend(9999, (java.lang.Boolean) false);
        java.awt.Paint paint11 = null;
        xYStepAreaRenderer3.setLegendTextPaint(0, paint11);
        boolean boolean13 = xYStepAreaRenderer3.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        segmentedTimeline3.addException((long) 2, 10L);
        long long7 = segmentedTimeline3.getSegmentsGroupSize();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        dateAxis9.centerRange((double) 'a');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape17 = xYStepAreaRenderer13.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        textTitle19.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle19.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        textTitle19.draw(graphics2D23, rectangle2D24);
        org.jfree.chart.entity.TitleEntity titleEntity27 = new org.jfree.chart.entity.TitleEntity(shape17, (org.jfree.chart.title.Title) textTitle19, "Combined Range XYPlot");
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity31 = new org.jfree.chart.entity.TitleEntity(shape17, (org.jfree.chart.title.Title) textTitle28, "Combined Range XYPlot", "java.awt.Color[r=255,g=0,b=0]");
        dateAxis9.setDownArrow(shape17);
        dateAxis9.setNegativeArrowVisible(true);
        java.util.Date date35 = dateAxis9.getMaximumDate();
        long long36 = segmentedTimeline3.toTimelineValue(date35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10700L + "'", long7 == 10700L);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears(12, serialDate5);
        serialDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart10.getXYPlot();
        boolean boolean15 = jFreeChart10.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection21 = chartRenderingInfo19.getEntityCollection();
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart10.createBufferedImage((int) (short) 0, (-1), (-2236514), chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -2236514");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertNotNull(entityCollection21);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic8.setOutlineStroke(stroke10);
        legendGraphic8.setShapeFilled(true);
        java.awt.Stroke stroke14 = legendGraphic8.getLineStroke();
        java.awt.Paint paint15 = legendGraphic8.getFillPaint();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        java.util.List list14 = jFreeChart10.getSubtitles();
        org.jfree.chart.plot.Plot plot15 = jFreeChart10.getPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo20.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection22 = chartRenderingInfo20.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.entity.EntityCollection entityCollection24 = chartRenderingInfo23.getEntityCollection();
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart10.createBufferedImage((-1), 13, (double) 0.0f, (double) 0L, chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (13) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(entityCollection22);
        org.junit.Assert.assertNotNull(entityCollection24);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        java.lang.Object obj4 = intervalXYDelegate3.clone();
        double double5 = intervalXYDelegate3.getFixedIntervalWidth();
        double double6 = intervalXYDelegate3.getIntervalWidth();
        try {
            java.lang.Number number9 = intervalXYDelegate3.getStartX(2147483647, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color9 = java.awt.Color.RED;
        xYStepAreaRenderer3.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color9, false);
        java.awt.Stroke stroke12 = xYStepAreaRenderer3.getBaseOutlineStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = xYStepAreaRenderer3.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator13);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setNotify(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer7.setAutoPopulateSeriesPaint(true);
        double double10 = xYAreaRenderer7.getItemLabelAnchorOffset();
        boolean boolean11 = xYAreaRenderer7.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot16.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot14.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot14.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator25, xYURLGenerator26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYStepAreaRenderer27.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color33 = java.awt.Color.RED;
        xYStepAreaRenderer27.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color33, false);
        categoryAxis23.setTickLabelPaint((java.awt.Paint) color33);
        java.awt.Paint paint37 = categoryAxis23.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = combinedRangeXYPlot39.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke42 = combinedRangeXYPlot39.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint37, stroke42);
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = combinedRangeXYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker43, layer44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke51 = null;
        xYAreaRenderer7.drawRangeLine(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, (org.jfree.chart.axis.ValueAxis) dateAxis47, rectangle2D48, (double) 60000L, paint50, stroke51);
        combinedRangeXYPlot1.setRangeZeroBaselinePaint(paint50);
        java.util.List list54 = combinedRangeXYPlot1.getSubplots();
        combinedRangeXYPlot1.clearDomainMarkers();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(list54);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot1.getDomainAxisLocation(7);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        java.util.List list14 = jFreeChart10.getSubtitles();
        org.jfree.chart.plot.Plot plot15 = jFreeChart10.getPlot();
        int int16 = jFreeChart10.getSubtitleCount();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.RenderingSource renderingSource8 = null;
        combinedRangeXYPlot1.select(0.0d, (double) 0, rectangle2D7, renderingSource8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator11, xYURLGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepAreaRenderer13.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        xYStepAreaRenderer13.setBaseToolTipGenerator(xYToolTipGenerator18, false);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYStepAreaRenderer13.initialise(graphics2D21, rectangle2D22, xYPlot23, xYDataset24, plotRenderingInfo25);
        java.awt.Paint paint28 = xYStepAreaRenderer13.getSeriesPaint((int) (short) 100);
        combinedRangeXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer13);
        xYStepAreaRenderer13.setPlotArea(true);
        java.awt.Paint paint32 = xYStepAreaRenderer13.getBasePaint();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator33 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toFixedWidth(0.0d);
        boolean boolean37 = standardXYURLGenerator33.equals((java.lang.Object) 0.0d);
        xYStepAreaRenderer13.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator33);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.setAnchorX((double) 2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean4 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean11 = segmentedTimeline8.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list12 = segmentedTimeline8.getExceptionSegments();
        segmentedTimeline3.setBaseTimeline(segmentedTimeline8);
        long long14 = segmentedTimeline8.getSegmentsExcludedSize();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setInverted(true);
        java.util.Date date19 = dateAxis16.getMaximumDate();
        long long20 = segmentedTimeline8.toTimelineValue(date19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9700L + "'", long14 == 9700L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int3 = java.awt.Color.HSBtoRGB((float) 2, (float) ' ', (float) 2147483647);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-65536) + "'", int3 == (-65536));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedRangeXYPlot1.getRangeAxis((int) (short) 1);
        combinedRangeXYPlot1.setDomainPannable(false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) xYAreaRenderer2);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        java.lang.Object obj8 = standardXYSeriesLabelGenerator6.clone();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart10.getXYPlot();
        jFreeChart10.removeLegend();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(xYPlot14);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = barRenderer3D0.getPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint17);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape24 = xYStepAreaRenderer20.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity25 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        java.awt.Color color26 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape24, (java.awt.Paint) color26);
        java.lang.Object obj28 = legendGraphic27.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = legendGraphic27.getFillPaintTransformer();
        intervalMarker18.setGradientPaintTransformer(gradientPaintTransformer29);
        xYBarRenderer14.setGradientPaintTransformer(gradientPaintTransformer29);
        barRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer29);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(gradientPaintTransformer29);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.util.LogFormat logFormat1 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat5.setMinimumIntegerDigits(0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("rect", (java.text.NumberFormat) logFormat1, (java.text.NumberFormat) logFormat5);
        java.lang.Object obj9 = standardXYToolTipGenerator8.clone();
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle7.getItemLabelPadding();
        java.lang.Object obj9 = null;
        boolean boolean10 = legendTitle7.equals(obj9);
        java.awt.Paint paint11 = legendTitle7.getItemPaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D5 = textTitle1.getBounds();
        try {
            boolean boolean6 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        try {
            java.lang.Number number5 = defaultPieDataset0.getValue((java.lang.Comparable) "rect");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: rect");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = combinedRangeXYPlot1.getLegendItems();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        ringPlot0.setInsets(rectangleInsets7, true);
        boolean boolean10 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test425");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) 0, false);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemLineVisible(0, 3);
        boolean boolean7 = xYLineAndShapeRenderer0.getDrawOutlines();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYLineAndShapeRenderer0.setBaseOutlineStroke(stroke8, true);
        java.awt.Paint paint12 = xYLineAndShapeRenderer0.lookupLegendTextPaint(10);
        xYLineAndShapeRenderer0.setDrawSeriesLineAsPath(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setDomainAxis(100, valueAxis3, true);
        java.awt.Stroke stroke6 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        combinedRangeXYPlot8.setDomainAxis(100, valueAxis10, true);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8, (int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = combinedRangeXYPlot18.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot16.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset22 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot16.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator27, xYURLGenerator28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepAreaRenderer29.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color35 = java.awt.Color.RED;
        xYStepAreaRenderer29.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color35, false);
        categoryAxis25.setTickLabelPaint((java.awt.Paint) color35);
        java.awt.Paint paint39 = categoryAxis25.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis40);
        org.jfree.chart.axis.AxisLocation axisLocation43 = combinedRangeXYPlot41.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke44 = combinedRangeXYPlot41.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint39, stroke44);
        org.jfree.chart.util.Layer layer46 = null;
        boolean boolean47 = combinedRangeXYPlot16.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker45, layer46);
        java.awt.Paint paint48 = valueMarker45.getLabelPaint();
        org.jfree.chart.util.Layer layer49 = null;
        boolean boolean50 = combinedRangeXYPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker45, layer49);
        try {
            valueMarker45.setAlpha((float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = null;
        polarPlot0.setRenderer(polarItemRenderer1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (short) 0, (java.lang.Number) 9999);
        java.lang.Object obj5 = xYDataItem4.clone();
        double double6 = xYDataItem4.getXValue();
        xYDataItem4.setY((java.lang.Number) 60000L);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.addOrUpdate(xYDataItem4);
        xYSeries1.add((java.lang.Number) 5, (java.lang.Number) 86400000L);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer16.getNegativeItemLabelPosition(0, (int) 'a', false);
        boolean boolean21 = xYSeries1.equals((java.lang.Object) false);
        boolean boolean22 = xYSeries1.getNotify();
        try {
            java.lang.Number number24 = xYSeries1.getX((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        java.awt.Paint paint8 = combinedRangeXYPlot1.getDomainMinorGridlinePaint();
        combinedRangeXYPlot1.setGap((double) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 10, 0);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day16, "", "hi!");
        timeSeries20.setMaximumItemCount(3);
        java.util.List list23 = timeSeries20.getItems();
        segmentedTimeline15.addExceptions(list23);
        try {
            combinedRangeXYPlot1.mapDatasetToRangeAxes((int) (byte) -1, list23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) 100.0f);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset6 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset6);
        java.lang.Object obj9 = defaultXYDataset6.clone();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset6, false);
        java.lang.String str14 = standardXYURLGenerator5.generateURL((org.jfree.data.xy.XYDataset) defaultXYDataset6, (int) (short) -1, 0);
        org.jfree.chart.entity.XYItemEntity xYItemEntity19 = new org.jfree.chart.entity.XYItemEntity(shape4, (org.jfree.data.xy.XYDataset) defaultXYDataset6, (int) 'a', 0, "TimePeriodAnchor.END", "RectangleAnchor.LEFT");
        xYItemEntity19.setSeriesIndex((int) 'a');
        java.lang.String str22 = xYItemEntity19.getShapeCoords();
        xYItemEntity19.setSeriesIndex(7);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "index.html?series=-1&amp;item=0" + "'", str14.equals("index.html?series=-1&amp;item=0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str22.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.centerRange((double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4);
        boolean boolean6 = dateAxis1.isAutoRange();
        org.jfree.data.Range range7 = dateAxis1.getRange();
        dateAxis1.setTickMarkOutsideLength((float) 30);
        java.lang.Object obj10 = dateAxis1.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset1 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getDomainGridlineStroke();
        combinedRangeXYPlot5.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset1, jFreeChart11, (int) ' ', 9999);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 13, jFreeChart11, 9, 9999);
        org.jfree.chart.JFreeChart jFreeChart18 = chartProgressEvent17.getChart();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(jFreeChart18);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color10 = java.awt.Color.RED;
        xYStepAreaRenderer4.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color10, false);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setTickMarkInsideLength(0.5f);
        java.lang.String str17 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarkInsideLength((float) (byte) 0);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset7);
        java.awt.Paint paint9 = null;
        combinedRangeXYPlot1.setBackgroundPaint(paint9);
        java.awt.Stroke stroke11 = combinedRangeXYPlot1.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        int int5 = timeSeries4.getItemCount();
        timeSeries4.removeAgedItems(0L, true);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.removeAgedItems((long) 'a', true);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.lang.Number number14 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate(regularTimePeriod13, number14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = combinedRangeXYPlot19.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot17.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot17.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset23);
        java.lang.Object obj25 = defaultXYDataset23.clone();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset23, valueAxis26, polarItemRenderer27);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset29 = new org.jfree.data.xy.DefaultXYDataset();
        polarPlot28.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset29);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
        polarPlot28.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot35.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = combinedRangeXYPlot35.getLegendItems();
        java.awt.Image image39 = null;
        combinedRangeXYPlot35.setBackgroundImage(image39);
        boolean boolean41 = numberTickUnit32.equals((java.lang.Object) combinedRangeXYPlot35);
        timeSeries4.setKey((java.lang.Comparable) boolean41);
        java.util.List list43 = timeSeries4.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(list43);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color9 = java.awt.Color.RED;
        xYStepAreaRenderer3.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color9, false);
        boolean boolean12 = xYStepAreaRenderer3.getPlotArea();
        java.awt.Shape shape14 = null;
        xYStepAreaRenderer3.setSeriesShape((int) '4', shape14);
        java.awt.Shape shape19 = xYStepAreaRenderer3.getItemShape(0, (int) (byte) 100, false);
        xYStepAreaRenderer3.setPlotArea(true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("{0}: ({1}, {2})");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name {0}: ({1}, {2}), locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot7.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        combinedRangeXYPlot7.datasetChanged(datasetChangeEvent13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = combinedRangeXYPlot7.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getDomainGridlineStroke();
        combinedRangeXYPlot17.setRangePannable(true);
        java.awt.Stroke stroke23 = combinedRangeXYPlot17.getDomainZeroBaselineStroke();
        combinedRangeXYPlot7.setRangeMinorGridlineStroke(stroke23);
        xYAreaRenderer0.setSeriesStroke((int) (byte) 1, stroke23);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = ringPlot1.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = ringPlot1.getLabelDistributor();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = ringPlot6.getToolTipGenerator();
        java.awt.Paint paint8 = ringPlot6.getOutlinePaint();
        java.awt.Color color9 = java.awt.Color.GRAY;
        ringPlot6.setBaseSectionPaint((java.awt.Paint) color9);
        org.jfree.chart.util.Rotation rotation11 = ringPlot6.getDirection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot1.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 0, plotRenderingInfo14);
        ringPlot6.setLabelLinksVisible(false);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleAnchor.LEFT", (org.jfree.chart.plot.Plot) ringPlot6);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesShapesVisible((int) (byte) 10, false);
        xYStepRenderer2.setBaseLinesVisible(true);
        double double8 = xYStepRenderer2.getItemLabelAnchorOffset();
        java.awt.Shape shape9 = xYStepRenderer2.getLegendLine();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!", font14, (java.awt.Paint) color15);
        xYAreaRenderer12.setBaseFillPaint((java.awt.Paint) color15, false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer21.setAutoPopulateSeriesPaint(true);
        double double24 = xYAreaRenderer21.getItemLabelAnchorOffset();
        boolean boolean25 = xYAreaRenderer21.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = combinedRangeXYPlot30.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot28.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot30);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset34 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot28.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator39 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator40 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator39, xYURLGenerator40);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = xYStepAreaRenderer41.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color47 = java.awt.Color.RED;
        xYStepAreaRenderer41.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color47, false);
        categoryAxis37.setTickLabelPaint((java.awt.Paint) color47);
        java.awt.Paint paint51 = categoryAxis37.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = combinedRangeXYPlot53.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke56 = combinedRangeXYPlot53.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint51, stroke56);
        org.jfree.chart.util.Layer layer58 = null;
        boolean boolean59 = combinedRangeXYPlot28.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        java.awt.Paint paint64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke65 = null;
        xYAreaRenderer21.drawRangeLine(graphics2D26, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot28, (org.jfree.chart.axis.ValueAxis) dateAxis61, rectangle2D62, (double) 60000L, paint64, stroke65);
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        xYAreaRenderer12.drawDomainGridLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis61, rectangle2D67, (double) (short) -1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor70 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor71 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition72 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor70, textAnchor71);
        xYAreaRenderer12.setBaseNegativeItemLabelPosition(itemLabelPosition72, false);
        xYStepRenderer2.setSeriesNegativeItemLabelPosition(15, itemLabelPosition72);
        xYStepRenderer2.setBaseLinesVisible(false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(itemLabelAnchor70);
        org.junit.Assert.assertNotNull(textAnchor71);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color10 = java.awt.Color.RED;
        xYStepAreaRenderer4.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color10, false);
        boolean boolean13 = xYStepAreaRenderer4.getPlotArea();
        java.awt.Shape shape15 = null;
        xYStepAreaRenderer4.setSeriesShape((int) '4', shape15);
        java.awt.Shape shape20 = xYStepAreaRenderer4.getItemShape(0, (int) (byte) 100, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = combinedRangeXYPlot22.getDomainAxisForDataset(0);
        java.awt.Paint paint25 = combinedRangeXYPlot22.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement27 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot22, (org.jfree.chart.block.Arrangement) columnArrangement26, (org.jfree.chart.block.Arrangement) borderArrangement27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle28.getLegendItemGraphicLocation();
        org.jfree.chart.entity.TitleEntity titleEntity31 = new org.jfree.chart.entity.TitleEntity(shape20, (org.jfree.chart.title.Title) legendTitle28, "ERROR : Relative To String");
        boolean boolean32 = standardPieSectionLabelGenerator0.equals((java.lang.Object) "ERROR : Relative To String");
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        boolean boolean5 = xYStepRenderer2.getItemShapeVisible(3, 2958465);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 100, 10, (int) 'a');
        boolean boolean14 = segmentedTimeline11.containsDomainRange((long) '4', (long) (short) 100);
        java.util.List list15 = segmentedTimeline11.getExceptionSegments();
        long long17 = segmentedTimeline11.toTimelineValue((long) (short) 100);
        boolean boolean18 = xYStepRenderer2.equals((java.lang.Object) (short) 100);
        java.awt.Shape shape19 = xYStepRenderer2.getBaseLegendShape();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(shape19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset0.validateObject();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        double[][] doubleArray5 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "JFreeChart", doubleArray5);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset6);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset6, (int) 'a');
        org.jfree.data.Range range12 = barRenderer3D0.findRangeBounds(categoryDataset6, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat3.setMinimumIntegerDigits(0);
        logFormat3.setMinimumIntegerDigits(100);
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat12.setMaximumIntegerDigits((-1));
        java.lang.StringBuffer stringBuffer16 = null;
        java.text.FieldPosition fieldPosition17 = null;
        java.lang.StringBuffer stringBuffer18 = logFormat12.format((double) (-457), stringBuffer16, fieldPosition17);
        java.text.FieldPosition fieldPosition19 = null;
        java.lang.StringBuffer stringBuffer20 = logFormat3.format((long) '#', stringBuffer16, fieldPosition19);
        java.math.RoundingMode roundingMode21 = null;
        try {
            logFormat3.setRoundingMode(roundingMode21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(stringBuffer18);
        org.junit.Assert.assertNotNull(stringBuffer20);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Paint paint5 = ringPlot0.getLabelLinkPaint();
        ringPlot0.setLabelGap((double) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean9 = categoryAxis8.isVisible();
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        polarPlot10.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = polarPlot10.getDataRange(valueAxis13);
        categoryAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot10);
        java.awt.Paint paint16 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        combinedRangeXYPlot18.setDomainAxis(100, valueAxis20, true);
        java.awt.Stroke stroke23 = combinedRangeXYPlot18.getRangeMinorGridlineStroke();
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder(paint16, stroke23, rectangleInsets25);
        categoryAxis8.setLabelInsets(rectangleInsets25, false);
        ringPlot0.setLabelPadding(rectangleInsets25);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0.5f, font4);
        double double8 = categoryAxis0.getLabelAngle();
        double double9 = categoryAxis0.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke14 = combinedRangeXYPlot11.getDomainGridlineStroke();
        combinedRangeXYPlot11.setRangePannable(true);
        java.awt.Stroke stroke17 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        categoryAxis0.setTickMarkStroke(stroke17);
        categoryAxis0.setTickMarksVisible(true);
        float float21 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart10.getXYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection21 = chartRenderingInfo19.getEntityCollection();
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart10.createBufferedImage(13, 2, (double) (short) -1, (-7.0d), chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertNotNull(entityCollection21);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYStepAreaRenderer4.setBaseToolTipGenerator(xYToolTipGenerator9, false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = xYStepAreaRenderer4.initialise(graphics2D12, rectangle2D13, xYPlot14, xYDataset15, plotRenderingInfo16);
        java.awt.Paint paint19 = xYStepAreaRenderer4.getSeriesPaint((int) (short) 100);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer4.setSeriesItemLabelFont((int) (short) 10, font21, false);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color24);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = labelBlock25.getContentAlignmentPoint();
        java.awt.Paint paint27 = labelBlock25.getPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer29.setAutoPopulateSeriesPaint(true);
        double double32 = xYAreaRenderer29.getItemLabelAnchorOffset();
        java.awt.Font font36 = xYAreaRenderer29.getItemLabelFont(0, 3, true);
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("RectangleAnchor.LEFT", font36);
        labelBlock25.setFont(font36);
        labelBlock25.setURLText("RectangleAnchor.LEFT");
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(xYItemRendererState17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.lang.Object obj2 = dateAxis1.clone();
        java.awt.Shape shape3 = dateAxis1.getLeftArrow();
        dateAxis1.centerRange((double) 2);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "hi!");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day5);
        timeSeries4.removeAgedItems((long) 'a', true);
        timeSeries4.fireSeriesChanged();
        java.lang.Object obj13 = timeSeries4.clone();
        try {
            timeSeries4.delete(7, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape5 = xYStepAreaRenderer1.getItemShape((-1), (int) 'a', false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        textTitle7.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle7.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle7.draw(graphics2D11, rectangle2D12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle7, "Combined Range XYPlot");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle16, "Combined Range XYPlot", "java.awt.Color[r=255,g=0,b=0]");
        java.awt.Graphics2D graphics2D20 = null;
        try {
            org.jfree.chart.util.Size2D size2D21 = textTitle16.arrange(graphics2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint2 = ringPlot0.getOutlinePaint();
        java.awt.Color color3 = java.awt.Color.GRAY;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color3);
        ringPlot0.setLabelLinkMargin(0.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        combinedRangeXYPlot1.setRangePannable(true);
        java.awt.Stroke stroke7 = combinedRangeXYPlot1.getDomainZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = combinedRangeXYPlot1.getFixedLegendItems();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItemCollection8);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) xYAreaRenderer2);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = xYAreaRenderer2.getToolTipGenerator(15, (int) (short) 10, true);
        xYAreaRenderer2.setAutoPopulateSeriesPaint(true);
        java.awt.Font font17 = xYAreaRenderer2.getItemLabelFont(2147483647, (int) (byte) 0, true);
        java.lang.Object obj18 = xYAreaRenderer2.clone();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.getAttributedLabel(100);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator4.getPercentFormat();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset6 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset6.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        java.text.AttributedString attributedString11 = standardPieSectionLabelGenerator4.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset6, (java.lang.Comparable) 1.0f);
        java.text.AttributedString attributedString13 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset6, (java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNull(attributedString11);
        org.junit.Assert.assertNull(attributedString13);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.util.LogFormat logFormat1 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat(0.0d, "", true);
        logFormat5.setMinimumIntegerDigits(0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("rect", (java.text.NumberFormat) logFormat1, (java.text.NumberFormat) logFormat5);
        java.lang.String str9 = standardXYToolTipGenerator8.getNullYString();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "null" + "'", str9.equals("null"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 100L, (double) 2, (double) (-457));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint8);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape15 = xYStepAreaRenderer11.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        java.awt.Color color17 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color17);
        java.lang.Object obj19 = legendGraphic18.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = legendGraphic18.getFillPaintTransformer();
        intervalMarker9.setGradientPaintTransformer(gradientPaintTransformer20);
        xYBarRenderer5.setGradientPaintTransformer(gradientPaintTransformer20);
        org.jfree.chart.LegendItem legendItem25 = xYBarRenderer5.getLegendItem(6, (int) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = xYBarRenderer5.getGradientPaintTransformer();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        textTitle30.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = textTitle30.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        java.awt.geom.Rectangle2D rectangle2D37 = plotRenderingInfo36.getDataArea();
        textTitle30.draw(graphics2D34, rectangle2D37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.configure();
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        textTitle43.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = textTitle43.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle43.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot49 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis48);
        org.jfree.chart.axis.ValueAxis valueAxis51 = combinedRangeXYPlot49.getDomainAxisForDataset(0);
        java.awt.Paint paint52 = combinedRangeXYPlot49.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement53 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement54 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot49, (org.jfree.chart.block.Arrangement) columnArrangement53, (org.jfree.chart.block.Arrangement) borderArrangement54);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = legendTitle55.getItemLabelPadding();
        java.lang.Object obj57 = legendTitle55.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = legendTitle55.getLegendItemGraphicEdge();
        double double59 = categoryAxis39.getCategoryStart(10, 4, rectangle2D47, rectangleEdge58);
        try {
            gradientXYBarPainter3.paintBar(graphics2D4, xYBarRenderer5, (int) (byte) 100, (-457), true, (java.awt.geom.RectangularShape) rectangle2D37, rectangleEdge58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(gradientPaintTransformer26);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        xYStepAreaRenderer5.setBaseToolTipGenerator(xYToolTipGenerator10, false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYStepAreaRenderer5.initialise(graphics2D13, rectangle2D14, xYPlot15, xYDataset16, plotRenderingInfo17);
        java.awt.Paint paint20 = xYStepAreaRenderer5.getSeriesPaint((int) (short) 100);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer5.setSeriesItemLabelFont((int) (short) 10, font22, false);
        java.awt.Color color25 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("", font22, (java.awt.Paint) color25);
        java.awt.Color color27 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("hi!", font22, (java.awt.Paint) color27);
        float float29 = textFragment28.getBaselineOffset();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            float float32 = textFragment28.calculateBaselineOffset(graphics2D30, textAnchor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor31);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        java.util.List list14 = jFreeChart10.getSubtitles();
        org.jfree.chart.plot.Plot plot15 = jFreeChart10.getPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.configure();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.CYAN;
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("hi!", font20, (java.awt.Paint) color21);
        categoryAxis16.setTickLabelFont((java.lang.Comparable) 0.5f, font20);
        double double24 = categoryAxis16.getLabelAngle();
        java.awt.Font font26 = null;
        categoryAxis16.setTickLabelFont((java.lang.Comparable) 0, font26);
        int int28 = categoryAxis16.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator30 = ringPlot29.getToolTipGenerator();
        java.lang.Object obj31 = ringPlot29.clone();
        boolean boolean32 = ringPlot29.getAutoPopulateSectionPaint();
        double double33 = ringPlot29.getInnerSeparatorExtension();
        double double34 = ringPlot29.getOuterSeparatorExtension();
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot29.setSeparatorStroke(stroke35);
        categoryAxis16.setAxisLineStroke(stroke35);
        jFreeChart10.setBorderStroke(stroke35);
        jFreeChart10.clearSubtitles();
        try {
            org.jfree.chart.title.Title title41 = jFreeChart10.getSubtitle(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(pieToolTipGenerator30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot2.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4);
        java.awt.Paint paint8 = combinedRangeXYPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        dateAxis11.setInverted(true);
        combinedRangeXYPlot2.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone15 = dateAxis11.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone15);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone15;
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(116.0d, (double) (byte) 100, paint3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape10 = xYStepAreaRenderer6.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color12);
        java.lang.Object obj14 = legendGraphic13.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendGraphic13.getFillPaintTransformer();
        intervalMarker4.setGradientPaintTransformer(gradientPaintTransformer15);
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer15);
        org.jfree.chart.LegendItem legendItem20 = xYBarRenderer0.getLegendItem(6, (int) (short) -1);
        xYBarRenderer0.setShadowYOffset(1.0E-5d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNull(legendItem20);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot2.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4);
        java.awt.Paint paint8 = combinedRangeXYPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        dateAxis11.setInverted(true);
        combinedRangeXYPlot2.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone15 = dateAxis11.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone15);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor18 = org.jfree.data.time.TimePeriodAnchor.END;
        timeSeriesCollection17.setXPosition(timePeriodAnchor18);
        try {
            int int21 = timeSeriesCollection17.getItemCount((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timePeriodAnchor18);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.String[] strArray2 = org.jfree.data.time.SerialDate.getMonths(true);
        org.jfree.chart.axis.SymbolAxis symbolAxis3 = new org.jfree.chart.axis.SymbolAxis("^-0.0", strArray2);
        org.jfree.data.RangeType rangeType4 = symbolAxis3.getRangeType();
        java.lang.String[] strArray5 = symbolAxis3.getSymbols();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        int int4 = waferMapPlot1.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis5.setPlot((org.jfree.chart.plot.Plot) waferMapPlot6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator9, xYURLGenerator10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYStepAreaRenderer11.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color17 = java.awt.Color.RED;
        xYStepAreaRenderer11.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color17, false);
        categoryAxis5.setAxisLinePaint((java.awt.Paint) color17);
        waferMapPlot1.setOutlinePaint((java.awt.Paint) color17);
        int int22 = color17.getTransparency();
        java.awt.Color color23 = color17.brighter();
        float[] floatArray30 = new float[] { 0.5f, 0L, 86400000L, 10L, (-61049779200000L), 64 };
        float[] floatArray31 = color17.getRGBColorComponents(floatArray30);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint((-2236514));
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) '#');
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.awt.geom.Point2D point2D7 = combinedRangeXYPlot3.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot3.getRangeAxisEdge();
        boolean boolean9 = combinedRangeXYPlot3.isRangePannable();
        combinedRangeXYPlot3.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        boolean boolean3 = ringPlot0.getAutoPopulateSectionPaint();
        double double4 = ringPlot0.getInnerSeparatorExtension();
        double double5 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Paint paint6 = ringPlot0.getLabelOutlinePaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
        java.awt.Shape shape12 = xYStepAreaRenderer8.getItemShape((-1), (int) 'a', false);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity13 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        java.awt.Color color14 = java.awt.Color.ORANGE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color14);
        boolean boolean16 = legendGraphic15.isShapeFilled();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendGraphic15.setOutlineStroke(stroke17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot20 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis19.setPlot((org.jfree.chart.plot.Plot) waferMapPlot20);
        float float22 = waferMapPlot20.getBackgroundImageAlpha();
        waferMapPlot20.setNoDataMessage("");
        java.awt.Stroke stroke25 = waferMapPlot20.getOutlineStroke();
        legendGraphic15.setOutlineStroke(stroke25);
        ringPlot0.setLabelOutlineStroke(stroke25);
        ringPlot0.setAutoPopulateSectionOutlinePaint(true);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator5, xYURLGenerator6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYStepAreaRenderer7.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYStepAreaRenderer7.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYStepAreaRenderer7.initialise(graphics2D15, rectangle2D16, xYPlot17, xYDataset18, plotRenderingInfo19);
        java.awt.Paint paint22 = xYStepAreaRenderer7.getSeriesPaint((int) (short) 100);
        boolean boolean23 = xYStepAreaRenderer7.getBaseSeriesVisible();
        java.awt.Color color24 = java.awt.Color.GRAY;
        xYStepAreaRenderer7.setBaseOutlinePaint((java.awt.Paint) color24);
        xYStepAreaRenderer7.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYStepAreaRenderer7.getBasePositiveItemLabelPosition();
        boolean boolean31 = axisLocation3.equals((java.lang.Object) itemLabelPosition30);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset2 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset2.setValue((java.lang.Comparable) 1.0f, (java.lang.Number) 1.0f);
        java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset2, (java.lang.Comparable) 1.0f);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator11, xYURLGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepAreaRenderer13.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        xYStepAreaRenderer13.setBaseToolTipGenerator(xYToolTipGenerator18, false);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYStepAreaRenderer13.initialise(graphics2D21, rectangle2D22, xYPlot23, xYDataset24, plotRenderingInfo25);
        java.awt.Paint paint28 = xYStepAreaRenderer13.getSeriesPaint((int) (short) 100);
        java.awt.Font font30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer13.setSeriesItemLabelFont((int) (short) 10, font30, false);
        java.awt.Color color33 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("", font30, (java.awt.Paint) color33);
        java.awt.Color color35 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("hi!", font30, (java.awt.Paint) color35);
        boolean boolean37 = standardPieSectionLabelGenerator0.equals((java.lang.Object) color35);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(attributedString7);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = combinedRangeXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot9.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11);
        java.awt.Paint paint15 = combinedRangeXYPlot9.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot9.getDomainAxisLocation(9999);
        combinedRangeXYPlot1.setRangeAxisLocation(axisLocation17, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        combinedRangeXYPlot1.datasetChanged(datasetChangeEvent20);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = null;
        try {
            combinedRangeXYPlot1.setOrientation(plotOrientation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset(0);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot1, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) borderArrangement6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle7.getLegendItemGraphicLocation();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle9.getHorizontalAlignment();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator16, xYURLGenerator17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepAreaRenderer18.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        xYStepAreaRenderer18.setBaseToolTipGenerator(xYToolTipGenerator23, false);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState31 = xYStepAreaRenderer18.initialise(graphics2D26, rectangle2D27, xYPlot28, xYDataset29, plotRenderingInfo30);
        java.awt.Paint paint33 = xYStepAreaRenderer18.getSeriesPaint((int) (short) 100);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer18.setSeriesItemLabelFont((int) (short) 10, font35, false);
        java.awt.Color color38 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("", font35, (java.awt.Paint) color38);
        java.awt.Color color40 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis41);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis43);
        org.jfree.chart.axis.AxisLocation axisLocation46 = combinedRangeXYPlot44.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot42.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot44);
        java.awt.geom.Point2D point2D48 = combinedRangeXYPlot44.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = combinedRangeXYPlot44.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("100", font35, (java.awt.Paint) color40, rectangleEdge49, horizontalAlignment50, verticalAlignment51, rectangleInsets52);
        double double55 = rectangleInsets52.calculateRightInset((double) (-457));
        textTitle9.setPadding(rectangleInsets52);
        legendTitle7.setLegendItemGraphicPadding(rectangleInsets52);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(xYItemRendererState31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke4 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace5, false);
        java.awt.Paint paint8 = combinedRangeXYPlot1.getDomainMinorGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedRangeXYPlot1.getLegendItems();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        combinedRangeXYPlot4.setNotify(false);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultXYDataset0, jFreeChart10, (int) ' ', 9999);
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart10.removeProgressListener(chartProgressListener14);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setSeriesShapesVisible((int) (byte) 10, false);
        java.awt.Stroke stroke7 = null;
        xYStepRenderer2.setSeriesStroke((int) ' ', stroke7);
        java.awt.Paint paint9 = xYStepRenderer2.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYAreaRenderer2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) xYAreaRenderer2);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("JFreeChart");
        xYAreaRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = xYAreaRenderer2.getToolTipGenerator(15, (int) (short) 10, true);
        xYAreaRenderer2.setAutoPopulateSeriesPaint(true);
        java.awt.Font font17 = xYAreaRenderer2.getItemLabelFont(2147483647, (int) (byte) 0, true);
        org.jfree.chart.plot.XYPlot xYPlot18 = xYAreaRenderer2.getPlot();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(xYPlot18);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        java.lang.Object obj2 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        ringPlot0.setShadowXOffset((double) (byte) 10);
        java.awt.Stroke stroke7 = ringPlot0.getLabelOutlineStroke();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Paint paint5 = ringPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) waferMapPlot1);
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.Plot plot4 = waferMapPlot1.getRootPlot();
        java.awt.Paint paint5 = null;
        waferMapPlot1.setBackgroundPaint(paint5);
        try {
            waferMapPlot1.setBackgroundImageAlpha((float) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) -1, (float) 10);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = polarPlot3.getDataRange(valueAxis6);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer8.setAutoPopulateSeriesPaint(true);
        double double11 = xYAreaRenderer8.getItemLabelAnchorOffset();
        boolean boolean12 = xYAreaRenderer8.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot17.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot15.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot15.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator26, xYURLGenerator27);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = xYStepAreaRenderer28.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color34 = java.awt.Color.RED;
        xYStepAreaRenderer28.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color34, false);
        categoryAxis24.setTickLabelPaint((java.awt.Paint) color34);
        java.awt.Paint paint38 = categoryAxis24.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = combinedRangeXYPlot40.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke43 = combinedRangeXYPlot40.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint38, stroke43);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = combinedRangeXYPlot15.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker44, layer45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke52 = null;
        xYAreaRenderer8.drawRangeLine(graphics2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) dateAxis48, rectangle2D49, (double) 60000L, paint51, stroke52);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot54 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.data.Range range55 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = null;
        dateAxis48.setTickUnit(dateTickUnit57, false, false);
        org.jfree.chart.entity.AxisEntity axisEntity63 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) dateAxis48, "-3,-3,3,3", "index.html");
        org.jfree.data.Range range64 = dateAxis48.getRange();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertNotNull(range64);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer4.getBasePositiveItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        barRenderer3D0.setDrawBarOutline(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = barRenderer3D0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        org.jfree.chart.RenderingSource renderingSource2 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = chartRenderingInfo0.getEntityCollection();
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
        org.junit.Assert.assertNotNull(entityCollection4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer4.getNegativeItemLabelPosition(0, (int) 'a', false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYStepAreaRenderer4.setBaseToolTipGenerator(xYToolTipGenerator9, false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = xYStepAreaRenderer4.initialise(graphics2D12, rectangle2D13, xYPlot14, xYDataset15, plotRenderingInfo16);
        java.awt.Paint paint19 = xYStepAreaRenderer4.getSeriesPaint((int) (short) 100);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYStepAreaRenderer4.setSeriesItemLabelFont((int) (short) 10, font21, false);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color24);
        java.lang.Object obj26 = labelBlock25.clone();
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(xYItemRendererState17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        combinedRangeXYPlot1.setDomainAxis(100, valueAxis3, true);
        java.awt.Stroke stroke6 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        java.lang.String str7 = combinedRangeXYPlot1.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot9.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset15 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot9.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset15);
        java.lang.Object obj17 = defaultXYDataset15.clone();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset15, valueAxis18, polarItemRenderer19);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        polarPlot20.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
        polarPlot20.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit24);
        boolean boolean26 = combinedRangeXYPlot1.equals((java.lang.Object) numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Combined Range XYPlot" + "'", str7.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.visible = true;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getHorizontalAlignment();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle1);
        textTitle1.setMaximumLinesToDisplay(9);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot1.getFixedLegendItems();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer6.setAutoPopulateSeriesPaint(true);
        double double9 = xYAreaRenderer6.getItemLabelAnchorOffset();
        boolean boolean10 = xYAreaRenderer6.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot15.getDomainAxisLocation((int) (byte) 0);
        combinedRangeXYPlot13.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot13.setDataset((org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1, xYToolTipGenerator24, xYURLGenerator25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYStepAreaRenderer26.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.awt.Color color32 = java.awt.Color.RED;
        xYStepAreaRenderer26.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color32, false);
        categoryAxis22.setTickLabelPaint((java.awt.Paint) color32);
        java.awt.Paint paint36 = categoryAxis22.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = combinedRangeXYPlot38.getDomainAxisLocation((int) (byte) 0);
        java.awt.Stroke stroke41 = combinedRangeXYPlot38.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint36, stroke41);
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = combinedRangeXYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker42, layer43);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke50 = null;
        xYAreaRenderer6.drawRangeLine(graphics2D11, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis46, rectangle2D47, (double) 60000L, paint49, stroke50);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot52 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis46);
        combinedRangeXYPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis46);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier54 = combinedRangeXYPlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(drawingSupplier54);
    }
}

