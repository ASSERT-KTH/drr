import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int3 = java.awt.Color.HSBtoRGB((float) 'a', (float) (short) -1, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 0L, (double) (-16777216), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType4, lengthAdjustmentType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = java.awt.Color.GRAY;
        float[] floatArray4 = new float[] { 100, 192, 1L };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) (-1));
        double double6 = rectangleInsets0.calculateBottomInset(0.0d);
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.Plot plot9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace13 = dateAxis0.reserveSpace(graphics2D8, plot9, rectangle2D10, rectangleEdge11, axisSpace12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange(0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        dateAxis0.zoomRange(0.0d, (double) (short) 0);
        boolean boolean12 = dateAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        categoryMarker1.setAlpha((float) (byte) 1);
        try {
            categoryMarker1.setAlpha((float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
//        boolean boolean3 = dateAxis0.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D5 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
//        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
//        boolean boolean8 = dateAxis0.isAutoRange();
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        long long12 = day11.getLastMillisecond();
//        java.util.Date date13 = day11.getStart();
//        try {
//            dateAxis0.setRange(date9, date13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(paint1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        float[] floatArray3 = new float[] { (-1), 11 };
        try {
            float[] floatArray4 = color0.getColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color5.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.calculateLeftOutset((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftInset((double) (byte) 0);
        double double4 = rectangleInsets0.calculateBottomOutset((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((int) ' ');
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day1.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.Range range7 = null;
        try {
            dateAxis0.setRange(range7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        double double4 = dateAxis0.getLowerMargin();
        try {
            dateAxis0.setRange((double) 1560495599999L, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            categoryPlot6.drawOutline(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftInset((double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        float float12 = dateAxis0.getTickMarkOutsideLength();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis0.setRightArrow(shape13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            boolean boolean14 = categoryPlot6.removeAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        try {
            numberAxis0.setRangeAboutValue((double) ' ', (-3.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (33.5) <= upper (30.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        boolean boolean16 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean19 = categoryPlot6.removeAnnotation(categoryAnnotation17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) (-1));
        double double6 = rectangleInsets0.calculateBottomInset(0.0d);
        double double8 = rectangleInsets0.calculateBottomOutset((double) '#');
        double double9 = rectangleInsets0.getBottom();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            boolean boolean17 = categoryPlot6.removeAnnotation(categoryAnnotation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        boolean boolean4 = dateAxis1.isVisible();
        try {
            dateAxis1.setRange((double) 9, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            boolean boolean9 = categoryPlot6.removeAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        dateAxis2.setLeftArrow(shape8);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        org.jfree.chart.plot.Plot plot9 = dateAxis0.getPlot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        java.awt.Color color11 = java.awt.Color.GREEN;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color11);
        int int13 = color11.getAlpha();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setUpArrow(shape5);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRendererForDataset(categoryDataset8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis((int) '4');
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke15);
        categoryPlot6.setRangeCrosshairStroke(stroke15);
        float float18 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.extendWidth(0.0d);
        double double23 = rectangleInsets19.trimWidth((double) (-1));
        double double25 = rectangleInsets19.calculateBottomInset(0.0d);
        categoryPlot6.setInsets(rectangleInsets19, false);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        categoryPlot6.drawBackgroundImage(graphics2D28, rectangle2D29);
        org.jfree.chart.plot.Plot plot31 = categoryPlot6.getParent();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-3.0d) + "'", double23 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNull(plot31);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis3.setRightArrow(shape4);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer6);
//        categoryPlot7.clearDomainMarkers();
//        categoryPlot7.zoom((double) (byte) -1);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
//        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis14.setAxisLineStroke(stroke15);
//        java.awt.Color color17 = java.awt.Color.BLUE;
//        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color12, stroke15, (java.awt.Paint) color17, stroke18, (float) (byte) 0);
//        categoryPlot7.setRangeCrosshairStroke(stroke15);
//        boolean boolean22 = day0.equals((java.lang.Object) stroke15);
//        long long23 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(shape4);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(stroke15);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str6 = lengthAdjustmentType5.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType4, lengthAdjustmentType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "NO_CHANGE" + "'", str6.equals("NO_CHANGE"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.Color color25 = java.awt.Color.MAGENTA;
        categoryPlot23.setRangeCrosshairPaint((java.awt.Paint) color25);
        int int27 = color25.getRGB();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-65281) + "'", int27 == (-65281));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot6.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(sortOrder24);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        java.awt.Paint paint4 = categoryMarker1.getOutlinePaint();
        java.lang.Object obj5 = categoryMarker1.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        float float12 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.zoomRange((double) 0.0f, (double) (short) 100);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.Class<?> wildcardClass17 = color16.getClass();
        dateAxis0.setLabelPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.text.NumberFormat numberFormat2 = null;
        numberAxis1.setNumberFormatOverride(numberFormat2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot13.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17, true);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setRightArrow(shape23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer25);
        categoryPlot26.clearAnnotations();
        categoryPlot26.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot26.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str33 = axisLocation32.toString();
        categoryPlot26.setRangeAxisLocation(axisLocation32);
        categoryPlot13.setDomainAxisLocation(axisLocation32, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation32, plotOrientation37);
        try {
            java.util.List list39 = numberAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str33.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        java.lang.String str12 = categoryPlot6.getPlotType();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot6.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot6.setDomainAxis(500, categoryAxis17, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) (-1));
        double double6 = rectangleInsets0.calculateBottomInset(0.0d);
        double double8 = rectangleInsets0.calculateBottomOutset((double) '#');
        java.lang.Class<?> wildcardClass9 = rectangleInsets0.getClass();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        dateAxis1.setLabelPaint(paint4);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke12);
        java.awt.Color color14 = java.awt.Color.BLUE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color9, stroke12, (java.awt.Paint) color14, stroke15, (float) (byte) 0);
        dateAxis1.setTickMarkStroke(stroke12);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        categoryPlot23.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot23.zoomDomainAxes(0.0d, plotRenderingInfo26, point2D27, true);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis32.setRightArrow(shape33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer35);
        categoryPlot36.clearAnnotations();
        categoryPlot36.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot36.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str43 = axisLocation42.toString();
        categoryPlot36.setRangeAxisLocation(axisLocation42);
        categoryPlot23.setDomainAxisLocation(axisLocation42, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation42, plotOrientation47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            org.jfree.chart.axis.AxisState axisState50 = dateAxis0.draw(graphics2D13, (double) 9, rectangle2D15, rectangle2D16, rectangleEdge48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str43.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getBottom();
        double double2 = rectangleInsets0.getBottom();
        double double4 = rectangleInsets0.calculateTopInset((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createInsetRectangle(rectangle2D5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        int int2 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        dateAxis2.configure();
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        try {
            dateAxis1.setRange((double) (short) 100, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setAnchorValue(Double.NEGATIVE_INFINITY);
        categoryPlot6.setDrawSharedDomainAxis(true);
        boolean boolean15 = categoryPlot6.isRangeZoomable();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setAnchorValue(Double.NEGATIVE_INFINITY);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot6.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets13.createInsetRectangle(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelAngle(0.05d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        boolean boolean16 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        double double17 = intervalMarker15.getStartValue();
        org.jfree.chart.util.UnitType unitType18 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean19 = intervalMarker15.equals((java.lang.Object) unitType18);
        java.lang.Object obj20 = intervalMarker15.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.6777216E7d) + "'", double17 == (-1.6777216E7d));
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis0.getMarkerBand();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis12.setRightArrow(shape13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer15);
        categoryPlot16.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot16.zoomDomainAxes(0.0d, plotRenderingInfo19, point2D20, true);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis25.setRightArrow(shape26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer28);
        categoryPlot29.clearAnnotations();
        categoryPlot29.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot29.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        categoryPlot29.setRangeAxisLocation(axisLocation35);
        categoryPlot16.setDomainAxisLocation(axisLocation35, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation35, plotOrientation40);
        try {
            java.util.List list42 = numberAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis3.setRightArrow(shape4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer6);
        categoryPlot7.clearDomainMarkers();
        categoryPlot7.zoom((double) (byte) -1);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color12, stroke15, (java.awt.Paint) color17, stroke18, (float) (byte) 0);
        categoryPlot7.setRangeCrosshairStroke(stroke15);
        boolean boolean22 = day0.equals((java.lang.Object) stroke15);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day0.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        float float10 = valueMarker9.getAlpha();
        double double11 = valueMarker9.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        java.awt.Color color11 = java.awt.Color.GREEN;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color11);
        int int13 = color11.getGreen();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis3.setRightArrow(shape4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer6);
        categoryPlot7.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes(0.0d, plotRenderingInfo10, point2D11, true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis16.setRightArrow(shape17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer19);
        categoryPlot20.clearAnnotations();
        categoryPlot20.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot20.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str27 = axisLocation26.toString();
        categoryPlot20.setRangeAxisLocation(axisLocation26);
        categoryPlot7.setDomainAxisLocation(axisLocation26, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation26, plotOrientation31);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str27.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType3);
        categoryMarker1.setKey((java.lang.Comparable) 15);
        java.lang.Comparable comparable7 = categoryMarker1.getKey();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 15 + "'", comparable7.equals(15));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        double double8 = categoryPlot6.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setRightArrow(shape11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer13);
        categoryPlot14.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot14.zoomDomainAxes(0.0d, plotRenderingInfo17, point2D18, true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis23.setRightArrow(shape24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer26);
        categoryPlot27.clearAnnotations();
        categoryPlot27.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot27.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str34 = axisLocation33.toString();
        categoryPlot27.setRangeAxisLocation(axisLocation33);
        categoryPlot14.setDomainAxisLocation(axisLocation33, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation33, plotOrientation38);
        try {
            double double40 = numberAxis0.valueToJava2D((double) 2019, rectangle2D7, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str34.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            java.awt.Color color1 = java.awt.Color.decode("UnitType.ABSOLUTE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UnitType.ABSOLUTE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int3 = java.awt.Color.HSBtoRGB((float) 10, (float) 9, (float) 1560495599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-65536) + "'", int3 == (-65536));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot22.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str29 = axisLocation28.toString();
        categoryPlot22.setRangeAxisLocation(axisLocation28);
        categoryPlot6.setDomainAxisLocation((int) (short) 0, axisLocation28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        double double39 = categoryPlot38.getRangeCrosshairValue();
        boolean boolean40 = categoryPlot38.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot38.getDomainAxisLocation(2);
        categoryPlot6.setRangeAxisLocation(axisLocation42, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot6.getDomainAxis((int) (short) 0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str29.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNull(categoryAxis46);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setUpperMargin((double) 7);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot13.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17, true);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setRightArrow(shape23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer25);
        categoryPlot26.clearAnnotations();
        categoryPlot26.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot26.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str33 = axisLocation32.toString();
        categoryPlot26.setRangeAxisLocation(axisLocation32);
        categoryPlot13.setDomainAxisLocation(axisLocation32, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation32, plotOrientation37);
        try {
            double double39 = categoryAxis1.getCategoryEnd(7, 1, rectangle2D6, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str33.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        java.awt.Shape shape8 = dateAxis1.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis1.valueToJava2D((double) (short) 100, rectangle2D10, rectangleEdge11);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setRightArrow(shape18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer20);
        categoryPlot21.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot21.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25, true);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis30.setRightArrow(shape31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer33);
        categoryPlot34.clearAnnotations();
        categoryPlot34.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis39 = categoryPlot34.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str41 = axisLocation40.toString();
        categoryPlot34.setRangeAxisLocation(axisLocation40);
        categoryPlot21.setDomainAxisLocation(axisLocation40, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation40, plotOrientation45);
        try {
            double double47 = dateAxis1.valueToJava2D((double) 1560452399999L, rectangle2D14, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str41.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        java.awt.Font font43 = categoryAxis37.getTickLabelFont((java.lang.Comparable) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions44 = null;
        try {
            categoryAxis37.setCategoryLabelPositions(categoryLabelPositions44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setRightArrow(shape11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer13);
        categoryPlot14.clearAnnotations();
        categoryPlot14.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot14.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str21 = axisLocation20.toString();
        categoryPlot14.setRangeAxisLocation(axisLocation20);
        categoryPlot6.setRangeAxisLocation(11, axisLocation20, false);
        double double25 = categoryPlot6.getAnchorValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str21.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        dateAxis0.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint12 = dateAxis0.getLabelPaint();
        java.awt.Stroke stroke13 = dateAxis0.getTickMarkStroke();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint18 = dateAxis17.getTickLabelPaint();
        boolean boolean20 = dateAxis17.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis17.lengthToJava2D((double) 'a', rectangle2D22, rectangleEdge23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis17.setTickLabelPaint((java.awt.Paint) color25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis17.setAxisLinePaint((java.awt.Paint) color27);
        boolean boolean29 = dateAxis17.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis17.setRange((org.jfree.data.Range) dateRange30, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer39);
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        double double44 = categoryAxis43.getUpperMargin();
        categoryAxis43.setMaximumCategoryLabelLines(2);
        java.awt.Color color47 = java.awt.Color.DARK_GRAY;
        categoryAxis43.setLabelPaint((java.awt.Paint) color47);
        categoryAxis43.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int52 = categoryPlot40.getDomainAxisIndex(categoryAxis43);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot40.getDomainAxisEdge((int) '4');
        try {
            java.util.List list55 = dateAxis0.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateRange30);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder11);
        double double13 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setRightArrow(shape18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer20);
        categoryPlot21.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot21.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25, true);
        java.awt.Paint paint28 = categoryPlot21.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot21.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(5, axisLocation29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot6.getDomainAxisForDataset(1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(categoryAxis32);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        boolean boolean16 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        categoryPlot6.setAnchorValue((double) (-16777216));
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.general.DatasetGroup datasetGroup42 = categoryPlot23.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis45.setRightArrow(shape46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer48);
        categoryPlot49.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot49.zoomDomainAxes(0.0d, plotRenderingInfo52, point2D53, true);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis58.setRightArrow(shape59);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis58, categoryItemRenderer61);
        categoryPlot62.clearAnnotations();
        categoryPlot62.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot62.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation68 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str69 = axisLocation68.toString();
        categoryPlot62.setRangeAxisLocation(axisLocation68);
        categoryPlot49.setDomainAxisLocation(axisLocation68, true);
        java.awt.Paint paint73 = categoryPlot49.getNoDataMessagePaint();
        categoryPlot23.setRangeCrosshairPaint(paint73);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer76 = categoryPlot23.getRenderer((int) (short) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNull(valueAxis67);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str69.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNull(categoryItemRenderer76);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        java.lang.String str2 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.RIGHT" + "'", str1.equals("RectangleAnchor.RIGHT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.RIGHT" + "'", str2.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double8 = intervalMarker7.getEndValue();
        boolean boolean9 = numberAxis2.equals((java.lang.Object) intervalMarker7);
        boolean boolean10 = objectList1.equals((java.lang.Object) intervalMarker7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        boolean boolean16 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        double double17 = intervalMarker15.getStartValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker15.setGradientPaintTransformer(gradientPaintTransformer18);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.6777216E7d) + "'", double17 == (-1.6777216E7d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis1.setTickLabelFont(font7);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker1.setLabelFont(font5);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 0.05d, dataset1);
        java.lang.Object obj3 = datasetChangeEvent2.getSource();
        java.lang.String str4 = datasetChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 0.05d + "'", obj3.equals(0.05d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=0.05]" + "'", str4.equals("org.jfree.data.general.DatasetChangeEvent[source=0.05]"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource8);
        java.lang.Object obj10 = dateAxis1.clone();
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color11);
        java.awt.Paint paint13 = null;
        try {
            dateAxis1.setTickMarkPaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.Class<?> wildcardClass4 = color3.getClass();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getComponents(floatArray6);
        float[] floatArray8 = color3.getColorComponents(floatArray6);
        float[] floatArray9 = java.awt.Color.RGBtoHSB((int) (short) -1, (-1), (int) (byte) 0, floatArray6);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer7);
        categoryPlot8.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot8.zoomDomainAxes(0.0d, plotRenderingInfo11, point2D12, true);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setAxisLineStroke(stroke17);
        categoryPlot8.setRangeCrosshairStroke(stroke17);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis23.setRightArrow(shape24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer26);
        categoryPlot27.clearDomainMarkers();
        categoryPlot27.zoom((double) (byte) -1);
        java.awt.Stroke stroke31 = categoryPlot27.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint33 = dateAxis32.getTickLabelPaint();
        boolean boolean35 = dateAxis32.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis32.lengthToJava2D((double) 'a', rectangle2D37, rectangleEdge38);
        boolean boolean40 = dateAxis32.isAutoRange();
        dateAxis32.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint44 = dateAxis32.getLabelPaint();
        java.awt.Stroke stroke45 = dateAxis32.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke48);
        java.awt.Stroke[] strokeArray50 = new java.awt.Stroke[] { stroke17, stroke20, stroke31, stroke45, stroke48 };
        java.awt.Stroke[] strokeArray51 = null;
        java.awt.Shape[] shapeArray52 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier53 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray50, strokeArray51, shapeArray52);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(strokeArray50);
        org.junit.Assert.assertNotNull(shapeArray52);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setUpperMargin((double) 7);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color5, stroke8, (java.awt.Paint) color10, stroke11, (float) (byte) 0);
        categoryAxis1.setAxisLineStroke(stroke11);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getTickLabelPaint();
        boolean boolean18 = dateAxis15.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = dateAxis15.lengthToJava2D((double) 'a', rectangle2D20, rectangleEdge21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis15.setAxisLinePaint((java.awt.Paint) color25);
        boolean boolean27 = dateAxis15.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis15.setRange((org.jfree.data.Range) dateRange28, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        double double42 = categoryAxis41.getUpperMargin();
        categoryAxis41.setMaximumCategoryLabelLines(2);
        java.awt.Color color45 = java.awt.Color.DARK_GRAY;
        categoryAxis41.setLabelPaint((java.awt.Paint) color45);
        categoryAxis41.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int50 = categoryPlot38.getDomainAxisIndex(categoryAxis41);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        double double53 = categoryAxis52.getUpperMargin();
        categoryAxis52.setLabelURL("RectangleAnchor.RIGHT");
        int int56 = categoryPlot38.getDomainAxisIndex(categoryAxis52);
        org.jfree.data.general.DatasetGroup datasetGroup57 = categoryPlot38.getDatasetGroup();
        boolean boolean58 = categoryPlot38.getDrawSharedDomainAxis();
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNull(datasetGroup57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomRangeAxes((double) '4', plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace15, true);
        boolean boolean18 = categoryPlot6.isDomainZoomable();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setRightArrow(shape1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets3.getBottom();
        double double5 = rectangleInsets3.getBottom();
        double double7 = rectangleInsets3.calculateLeftOutset((double) 10L);
        dateAxis0.setLabelInsets(rectangleInsets3);
        double double9 = rectangleInsets3.getTop();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets3.createInsetRectangle(rectangle2D10, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        float float12 = dateAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getTickLabelPaint();
        boolean boolean16 = dateAxis13.isHiddenValue(10L);
        java.lang.Object obj17 = dateAxis13.clone();
        dateAxis13.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setRightArrow(shape23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer25);
        categoryPlot26.clearAnnotations();
        dateAxis13.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot26.getDomainAxisForDataset((int) '4');
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot26);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(categoryAxis30);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        java.awt.Stroke stroke10 = categoryPlot6.getRangeGridlineStroke();
        categoryPlot6.clearRangeAxes();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        categoryPlot6.clearDomainMarkers((int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot6.getRangeAxis();
        org.jfree.chart.util.SortOrder sortOrder27 = null;
        try {
            categoryPlot6.setRowRenderingOrder(sortOrder27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(valueAxis26);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        double double42 = categoryAxis37.getLowerMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor45 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint50 = dateAxis49.getTickLabelPaint();
        boolean boolean52 = dateAxis49.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = dateAxis49.lengthToJava2D((double) 'a', rectangle2D54, rectangleEdge55);
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis49.setTickLabelPaint((java.awt.Paint) color57);
        java.awt.Color color59 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis49.setAxisLinePaint((java.awt.Paint) color59);
        boolean boolean61 = dateAxis49.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange62 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis49.setRange((org.jfree.data.Range) dateRange62, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset66 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape69 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis68.setRightArrow(shape69);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, (org.jfree.chart.axis.ValueAxis) dateAxis68, categoryItemRenderer71);
        dateAxis49.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot72);
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = new org.jfree.chart.axis.CategoryAxis("");
        double double76 = categoryAxis75.getUpperMargin();
        categoryAxis75.setMaximumCategoryLabelLines(2);
        java.awt.Color color79 = java.awt.Color.DARK_GRAY;
        categoryAxis75.setLabelPaint((java.awt.Paint) color79);
        categoryAxis75.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int84 = categoryPlot72.getDomainAxisIndex(categoryAxis75);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = categoryPlot72.getDomainAxisEdge((int) '4');
        try {
            double double87 = categoryAxis37.getCategoryJava2DCoordinate(categoryAnchor45, 2, 0, rectangle2D48, rectangleEdge86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(categoryAnchor45);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateRange62);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge86);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Stroke stroke3 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryMarker5.notifyListeners(markerChangeEvent6);
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryMarker5.setPaint(paint8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 12, 0.0d, (java.awt.Paint) color2, stroke3, paint8, stroke10, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        try {
            double double48 = categoryAxis37.getCategorySeriesMiddle((java.lang.Comparable) (byte) 0, (java.lang.Comparable) "UnitType.RELATIVE", categoryDataset44, (double) 11, rectangle2D46, rectangleEdge47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource8);
        java.lang.Object obj10 = dateAxis1.clone();
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color11);
        dateAxis1.setLowerMargin((double) 'a');
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double3 = intervalMarker2.getEndValue();
        java.lang.Object obj4 = intervalMarker2.clone();
        java.lang.Class class5 = null;
        try {
            java.util.EventListener[] eventListenerArray6 = intervalMarker2.getListeners(class5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        java.awt.Paint paint4 = categoryMarker1.getOutlinePaint();
        try {
            categoryMarker1.setAlpha((float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        float float10 = valueMarker9.getAlpha();
        valueMarker9.setAlpha((float) 0L);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot6.getDomainMarkers((int) '4', layer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace15, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Paint paint3 = categoryMarker1.getOutlinePaint();
        java.awt.Paint paint4 = null;
        try {
            categoryMarker1.setLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean7 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setAxisLineStroke(stroke5);
        java.awt.Color color7 = java.awt.Color.BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color2, stroke5, (java.awt.Paint) color7, stroke8, (float) (byte) 0);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) false);
        valueMarker10.setOutlinePaint((java.awt.Paint) color11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setRightArrow(shape18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer20);
        categoryPlot21.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        categoryPlot21.notifyListeners(plotChangeEvent23);
        java.lang.String str25 = categoryPlot21.getNoDataMessage();
        java.awt.Color color26 = java.awt.Color.GREEN;
        categoryPlot21.setDomainGridlinePaint((java.awt.Paint) color26);
        int int28 = color26.getGreen();
        java.awt.Color color29 = java.awt.Color.GREEN;
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis32.setRightArrow(shape33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer35);
        categoryPlot36.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot36.zoomDomainAxes(0.0d, plotRenderingInfo39, point2D40, true);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setAxisLineStroke(stroke45);
        categoryPlot36.setRangeCrosshairStroke(stroke45);
        float float48 = categoryPlot36.getForegroundAlpha();
        java.awt.Paint paint49 = categoryPlot36.getRangeGridlinePaint();
        java.awt.Color color50 = java.awt.Color.black;
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray52 = new java.awt.Paint[] { color11, color26, color29, paint49, color50, color51 };
        java.awt.Stroke[] strokeArray53 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker57 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        java.awt.Stroke stroke58 = intervalMarker57.getStroke();
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape61 = defaultDrawingSupplier60.getNextShape();
        java.awt.Stroke stroke62 = defaultDrawingSupplier60.getNextOutlineStroke();
        java.awt.Stroke stroke63 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray64 = new java.awt.Stroke[] { stroke54, stroke58, stroke59, stroke62, stroke63 };
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint66 = dateAxis65.getTickLabelPaint();
        boolean boolean68 = dateAxis65.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = dateAxis65.lengthToJava2D((double) 'a', rectangle2D70, rectangleEdge71);
        java.awt.Color color73 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis65.setTickLabelPaint((java.awt.Paint) color73);
        java.awt.Color color75 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis65.setAxisLinePaint((java.awt.Paint) color75);
        float float77 = dateAxis65.getTickMarkOutsideLength();
        java.awt.Shape shape78 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis65.setRightArrow(shape78);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke82 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis81.setAxisLineStroke(stroke82);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition84 = dateAxis81.getTickMarkPosition();
        java.awt.Shape shape85 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis81.setUpArrow(shape85);
        java.awt.Shape[] shapeArray87 = new java.awt.Shape[] { shape78, shape85 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier88 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray52, strokeArray53, strokeArray64, shapeArray87);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 1.0f + "'", float48 == 1.0f);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(paintArray52);
        org.junit.Assert.assertNotNull(strokeArray53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(strokeArray64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 2.0f + "'", float77 == 2.0f);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(dateTickMarkPosition84);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(shapeArray87);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = null;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 100, (java.awt.Paint) color1, stroke2, paint3, stroke4, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot19.notifyListeners(plotChangeEvent21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot19.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder24 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot19.setRowRenderingOrder(sortOrder24);
        double double26 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis31.setRightArrow(shape32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer34);
        categoryPlot35.clearAnnotations();
        categoryPlot35.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot35.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot35.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray43 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot35.setRenderers(categoryItemRendererArray43);
        categoryPlot11.setRenderers(categoryItemRendererArray43);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        categoryPlot11.setDataset(categoryDataset46);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(categoryItemRendererArray43);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        boolean boolean9 = dateAxis1.isAxisLineVisible();
        dateAxis1.setPositiveArrowVisible(false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateRange12);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        boolean boolean4 = dateAxis0.isAutoRange();
        double double5 = dateAxis0.getFixedAutoRange();
        dateAxis0.setAutoTickUnitSelection(false, false);
        java.util.Date date9 = null;
        java.lang.Class class10 = null;
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        try {
            dateAxis0.setRange(date9, date11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        try {
            categoryPlot9.setDomainAxisLocation(axisLocation14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot9.getRenderer();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        categoryPlot13.clearRangeMarkers(192);
        float float20 = categoryPlot13.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLabelURL("RectangleAnchor.RIGHT");
        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        boolean boolean2 = unitType0.equals((java.lang.Object) tickUnitSource1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color3, stroke6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getTickLabelPaint();
        boolean boolean12 = dateAxis9.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis9.lengthToJava2D((double) 'a', rectangle2D14, rectangleEdge15);
        boolean boolean17 = dateAxis9.isAutoRange();
        dateAxis9.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint21 = dateAxis9.getLabelPaint();
        java.awt.Stroke stroke22 = dateAxis9.getTickMarkStroke();
        java.awt.Paint paint23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis26.setRightArrow(shape27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer29);
        categoryPlot30.clearDomainMarkers();
        categoryPlot30.zoom((double) (byte) -1);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setAxisLineStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.BLUE;
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color35, stroke38, (java.awt.Paint) color40, stroke41, (float) (byte) 0);
        categoryPlot30.setRangeCrosshairStroke(stroke38);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, (double) (short) 1, (java.awt.Paint) color3, stroke22, paint23, stroke38, (float) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot6.getIndexOf(categoryItemRenderer7);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot6.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(sortOrder9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color2 = java.awt.Color.getColor("java.awt.Color[r=192,g=0,b=192]", 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot22.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str29 = axisLocation28.toString();
        categoryPlot22.setRangeAxisLocation(axisLocation28);
        categoryPlot6.setDomainAxisLocation((int) (short) 0, axisLocation28);
        int int32 = categoryPlot6.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str29.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        float float12 = dateAxis0.getTickMarkOutsideLength();
        double double13 = dateAxis0.getFixedDimension();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        categoryPlot23.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot23.zoomDomainAxes(0.0d, plotRenderingInfo26, point2D27, true);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis32.setRightArrow(shape33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer35);
        categoryPlot36.clearAnnotations();
        categoryPlot36.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot36.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str43 = axisLocation42.toString();
        categoryPlot36.setRangeAxisLocation(axisLocation42);
        categoryPlot23.setDomainAxisLocation(axisLocation42, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation42, plotOrientation47);
        try {
            java.util.List list49 = dateAxis0.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str43.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        int int24 = categoryPlot6.getWeight();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean2 = dateAxis0.isNegativeArrowVisible();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint7 = dateAxis6.getTickLabelPaint();
        boolean boolean9 = dateAxis6.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis6.lengthToJava2D((double) 'a', rectangle2D11, rectangleEdge12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis6.setTickLabelPaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis6.setAxisLinePaint((java.awt.Paint) color16);
        boolean boolean18 = dateAxis6.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRange((org.jfree.data.Range) dateRange19, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis25.setRightArrow(shape26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer28);
        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        double double33 = categoryAxis32.getUpperMargin();
        categoryAxis32.setMaximumCategoryLabelLines(2);
        java.awt.Color color36 = java.awt.Color.DARK_GRAY;
        categoryAxis32.setLabelPaint((java.awt.Paint) color36);
        categoryAxis32.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int41 = categoryPlot29.getDomainAxisIndex(categoryAxis32);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getDomainAxisEdge((int) '4');
        try {
            double double44 = dateAxis0.dateToJava2D(date3, rectangle2D5, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setAnchorValue(Double.NEGATIVE_INFINITY);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxisForDataset(0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(valueAxis14);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat12 = null;
        numberAxis9.setNumberFormatOverride(numberFormat12);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType17 = numberAxis14.getRangeType();
        numberAxis9.setRangeType(rangeType17);
        numberAxis1.setRangeType(rangeType17);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rangeType17);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        categoryPlot6.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot6.setRenderer(0, categoryItemRenderer31, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            categoryPlot6.handleClick(0, (int) ' ', plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setRightArrow(shape1);
        dateAxis0.setFixedAutoRange((double) (short) 0);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str4 = rectangleAnchor3.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 11, 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleAnchor.RIGHT" + "'", str4.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        categoryAxis26.removeCategoryLabelToolTip((java.lang.Comparable) (-16777216));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder11);
        double double13 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setRightArrow(shape18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer20);
        categoryPlot21.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot21.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25, true);
        java.awt.Paint paint28 = categoryPlot21.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot21.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(5, axisLocation29);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot6.getDatasetGroup();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(datasetGroup31);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 0.05d, dataset1);
        java.lang.Object obj3 = datasetChangeEvent2.getSource();
        org.jfree.data.general.Dataset dataset4 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 0.05d + "'", obj3.equals(0.05d));
        org.junit.Assert.assertNull(dataset4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        categoryPlot6.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation25, plotOrientation30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis33.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis37.setRightArrow(shape38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer40);
        categoryPlot41.clearAnnotations();
        categoryPlot41.setDrawSharedDomainAxis(true);
        dateAxis33.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot41);
        boolean boolean46 = axisLocation25.equals((java.lang.Object) dateAxis33);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        double double42 = categoryAxis37.getLowerMargin();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setAxisLineStroke(stroke45);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape48 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis47.setRightArrow(shape48);
        dateAxis44.setRightArrow(shape48);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis44.setStandardTickUnits(tickUnitSource51);
        java.lang.Object obj53 = dateAxis44.clone();
        java.awt.Color color54 = java.awt.Color.DARK_GRAY;
        dateAxis44.setTickMarkPaint((java.awt.Paint) color54);
        categoryAxis37.setTickMarkPaint((java.awt.Paint) color54);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateLeftOutset((double) 1);
        double double7 = rectangleInsets3.calculateRightInset((double) ' ');
        try {
            objectList1.set((int) (byte) -1, (java.lang.Object) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        categoryPlot6.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot6.zoomRangeAxes((double) (-1), (double) 43629L, plotRenderingInfo32, point2D33);
        categoryPlot6.setRangeCrosshairValue(1.0d, true);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color38);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent40 = null;
        categoryPlot6.axisChanged(axisChangeEvent40);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke10 = categoryPlot6.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        categoryAxis37.removeCategoryLabelToolTip((java.lang.Comparable) false);
        categoryAxis37.setLabelToolTip("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightInset((double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis2.setUpperMargin((double) 7);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setAxisLineStroke(stroke9);
        java.awt.Color color11 = java.awt.Color.BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color6, stroke9, (java.awt.Paint) color11, stroke12, (float) (byte) 0);
        categoryAxis2.setAxisLineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint17 = dateAxis16.getTickLabelPaint();
        boolean boolean19 = dateAxis16.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis16.lengthToJava2D((double) 'a', rectangle2D21, rectangleEdge22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis16.setAxisLinePaint((java.awt.Paint) color26);
        boolean boolean28 = dateAxis16.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis16.setRange((org.jfree.data.Range) dateRange29, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis35.setRightArrow(shape36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer38);
        dateAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        double double43 = categoryAxis42.getUpperMargin();
        categoryAxis42.setMaximumCategoryLabelLines(2);
        java.awt.Color color46 = java.awt.Color.DARK_GRAY;
        categoryAxis42.setLabelPaint((java.awt.Paint) color46);
        categoryAxis42.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int51 = categoryPlot39.getDomainAxisIndex(categoryAxis42);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("");
        double double54 = categoryAxis53.getUpperMargin();
        categoryAxis53.setLabelURL("RectangleAnchor.RIGHT");
        int int57 = categoryPlot39.getDomainAxisIndex(categoryAxis53);
        org.jfree.data.general.DatasetGroup datasetGroup58 = categoryPlot39.getDatasetGroup();
        boolean boolean59 = categoryPlot39.getDrawSharedDomainAxis();
        categoryAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        boolean boolean61 = layer0.equals((java.lang.Object) categoryAxis2);
        java.lang.Object obj62 = null;
        boolean boolean63 = layer0.equals(obj62);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNull(datasetGroup58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent15);
        double double17 = categoryPlot6.getAnchorValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace13, true);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            categoryPlot6.drawBackground(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftInset((double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.plot.Marker marker11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker(marker11);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot13.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17, true);
        java.awt.Paint paint20 = categoryPlot13.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot13.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean24 = plotOrientation22.equals((java.lang.Object) 1.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation21, plotOrientation22);
        try {
            double double26 = categoryAxis1.getCategoryMiddle((int) ' ', 15, rectangle2D6, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        numberAxis16.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot11.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot11.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot11.setRenderers(categoryItemRendererArray19);
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) categoryItemRendererArray19);
        boolean boolean22 = categoryAxis1.isAxisLineVisible();
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis31.setRightArrow(shape32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer34);
        categoryPlot35.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot35.zoomDomainAxes(0.0d, plotRenderingInfo38, point2D39, true);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape45 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis44.setRightArrow(shape45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer47);
        categoryPlot48.clearAnnotations();
        categoryPlot48.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis53 = categoryPlot48.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        categoryPlot48.setRangeAxisLocation(axisLocation54);
        categoryPlot35.setDomainAxisLocation(axisLocation54, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation59 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation54, plotOrientation59);
        try {
            double double61 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) "RectangleAnchor.RIGHT", (java.lang.Comparable) day25, categoryDataset26, (double) 100L, rectangle2D28, rectangleEdge60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNull(valueAxis53);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str55.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation59);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Paint paint1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer7);
        categoryPlot8.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot8.notifyListeners(plotChangeEvent10);
        java.lang.String str12 = categoryPlot8.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextOutlinePaint();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot22.zoomDomainAxes(0.0d, plotRenderingInfo25, point2D26, true);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis31.setRightArrow(shape32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer34);
        categoryPlot35.clearAnnotations();
        categoryPlot35.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot35.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str42 = axisLocation41.toString();
        categoryPlot35.setRangeAxisLocation(axisLocation41);
        categoryPlot22.setDomainAxisLocation(axisLocation41, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation41, plotOrientation46);
        categoryPlot8.setRangeAxisLocation(axisLocation41, true);
        java.awt.Stroke stroke50 = categoryPlot8.getDomainGridlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(8.0d, paint1, stroke50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str42.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        categoryPlot6.axisChanged(axisChangeEvent10);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        categoryPlot6.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot6.zoomRangeAxes((double) (-1), (double) 43629L, plotRenderingInfo32, point2D33);
        categoryPlot6.setRangeCrosshairValue(1.0d, true);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color38);
        int int40 = categoryPlot6.getDomainAxisCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.text.NumberFormat numberFormat2 = null;
        numberAxis1.setNumberFormatOverride(numberFormat2);
        numberAxis1.setAutoRangeIncludesZero(true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.lang.String str2 = unitType1.toString();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot9.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot9.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot9.setRenderers(categoryItemRendererArray17);
        boolean boolean19 = unitType1.equals((java.lang.Object) categoryPlot9);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        categoryAxis37.setUpperMargin((-1.0d));
        java.lang.String str45 = categoryAxis37.getCategoryLabelToolTip((java.lang.Comparable) 0.2d);
        categoryAxis37.setMaximumCategoryLabelWidthRatio((float) '#');
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getBottom();
        double double2 = rectangleInsets0.getBottom();
        double double4 = rectangleInsets0.calculateLeftOutset((double) 10L);
        double double6 = rectangleInsets0.calculateRightInset(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            categoryPlot6.drawBackground(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis3.setRightArrow(shape4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer6);
        categoryPlot7.clearAnnotations();
        categoryPlot7.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot7.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot7.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray15 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot7.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis21.setRightArrow(shape22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer24);
        categoryPlot25.clearAnnotations();
        categoryPlot25.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot25.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str32 = axisLocation31.toString();
        categoryPlot25.setRangeAxisLocation(axisLocation31);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis37.setRightArrow(shape38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer40);
        categoryPlot41.clearAnnotations();
        categoryPlot41.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot41.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str48 = axisLocation47.toString();
        categoryPlot41.setRangeAxisLocation(axisLocation47);
        categoryPlot25.setDomainAxisLocation((int) (short) 0, axisLocation47);
        categoryPlot7.setRangeAxisLocation((int) (byte) 1, axisLocation47);
        boolean boolean52 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        categoryPlot7.setRenderer(categoryItemRenderer53);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray15);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str32.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str48.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        valueMarker9.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = valueMarker9.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.JFreeChart jFreeChart14 = markerChangeEvent13.getChart();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNull(jFreeChart14);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setTickMarkOutsideLength((float) '4');
        org.jfree.chart.event.AxisChangeListener axisChangeListener7 = null;
        dateAxis0.addChangeListener(axisChangeListener7);
        try {
            dateAxis0.setRange((double) 10L, (double) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        double double2 = numberAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        java.awt.Paint paint23 = numberAxis16.getLabelPaint();
        java.lang.Class<?> wildcardClass24 = paint23.getClass();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        try {
            dateAxis0.setRange((double) 4, 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        java.awt.Paint paint23 = numberAxis16.getLabelPaint();
        numberAxis16.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        numberAxis0.setTickMarkOutsideLength((float) 7);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint12 = dateAxis11.getTickLabelPaint();
        boolean boolean14 = dateAxis11.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = dateAxis11.lengthToJava2D((double) 'a', rectangle2D16, rectangleEdge17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis11.setAxisLinePaint((java.awt.Paint) color21);
        boolean boolean23 = dateAxis11.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis11.setRange((org.jfree.data.Range) dateRange24, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis30.setRightArrow(shape31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer33);
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setMaximumCategoryLabelLines(2);
        java.awt.Color color41 = java.awt.Color.DARK_GRAY;
        categoryAxis37.setLabelPaint((java.awt.Paint) color41);
        categoryAxis37.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int46 = categoryPlot34.getDomainAxisIndex(categoryAxis37);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot34.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            org.jfree.chart.axis.AxisState axisState50 = numberAxis0.draw(graphics2D7, 8.0d, rectangle2D9, rectangle2D10, rectangleEdge48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis2.setRightArrow(shape3);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
//        categoryPlot6.clearAnnotations();
//        categoryPlot6.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot6.setRenderers(categoryItemRendererArray14);
//        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot6.getDomainGridlinePosition();
//        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
//        categoryPlot6.notifyListeners(plotChangeEvent17);
//        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
//        double double21 = categoryAxis20.getUpperMargin();
//        categoryAxis20.setMaximumCategoryLabelLines(2);
//        java.awt.Color color24 = java.awt.Color.DARK_GRAY;
//        categoryAxis20.setLabelPaint((java.awt.Paint) color24);
//        categoryAxis20.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
//        int int29 = categoryPlot6.getDomainAxisIndex(categoryAxis20);
//        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        long long32 = day31.getLastMillisecond();
//        java.util.Date date33 = day31.getStart();
//        long long34 = day31.getSerialIndex();
//        int int35 = day31.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint37 = dateAxis36.getTickLabelPaint();
//        int int38 = day31.compareTo((java.lang.Object) dateAxis36);
//        org.jfree.data.time.SerialDate serialDate39 = day31.getSerialDate();
//        java.lang.String str40 = categoryAxis20.getCategoryLabelToolTip((java.lang.Comparable) serialDate39);
//        org.junit.Assert.assertNotNull(shape3);
//        org.junit.Assert.assertNull(valueAxis11);
//        org.junit.Assert.assertNull(categoryAxis13);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
//        org.junit.Assert.assertNotNull(categoryAnchor16);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
//        org.junit.Assert.assertNotNull(color24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43629L + "'", long34 == 43629L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertNotNull(paint37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNull(str40);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot11.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot11.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot11.setRenderers(categoryItemRendererArray19);
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) categoryItemRendererArray19);
        double double22 = categoryAxis1.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleAnchor.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleAnchor.RIGHT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        java.lang.Class class0 = null;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone3);
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint6 = dateAxis5.getTickLabelPaint();
//        boolean boolean8 = dateAxis5.isHiddenValue(10L);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        long long11 = day10.getLastMillisecond();
//        java.util.Date date12 = day10.getStart();
//        long long13 = day10.getSerialIndex();
//        int int14 = day10.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint16 = dateAxis15.getTickLabelPaint();
//        int int17 = day10.compareTo((java.lang.Object) dateAxis15);
//        java.util.TimeZone timeZone18 = dateAxis15.getTimeZone();
//        dateAxis5.setTimeZone(timeZone18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date1, timeZone18);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = day20.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(paint6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(paint16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(timeZone18);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.general.DatasetGroup datasetGroup42 = categoryPlot23.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis45.setRightArrow(shape46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer48);
        categoryPlot49.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot49.zoomDomainAxes(0.0d, plotRenderingInfo52, point2D53, true);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis58.setRightArrow(shape59);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis58, categoryItemRenderer61);
        categoryPlot62.clearAnnotations();
        categoryPlot62.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot62.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation68 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str69 = axisLocation68.toString();
        categoryPlot62.setRangeAxisLocation(axisLocation68);
        categoryPlot49.setDomainAxisLocation(axisLocation68, true);
        java.awt.Paint paint73 = categoryPlot49.getNoDataMessagePaint();
        categoryPlot23.setRangeCrosshairPaint(paint73);
        org.jfree.chart.axis.ValueAxis valueAxis75 = categoryPlot23.getRangeAxis();
        java.awt.Shape shape76 = valueAxis75.getLeftArrow();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNull(valueAxis67);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str69.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(valueAxis75);
        org.junit.Assert.assertNotNull(shape76);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        double double42 = categoryAxis37.getLowerMargin();
        categoryAxis37.setMaximumCategoryLabelLines(10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getComponents(floatArray2);
        float[] floatArray4 = color0.getRGBComponents(floatArray3);
        float[] floatArray5 = new float[] {};
        try {
            float[] floatArray6 = color0.getColorComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit9);
        numberAxis0.setTickUnit(numberTickUnit9, false, false);
        boolean boolean14 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.configure();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint11 = dateAxis10.getTickLabelPaint();
        boolean boolean13 = dateAxis10.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis10.lengthToJava2D((double) 'a', rectangle2D15, rectangleEdge16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis10.setTickLabelPaint((java.awt.Paint) color18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis10.setAxisLinePaint((java.awt.Paint) color20);
        boolean boolean22 = dateAxis10.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setRange((org.jfree.data.Range) dateRange23, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setRightArrow(shape30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer32);
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot33);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        double double37 = categoryAxis36.getUpperMargin();
        categoryAxis36.setMaximumCategoryLabelLines(2);
        java.awt.Color color40 = java.awt.Color.DARK_GRAY;
        categoryAxis36.setLabelPaint((java.awt.Paint) color40);
        categoryAxis36.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int45 = categoryPlot33.getDomainAxisIndex(categoryAxis36);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        double double48 = categoryAxis47.getUpperMargin();
        categoryAxis47.setLabelURL("RectangleAnchor.RIGHT");
        int int51 = categoryPlot33.getDomainAxisIndex(categoryAxis47);
        categoryPlot33.setNoDataMessage("java.awt.Color[r=0,g=0,b=255]");
        java.awt.Stroke stroke54 = categoryPlot33.getDomainGridlineStroke();
        valueMarker9.setStroke(stroke54);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        java.lang.Object obj14 = defaultDrawingSupplier11.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        org.jfree.chart.util.Layer layer19 = null;
        categoryPlot6.addRangeMarker(12, (org.jfree.chart.plot.Marker) categoryMarker16, layer19, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker24.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker24.setLabelOffsetType(lengthAdjustmentType26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis30.setRightArrow(shape31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer33);
        categoryPlot34.clearAnnotations();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection37 = categoryPlot34.getDomainMarkers(layer36);
        boolean boolean38 = categoryPlot6.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) categoryMarker24, layer36);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets();
        double double41 = rectangleInsets39.extendWidth(0.0d);
        double double43 = rectangleInsets39.extendHeight((double) 0.0f);
        java.lang.Class<?> wildcardClass44 = rectangleInsets39.getClass();
        try {
            java.util.EventListener[] eventListenerArray45 = categoryMarker24.getListeners((java.lang.Class) wildcardClass44);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.util.RectangleInsets; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(wildcardClass44);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Date date3 = day1.getStart();
//        java.util.Date date4 = day1.getEnd();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint20 = dateAxis19.getTickLabelPaint();
        boolean boolean22 = dateAxis19.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis19.lengthToJava2D((double) 'a', rectangle2D24, rectangleEdge25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis19.setTickLabelPaint((java.awt.Paint) color27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis19.setAxisLinePaint((java.awt.Paint) color29);
        boolean boolean31 = dateAxis19.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis19.setRange((org.jfree.data.Range) dateRange32, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setRightArrow(shape39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer41);
        dateAxis19.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        double double46 = categoryAxis45.getUpperMargin();
        categoryAxis45.setMaximumCategoryLabelLines(2);
        java.awt.Color color49 = java.awt.Color.DARK_GRAY;
        categoryAxis45.setLabelPaint((java.awt.Paint) color49);
        categoryAxis45.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int54 = categoryPlot42.getDomainAxisIndex(categoryAxis45);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("");
        double double57 = categoryAxis56.getUpperMargin();
        categoryAxis56.setLabelURL("RectangleAnchor.RIGHT");
        int int60 = categoryPlot42.getDomainAxisIndex(categoryAxis56);
        categoryAxis56.setUpperMargin((-1.0d));
        try {
            categoryPlot13.setDomainAxis((-16777216), categoryAxis56, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateRange32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setAxisLineStroke(stroke14);
        java.awt.Color color16 = java.awt.Color.BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color11, stroke14, (java.awt.Paint) color16, stroke17, (float) (byte) 0);
        categoryPlot6.setRangeCrosshairStroke(stroke14);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setAxisOffset(rectangleInsets21);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getTickLabelPaint();
        boolean boolean10 = dateAxis7.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis7.lengthToJava2D((double) 'a', rectangle2D12, rectangleEdge13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis7.setAxisLinePaint((java.awt.Paint) color17);
        boolean boolean19 = dateAxis7.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis7.setRange((org.jfree.data.Range) dateRange20, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis26.setRightArrow(shape27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer29);
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        double double34 = categoryAxis33.getUpperMargin();
        categoryAxis33.setMaximumCategoryLabelLines(2);
        java.awt.Color color37 = java.awt.Color.DARK_GRAY;
        categoryAxis33.setLabelPaint((java.awt.Paint) color37);
        categoryAxis33.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int42 = categoryPlot30.getDomainAxisIndex(categoryAxis33);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot30.getDomainAxisEdge((int) '4');
        try {
            double double45 = dateAxis1.dateToJava2D(date4, rectangle2D6, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        boolean boolean24 = numberAxis16.equals((java.lang.Object) 43629L);
        org.jfree.data.Range range25 = numberAxis16.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot11.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot11.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot11.setRenderers(categoryItemRendererArray19);
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) categoryItemRendererArray19);
        categoryAxis1.setLowerMargin(1.0E-8d);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str29 = plotOrientation28.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation27, plotOrientation28);
        try {
            double double31 = categoryAxis1.getCategoryMiddle((int) (short) 1, (int) (byte) 100, rectangle2D26, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str29.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis0.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis0.setMarkerBand(markerAxisBand7);
        java.lang.String str9 = numberAxis0.getLabel();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNull(str9);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        java.lang.Class class0 = null;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone3);
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint6 = dateAxis5.getTickLabelPaint();
//        boolean boolean8 = dateAxis5.isHiddenValue(10L);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        long long11 = day10.getLastMillisecond();
//        java.util.Date date12 = day10.getStart();
//        long long13 = day10.getSerialIndex();
//        int int14 = day10.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint16 = dateAxis15.getTickLabelPaint();
//        int int17 = day10.compareTo((java.lang.Object) dateAxis15);
//        java.util.TimeZone timeZone18 = dateAxis15.getTimeZone();
//        dateAxis5.setTimeZone(timeZone18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date1, timeZone18);
//        java.util.Date date21 = day20.getEnd();
//        int int22 = day20.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(paint6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(paint16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        int int2 = day1.getYear();
//        java.util.Date date3 = day1.getStart();
//        long long4 = day1.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        boolean boolean16 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        double double17 = intervalMarker15.getStartValue();
        org.jfree.chart.util.UnitType unitType18 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean19 = intervalMarker15.equals((java.lang.Object) unitType18);
        java.lang.String str20 = unitType18.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.6777216E7d) + "'", double17 == (-1.6777216E7d));
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnitType.RELATIVE" + "'", str20.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot6.getInsets();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str11 = lengthAdjustmentType10.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str13 = lengthAdjustmentType12.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets8.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType10, lengthAdjustmentType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NO_CHANGE" + "'", str11.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "NO_CHANGE" + "'", str13.equals("NO_CHANGE"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.general.DatasetGroup datasetGroup42 = categoryPlot23.getDatasetGroup();
        boolean boolean43 = categoryPlot23.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace44 = categoryPlot23.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(axisSpace44);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 10);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Date date3 = day1.getStart();
//        long long4 = day1.getSerialIndex();
//        int int5 = day1.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint7 = dateAxis6.getTickLabelPaint();
//        int int8 = day1.compareTo((java.lang.Object) dateAxis6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day1.next();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        boolean boolean4 = dateAxis0.isAutoRange();
        double double5 = dateAxis0.getFixedAutoRange();
        dateAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint11 = dateAxis10.getTickLabelPaint();
        boolean boolean12 = dateAxis10.isNegativeArrowVisible();
        categoryPlot6.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) dateAxis10, false);
        java.text.DateFormat dateFormat15 = null;
        dateAxis10.setDateFormatOverride(dateFormat15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot19.notifyListeners(plotChangeEvent21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot19.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder24 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot19.setRowRenderingOrder(sortOrder24);
        double double26 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot11);
        boolean boolean29 = categoryPlot11.isRangeGridlinesVisible();
        java.lang.Object obj30 = categoryPlot11.clone();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        double double42 = categoryAxis37.getLowerMargin();
        double double43 = categoryAxis37.getCategoryMargin();
        java.awt.Font font45 = categoryAxis37.getTickLabelFont((java.lang.Comparable) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryMarker48.notifyListeners(markerChangeEvent49);
        categoryMarker48.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable53 = categoryMarker48.getKey();
        java.awt.Font font54 = categoryMarker48.getLabelFont();
        categoryAxis37.setTickLabelFont((java.lang.Comparable) (-3.0d), font54);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + 0L + "'", comparable53.equals(0L));
        org.junit.Assert.assertNotNull(font54);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot6.getRangeGridlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot6.removeChangeListener(plotChangeListener9);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType3);
        categoryMarker1.setKey((java.lang.Comparable) 15);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getTickLabelPaint();
        boolean boolean10 = dateAxis7.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis7.lengthToJava2D((double) 'a', rectangle2D12, rectangleEdge13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis7.setAxisLinePaint((java.awt.Paint) color17);
        boolean boolean19 = dateAxis7.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis7.setRange((org.jfree.data.Range) dateRange20, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis26.setRightArrow(shape27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer29);
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        double double34 = categoryAxis33.getUpperMargin();
        categoryAxis33.setMaximumCategoryLabelLines(2);
        java.awt.Color color37 = java.awt.Color.DARK_GRAY;
        categoryAxis33.setLabelPaint((java.awt.Paint) color37);
        categoryAxis33.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int42 = categoryPlot30.getDomainAxisIndex(categoryAxis33);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot30.getDomainAxisEdge((int) '4');
        java.awt.Image image45 = null;
        categoryPlot30.setBackgroundImage(image45);
        categoryMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot30);
        categoryMarker1.setKey((java.lang.Comparable) 10.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = null;
        try {
            categoryMarker1.setLabelOffset(rectangleInsets50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        dateAxis0.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint12 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getTickLabelPaint();
        boolean boolean16 = dateAxis13.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis13.lengthToJava2D((double) 'a', rectangle2D18, rectangleEdge19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis13.setTickLabelPaint((java.awt.Paint) color21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis13.setAxisLinePaint((java.awt.Paint) color23);
        boolean boolean25 = dateAxis13.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis13.setRange((org.jfree.data.Range) dateRange26, true, false);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange26, true, true);
        dateAxis0.setTickMarkOutsideLength((float) 1560495599999L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateRange26);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.DatasetChangeEvent[source=0.05]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot6.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis20.setRightArrow(shape21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer23);
        categoryPlot24.clearAnnotations();
        categoryPlot24.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot24.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str31 = axisLocation30.toString();
        categoryPlot24.setRangeAxisLocation(axisLocation30);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer39);
        categoryPlot40.clearAnnotations();
        categoryPlot40.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot40.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str47 = axisLocation46.toString();
        categoryPlot40.setRangeAxisLocation(axisLocation46);
        categoryPlot24.setDomainAxisLocation((int) (short) 0, axisLocation46);
        categoryPlot6.setRangeAxisLocation((int) (byte) 1, axisLocation46);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation51 = null;
        try {
            boolean boolean53 = categoryPlot6.removeAnnotation(categoryAnnotation51, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str31.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str47.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 8, (double) 2019, (double) 1560409200000L);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        categoryPlot13.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot13.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        categoryPlot13.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryMarker23.notifyListeners(markerChangeEvent24);
        categoryMarker23.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable28 = categoryMarker23.getKey();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot13.addDomainMarker(categoryMarker23, layer29);
        boolean boolean31 = rectangleInsets6.equals((java.lang.Object) categoryMarker23);
        double double33 = rectangleInsets6.calculateBottomInset((double) (-65281));
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str20.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 0L + "'", comparable28.equals(0L));
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.31802339E8d) + "'", double33 == (-1.31802339E8d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace13, true);
        categoryPlot6.setOutlineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis21.setRightArrow(shape22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer24);
        categoryPlot25.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        categoryPlot25.notifyListeners(plotChangeEvent27);
        java.lang.String str29 = categoryPlot25.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextOutlinePaint();
        categoryPlot25.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis35.setRightArrow(shape36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer38);
        categoryPlot39.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot39.zoomDomainAxes(0.0d, plotRenderingInfo42, point2D43, true);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape49 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis48.setRightArrow(shape49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer51);
        categoryPlot52.clearAnnotations();
        categoryPlot52.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot52.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str59 = axisLocation58.toString();
        categoryPlot52.setRangeAxisLocation(axisLocation58);
        categoryPlot39.setDomainAxisLocation(axisLocation58, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation63 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation58, plotOrientation63);
        categoryPlot25.setRangeAxisLocation(axisLocation58, true);
        categoryPlot6.setRangeAxisLocation(13, axisLocation58, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str59.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10, false);
        categoryPlot6.clearDomainMarkers(9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot6.handleClick((-65536), (-16777216), plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        boolean boolean10 = dateAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRendererForDataset(categoryDataset8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.configureDomainAxes();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource8);
        java.lang.Object obj10 = dateAxis1.clone();
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color11);
        int int13 = color11.getRed();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 64 + "'", int13 == 64);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberTickUnit3, jFreeChart5);
        org.junit.Assert.assertNotNull(numberTickUnit3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj3 = null;
        boolean boolean4 = chartChangeEventType2.equals(obj3);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        chartChangeEvent5.setChart(jFreeChart6);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        boolean boolean4 = dateAxis0.isAutoRange();
        java.util.Date date5 = null;
        try {
            dateAxis0.setMinimumDate(date5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Date date3 = day1.getStart();
//        long long4 = day1.getSerialIndex();
//        int int5 = day1.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint7 = dateAxis6.getTickLabelPaint();
//        int int8 = day1.compareTo((java.lang.Object) dateAxis6);
//        java.util.TimeZone timeZone9 = dateAxis6.getTimeZone();
//        try {
//            dateAxis6.setAutoRangeMinimumSize(Double.NEGATIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(timeZone9);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        categoryPlot6.setAnchorValue((double) (byte) 10, true);
        categoryPlot6.setAnchorValue((double) 1.0f);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = null;
        try {
            categoryPlot6.setRangeAxes(valueAxisArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        java.awt.Paint paint4 = categoryMarker1.getOutlinePaint();
        try {
            categoryMarker1.setAlpha((float) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        dateAxis0.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint12 = dateAxis0.getLabelPaint();
        dateAxis0.resizeRange((double) 11);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int16 = color15.getGreen();
        dateAxis0.setLabelPaint((java.awt.Paint) color15);
        java.awt.Color color18 = color15.darker();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 192 + "'", int16 == 192);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        categoryMarker15.notifyListeners(markerChangeEvent16);
        categoryMarker15.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable20 = categoryMarker15.getKey();
        categoryMarker15.setKey((java.lang.Comparable) '4');
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis25.setRightArrow(shape26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer28);
        categoryPlot29.clearDomainMarkers();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean33 = color31.equals((java.lang.Object) false);
        categoryPlot29.setOutlinePaint((java.awt.Paint) color31);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setRightArrow(shape39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer41);
        categoryPlot42.clearAnnotations();
        categoryPlot42.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis47 = categoryPlot42.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str49 = axisLocation48.toString();
        categoryPlot42.setRangeAxisLocation(axisLocation48);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent53 = null;
        categoryMarker52.notifyListeners(markerChangeEvent53);
        categoryMarker52.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable57 = categoryMarker52.getKey();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot42.addDomainMarker(categoryMarker52, layer58);
        java.util.Collection collection60 = categoryPlot29.getDomainMarkers(11, layer58);
        boolean boolean62 = categoryPlot6.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker15, layer58, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation63 = null;
        try {
            boolean boolean65 = categoryPlot6.removeAnnotation(categoryAnnotation63, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 0L + "'", comparable20.equals(0L));
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str49.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + 0L + "'", comparable57.equals(0L));
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        categoryPlot6.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot6.zoomRangeAxes((double) (-1), (double) 43629L, plotRenderingInfo32, point2D33);
        categoryPlot6.setRangeCrosshairValue(1.0d, true);
        categoryPlot6.clearDomainMarkers();
        java.awt.Paint paint39 = categoryPlot6.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getComponents(floatArray4);
        float[] floatArray6 = color1.getColorComponents(floatArray4);
        float[] floatArray7 = color0.getColorComponents(floatArray4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setTickMarkOutsideLength((float) '4');
        dateAxis0.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        dateAxis0.setTickUnit(dateTickUnit9, false, false);
        dateAxis0.setLowerBound((double) 10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = null;
        try {
            java.util.Date date16 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        categoryPlot6.setAnchorValue((double) 2.0f, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke20);
        java.awt.Color color22 = java.awt.Color.BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color17, stroke20, (java.awt.Paint) color22, stroke23, (float) (byte) 0);
        double double26 = valueMarker25.getValue();
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean28 = valueMarker25.equals((java.lang.Object) paint27);
        org.jfree.chart.text.TextAnchor textAnchor29 = valueMarker25.getLabelTextAnchor();
        valueMarker25.setValue((double) 7);
        boolean boolean32 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 32.0d + "'", double26 == 32.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        categoryPlot6.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot6.zoomRangeAxes((double) (-1), (double) 43629L, plotRenderingInfo32, point2D33);
        categoryPlot6.setRangeCrosshairValue(1.0d, true);
        categoryPlot6.setWeight((int) '4');
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 10, (double) (-65281), 0.0d, (double) 8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 0, (double) 1560452399999L, 7.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D5, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        java.awt.Paint paint9 = dateAxis1.getTickLabelPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = dateAxis1.getTickMarkPaint();
        try {
            dateAxis1.setAutoRangeMinimumSize((double) 0.0f, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setRightArrow(shape1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets3.getBottom();
        double double5 = rectangleInsets3.getBottom();
        double double7 = rectangleInsets3.calculateLeftOutset((double) 10L);
        dateAxis0.setLabelInsets(rectangleInsets3);
        double double9 = dateAxis0.getLowerBound();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape11 = defaultDrawingSupplier10.getNextShape();
        java.awt.Stroke stroke12 = defaultDrawingSupplier10.getNextOutlineStroke();
        java.awt.Shape shape13 = defaultDrawingSupplier10.getNextShape();
        dateAxis0.setRightArrow(shape13);
        boolean boolean15 = dateAxis0.isAutoTickUnitSelection();
        dateAxis0.setLabelAngle((double) (-1.0f));
        java.util.Date date18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setRightArrow(shape23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer25);
        categoryPlot26.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot26.zoomDomainAxes(0.0d, plotRenderingInfo29, point2D30, true);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setAxisLineStroke(stroke35);
        categoryPlot26.setRangeCrosshairStroke(stroke35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot26.getRangeAxisEdge();
        try {
            double double39 = dateAxis0.dateToJava2D(date18, rectangle2D19, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        double double36 = categoryAxis26.getCategoryMargin();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.2d + "'", double36 == 0.2d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) false);
        valueMarker9.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint15 = dateAxis14.getTickLabelPaint();
        boolean boolean17 = dateAxis14.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis14.lengthToJava2D((double) 'a', rectangle2D19, rectangleEdge20);
        boolean boolean22 = dateAxis14.isAutoRange();
        dateAxis14.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint26 = dateAxis14.getLabelPaint();
        java.awt.Stroke stroke27 = dateAxis14.getTickMarkStroke();
        valueMarker9.setStroke(stroke27);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        numberAxis0.setRangeWithMargins((double) (short) -1, (double) 100L);
        boolean boolean8 = numberAxis0.isPositiveArrowVisible();
        numberAxis0.setUpperBound((double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot19.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        java.awt.Paint paint26 = categoryPlot19.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot19.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean30 = plotOrientation28.equals((java.lang.Object) 1.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation28);
        try {
            double double32 = numberAxis0.valueToJava2D((double) 13, rectangle2D12, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        categoryAxis1.setCategoryMargin((double) (byte) 10);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 7.0d, "");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot19.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        java.awt.Paint paint26 = categoryPlot19.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot19.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean30 = plotOrientation28.equals((java.lang.Object) 1.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation28);
        try {
            double double32 = categoryAxis1.getCategoryEnd((int) (byte) 10, (int) '4', rectangle2D12, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        categoryAxis1.setCategoryMargin((double) (byte) 10);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 7.0d, "");
        java.lang.Comparable comparable10 = null;
        try {
            java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint(comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        java.lang.String str4 = categoryMarker1.getLabel();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double3 = intervalMarker2.getEndValue();
        java.lang.Object obj4 = intervalMarker2.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke15);
        categoryPlot6.setRangeCrosshairStroke(stroke15);
        float float18 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.extendWidth(0.0d);
        double double23 = rectangleInsets19.trimWidth((double) (-1));
        double double25 = rectangleInsets19.calculateBottomInset(0.0d);
        categoryPlot6.setInsets(rectangleInsets19, false);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        categoryPlot6.drawBackgroundImage(graphics2D28, rectangle2D29);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-3.0d) + "'", double23 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis2.setUpperMargin((double) 7);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setAxisLineStroke(stroke9);
        java.awt.Color color11 = java.awt.Color.BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color6, stroke9, (java.awt.Paint) color11, stroke12, (float) (byte) 0);
        categoryAxis2.setAxisLineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint17 = dateAxis16.getTickLabelPaint();
        boolean boolean19 = dateAxis16.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis16.lengthToJava2D((double) 'a', rectangle2D21, rectangleEdge22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis16.setAxisLinePaint((java.awt.Paint) color26);
        boolean boolean28 = dateAxis16.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis16.setRange((org.jfree.data.Range) dateRange29, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis35.setRightArrow(shape36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer38);
        dateAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        double double43 = categoryAxis42.getUpperMargin();
        categoryAxis42.setMaximumCategoryLabelLines(2);
        java.awt.Color color46 = java.awt.Color.DARK_GRAY;
        categoryAxis42.setLabelPaint((java.awt.Paint) color46);
        categoryAxis42.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int51 = categoryPlot39.getDomainAxisIndex(categoryAxis42);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("");
        double double54 = categoryAxis53.getUpperMargin();
        categoryAxis53.setLabelURL("RectangleAnchor.RIGHT");
        int int57 = categoryPlot39.getDomainAxisIndex(categoryAxis53);
        org.jfree.data.general.DatasetGroup datasetGroup58 = categoryPlot39.getDatasetGroup();
        boolean boolean59 = categoryPlot39.getDrawSharedDomainAxis();
        categoryAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        boolean boolean61 = layer0.equals((java.lang.Object) categoryAxis2);
        int int62 = categoryAxis2.getCategoryLabelPositionOffset();
        java.lang.Class<?> wildcardClass63 = categoryAxis2.getClass();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNull(datasetGroup58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        boolean boolean16 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        double double17 = intervalMarker15.getStartValue();
        java.lang.Object obj18 = intervalMarker15.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        intervalMarker15.setLabelOffset(rectangleInsets19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets19.createInsetRectangle(rectangle2D21, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.6777216E7d) + "'", double17 == (-1.6777216E7d));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot22.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str29 = axisLocation28.toString();
        categoryPlot22.setRangeAxisLocation(axisLocation28);
        categoryPlot6.setDomainAxisLocation((int) (short) 0, axisLocation28);
        java.awt.Image image32 = null;
        categoryPlot6.setBackgroundImage(image32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot6.getRenderer();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str29.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(categoryItemRenderer34);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        double double5 = categoryAxis4.getUpperMargin();
        categoryAxis4.setMaximumCategoryLabelLines(2);
        java.awt.Color color8 = java.awt.Color.DARK_GRAY;
        categoryAxis4.setLabelPaint((java.awt.Paint) color8);
        boolean boolean10 = defaultDrawingSupplier1.equals((java.lang.Object) color8);
        java.awt.Color color11 = java.awt.Color.getColor("NO_CHANGE", color8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint15 = dateAxis14.getTickLabelPaint();
        boolean boolean17 = dateAxis14.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis14.lengthToJava2D((double) 'a', rectangle2D19, rectangleEdge20);
        boolean boolean22 = dateAxis14.isAutoRange();
        dateAxis14.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint26 = dateAxis14.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint28 = dateAxis27.getTickLabelPaint();
        boolean boolean30 = dateAxis27.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = dateAxis27.lengthToJava2D((double) 'a', rectangle2D32, rectangleEdge33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis27.setAxisLinePaint((java.awt.Paint) color37);
        boolean boolean39 = dateAxis27.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis27.setRange((org.jfree.data.Range) dateRange40, true, false);
        dateAxis14.setRangeWithMargins((org.jfree.data.Range) dateRange40, true, true);
        dateAxis1.setRange((org.jfree.data.Range) dateRange40, true, true);
        dateAxis1.setUpperMargin(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateRange40);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRendererForDataset(categoryDataset8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot6.removeChangeListener(plotChangeListener11);
        org.jfree.chart.util.UnitType unitType13 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) 1560409200000L, (double) 0L, (double) ' ', (double) 4);
        categoryPlot6.setInsets(rectangleInsets18, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Color color1 = java.awt.Color.magenta;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearDomainMarkers();
        categoryPlot9.zoom((double) (byte) -1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setAxisLineStroke(stroke17);
        java.awt.Color color19 = java.awt.Color.BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color14, stroke17, (java.awt.Paint) color19, stroke20, (float) (byte) 0);
        categoryPlot9.setRangeCrosshairStroke(stroke17);
        boolean boolean24 = day2.equals((java.lang.Object) stroke17);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke17);
        int int26 = color1.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setAnchorValue(Double.NEGATIVE_INFINITY);
        categoryPlot6.setDrawSharedDomainAxis(true);
        categoryPlot6.clearRangeMarkers();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        float float12 = dateAxis0.getTickMarkOutsideLength();
        java.util.Date date13 = null;
        try {
            dateAxis0.setMinimumDate(date13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        dateAxis2.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke15);
        categoryPlot6.setRangeCrosshairStroke(stroke15);
        float float18 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.extendWidth(0.0d);
        double double23 = rectangleInsets19.trimWidth((double) (-1));
        double double25 = rectangleInsets19.calculateBottomInset(0.0d);
        categoryPlot6.setInsets(rectangleInsets19, false);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        categoryPlot6.drawBackgroundImage(graphics2D28, rectangle2D29);
        java.lang.Object obj31 = categoryPlot6.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection32);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-3.0d) + "'", double23 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis5.setTickUnit(numberTickUnit8);
        numberAxis0.setTickUnit(numberTickUnit8);
        java.lang.Object obj11 = numberAxis0.clone();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomRangeAxes((double) '4', plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace15, true);
        float float18 = categoryPlot6.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        java.awt.Paint paint9 = dateAxis1.getTickLabelPaint();
        dateAxis1.resizeRange((double) 'a', (double) 100);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryMarker14.notifyListeners(markerChangeEvent15);
        categoryMarker14.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable19 = categoryMarker14.getKey();
        java.awt.Font font20 = categoryMarker14.getLabelFont();
        dateAxis1.setLabelFont(font20);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 0L + "'", comparable19.equals(0L));
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        java.lang.String str23 = categoryPlot9.getNoDataMessage();
        categoryPlot9.zoom(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot6.getIndexOf(categoryItemRenderer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot6.getParent();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint11 = dateAxis10.getTickLabelPaint();
        boolean boolean13 = dateAxis10.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis10.lengthToJava2D((double) 'a', rectangle2D15, rectangleEdge16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis10.setTickLabelPaint((java.awt.Paint) color18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis10.setAxisLinePaint((java.awt.Paint) color20);
        boolean boolean22 = dateAxis10.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setRange((org.jfree.data.Range) dateRange23, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setRightArrow(shape30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer32);
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot33);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        double double37 = categoryAxis36.getUpperMargin();
        categoryAxis36.setMaximumCategoryLabelLines(2);
        java.awt.Color color40 = java.awt.Color.DARK_GRAY;
        categoryAxis36.setLabelPaint((java.awt.Paint) color40);
        categoryAxis36.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int45 = categoryPlot33.getDomainAxisIndex(categoryAxis36);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        double double48 = categoryAxis47.getUpperMargin();
        categoryAxis47.setLabelURL("RectangleAnchor.RIGHT");
        int int51 = categoryPlot33.getDomainAxisIndex(categoryAxis47);
        categoryPlot33.setNoDataMessage("java.awt.Color[r=0,g=0,b=255]");
        java.awt.Stroke stroke54 = categoryPlot33.getDomainGridlineStroke();
        categoryPlot6.setRangeCrosshairStroke(stroke54);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        categoryMarker1.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable6 = categoryMarker1.getKey();
        categoryMarker1.setKey((java.lang.Comparable) '4');
        java.lang.String str9 = categoryMarker1.getLabel();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0L + "'", comparable6.equals(0L));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        int int14 = categoryPlot6.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke15);
        categoryPlot6.setRangeCrosshairStroke(stroke15);
        float float18 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.extendWidth(0.0d);
        double double23 = rectangleInsets19.trimWidth((double) (-1));
        double double25 = rectangleInsets19.calculateBottomInset(0.0d);
        categoryPlot6.setInsets(rectangleInsets19, false);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        categoryPlot6.drawBackgroundImage(graphics2D28, rectangle2D29);
        java.awt.Paint paint31 = categoryPlot6.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-3.0d) + "'", double23 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        java.lang.String str23 = categoryPlot9.getNoDataMessage();
        boolean boolean24 = categoryPlot9.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12566464) + "'", int1 == (-12566464));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean7 = numberAxis1.isAxisLineVisible();
        boolean boolean8 = numberAxis1.getAutoRangeStickyZero();
        try {
            numberAxis1.setRange(0.0d, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        categoryPlot6.zoom((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        double double28 = categoryAxis27.getUpperMargin();
        categoryAxis27.setLabelURL("RectangleAnchor.RIGHT");
        categoryPlot6.setDomainAxis(categoryAxis27);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation32 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean2 = dateAxis0.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange3, false, false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis12.setRightArrow(shape13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer15);
        categoryPlot16.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot16.zoomDomainAxes(0.0d, plotRenderingInfo19, point2D20, true);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis25.setRightArrow(shape26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer28);
        categoryPlot29.clearAnnotations();
        categoryPlot29.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot29.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        categoryPlot29.setRangeAxisLocation(axisLocation35);
        categoryPlot16.setDomainAxisLocation(axisLocation35, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation35, plotOrientation40);
        try {
            double double42 = dateAxis0.valueToJava2D(8.0d, rectangle2D9, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNull(categoryAxis13);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor26 = categoryMarker25.getLabelTextAnchor();
        java.awt.Font font27 = categoryMarker25.getLabelFont();
        java.awt.Paint paint28 = categoryMarker25.getOutlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        categoryMarker30.notifyListeners(markerChangeEvent31);
        java.awt.Paint paint33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryMarker30.setPaint(paint33);
        categoryMarker25.setPaint(paint33);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setRightArrow(shape39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer41);
        categoryPlot42.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot42.zoomDomainAxes(0.0d, plotRenderingInfo45, point2D46, true);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape52 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis51.setRightArrow(shape52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer54);
        categoryPlot55.clearAnnotations();
        categoryPlot55.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot55.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str62 = axisLocation61.toString();
        categoryPlot55.setRangeAxisLocation(axisLocation61);
        categoryPlot42.setDomainAxisLocation(axisLocation61, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot42.zoomRangeAxes((double) (-1), (double) 43629L, plotRenderingInfo68, point2D69);
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection72 = categoryPlot42.getDomainMarkers(layer71);
        categoryPlot9.addRangeMarker(7, (org.jfree.chart.plot.Marker) categoryMarker25, layer71);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str62.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection72);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        objectList1.clear();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        int int5 = objectList1.indexOf((java.lang.Object) "UnitType.ABSOLUTE");
        java.lang.Object obj7 = objectList1.get(10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(obj7);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis2.setRightArrow(shape3);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
//        categoryPlot6.clearAnnotations();
//        categoryPlot6.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot6.setRenderers(categoryItemRendererArray14);
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis17.setAxisLineStroke(stroke18);
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis20.setRightArrow(shape21);
//        dateAxis17.setRightArrow(shape21);
//        boolean boolean24 = dateAxis17.isAxisLineVisible();
//        java.awt.Paint paint25 = dateAxis17.getTickLabelPaint();
//        org.jfree.data.Range range26 = dateAxis17.getRange();
//        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        long long30 = day29.getLastMillisecond();
//        java.util.Date date31 = day29.getStart();
//        long long32 = day29.getSerialIndex();
//        int int33 = day29.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint35 = dateAxis34.getTickLabelPaint();
//        int int36 = day29.compareTo((java.lang.Object) dateAxis34);
//        java.util.TimeZone timeZone37 = dateAxis34.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone37);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint40 = dateAxis39.getTickLabelPaint();
//        boolean boolean42 = dateAxis39.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D44 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
//        double double46 = dateAxis39.lengthToJava2D((double) 'a', rectangle2D44, rectangleEdge45);
//        boolean boolean47 = dateAxis39.isAutoRange();
//        org.jfree.chart.plot.Plot plot48 = dateAxis39.getPlot();
//        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis49.setAutoRangeIncludesZero(false);
//        java.text.NumberFormat numberFormat52 = null;
//        numberAxis49.setNumberFormatOverride(numberFormat52);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { dateAxis17, dateAxis38, dateAxis39, numberAxis49 };
//        categoryPlot6.setRangeAxes(valueAxisArray54);
//        org.jfree.chart.event.AxisChangeEvent axisChangeEvent56 = null;
//        categoryPlot6.axisChanged(axisChangeEvent56);
//        org.junit.Assert.assertNotNull(shape3);
//        org.junit.Assert.assertNull(valueAxis11);
//        org.junit.Assert.assertNull(categoryAxis13);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(shape21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertNotNull(range26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(paint40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNull(plot48);
//        org.junit.Assert.assertNotNull(valueAxisArray54);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color1, stroke4);
        java.awt.Stroke stroke7 = categoryMarker6.getOutlineStroke();
        boolean boolean8 = categoryMarker6.getDrawAsLine();
        java.awt.Paint paint9 = categoryMarker6.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearDomainMarkers();
        categoryPlot11.zoom((double) (byte) -1);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setAxisLineStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color16, stroke19, (java.awt.Paint) color21, stroke22, (float) (byte) 0);
        categoryPlot11.setRangeCrosshairStroke(stroke19);
        boolean boolean26 = day4.equals((java.lang.Object) stroke19);
        org.jfree.data.time.SerialDate serialDate27 = day4.getSerialDate();
        categoryMarker1.setKey((java.lang.Comparable) serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis16.setRightArrow(shape17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer19);
        categoryPlot20.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo23, point2D24, true);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setRightArrow(shape30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer32);
        categoryPlot33.clearAnnotations();
        categoryPlot33.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot33.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str40 = axisLocation39.toString();
        categoryPlot33.setRangeAxisLocation(axisLocation39);
        categoryPlot20.setDomainAxisLocation(axisLocation39, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation39, plotOrientation44);
        categoryPlot6.setRangeAxisLocation(axisLocation39, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray48 = null;
        try {
            categoryPlot6.setRenderers(categoryItemRendererArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str40.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        categoryPlot6.setAnchorValue((double) (byte) 10, true);
        categoryPlot6.zoom((double) (-65536));
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint11 = dateAxis10.getTickLabelPaint();
        boolean boolean12 = dateAxis10.isNegativeArrowVisible();
        categoryPlot6.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) dateAxis10, false);
        java.awt.Shape shape15 = dateAxis10.getLeftArrow();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        boolean boolean4 = dateAxis0.isAutoRange();
        dateAxis0.setRangeAboutValue((double) (short) 10, 0.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        categoryPlot6.clearDomainAxes();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 0.05d, dataset10);
        java.lang.String str12 = datasetChangeEvent11.toString();
        categoryPlot6.datasetChanged(datasetChangeEvent11);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=0.05]" + "'", str12.equals("org.jfree.data.general.DatasetChangeEvent[source=0.05]"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder11);
        double double13 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setRightArrow(shape18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer20);
        categoryPlot21.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot21.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25, true);
        java.awt.Paint paint28 = categoryPlot21.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot21.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(5, axisLocation29);
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setAxisLineStroke(stroke35);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color32, stroke35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker37);
        categoryPlot6.markerChanged(markerChangeEvent38);
        boolean boolean40 = categoryPlot6.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis1.removeChangeListener(axisChangeListener3);
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setAutoRange(false);
        java.lang.Object obj8 = dateAxis1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis1.getTickLabelInsets();
        java.lang.Object obj10 = dateAxis1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "PlotOrientation.HORIZONTAL");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.Plot plot11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getTickLabelPaint();
        boolean boolean16 = dateAxis13.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis13.lengthToJava2D((double) 'a', rectangle2D18, rectangleEdge19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis13.setTickLabelPaint((java.awt.Paint) color21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis13.setAxisLinePaint((java.awt.Paint) color23);
        boolean boolean25 = dateAxis13.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis13.setRange((org.jfree.data.Range) dateRange26, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis32.setRightArrow(shape33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer35);
        dateAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        double double40 = categoryAxis39.getUpperMargin();
        categoryAxis39.setMaximumCategoryLabelLines(2);
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        categoryAxis39.setLabelPaint((java.awt.Paint) color43);
        categoryAxis39.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int48 = categoryPlot36.getDomainAxisIndex(categoryAxis39);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot36.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace52 = categoryAxis1.reserveSpace(graphics2D10, plot11, rectangle2D12, rectangleEdge50, axisSpace51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.lang.Object obj5 = dateAxis1.clone();
        double double6 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        dateAxis0.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint12 = dateAxis0.getLabelPaint();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.util.List list17 = dateAxis0.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
        java.lang.Class class18 = null;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone21);
        dateAxis0.setMinimumDate(date19);
        java.lang.String str24 = dateAxis0.getLabelURL();
        dateAxis0.setLabelAngle((double) (short) 1);
        boolean boolean27 = dateAxis0.isTickMarksVisible();
        dateAxis0.setRange(0.0d, (double) 1.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        java.lang.Class class1 = null;
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone4);
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint7 = dateAxis6.getTickLabelPaint();
//        boolean boolean9 = dateAxis6.isHiddenValue(10L);
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        long long12 = day11.getLastMillisecond();
//        java.util.Date date13 = day11.getStart();
//        long long14 = day11.getSerialIndex();
//        int int15 = day11.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint17 = dateAxis16.getTickLabelPaint();
//        int int18 = day11.compareTo((java.lang.Object) dateAxis16);
//        java.util.TimeZone timeZone19 = dateAxis16.getTimeZone();
//        dateAxis6.setTimeZone(timeZone19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date2, timeZone19);
//        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("CategoryAnchor.END", timeZone19);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(paint17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(timeZone19);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color1, stroke4);
        java.awt.Stroke stroke7 = categoryMarker6.getOutlineStroke();
        boolean boolean8 = categoryMarker6.getDrawAsLine();
        float float9 = categoryMarker6.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot6.getRenderer((int) '#');
        float float15 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot6.getDomainMarkers((int) '4', layer13);
        categoryPlot6.setAnchorValue((-1.0d));
        double double17 = categoryPlot6.getAnchorValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0.0f, (double) 12, 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis1.removeChangeListener(axisChangeListener3);
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        java.lang.Class class2 = null;
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone5);
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint8 = dateAxis7.getTickLabelPaint();
//        boolean boolean10 = dateAxis7.isHiddenValue(10L);
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        long long13 = day12.getLastMillisecond();
//        java.util.Date date14 = day12.getStart();
//        long long15 = day12.getSerialIndex();
//        int int16 = day12.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint18 = dateAxis17.getTickLabelPaint();
//        int int19 = day12.compareTo((java.lang.Object) dateAxis17);
//        java.util.TimeZone timeZone20 = dateAxis17.getTimeZone();
//        dateAxis7.setTimeZone(timeZone20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date3, timeZone20);
//        java.util.Date date23 = day22.getEnd();
//        java.awt.Font font24 = categoryAxis1.getTickLabelFont((java.lang.Comparable) day22);
//        categoryAxis1.setCategoryLabelPositionOffset(0);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(paint18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(font24);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Paint paint3 = categoryMarker1.getOutlinePaint();
        java.awt.Font font4 = categoryMarker1.getLabelFont();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType8 = numberAxis5.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat12 = null;
        numberAxis9.setNumberFormatOverride(numberFormat12);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType17 = numberAxis14.getRangeType();
        numberAxis9.setRangeType(rangeType17);
        numberAxis5.setRangeType(rangeType17);
        numberAxis0.setRangeType(rangeType17);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets21.createOutsetRectangle(rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        java.lang.Class class0 = null;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone3);
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        long long8 = day7.getLastMillisecond();
//        java.util.Date date9 = day7.getStart();
//        long long10 = day7.getSerialIndex();
//        int int11 = day7.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint13 = dateAxis12.getTickLabelPaint();
//        int int14 = day7.compareTo((java.lang.Object) dateAxis12);
//        java.util.TimeZone timeZone15 = dateAxis12.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date1, timeZone15);
//        java.util.Date date18 = day17.getEnd();
//        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint20 = dateAxis19.getTickLabelPaint();
//        boolean boolean22 = dateAxis19.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = dateAxis19.lengthToJava2D((double) 'a', rectangle2D24, rectangleEdge25);
//        boolean boolean27 = dateAxis19.isAutoRange();
//        dateAxis19.zoomRange(0.0d, (double) (short) 0);
//        java.awt.Paint paint31 = dateAxis19.getLabelPaint();
//        dateAxis19.resizeRange((double) 11);
//        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_YELLOW;
//        int int35 = color34.getGreen();
//        dateAxis19.setLabelPaint((java.awt.Paint) color34);
//        int int37 = day17.compareTo((java.lang.Object) dateAxis19);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(paint20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(paint31);
//        org.junit.Assert.assertNotNull(color34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 192 + "'", int35 == 192);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) false);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryMarker29.notifyListeners(markerChangeEvent30);
        categoryMarker29.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable34 = categoryMarker29.getKey();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot19.addDomainMarker(categoryMarker29, layer35);
        java.util.Collection collection37 = categoryPlot6.getDomainMarkers(11, layer35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis38.setTickUnit(numberTickUnit41);
        java.text.NumberFormat numberFormat43 = numberAxis38.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit47 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis44.setTickUnit(numberTickUnit47);
        numberAxis38.setTickUnit(numberTickUnit47, false, false);
        int int52 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        categoryPlot6.setDomainGridlinesVisible(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = null;
        categoryPlot6.notifyListeners(plotChangeEvent55);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0L + "'", comparable34.equals(0L));
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(numberTickUnit41);
        org.junit.Assert.assertNull(numberFormat43);
        org.junit.Assert.assertNotNull(numberTickUnit47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        try {
            int int43 = categoryPlot23.getDomainAxisIndex(categoryAxis42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot6.getDomainAxis(3);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setAxisLineStroke(stroke21);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis23.setRightArrow(shape24);
        dateAxis20.setRightArrow(shape24);
        java.awt.Shape shape27 = dateAxis20.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit31 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis28.setTickUnit(numberTickUnit31);
        java.text.NumberFormat numberFormat33 = numberAxis28.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = numberAxis28.getMarkerBand();
        numberAxis28.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis28, xYItemRenderer37);
        java.awt.Stroke stroke39 = xYPlot38.getRangeZeroBaselineStroke();
        categoryPlot6.setRangeCrosshairStroke(stroke39);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(numberTickUnit31);
        org.junit.Assert.assertNull(numberFormat33);
        org.junit.Assert.assertNull(markerAxisBand34);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot22.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str29 = axisLocation28.toString();
        categoryPlot22.setRangeAxisLocation(axisLocation28);
        categoryPlot6.setDomainAxisLocation((int) (short) 0, axisLocation28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        double double39 = categoryPlot38.getRangeCrosshairValue();
        boolean boolean40 = categoryPlot38.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot38.getDomainAxisLocation(2);
        categoryPlot6.setRangeAxisLocation(axisLocation42, true);
        categoryPlot6.setForegroundAlpha((float) 5);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation47 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation47, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str29.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        double double42 = categoryAxis37.getLowerMargin();
        double double43 = categoryAxis37.getCategoryMargin();
        categoryAxis37.setCategoryMargin((double) 0.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        double double10 = valueMarker9.getValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = valueMarker9.getLabelOffset();
        double double13 = rectangleInsets11.calculateLeftInset((double) 2);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        try {
            xYPlot20.addAnnotation(xYAnnotation21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot6.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot6.getDataset();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNull(categoryDataset17);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setRightArrow(shape11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer13);
        categoryPlot14.clearAnnotations();
        categoryPlot14.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot14.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str21 = axisLocation20.toString();
        categoryPlot14.setRangeAxisLocation(axisLocation20);
        categoryPlot6.setRangeAxisLocation(11, axisLocation20, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        try {
            boolean boolean27 = categoryPlot6.removeAnnotation(categoryAnnotation25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str21.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.Object obj1 = null;
        boolean boolean2 = seriesRenderingOrder0.equals(obj1);
        java.lang.String str3 = seriesRenderingOrder0.toString();
        java.lang.String str4 = seriesRenderingOrder0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        double double12 = categoryPlot11.getRangeCrosshairValue();
        categoryPlot11.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getTickLabelPaint();
        boolean boolean17 = dateAxis15.isNegativeArrowVisible();
        categoryPlot11.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) dateAxis15, false);
        boolean boolean20 = seriesRenderingOrder0.equals((java.lang.Object) categoryPlot11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str3.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str4.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        boolean boolean9 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.plot.Plot plot10 = dateAxis1.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.extendWidth(0.0d);
        double double15 = rectangleInsets11.trimWidth((double) (-1));
        dateAxis1.setTickLabelInsets(rectangleInsets11);
        java.awt.Shape shape17 = null;
        try {
            dateAxis1.setUpArrow(shape17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-3.0d) + "'", double15 == (-3.0d));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        categoryPlot23.setNoDataMessage("java.awt.Color[r=0,g=0,b=255]");
        java.awt.Stroke stroke44 = categoryPlot23.getDomainGridlineStroke();
        java.awt.Paint paint45 = null;
        try {
            categoryPlot23.setRangeGridlinePaint(paint45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setDrawSharedDomainAxis(true);
        boolean boolean13 = categoryPlot6.isDomainZoomable();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        categoryMarker1.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable6 = categoryMarker1.getKey();
        java.awt.Stroke stroke7 = categoryMarker1.getStroke();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0L + "'", comparable6.equals(0L));
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        categoryAxis1.setCategoryMargin((double) (byte) 10);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 7.0d, "");
        double double10 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setUpperMargin(0.05d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        categoryPlot6.setAnchorValue((double) 2.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot6.getRangeAxis(10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        categoryPlot6.zoom((double) 0L);
        java.lang.String str26 = categoryPlot6.getPlotType();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot13.setFixedDomainAxisSpace(axisSpace18, false);
        float float21 = categoryPlot13.getForegroundAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        int int23 = color22.getGreen();
        xYPlot20.setRangeGridlinePaint((java.awt.Paint) color22);
        int int25 = xYPlot20.getWeight();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType3);
        categoryMarker1.setKey((java.lang.Comparable) 15);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getTickLabelPaint();
        boolean boolean10 = dateAxis7.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis7.lengthToJava2D((double) 'a', rectangle2D12, rectangleEdge13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis7.setAxisLinePaint((java.awt.Paint) color17);
        boolean boolean19 = dateAxis7.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis7.setRange((org.jfree.data.Range) dateRange20, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis26.setRightArrow(shape27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer29);
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        double double34 = categoryAxis33.getUpperMargin();
        categoryAxis33.setMaximumCategoryLabelLines(2);
        java.awt.Color color37 = java.awt.Color.DARK_GRAY;
        categoryAxis33.setLabelPaint((java.awt.Paint) color37);
        categoryAxis33.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int42 = categoryPlot30.getDomainAxisIndex(categoryAxis33);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot30.getDomainAxisEdge((int) '4');
        java.awt.Image image45 = null;
        categoryPlot30.setBackgroundImage(image45);
        categoryMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot30);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        double double51 = categoryAxis50.getUpperMargin();
        categoryAxis50.setMaximumCategoryLabelLines(2);
        java.awt.Color color54 = java.awt.Color.DARK_GRAY;
        categoryAxis50.setLabelPaint((java.awt.Paint) color54);
        categoryAxis50.addCategoryLabelToolTip((java.lang.Comparable) "", "PlotOrientation.HORIZONTAL");
        categoryPlot30.setDomainAxis((int) (byte) 1, categoryAxis50);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryAxis50.getLabelInsets();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleInsets60);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double3 = intervalMarker2.getEndValue();
        java.lang.Object obj4 = intervalMarker2.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(gradientPaintTransformer5);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.general.DatasetGroup datasetGroup42 = categoryPlot23.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis45.setRightArrow(shape46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer48);
        categoryPlot49.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot49.zoomDomainAxes(0.0d, plotRenderingInfo52, point2D53, true);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis58.setRightArrow(shape59);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis58, categoryItemRenderer61);
        categoryPlot62.clearAnnotations();
        categoryPlot62.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot62.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation68 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str69 = axisLocation68.toString();
        categoryPlot62.setRangeAxisLocation(axisLocation68);
        categoryPlot49.setDomainAxisLocation(axisLocation68, true);
        java.awt.Paint paint73 = categoryPlot49.getNoDataMessagePaint();
        categoryPlot23.setRangeCrosshairPaint(paint73);
        org.jfree.chart.axis.CategoryAxis categoryAxis77 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis77.setUpperMargin((double) 7);
        java.awt.Color color81 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke84 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis83.setAxisLineStroke(stroke84);
        java.awt.Color color86 = java.awt.Color.BLUE;
        java.awt.Stroke stroke87 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker89 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color81, stroke84, (java.awt.Paint) color86, stroke87, (float) (byte) 0);
        categoryAxis77.setAxisLineStroke(stroke87);
        categoryPlot23.setDomainAxis((int) (short) 0, categoryAxis77);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNull(valueAxis67);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str69.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(color86);
        org.junit.Assert.assertNotNull(stroke87);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        boolean boolean9 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.plot.Plot plot10 = dateAxis1.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.extendWidth(0.0d);
        double double15 = rectangleInsets11.trimWidth((double) (-1));
        dateAxis1.setTickLabelInsets(rectangleInsets11);
        double double18 = rectangleInsets11.trimWidth((double) 1560495599999L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-3.0d) + "'", double15 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.560495599997E12d + "'", double18 == 1.560495599997E12d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        java.awt.Paint paint4 = categoryMarker1.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType5);
        java.awt.Paint paint7 = categoryMarker1.getLabelPaint();
        java.lang.String str8 = categoryMarker1.getLabel();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot6.getIndexOf(categoryItemRenderer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot6.getRootPlot();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        int int23 = color22.getGreen();
        xYPlot20.setRangeGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation25 = null;
        try {
            boolean boolean26 = xYPlot20.removeAnnotation(xYAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 1);
        double double4 = rectangleInsets0.calculateLeftInset(32.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Color color1 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = dateAxis0.isVerticalTickLabels();
        java.lang.String str8 = dateAxis0.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color1, stroke4);
        java.awt.Color color7 = color1.darker();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        java.lang.Class<?> wildcardClass9 = dateAxis1.getClass();
        java.text.DateFormat dateFormat10 = dateAxis1.getDateFormatOverride();
        java.awt.Paint paint11 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(paint11);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis3.setRightArrow(shape4);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer6);
//        categoryPlot7.clearDomainMarkers();
//        categoryPlot7.zoom((double) (byte) -1);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
//        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis14.setAxisLineStroke(stroke15);
//        java.awt.Color color17 = java.awt.Color.BLUE;
//        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color12, stroke15, (java.awt.Paint) color17, stroke18, (float) (byte) 0);
//        categoryPlot7.setRangeCrosshairStroke(stroke15);
//        boolean boolean22 = day0.equals((java.lang.Object) stroke15);
//        org.jfree.data.time.SerialDate serialDate23 = day0.getSerialDate();
//        long long24 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(shape4);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(stroke15);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43629L + "'", long24 == 43629L);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        dateAxis0.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint12 = dateAxis0.getLabelPaint();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.util.List list17 = dateAxis0.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
        java.lang.Class class18 = null;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone21);
        dateAxis0.setMinimumDate(date19);
        java.lang.String str24 = dateAxis0.getLabelURL();
        dateAxis0.setLowerBound(0.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType8 = numberAxis5.getRangeType();
        numberAxis0.setRangeType(rangeType8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            org.jfree.chart.axis.AxisState axisState16 = numberAxis0.draw(graphics2D10, (double) (-1), rectangle2D12, rectangle2D13, rectangleEdge14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType8);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        categoryPlot6.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot6.setRenderer(0, categoryItemRenderer31, false);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot6.getRangeAxis();
        double double35 = valueAxis34.getLabelAngle();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("CategoryAnchor.END", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        categoryPlot9.zoom((double) 43629L);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis2.setRightArrow(shape3);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
//        categoryPlot6.clearAnnotations();
//        categoryPlot6.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot6.setRenderers(categoryItemRendererArray14);
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis17.setAxisLineStroke(stroke18);
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis20.setRightArrow(shape21);
//        dateAxis17.setRightArrow(shape21);
//        boolean boolean24 = dateAxis17.isAxisLineVisible();
//        java.awt.Paint paint25 = dateAxis17.getTickLabelPaint();
//        org.jfree.data.Range range26 = dateAxis17.getRange();
//        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        long long30 = day29.getLastMillisecond();
//        java.util.Date date31 = day29.getStart();
//        long long32 = day29.getSerialIndex();
//        int int33 = day29.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint35 = dateAxis34.getTickLabelPaint();
//        int int36 = day29.compareTo((java.lang.Object) dateAxis34);
//        java.util.TimeZone timeZone37 = dateAxis34.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone37);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint40 = dateAxis39.getTickLabelPaint();
//        boolean boolean42 = dateAxis39.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D44 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
//        double double46 = dateAxis39.lengthToJava2D((double) 'a', rectangle2D44, rectangleEdge45);
//        boolean boolean47 = dateAxis39.isAutoRange();
//        org.jfree.chart.plot.Plot plot48 = dateAxis39.getPlot();
//        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis49.setAutoRangeIncludesZero(false);
//        java.text.NumberFormat numberFormat52 = null;
//        numberAxis49.setNumberFormatOverride(numberFormat52);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { dateAxis17, dateAxis38, dateAxis39, numberAxis49 };
//        categoryPlot6.setRangeAxes(valueAxisArray54);
//        org.jfree.chart.axis.CategoryAxis categoryAxis57 = categoryPlot6.getDomainAxis((int) (short) 0);
//        org.junit.Assert.assertNotNull(shape3);
//        org.junit.Assert.assertNull(valueAxis11);
//        org.junit.Assert.assertNull(categoryAxis13);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(shape21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertNotNull(range26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(paint40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNull(plot48);
//        org.junit.Assert.assertNotNull(valueAxisArray54);
//        org.junit.Assert.assertNull(categoryAxis57);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font2 = dateAxis1.getLabelFont();
        categoryAxis0.setLabelFont(font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        double double10 = valueMarker9.getValue();
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean12 = valueMarker9.equals((java.lang.Object) paint11);
        org.jfree.chart.text.TextAnchor textAnchor13 = valueMarker9.getLabelTextAnchor();
        valueMarker9.setValue((double) 7);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke20);
        java.awt.Color color22 = java.awt.Color.BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color17, stroke20, (java.awt.Paint) color22, stroke23, (float) (byte) 0);
        double double26 = valueMarker25.getValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker25.getLabelOffset();
        java.awt.Font font28 = valueMarker25.getLabelFont();
        valueMarker9.setLabelFont(font28);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 32.0d + "'", double26 == 32.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        java.awt.Paint paint9 = dateAxis1.getTickLabelPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis1.isAutoTickUnitSelection();
        double double13 = dateAxis1.getLabelAngle();
        dateAxis1.setVisible(true);
        dateAxis1.configure();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis1.removeChangeListener(axisChangeListener3);
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setAutoRange(false);
        java.lang.Object obj8 = dateAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis13.setRightArrow(shape14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer16);
        categoryPlot17.clearAnnotations();
        categoryPlot17.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot17.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str24 = axisLocation23.toString();
        categoryPlot17.setRangeAxisLocation(axisLocation23);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryMarker27.notifyListeners(markerChangeEvent28);
        categoryMarker27.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable32 = categoryMarker27.getKey();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot17.addDomainMarker(categoryMarker27, layer33);
        categoryPlot17.zoom((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot17.getDomainAxisEdge();
        try {
            double double38 = dateAxis1.lengthToJava2D(0.0d, rectangle2D10, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str24.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 0L + "'", comparable32.equals(0L));
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryMarker14.notifyListeners(markerChangeEvent15);
        categoryMarker14.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable19 = categoryMarker14.getKey();
        categoryMarker14.setKey((java.lang.Comparable) '4');
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setRightArrow(shape25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer27);
        categoryPlot28.clearAnnotations();
        categoryPlot28.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot28.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str35 = axisLocation34.toString();
        categoryPlot28.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent39 = null;
        categoryMarker38.notifyListeners(markerChangeEvent39);
        categoryMarker38.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable43 = categoryMarker38.getKey();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot28.addDomainMarker(categoryMarker38, layer44);
        categoryPlot6.addDomainMarker(13, categoryMarker14, layer44, true);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint49 = dateAxis48.getTickLabelPaint();
        boolean boolean51 = dateAxis48.isHiddenValue(10L);
        boolean boolean52 = dateAxis48.isAutoRange();
        double double53 = dateAxis48.getFixedAutoRange();
        java.awt.Font font54 = dateAxis48.getTickLabelFont();
        categoryMarker14.setLabelFont(font54);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 0L + "'", comparable19.equals(0L));
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str35.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 0L + "'", comparable43.equals(0L));
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(font54);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.calculateTopOutset(2.0d);
        double double4 = rectangleInsets0.getBottom();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        double double10 = valueMarker9.getValue();
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean12 = valueMarker9.equals((java.lang.Object) paint11);
        org.jfree.chart.text.TextAnchor textAnchor13 = valueMarker9.getLabelTextAnchor();
        valueMarker9.setValue((double) (-1));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        java.lang.Class class0 = null;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone3);
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint6 = dateAxis5.getTickLabelPaint();
//        boolean boolean8 = dateAxis5.isHiddenValue(10L);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        long long11 = day10.getLastMillisecond();
//        java.util.Date date12 = day10.getStart();
//        long long13 = day10.getSerialIndex();
//        int int14 = day10.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint16 = dateAxis15.getTickLabelPaint();
//        int int17 = day10.compareTo((java.lang.Object) dateAxis15);
//        java.util.TimeZone timeZone18 = dateAxis15.getTimeZone();
//        dateAxis5.setTimeZone(timeZone18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date1, timeZone18);
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
//        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker24.getLabelTextAnchor();
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
//        categoryMarker24.setLabelOffsetType(lengthAdjustmentType26);
//        categoryMarker24.setKey((java.lang.Comparable) 15);
//        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint31 = dateAxis30.getTickLabelPaint();
//        boolean boolean33 = dateAxis30.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D35 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
//        double double37 = dateAxis30.lengthToJava2D((double) 'a', rectangle2D35, rectangleEdge36);
//        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        dateAxis30.setTickLabelPaint((java.awt.Paint) color38);
//        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
//        dateAxis30.setAxisLinePaint((java.awt.Paint) color40);
//        boolean boolean42 = dateAxis30.isVerticalTickLabels();
//        org.jfree.data.time.DateRange dateRange43 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
//        dateAxis30.setRange((org.jfree.data.Range) dateRange43, true, false);
//        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
//        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape50 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis49.setRightArrow(shape50);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer52);
//        dateAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
//        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("");
//        double double57 = categoryAxis56.getUpperMargin();
//        categoryAxis56.setMaximumCategoryLabelLines(2);
//        java.awt.Color color60 = java.awt.Color.DARK_GRAY;
//        categoryAxis56.setLabelPaint((java.awt.Paint) color60);
//        categoryAxis56.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
//        int int65 = categoryPlot53.getDomainAxisIndex(categoryAxis56);
//        org.jfree.chart.util.RectangleEdge rectangleEdge67 = categoryPlot53.getDomainAxisEdge((int) '4');
//        java.awt.Image image68 = null;
//        categoryPlot53.setBackgroundImage(image68);
//        categoryMarker24.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot53);
//        int int71 = day22.compareTo((java.lang.Object) categoryMarker24);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(paint6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(paint16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(textAnchor25);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
//        org.junit.Assert.assertNotNull(paint31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
//        org.junit.Assert.assertNotNull(color38);
//        org.junit.Assert.assertNotNull(color40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateRange43);
//        org.junit.Assert.assertNotNull(shape50);
//        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
//        org.junit.Assert.assertNotNull(color60);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertNotNull(rectangleEdge67);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        categoryPlot23.setNoDataMessage("java.awt.Color[r=0,g=0,b=255]");
        java.awt.Stroke stroke44 = categoryPlot23.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = categoryPlot23.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str49 = plotOrientation48.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation47, plotOrientation48);
        categoryPlot23.setRangeAxisLocation((int) 'a', axisLocation47, true);
        org.jfree.chart.axis.AxisLocation axisLocation53 = axisLocation47.getOpposite();
        java.lang.String str54 = axisLocation47.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str49.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str54.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setTickMarkOutsideLength((float) '4');
        dateAxis0.setInverted(false);
        float float9 = dateAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.Color color25 = java.awt.Color.MAGENTA;
        categoryPlot23.setRangeCrosshairPaint((java.awt.Paint) color25);
        java.lang.String str27 = color25.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str27.equals("java.awt.Color[r=255,g=0,b=255]"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date3 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit2);
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        int int2 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "PlotOrientation.HORIZONTAL");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis13.setRightArrow(shape14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer16);
        double double18 = categoryPlot17.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryPlot17.getInsets();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis23.setRightArrow(shape24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer26);
        categoryPlot27.clearAnnotations();
        categoryPlot27.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot27.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str34 = axisLocation33.toString();
        categoryPlot27.setRangeAxisLocation(axisLocation33);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        categoryMarker37.notifyListeners(markerChangeEvent38);
        categoryMarker37.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable42 = categoryMarker37.getKey();
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot27.addDomainMarker(categoryMarker37, layer43);
        categoryPlot27.zoom((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot27.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace49 = categoryAxis1.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot17, rectangle2D20, rectangleEdge47, axisSpace48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str34.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 0L + "'", comparable42.equals(0L));
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        categoryPlot6.zoom((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot6.getDomainAxisEdge();
        java.awt.Stroke stroke27 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot6.getInsets();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, Double.NEGATIVE_INFINITY, (double) 2.0f);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis2.setRightArrow(shape3);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
//        categoryPlot6.clearAnnotations();
//        categoryPlot6.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
//        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        java.lang.String str13 = axisLocation12.toString();
//        categoryPlot6.setRangeAxisLocation(axisLocation12);
//        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
//        categoryMarker16.notifyListeners(markerChangeEvent17);
//        categoryMarker16.setAlpha((float) (byte) 1);
//        java.lang.Comparable comparable21 = categoryMarker16.getKey();
//        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
//        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
//        categoryPlot6.zoom((double) 0L);
//        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot6.getDomainAxisEdge();
//        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
//        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis29.setRightArrow(shape30);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer32);
//        categoryPlot33.clearAnnotations();
//        categoryPlot33.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot33.getRangeAxis((int) (short) 100);
//        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot33.getDomainAxis((int) (short) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray41 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot33.setRenderers(categoryItemRendererArray41);
//        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis44.setAxisLineStroke(stroke45);
//        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape48 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis47.setRightArrow(shape48);
//        dateAxis44.setRightArrow(shape48);
//        boolean boolean51 = dateAxis44.isAxisLineVisible();
//        java.awt.Paint paint52 = dateAxis44.getTickLabelPaint();
//        org.jfree.data.Range range53 = dateAxis44.getRange();
//        java.util.Date date55 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
//        long long57 = day56.getLastMillisecond();
//        java.util.Date date58 = day56.getStart();
//        long long59 = day56.getSerialIndex();
//        int int60 = day56.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint62 = dateAxis61.getTickLabelPaint();
//        int int63 = day56.compareTo((java.lang.Object) dateAxis61);
//        java.util.TimeZone timeZone64 = dateAxis61.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone64);
//        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint67 = dateAxis66.getTickLabelPaint();
//        boolean boolean69 = dateAxis66.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D71 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
//        double double73 = dateAxis66.lengthToJava2D((double) 'a', rectangle2D71, rectangleEdge72);
//        boolean boolean74 = dateAxis66.isAutoRange();
//        org.jfree.chart.plot.Plot plot75 = dateAxis66.getPlot();
//        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis76.setAutoRangeIncludesZero(false);
//        java.text.NumberFormat numberFormat79 = null;
//        numberAxis76.setNumberFormatOverride(numberFormat79);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray81 = new org.jfree.chart.axis.ValueAxis[] { dateAxis44, dateAxis65, dateAxis66, numberAxis76 };
//        categoryPlot33.setRangeAxes(valueAxisArray81);
//        categoryPlot6.setRangeAxes(valueAxisArray81);
//        org.junit.Assert.assertNotNull(shape3);
//        org.junit.Assert.assertNull(valueAxis11);
//        org.junit.Assert.assertNotNull(axisLocation12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
//        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
//        org.junit.Assert.assertNotNull(layer22);
//        org.junit.Assert.assertNotNull(rectangleEdge26);
//        org.junit.Assert.assertNotNull(shape30);
//        org.junit.Assert.assertNull(valueAxis38);
//        org.junit.Assert.assertNull(categoryAxis40);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray41);
//        org.junit.Assert.assertNotNull(stroke45);
//        org.junit.Assert.assertNotNull(shape48);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(paint52);
//        org.junit.Assert.assertNotNull(range53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560495599999L + "'", long57 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(paint62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(paint67);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNull(plot75);
//        org.junit.Assert.assertNotNull(valueAxisArray81);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            boolean boolean17 = categoryPlot6.removeAnnotation(categoryAnnotation15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10, false);
        categoryPlot6.clearDomainMarkers(9);
        java.lang.Class<?> wildcardClass15 = categoryPlot6.getClass();
        categoryPlot6.configureDomainAxes();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot22.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str29 = axisLocation28.toString();
        categoryPlot22.setRangeAxisLocation(axisLocation28);
        categoryPlot6.setDomainAxisLocation((int) (short) 0, axisLocation28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        double double39 = categoryPlot38.getRangeCrosshairValue();
        boolean boolean40 = categoryPlot38.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot38.getDomainAxisLocation(2);
        categoryPlot6.setRangeAxisLocation(axisLocation42, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation42, plotOrientation45);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str29.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        valueMarker9.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = valueMarker9.getLabelAnchor();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot19.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis28.setRightArrow(shape29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer31);
        categoryPlot32.clearAnnotations();
        categoryPlot32.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot32.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str39 = axisLocation38.toString();
        categoryPlot32.setRangeAxisLocation(axisLocation38);
        categoryPlot19.setDomainAxisLocation(axisLocation38, true);
        java.awt.Paint paint43 = categoryPlot19.getNoDataMessagePaint();
        valueMarker9.setOutlinePaint(paint43);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str39.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=255,g=0,b=255]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=255,g=0,b=255]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        java.awt.Color color7 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_RIGHT", 192);
        numberAxis0.setAxisLinePaint((java.awt.Paint) color7);
        int int9 = color7.getRGB();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16777024) + "'", int9 == (-16777024));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.RELATIVE", color1);
        int int3 = color2.getRGB();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16744320) + "'", int3 == (-16744320));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        java.awt.Paint paint4 = categoryMarker1.getOutlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryMarker6.notifyListeners(markerChangeEvent7);
        java.awt.Paint paint9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryMarker6.setPaint(paint9);
        categoryMarker1.setPaint(paint9);
        java.lang.Comparable comparable12 = categoryMarker1.getKey();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = categoryMarker1.getLabelOffsetType();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = dateAxis15.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        categoryPlot23.clearAnnotations();
        categoryPlot23.setDrawSharedDomainAxis(true);
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        boolean boolean28 = categoryPlot23.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat33 = null;
        numberAxis30.setNumberFormatOverride(numberFormat33);
        categoryPlot23.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis30, true);
        categoryPlot23.setRangeGridlinesVisible(true);
        categoryPlot23.setBackgroundImageAlignment(0);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setAxisLineStroke(stroke45);
        java.awt.Color color47 = java.awt.Color.BLUE;
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color42, stroke45, (java.awt.Paint) color47, stroke48, (float) (byte) 0);
        valueMarker50.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = valueMarker50.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent54 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker50);
        categoryPlot23.markerChanged(markerChangeEvent54);
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.JFreeChart jFreeChart57 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType58 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj59 = null;
        boolean boolean60 = chartChangeEventType58.equals(obj59);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor56, jFreeChart57, chartChangeEventType58);
        markerChangeEvent54.setType(chartChangeEventType58);
        categoryMarker1.notifyListeners(markerChangeEvent54);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0L + "'", comparable12.equals(0L));
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertNotNull(chartChangeEventType58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot19.getInsets();
        categoryPlot6.setInsets(rectangleInsets21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets21.createInsetRectangle(rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot11.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot11.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot11.setRenderers(categoryItemRendererArray19);
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) categoryItemRendererArray19);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis27.setRightArrow(shape28);
        dateAxis24.setRightArrow(shape28);
        java.awt.Shape shape31 = dateAxis24.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis32.setTickUnit(numberTickUnit35);
        java.text.NumberFormat numberFormat37 = numberAxis32.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = numberAxis32.getMarkerBand();
        numberAxis32.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer41);
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double46 = intervalMarker45.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer47 = intervalMarker45.getGradientPaintTransformer();
        boolean boolean48 = xYPlot42.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker45);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        java.util.List list51 = null;
        xYPlot42.drawDomainTickBands(graphics2D49, rectangle2D50, list51);
        int int53 = xYPlot42.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setAxisLineStroke(stroke56);
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis58.setRightArrow(shape59);
        dateAxis55.setRightArrow(shape59);
        org.jfree.chart.axis.TickUnitSource tickUnitSource62 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis55.setStandardTickUnits(tickUnitSource62);
        java.lang.Object obj64 = dateAxis55.clone();
        java.awt.Color color65 = java.awt.Color.DARK_GRAY;
        dateAxis55.setTickMarkPaint((java.awt.Paint) color65);
        xYPlot42.setRangeCrosshairPaint((java.awt.Paint) color65);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color65);
        categoryAxis1.setCategoryLabelPositionOffset(500);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(numberTickUnit35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNull(markerAxisBand38);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-1.0d) + "'", double46 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(tickUnitSource62);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType3);
        java.lang.Comparable comparable5 = categoryMarker1.getKey();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setRightArrow(shape11);
        dateAxis7.setRightArrow(shape11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis7.setStandardTickUnits(tickUnitSource14);
        java.lang.Object obj16 = dateAxis7.clone();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        categoryPlot23.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = null;
        categoryPlot23.notifyListeners(plotChangeEvent25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot23.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot23.setRowRenderingOrder(sortOrder28);
        double double30 = categoryPlot23.getRangeCrosshairValue();
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        categoryMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot23);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0L + "'", comparable5.equals(0L));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        boolean boolean11 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint12 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        numberAxis0.setAutoRangeIncludesZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getDomainAxisLocation(2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot6.addChangeListener(plotChangeListener11);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot6.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot6.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis14.setRightArrow(shape15);
        dateAxis11.setRightArrow(shape15);
        java.awt.Shape shape18 = dateAxis11.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis19.setTickUnit(numberTickUnit22);
        java.text.NumberFormat numberFormat24 = numberAxis19.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = numberAxis19.getMarkerBand();
        numberAxis19.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer28);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double33 = intervalMarker32.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer34 = intervalMarker32.getGradientPaintTransformer();
        boolean boolean35 = xYPlot29.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker32);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = xYPlot29.getLegendItems();
        categoryPlot6.setFixedLegendItems(legendItemCollection36);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertNull(numberFormat24);
        org.junit.Assert.assertNull(markerAxisBand25);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(legendItemCollection36);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj3 = null;
        boolean boolean4 = chartChangeEventType2.equals(obj3);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart1, chartChangeEventType2);
        java.lang.String str6 = chartChangeEvent5.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=TextAnchor.HALF_ASCENT_LEFT]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=TextAnchor.HALF_ASCENT_LEFT]"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        boolean boolean22 = xYPlot20.isDomainCrosshairLockedOnData();
        java.awt.Paint paint23 = xYPlot20.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftInset((double) (byte) 0);
        double double3 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            rectangleInsets0.trim(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.trimWidth((double) 1560495599999L);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            rectangleInsets0.trim(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.560495599997E12d + "'", double3 == 1.560495599997E12d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getComponents(floatArray4);
        float[] floatArray6 = color1.getColorComponents(floatArray4);
        float[] floatArray7 = color0.getColorComponents(floatArray4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint17 = dateAxis16.getTickLabelPaint();
        boolean boolean18 = dateAxis16.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis16.setRange((org.jfree.data.Range) dateRange19, false, false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition23 = dateAxis16.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition23);
        dateAxis0.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertNotNull(dateTickMarkPosition23);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 6, 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryMarker22.getLabelTextAnchor();
        java.awt.Paint paint24 = categoryMarker22.getOutlinePaint();
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker22);
        xYPlot20.configureRangeAxes();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot6.getInsets();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        double double42 = categoryAxis37.getLabelAngle();
        java.awt.Paint paint43 = categoryAxis37.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        boolean boolean9 = dateAxis2.isAxisLineVisible();
        boolean boolean10 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis14.getMarkerBand();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer16);
        xYPlot17.mapDatasetToDomainAxis((int) (short) -1, 12);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setRightArrow(shape25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer27);
        categoryPlot28.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot28.zoomDomainAxes(0.0d, plotRenderingInfo31, point2D32, true);
        java.awt.Paint paint35 = categoryPlot28.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot28.setRenderer((int) (byte) 1, categoryItemRenderer37);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis42.setRightArrow(shape43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer45);
        categoryPlot46.clearAnnotations();
        categoryPlot46.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis51 = categoryPlot46.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str53 = axisLocation52.toString();
        categoryPlot46.setRangeAxisLocation(axisLocation52);
        categoryPlot28.setDomainAxisLocation(10, axisLocation52);
        xYPlot17.setDomainAxisLocation(6, axisLocation52);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(markerAxisBand15);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str53.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        int int36 = categoryAxis26.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint38 = dateAxis37.getTickLabelPaint();
        boolean boolean40 = dateAxis37.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = dateAxis37.lengthToJava2D((double) 'a', rectangle2D42, rectangleEdge43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis37.setTickLabelPaint((java.awt.Paint) color45);
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis37.setAxisLinePaint((java.awt.Paint) color47);
        boolean boolean49 = dateAxis37.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis37.setRange((org.jfree.data.Range) dateRange50, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape57 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis56.setRightArrow(shape57);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis56, categoryItemRenderer59);
        dateAxis37.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot60);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor62 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.Object obj63 = null;
        boolean boolean64 = categoryAnchor62.equals(obj63);
        categoryPlot60.setDomainGridlinePosition(categoryAnchor62);
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.data.category.CategoryDataset categoryDataset69 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape72 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis71.setRightArrow(shape72);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, (org.jfree.chart.axis.ValueAxis) dateAxis71, categoryItemRenderer74);
        categoryPlot75.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot75.zoomDomainAxes(0.0d, plotRenderingInfo78, point2D79, true);
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke84 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis83.setAxisLineStroke(stroke84);
        categoryPlot75.setRangeCrosshairStroke(stroke84);
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = categoryPlot75.getRangeAxisEdge();
        try {
            double double88 = categoryAxis26.getCategoryJava2DCoordinate(categoryAnchor62, 10, 7, rectangle2D68, rectangleEdge87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateRange50);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(categoryAnchor62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(rectangleEdge87);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot22.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str29 = axisLocation28.toString();
        categoryPlot22.setRangeAxisLocation(axisLocation28);
        categoryPlot6.setDomainAxisLocation((int) (short) 0, axisLocation28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        double double39 = categoryPlot38.getRangeCrosshairValue();
        boolean boolean40 = categoryPlot38.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot38.getDomainAxisLocation(2);
        categoryPlot6.setRangeAxisLocation(axisLocation42, true);
        java.awt.Stroke stroke45 = categoryPlot6.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str29.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.lang.String str2 = rectangleInsets0.toString();
        double double4 = rectangleInsets0.calculateLeftOutset((double) 11);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str2.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        dateAxis0.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint12 = dateAxis0.getLabelPaint();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.util.List list17 = dateAxis0.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
        java.lang.Class class18 = null;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone21);
        dateAxis0.setMinimumDate(date19);
        java.lang.String str24 = dateAxis0.getLabelURL();
        java.util.TimeZone timeZone25 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        boolean boolean21 = dateAxis2.isAutoRange();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setUpperMargin((double) 7);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color5, stroke8, (java.awt.Paint) color10, stroke11, (float) (byte) 0);
        categoryAxis1.setAxisLineStroke(stroke11);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getTickLabelPaint();
        boolean boolean18 = dateAxis15.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = dateAxis15.lengthToJava2D((double) 'a', rectangle2D20, rectangleEdge21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis15.setAxisLinePaint((java.awt.Paint) color25);
        boolean boolean27 = dateAxis15.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis15.setRange((org.jfree.data.Range) dateRange28, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        double double42 = categoryAxis41.getUpperMargin();
        categoryAxis41.setMaximumCategoryLabelLines(2);
        java.awt.Color color45 = java.awt.Color.DARK_GRAY;
        categoryAxis41.setLabelPaint((java.awt.Paint) color45);
        categoryAxis41.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int50 = categoryPlot38.getDomainAxisIndex(categoryAxis41);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        double double53 = categoryAxis52.getUpperMargin();
        categoryAxis52.setLabelURL("RectangleAnchor.RIGHT");
        int int56 = categoryPlot38.getDomainAxisIndex(categoryAxis52);
        org.jfree.data.general.DatasetGroup datasetGroup57 = categoryPlot38.getDatasetGroup();
        boolean boolean58 = categoryPlot38.getDrawSharedDomainAxis();
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot38.getRangeAxis();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNull(datasetGroup57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(valueAxis60);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getDomainAxisLocation(2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot6.addChangeListener(plotChangeListener11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot6.getRangeAxisLocation(13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        java.awt.Paint paint22 = xYPlot20.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint24 = dateAxis23.getTickLabelPaint();
        boolean boolean26 = dateAxis23.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis23.lengthToJava2D((double) 'a', rectangle2D28, rectangleEdge29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis23.setTickLabelPaint((java.awt.Paint) color31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis23.setAxisLinePaint((java.awt.Paint) color33);
        boolean boolean35 = dateAxis23.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis23.setRange((org.jfree.data.Range) dateRange36, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis42.setRightArrow(shape43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer45);
        dateAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        double double50 = categoryAxis49.getUpperMargin();
        categoryAxis49.setMaximumCategoryLabelLines(2);
        java.awt.Color color53 = java.awt.Color.DARK_GRAY;
        categoryAxis49.setLabelPaint((java.awt.Paint) color53);
        categoryAxis49.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int58 = categoryPlot46.getDomainAxisIndex(categoryAxis49);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("");
        double double61 = categoryAxis60.getUpperMargin();
        categoryAxis60.setLabelURL("RectangleAnchor.RIGHT");
        int int64 = categoryPlot46.getDomainAxisIndex(categoryAxis60);
        categoryPlot46.setNoDataMessage("java.awt.Color[r=0,g=0,b=255]");
        java.awt.Stroke stroke67 = categoryPlot46.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = categoryPlot46.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation70 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation71 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str72 = plotOrientation71.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation70, plotOrientation71);
        categoryPlot46.setRangeAxisLocation((int) 'a', axisLocation70, true);
        xYPlot20.setRangeAxisLocation(axisLocation70, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation78 = null;
        try {
            boolean boolean79 = xYPlot20.removeAnnotation(xYAnnotation78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(plotOrientation71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str72.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge73);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Date date3 = day1.getStart();
//        long long4 = day1.getSerialIndex();
//        int int5 = day1.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint7 = dateAxis6.getTickLabelPaint();
//        int int8 = day1.compareTo((java.lang.Object) dateAxis6);
//        org.jfree.data.time.SerialDate serialDate9 = day1.getSerialDate();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day1.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        double double10 = categoryAxis1.getCategoryMargin();
        double double11 = categoryAxis1.getUpperMargin();
        categoryAxis1.configure();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) (byte) 0, (float) (short) -1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Color color32 = java.awt.Color.getHSBColor((-1.0f), (float) (byte) 10, 1.0f);
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color32);
        java.awt.Paint paint34 = xYPlot20.getDomainTickBandPaint();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setRightArrow(shape39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer41);
        categoryPlot42.clearDomainMarkers();
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean46 = color44.equals((java.lang.Object) false);
        categoryPlot42.setOutlinePaint((java.awt.Paint) color44);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape52 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis51.setRightArrow(shape52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer54);
        categoryPlot55.clearAnnotations();
        categoryPlot55.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot55.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str62 = axisLocation61.toString();
        categoryPlot55.setRangeAxisLocation(axisLocation61);
        org.jfree.chart.plot.CategoryMarker categoryMarker65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent66 = null;
        categoryMarker65.notifyListeners(markerChangeEvent66);
        categoryMarker65.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable70 = categoryMarker65.getKey();
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot55.addDomainMarker(categoryMarker65, layer71);
        java.util.Collection collection73 = categoryPlot42.getDomainMarkers(11, layer71);
        java.util.Collection collection74 = xYPlot20.getDomainMarkers(5, layer71);
        xYPlot20.clearDomainMarkers(6);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str62.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable70 + "' != '" + 0L + "'", comparable70.equals(0L));
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection73);
        org.junit.Assert.assertNull(collection74);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke15);
        categoryPlot6.setRangeCrosshairStroke(stroke15);
        int int18 = categoryPlot6.getBackgroundImageAlignment();
        categoryPlot6.clearRangeMarkers();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Color color0 = java.awt.Color.blue;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=0,b=255]" + "'", str1.equals("java.awt.Color[r=0,g=0,b=255]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        dateAxis1.setAxisLineVisible(true);
        double double7 = dateAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray3 = null;
        float[] floatArray4 = color2.getComponents(floatArray3);
        float[] floatArray5 = color0.getRGBColorComponents(floatArray4);
        int int6 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-8388608) + "'", int6 == (-8388608));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.general.DatasetGroup datasetGroup42 = categoryPlot23.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis45.setRightArrow(shape46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer48);
        categoryPlot49.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot49.zoomDomainAxes(0.0d, plotRenderingInfo52, point2D53, true);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis58.setRightArrow(shape59);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis58, categoryItemRenderer61);
        categoryPlot62.clearAnnotations();
        categoryPlot62.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot62.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation68 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str69 = axisLocation68.toString();
        categoryPlot62.setRangeAxisLocation(axisLocation68);
        categoryPlot49.setDomainAxisLocation(axisLocation68, true);
        java.awt.Paint paint73 = categoryPlot49.getNoDataMessagePaint();
        categoryPlot23.setRangeCrosshairPaint(paint73);
        org.jfree.chart.axis.ValueAxis valueAxis75 = categoryPlot23.getRangeAxis();
        java.awt.Shape shape76 = valueAxis75.getDownArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource77 = valueAxis75.getStandardTickUnits();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNull(valueAxis67);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str69.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(valueAxis75);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(tickUnitSource77);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer7);
        categoryPlot8.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot8.zoomDomainAxes(0.0d, plotRenderingInfo11, point2D12, true);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setRightArrow(shape18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer20);
        categoryPlot21.clearAnnotations();
        categoryPlot21.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot21.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str28 = axisLocation27.toString();
        categoryPlot21.setRangeAxisLocation(axisLocation27);
        categoryPlot8.setDomainAxisLocation(axisLocation27, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot8.zoomRangeAxes((double) (-1), (double) 43629L, plotRenderingInfo34, point2D35);
        categoryPlot8.setRangeCrosshairValue(1.0E-8d, false);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.lang.String str41 = color40.toString();
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color40);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis46.setAxisLineStroke(stroke47);
        java.awt.Color color49 = java.awt.Color.BLUE;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color44, stroke47, (java.awt.Paint) color49, stroke50, (float) (byte) 0);
        java.awt.Paint paint53 = null;
        java.awt.Stroke stroke54 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker56 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) (short) 0, (java.awt.Paint) color40, stroke50, paint53, stroke54, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str28.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=192,g=0,b=192]" + "'", str41.equals("java.awt.Color[r=192,g=0,b=192]"));
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis1.removeChangeListener(axisChangeListener3);
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setAutoRange(false);
        java.lang.Object obj8 = dateAxis1.clone();
        dateAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.extendHeight((double) 0.0f);
        double double6 = rectangleInsets0.calculateRightInset((double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        dateAxis1.setFixedAutoRange((double) (short) 100);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getTickLabelPaint();
        boolean boolean5 = dateAxis2.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis2.lengthToJava2D((double) 'a', rectangle2D7, rectangleEdge8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis2.setTickLabelPaint((java.awt.Paint) color10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis2.setAxisLinePaint((java.awt.Paint) color12);
        boolean boolean14 = dateAxis2.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis2.setRange((org.jfree.data.Range) dateRange15, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis21.setRightArrow(shape22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer24);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot25);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        double double29 = categoryAxis28.getUpperMargin();
        categoryAxis28.setMaximumCategoryLabelLines(2);
        java.awt.Color color32 = java.awt.Color.DARK_GRAY;
        categoryAxis28.setLabelPaint((java.awt.Paint) color32);
        categoryAxis28.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int37 = categoryPlot25.getDomainAxisIndex(categoryAxis28);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        double double40 = categoryAxis39.getUpperMargin();
        categoryAxis39.setLabelURL("RectangleAnchor.RIGHT");
        int int43 = categoryPlot25.getDomainAxisIndex(categoryAxis39);
        double double44 = categoryAxis39.getLowerMargin();
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor48 = categoryMarker47.getLabelTextAnchor();
        java.awt.Font font49 = categoryMarker47.getLabelFont();
        categoryAxis39.setTickLabelFont((java.lang.Comparable) 'a', font49);
        dateAxis1.setLabelFont(font49);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(textAnchor48);
        org.junit.Assert.assertNotNull(font49);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace13, true);
        categoryPlot6.setOutlineVisible(true);
        categoryPlot6.zoom(0.2d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Color color32 = java.awt.Color.getHSBColor((-1.0f), (float) (byte) 10, 1.0f);
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot20.getRenderer((int) (short) 100);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(xYItemRenderer35);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) day4, font5);
        double double7 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        categoryPlot9.setRangeGridlinesVisible(true);
        categoryPlot9.setBackgroundImageAlignment(0);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke31);
        java.awt.Color color33 = java.awt.Color.BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color28, stroke31, (java.awt.Paint) color33, stroke34, (float) (byte) 0);
        valueMarker36.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = valueMarker36.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker36);
        categoryPlot9.markerChanged(markerChangeEvent40);
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot9.getDomainAxisLocation(4);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(axisLocation43);
    }
}

