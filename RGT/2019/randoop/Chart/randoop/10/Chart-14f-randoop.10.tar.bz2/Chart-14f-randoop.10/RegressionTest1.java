import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int int3 = java.awt.Color.HSBtoRGB((float) (-8388608), 1.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16646144) + "'", int3 == (-16646144));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryMarker23.notifyListeners(markerChangeEvent24);
        categoryMarker23.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable28 = categoryMarker23.getKey();
        java.awt.Font font29 = categoryMarker23.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double32 = rectangleInsets30.calculateRightOutset((double) 1);
        categoryMarker23.setLabelOffset(rectangleInsets30);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer39);
        categoryPlot40.clearAnnotations();
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection43 = categoryPlot40.getDomainMarkers(layer42);
        xYPlot20.addDomainMarker(10, (org.jfree.chart.plot.Marker) categoryMarker23, layer42);
        java.awt.Paint paint45 = xYPlot20.getDomainGridlinePaint();
        boolean boolean47 = xYPlot20.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 0L + "'", comparable28.equals(0L));
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 8.0d + "'", double32 == 8.0d);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot6.getRenderer((int) '#');
        float float15 = categoryPlot6.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setAxisLineStroke(stroke27);
        java.awt.Color color29 = java.awt.Color.BLUE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color24, stroke27, (java.awt.Paint) color29, stroke30, (float) (byte) 0);
        valueMarker32.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = valueMarker32.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker32);
        double double37 = valueMarker32.getValue();
        boolean boolean38 = categoryPlot22.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker32);
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker32);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 32.0d + "'", double37 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis11.setRightArrow(shape12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer14);
        categoryPlot15.clearAnnotations();
        categoryPlot15.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot15.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str22 = axisLocation21.toString();
        categoryPlot15.setRangeAxisLocation(axisLocation21);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        categoryMarker25.notifyListeners(markerChangeEvent26);
        categoryMarker25.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable30 = categoryMarker25.getKey();
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot15.addDomainMarker(categoryMarker25, layer31);
        categoryPlot15.zoom((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot15.getDomainAxisEdge();
        try {
            java.util.List list36 = numberAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str22.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + 0L + "'", comparable30.equals(0L));
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        categoryPlot6.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot6.zoomRangeAxes((double) (-1), (double) 43629L, plotRenderingInfo32, point2D33);
        categoryPlot6.setRangeCrosshairValue(1.0E-8d, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.lang.String str39 = color38.toString();
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color38);
        org.jfree.chart.axis.ValueAxis valueAxis42 = categoryPlot6.getRangeAxisForDataset(15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=192,g=0,b=192]" + "'", str39.equals("java.awt.Color[r=192,g=0,b=192]"));
        org.junit.Assert.assertNotNull(valueAxis42);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Color color32 = java.awt.Color.getHSBColor((-1.0f), (float) (byte) 10, 1.0f);
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color32);
        java.awt.Paint paint34 = xYPlot20.getDomainTickBandPaint();
        java.awt.Stroke stroke35 = xYPlot20.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("org.jfree.data.general.DatasetChangeEvent[source=0.05]");
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) 1.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        double double5 = categoryAxis4.getUpperMargin();
        categoryAxis4.setMaximumCategoryLabelLines(2);
        categoryAxis4.setCategoryMargin((double) (byte) 10);
        categoryAxis4.addCategoryLabelToolTip((java.lang.Comparable) 7.0d, "");
        double double13 = categoryAxis4.getCategoryMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis15.setUpperMargin((double) 7);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setAxisLineStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color19, stroke22, (java.awt.Paint) color24, stroke25, (float) (byte) 0);
        categoryAxis15.setAxisLineStroke(stroke25);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions29 = categoryAxis15.getCategoryLabelPositions();
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions29);
        boolean boolean31 = plotOrientation0.equals((java.lang.Object) categoryAxis4);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(categoryLabelPositions29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        categoryMarker1.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable6 = categoryMarker1.getKey();
        java.awt.Font font7 = categoryMarker1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets8.calculateRightOutset((double) 1);
        categoryMarker1.setLabelOffset(rectangleInsets8);
        double double13 = rectangleInsets8.calculateBottomOutset((-1.31802339E8d));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0L + "'", comparable6.equals(0L));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.0d + "'", double10 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) 1.0f);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke20);
        dateAxis19.zoomRange((double) 1L, (double) 2.0f);
        boolean boolean25 = plotOrientation15.equals((java.lang.Object) 1L);
        categoryPlot9.setOrientation(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        boolean boolean4 = dateAxis0.isAutoRange();
        double double5 = dateAxis0.getFixedAutoRange();
        java.awt.Font font6 = dateAxis0.getTickLabelFont();
        boolean boolean8 = dateAxis0.isHiddenValue((long) (byte) 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        objectList1.clear();
        int int3 = objectList1.size();
        java.lang.Object obj4 = objectList1.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke11);
        java.awt.Color color13 = java.awt.Color.BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color8, stroke11, (java.awt.Paint) color13, stroke14, (float) (byte) 0);
        valueMarker16.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = valueMarker16.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker16);
        double double21 = valueMarker16.getValue();
        boolean boolean22 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker16);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot6.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(axisSpace23);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis2.setRightArrow(shape3);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
//        categoryPlot6.clearAnnotations();
//        categoryPlot6.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot6.setRenderers(categoryItemRendererArray14);
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis17.setAxisLineStroke(stroke18);
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis20.setRightArrow(shape21);
//        dateAxis17.setRightArrow(shape21);
//        boolean boolean24 = dateAxis17.isAxisLineVisible();
//        java.awt.Paint paint25 = dateAxis17.getTickLabelPaint();
//        org.jfree.data.Range range26 = dateAxis17.getRange();
//        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        long long30 = day29.getLastMillisecond();
//        java.util.Date date31 = day29.getStart();
//        long long32 = day29.getSerialIndex();
//        int int33 = day29.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint35 = dateAxis34.getTickLabelPaint();
//        int int36 = day29.compareTo((java.lang.Object) dateAxis34);
//        java.util.TimeZone timeZone37 = dateAxis34.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone37);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint40 = dateAxis39.getTickLabelPaint();
//        boolean boolean42 = dateAxis39.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D44 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
//        double double46 = dateAxis39.lengthToJava2D((double) 'a', rectangle2D44, rectangleEdge45);
//        boolean boolean47 = dateAxis39.isAutoRange();
//        org.jfree.chart.plot.Plot plot48 = dateAxis39.getPlot();
//        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis49.setAutoRangeIncludesZero(false);
//        java.text.NumberFormat numberFormat52 = null;
//        numberAxis49.setNumberFormatOverride(numberFormat52);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { dateAxis17, dateAxis38, dateAxis39, numberAxis49 };
//        categoryPlot6.setRangeAxes(valueAxisArray54);
//        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
//        categoryPlot6.setDataset(categoryDataset56);
//        org.junit.Assert.assertNotNull(shape3);
//        org.junit.Assert.assertNull(valueAxis11);
//        org.junit.Assert.assertNull(categoryAxis13);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(shape21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertNotNull(range26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(paint40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNull(plot48);
//        org.junit.Assert.assertNotNull(valueAxisArray54);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis0.getMarkerBand();
        numberAxis0.setUpperMargin((double) (byte) 0);
        numberAxis0.setTickMarkInsideLength((float) (short) 0);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNull(markerAxisBand6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) (-1));
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1), dataset5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        boolean boolean24 = numberAxis16.equals((java.lang.Object) 43629L);
        java.awt.Paint paint25 = numberAxis16.getLabelPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str19 = plotOrientation18.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation18);
        categoryPlot6.setDomainAxisLocation(axisLocation17, true);
        java.lang.String str23 = axisLocation17.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str19.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str23.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        categoryPlot23.setNoDataMessage("java.awt.Color[r=0,g=0,b=255]");
        java.awt.Stroke stroke44 = categoryPlot23.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = categoryPlot23.getInsets();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets45.createInsetRectangle(rectangle2D46, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 100, 192, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Color color32 = java.awt.Color.getHSBColor((-1.0f), (float) (byte) 10, 1.0f);
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color32);
        xYPlot20.clearAnnotations();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double3 = intervalMarker2.getEndValue();
        java.lang.Object obj4 = intervalMarker2.clone();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setAxisLineStroke(stroke9);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color6, stroke9);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker11);
        intervalMarker2.notifyListeners(markerChangeEvent12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis0.isAutoRange();
        dateAxis0.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint12 = dateAxis0.getLabelPaint();
        dateAxis0.resizeRange((double) 11);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int16 = color15.getGreen();
        dateAxis0.setLabelPaint((java.awt.Paint) color15);
        dateAxis0.zoomRange((double) 1560495599999L, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint22 = dateAxis21.getTickLabelPaint();
        boolean boolean24 = dateAxis21.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis21.lengthToJava2D((double) 'a', rectangle2D26, rectangleEdge27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis21.setTickLabelPaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis21.setAxisLinePaint((java.awt.Paint) color31);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis33.setRightArrow(shape34);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape37 = defaultDrawingSupplier36.getNextShape();
        dateAxis33.setLeftArrow(shape37);
        dateAxis21.setUpArrow(shape37);
        dateAxis0.setRightArrow(shape37);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 192 + "'", int16 == 192);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setRightArrow(shape11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer13);
        categoryPlot14.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        categoryPlot14.notifyListeners(plotChangeEvent16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder19 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder19);
        double double21 = categoryPlot14.getRangeCrosshairValue();
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot6.getRendererForDataset(categoryDataset23);
        categoryPlot6.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double33 = intervalMarker32.getEndValue();
        boolean boolean34 = numberAxis27.equals((java.lang.Object) intervalMarker32);
        intervalMarker32.setEndValue(1.0d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer37 = null;
        intervalMarker32.setGradientPaintTransformer(gradientPaintTransformer37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = intervalMarker32.getLabelOffset();
        categoryPlot6.setInsets(rectangleInsets39, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.Color color25 = java.awt.Color.MAGENTA;
        categoryPlot23.setRangeCrosshairPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.Marker marker27 = null;
        boolean boolean28 = categoryPlot23.removeDomainMarker(marker27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint31 = dateAxis30.getTickLabelPaint();
        boolean boolean33 = dateAxis30.isHiddenValue(10L);
        java.lang.Object obj34 = dateAxis30.clone();
        dateAxis30.setTickMarkOutsideLength((float) '4');
        categoryPlot23.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis30, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis10.java2DToValue((double) (-16777216), rectangle2D12, rectangleEdge13);
        boolean boolean15 = numberAxis10.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis10.isAxisLineVisible();
        numberAxis10.setInverted(false);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue((double) (-16777216), rectangle2D22, rectangleEdge23);
        java.text.NumberFormat numberFormat25 = numberAxis20.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis26.setTickUnit(numberTickUnit29);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit34);
        numberAxis26.setTickUnit(numberTickUnit34);
        numberAxis20.setTickUnit(numberTickUnit34, false, true);
        numberAxis10.setTickUnit(numberTickUnit34);
        numberAxis1.setTickUnit(numberTickUnit34, true, true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.NEGATIVE_INFINITY + "'", double14 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNull(numberFormat25);
        org.junit.Assert.assertNotNull(numberTickUnit29);
        org.junit.Assert.assertNotNull(numberTickUnit34);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint32 = dateAxis31.getTickLabelPaint();
        boolean boolean34 = dateAxis31.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = dateAxis31.lengthToJava2D((double) 'a', rectangle2D36, rectangleEdge37);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis31.setTickLabelPaint((java.awt.Paint) color39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis31.setAxisLinePaint((java.awt.Paint) color41);
        boolean boolean43 = dateAxis31.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange44 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis31.setRange((org.jfree.data.Range) dateRange44, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape51 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis50.setRightArrow(shape51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer53);
        dateAxis31.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot54);
        xYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        xYPlot20.setRangeCrosshairValue(10.0d, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = xYPlot20.getAxisOffset();
        xYPlot20.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateRange44);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(rectangleInsets60);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot6.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot6.notifyListeners(plotChangeEvent17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        double double21 = categoryAxis20.getUpperMargin();
        categoryAxis20.setMaximumCategoryLabelLines(2);
        java.awt.Color color24 = java.awt.Color.DARK_GRAY;
        categoryAxis20.setLabelPaint((java.awt.Paint) color24);
        categoryAxis20.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int29 = categoryPlot6.getDomainAxisIndex(categoryAxis20);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor32 = categoryMarker31.getLabelTextAnchor();
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryMarker31.setOutlineStroke(stroke33);
        categoryPlot6.addDomainMarker(categoryMarker31);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setUpperMargin((double) 7);
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        double double5 = categoryAxis1.getUpperMargin();
        double double6 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.0d + "'", double5 == 7.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot13.getDomainGridlinePosition();
        boolean boolean19 = categoryPlot13.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup20 = categoryPlot13.getDatasetGroup();
        boolean boolean21 = categoryPlot13.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(datasetGroup20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        categoryAxis26.setLowerMargin((double) 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot13.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        double double21 = categoryAxis20.getUpperMargin();
        categoryAxis20.setMaximumCategoryLabelLines(2);
        java.awt.Color color24 = java.awt.Color.DARK_GRAY;
        categoryAxis20.setLabelPaint((java.awt.Paint) color24);
        categoryAxis20.addCategoryLabelToolTip((java.lang.Comparable) "", "PlotOrientation.HORIZONTAL");
        java.awt.Paint paint30 = categoryAxis20.getTickLabelPaint((java.lang.Comparable) 5);
        boolean boolean31 = categoryAnchor18.equals((java.lang.Object) 5);
        java.lang.String str32 = categoryAnchor18.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str32.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.general.DatasetGroup datasetGroup42 = categoryPlot23.getDatasetGroup();
        boolean boolean43 = categoryPlot23.getDrawSharedDomainAxis();
        categoryPlot23.mapDatasetToDomainAxis(0, (-16646144));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double6 = intervalMarker5.getEndValue();
        boolean boolean7 = numberAxis0.equals((java.lang.Object) intervalMarker5);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis0.setNumberFormatOverride(numberFormat8);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) (-1));
        double double6 = rectangleInsets0.calculateBottomInset(0.0d);
        double double8 = rectangleInsets0.calculateBottomOutset((double) '#');
        java.lang.Object obj9 = null;
        boolean boolean10 = rectangleInsets0.equals(obj9);
        double double12 = rectangleInsets0.calculateBottomInset((double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.Stroke stroke21 = xYPlot20.getDomainCrosshairStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot20.setRenderer(0, xYItemRenderer23, false);
        boolean boolean26 = xYPlot20.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj31 = null;
        boolean boolean32 = datasetRenderingOrder30.equals(obj31);
        xYPlot20.setDatasetRenderingOrder(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        categoryPlot6.zoom((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot6.getDomainAxisEdge();
        java.awt.Stroke stroke27 = categoryPlot6.getOutlineStroke();
        java.lang.String str28 = categoryPlot6.getPlotType();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Category Plot" + "'", str28.equals("Category Plot"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 1560409200000L, (float) (-12566464), (float) 2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.awt.Paint paint4 = categoryMarker1.getPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker1.setLabelTextAnchor(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        double double2 = dateAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis0.getMarkerBand();
        numberAxis0.setUpperMargin((double) (byte) 0);
        java.awt.Stroke stroke9 = numberAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        java.lang.String str3 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        double double2 = categoryAxis1.getUpperMargin();
//        categoryAxis1.setMaximumCategoryLabelLines(2);
//        categoryAxis1.setCategoryMargin((double) (byte) 10);
//        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 7.0d, "");
//        double double10 = categoryAxis1.getCategoryMargin();
//        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis12.setUpperMargin((double) 7);
//        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
//        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis18.setAxisLineStroke(stroke19);
//        java.awt.Color color21 = java.awt.Color.BLUE;
//        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color16, stroke19, (java.awt.Paint) color21, stroke22, (float) (byte) 0);
//        categoryAxis12.setAxisLineStroke(stroke22);
//        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis12.getCategoryLabelPositions();
//        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions26);
//        java.lang.Class class28 = null;
//        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone31);
//        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        long long36 = day35.getLastMillisecond();
//        java.util.Date date37 = day35.getStart();
//        long long38 = day35.getSerialIndex();
//        int int39 = day35.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint41 = dateAxis40.getTickLabelPaint();
//        int int42 = day35.compareTo((java.lang.Object) dateAxis40);
//        java.util.TimeZone timeZone43 = dateAxis40.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date29, timeZone43);
//        java.awt.Font font46 = categoryAxis1.getTickLabelFont((java.lang.Comparable) day45);
//        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
//        org.junit.Assert.assertNotNull(color16);
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(color21);
//        org.junit.Assert.assertNotNull(stroke22);
//        org.junit.Assert.assertNotNull(categoryLabelPositions26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560495599999L + "'", long36 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43629L + "'", long38 == 43629L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertNotNull(paint41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(font46);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot13.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17, true);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setAxisLineStroke(stroke22);
        categoryPlot13.setRangeCrosshairStroke(stroke22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot13.getRangeAxisEdge();
        try {
            java.util.List list26 = numberAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis16.setRightArrow(shape17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer19);
        categoryPlot20.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo23, point2D24, true);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setRightArrow(shape30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer32);
        categoryPlot33.clearAnnotations();
        categoryPlot33.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot33.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str40 = axisLocation39.toString();
        categoryPlot33.setRangeAxisLocation(axisLocation39);
        categoryPlot20.setDomainAxisLocation(axisLocation39, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation39, plotOrientation44);
        categoryPlot6.setRangeAxisLocation(axisLocation39, true);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape51 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis50.setRightArrow(shape51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer53);
        categoryPlot54.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = null;
        categoryPlot54.notifyListeners(plotChangeEvent56);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot54.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder59 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot54.setRowRenderingOrder(sortOrder59);
        categoryPlot6.setColumnRenderingOrder(sortOrder59);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot6.getDomainAxisLocation((int) (byte) 1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str40.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNull(legendItemCollection58);
        org.junit.Assert.assertNotNull(sortOrder59);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge();
        boolean boolean30 = xYPlot20.isRangeZoomable();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis20.setRightArrow(shape21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer23);
        categoryPlot24.clearAnnotations();
        categoryPlot24.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot24.setFixedDomainAxisSpace(axisSpace28, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        boolean boolean34 = categoryPlot24.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker33);
        double double35 = intervalMarker33.getStartValue();
        org.jfree.chart.util.UnitType unitType36 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean37 = intervalMarker33.equals((java.lang.Object) unitType36);
        double double38 = intervalMarker33.getEndValue();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis41.setRightArrow(shape42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis41, categoryItemRenderer44);
        categoryPlot45.clearAnnotations();
        categoryPlot45.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis50 = categoryPlot45.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str52 = axisLocation51.toString();
        categoryPlot45.setRangeAxisLocation(axisLocation51);
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent56 = null;
        categoryMarker55.notifyListeners(markerChangeEvent56);
        categoryMarker55.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable60 = categoryMarker55.getKey();
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot45.addDomainMarker(categoryMarker55, layer61);
        boolean boolean63 = categoryPlot6.removeDomainMarker((-16744320), (org.jfree.chart.plot.Marker) intervalMarker33, layer61);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation64 = null;
        try {
            boolean boolean66 = categoryPlot6.removeAnnotation(categoryAnnotation64, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-1.6777216E7d) + "'", double35 == (-1.6777216E7d));
        org.junit.Assert.assertNotNull(unitType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(valueAxis50);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str52.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + 0L + "'", comparable60.equals(0L));
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryMarker22.getLabelTextAnchor();
        java.awt.Paint paint24 = categoryMarker22.getOutlinePaint();
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker22);
        xYPlot20.clearDomainAxes();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setAxisLineStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        dateAxis33.setRightArrow(shape37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis33.setStandardTickUnits(tickUnitSource40);
        java.lang.Object obj42 = dateAxis33.clone();
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        dateAxis33.setTickMarkPaint((java.awt.Paint) color43);
        xYPlot20.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = xYPlot20.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape50 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis49.setRightArrow(shape50);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer52);
        categoryPlot53.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = null;
        categoryPlot53.notifyListeners(plotChangeEvent55);
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot53.getFixedLegendItems();
        categoryPlot53.setAnchorValue(Double.NEGATIVE_INFINITY);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryPlot53.getAxisOffset();
        java.awt.Color color61 = org.jfree.chart.ChartColor.DARK_RED;
        int int62 = color61.getGreen();
        categoryPlot53.setOutlinePaint((java.awt.Paint) color61);
        xYPlot20.setRangeZeroBaselinePaint((java.awt.Paint) color61);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis66 = xYPlot20.getRangeAxisForDataset(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 500 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis2.setUpperMargin((double) 7);
//        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
//        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis8.setAxisLineStroke(stroke9);
//        java.awt.Color color11 = java.awt.Color.BLUE;
//        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color6, stroke9, (java.awt.Paint) color11, stroke12, (float) (byte) 0);
//        categoryAxis2.setAxisLineStroke(stroke12);
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint17 = dateAxis16.getTickLabelPaint();
//        boolean boolean19 = dateAxis16.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D21 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
//        double double23 = dateAxis16.lengthToJava2D((double) 'a', rectangle2D21, rectangleEdge22);
//        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        dateAxis16.setTickLabelPaint((java.awt.Paint) color24);
//        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_MAGENTA;
//        dateAxis16.setAxisLinePaint((java.awt.Paint) color26);
//        boolean boolean28 = dateAxis16.isVerticalTickLabels();
//        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
//        dateAxis16.setRange((org.jfree.data.Range) dateRange29, true, false);
//        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
//        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis35.setRightArrow(shape36);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer38);
//        dateAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
//        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
//        double double43 = categoryAxis42.getUpperMargin();
//        categoryAxis42.setMaximumCategoryLabelLines(2);
//        java.awt.Color color46 = java.awt.Color.DARK_GRAY;
//        categoryAxis42.setLabelPaint((java.awt.Paint) color46);
//        categoryAxis42.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
//        int int51 = categoryPlot39.getDomainAxisIndex(categoryAxis42);
//        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("");
//        double double54 = categoryAxis53.getUpperMargin();
//        categoryAxis53.setLabelURL("RectangleAnchor.RIGHT");
//        int int57 = categoryPlot39.getDomainAxisIndex(categoryAxis53);
//        org.jfree.data.general.DatasetGroup datasetGroup58 = categoryPlot39.getDatasetGroup();
//        boolean boolean59 = categoryPlot39.getDrawSharedDomainAxis();
//        categoryAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
//        boolean boolean61 = layer0.equals((java.lang.Object) categoryAxis2);
//        categoryAxis2.setMaximumCategoryLabelLines(100);
//        java.lang.Class class64 = null;
//        java.util.Date date65 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
//        java.util.TimeZone timeZone67 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone67);
//        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint70 = dateAxis69.getTickLabelPaint();
//        boolean boolean72 = dateAxis69.isHiddenValue(10L);
//        java.util.Date date73 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
//        long long75 = day74.getLastMillisecond();
//        java.util.Date date76 = day74.getStart();
//        long long77 = day74.getSerialIndex();
//        int int78 = day74.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint80 = dateAxis79.getTickLabelPaint();
//        int int81 = day74.compareTo((java.lang.Object) dateAxis79);
//        java.util.TimeZone timeZone82 = dateAxis79.getTimeZone();
//        dateAxis69.setTimeZone(timeZone82);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date65, timeZone82);
//        int int85 = day84.getDayOfMonth();
//        org.jfree.chart.util.RectangleInsets rectangleInsets86 = new org.jfree.chart.util.RectangleInsets();
//        org.jfree.chart.util.UnitType unitType87 = rectangleInsets86.getUnitType();
//        java.lang.String str88 = unitType87.toString();
//        boolean boolean89 = day84.equals((java.lang.Object) str88);
//        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) boolean89, "");
//        org.junit.Assert.assertNotNull(layer0);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNotNull(stroke9);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNotNull(stroke12);
//        org.junit.Assert.assertNotNull(paint17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
//        org.junit.Assert.assertNotNull(color24);
//        org.junit.Assert.assertNotNull(color26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateRange29);
//        org.junit.Assert.assertNotNull(shape36);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
//        org.junit.Assert.assertNotNull(color46);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertNull(datasetGroup58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(paint70);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560495599999L + "'", long75 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 43629L + "'", long77 == 43629L);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
//        org.junit.Assert.assertNotNull(paint80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 13 + "'", int85 == 13);
//        org.junit.Assert.assertNotNull(unitType87);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "UnitType.ABSOLUTE" + "'", str88.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setRightArrow(shape1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets3.getBottom();
        double double5 = rectangleInsets3.getBottom();
        double double7 = rectangleInsets3.calculateLeftOutset((double) 10L);
        dateAxis0.setLabelInsets(rectangleInsets3);
        double double9 = dateAxis0.getLowerBound();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str15 = plotOrientation14.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        try {
            java.util.List list17 = dateAxis0.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str15.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) 1.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation14, plotOrientation15);
        boolean boolean20 = axisLocation14.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) false);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryMarker29.notifyListeners(markerChangeEvent30);
        categoryMarker29.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable34 = categoryMarker29.getKey();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot19.addDomainMarker(categoryMarker29, layer35);
        java.util.Collection collection37 = categoryPlot6.getDomainMarkers(11, layer35);
        java.awt.Paint paint38 = categoryPlot6.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0L + "'", comparable34.equals(0L));
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomRangeAxes((double) '4', plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace15, true);
        categoryPlot6.configureRangeAxes();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setDrawSharedDomainAxis(true);
        boolean boolean13 = categoryPlot6.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setAxisLineStroke(stroke17);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        dateAxis16.setRightArrow(shape20);
        java.awt.Shape shape23 = dateAxis16.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis24.setTickUnit(numberTickUnit27);
        java.text.NumberFormat numberFormat29 = numberAxis24.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = numberAxis24.getMarkerBand();
        numberAxis24.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis24, xYItemRenderer33);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double38 = intervalMarker37.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = intervalMarker37.getGradientPaintTransformer();
        boolean boolean40 = xYPlot34.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker37);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.util.List list43 = null;
        xYPlot34.drawDomainTickBands(graphics2D41, rectangle2D42, list43);
        int int45 = xYPlot34.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke48);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape51 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis50.setRightArrow(shape51);
        dateAxis47.setRightArrow(shape51);
        org.jfree.chart.axis.TickUnitSource tickUnitSource54 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis47.setStandardTickUnits(tickUnitSource54);
        java.lang.Object obj56 = dateAxis47.clone();
        java.awt.Color color57 = java.awt.Color.DARK_GRAY;
        dateAxis47.setTickMarkPaint((java.awt.Paint) color57);
        xYPlot34.setRangeCrosshairPaint((java.awt.Paint) color57);
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = xYPlot34.getOrientation();
        categoryPlot6.setOrientation(plotOrientation60);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(numberTickUnit27);
        org.junit.Assert.assertNull(numberFormat29);
        org.junit.Assert.assertNull(markerAxisBand30);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(tickUnitSource54);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(plotOrientation60);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        categoryPlot6.zoom((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        double double28 = categoryAxis27.getUpperMargin();
        categoryAxis27.setLabelURL("RectangleAnchor.RIGHT");
        categoryPlot6.setDomainAxis(categoryAxis27);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis32.setTickUnit(numberTickUnit35);
        categoryAxis27.removeCategoryLabelToolTip((java.lang.Comparable) numberTickUnit35);
        categoryAxis27.addCategoryLabelToolTip((java.lang.Comparable) (short) 100, "org.jfree.chart.event.ChartChangeEvent[source=TextAnchor.HALF_ASCENT_LEFT]");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(numberTickUnit35);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis16.setRightArrow(shape17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer19);
        categoryPlot20.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo23, point2D24, true);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setRightArrow(shape30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer32);
        categoryPlot33.clearAnnotations();
        categoryPlot33.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot33.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str40 = axisLocation39.toString();
        categoryPlot33.setRangeAxisLocation(axisLocation39);
        categoryPlot20.setDomainAxisLocation(axisLocation39, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation39, plotOrientation44);
        categoryPlot6.setRangeAxisLocation(axisLocation39, true);
        java.awt.Stroke stroke48 = categoryPlot6.getDomainGridlineStroke();
        java.util.List list49 = categoryPlot6.getCategories();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str40.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(list49);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Date date3 = day1.getStart();
//        long long4 = day1.getSerialIndex();
//        int int5 = day1.getYear();
//        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
//        categoryMarker7.notifyListeners(markerChangeEvent8);
//        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
//        categoryMarker7.setPaint(paint10);
//        int int12 = day1.compareTo((java.lang.Object) categoryMarker7);
//        java.awt.Paint paint13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryMarker7.setOutlinePaint(paint13);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(paint10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(paint13);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        dateAxis0.setNegativeArrowVisible(true);
        boolean boolean10 = dateAxis0.isAutoRange();
        dateAxis0.setLabelToolTip("PlotOrientation.HORIZONTAL");
        java.util.Date date13 = null;
        try {
            dateAxis0.setMaximumDate(date13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource8);
        java.lang.Object obj10 = dateAxis1.clone();
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color11);
        int int13 = color11.getBlue();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 64 + "'", int13 == 64);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        int int12 = color10.getGreen();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryMarker22.getLabelTextAnchor();
        java.awt.Paint paint24 = categoryMarker22.getOutlinePaint();
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker22);
        boolean boolean26 = xYPlot20.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = xYPlot20.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot20.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.Stroke stroke21 = xYPlot20.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.util.List list24 = null;
        xYPlot20.drawDomainTickBands(graphics2D22, rectangle2D23, list24);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setAxisLineStroke(stroke30);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis32.setRightArrow(shape33);
        dateAxis29.setRightArrow(shape33);
        java.awt.Shape shape36 = dateAxis29.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis37.setTickUnit(numberTickUnit40);
        java.text.NumberFormat numberFormat42 = numberAxis37.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand43 = numberAxis37.getMarkerBand();
        numberAxis37.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer46);
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent51 = null;
        categoryMarker50.notifyListeners(markerChangeEvent51);
        categoryMarker50.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable55 = categoryMarker50.getKey();
        java.awt.Font font56 = categoryMarker50.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double59 = rectangleInsets57.calculateRightOutset((double) 1);
        categoryMarker50.setLabelOffset(rectangleInsets57);
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape64 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis63.setRightArrow(shape64);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, (org.jfree.chart.axis.ValueAxis) dateAxis63, categoryItemRenderer66);
        categoryPlot67.clearAnnotations();
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection70 = categoryPlot67.getDomainMarkers(layer69);
        xYPlot47.addDomainMarker(10, (org.jfree.chart.plot.Marker) categoryMarker50, layer69);
        org.jfree.chart.util.Layer layer72 = null;
        try {
            xYPlot20.addDomainMarker(100, (org.jfree.chart.plot.Marker) categoryMarker50, layer72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(numberTickUnit40);
        org.junit.Assert.assertNull(numberFormat42);
        org.junit.Assert.assertNull(markerAxisBand43);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + 0L + "'", comparable55.equals(0L));
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 8.0d + "'", double59 == 8.0d);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertNull(collection70);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.Class<?> wildcardClass4 = color3.getClass();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getComponents(floatArray6);
        float[] floatArray8 = color3.getRGBColorComponents(floatArray7);
        float[] floatArray9 = java.awt.Color.RGBtoHSB((-12566464), (int) (byte) -1, (int) (byte) 10, floatArray7);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryMarker2.notifyListeners(markerChangeEvent3);
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryMarker2.setPaint(paint5);
        java.awt.Paint paint7 = categoryMarker2.getOutlinePaint();
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) categoryMarker2);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis11.setRightArrow(shape12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer14);
        double double16 = categoryPlot15.getRangeCrosshairValue();
        boolean boolean17 = categoryPlot15.isRangeCrosshairVisible();
        categoryMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot15);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot15.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-16777024));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot23.getDomainAxisEdge((int) '4');
        java.awt.Image image38 = null;
        categoryPlot23.setBackgroundImage(image38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot23.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot23.getDomainAxisForDataset(192);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertNull(categoryAxis42);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot19.notifyListeners(plotChangeEvent21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot19.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder24 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot19.setRowRenderingOrder(sortOrder24);
        double double26 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot11);
        boolean boolean29 = categoryPlot11.isRangeGridlinesVisible();
        int int30 = categoryPlot11.getDatasetCount();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke7, (float) (byte) 0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) false);
        valueMarker9.setOutlinePaint((java.awt.Paint) color10);
        valueMarker9.setValue((double) (-65536));
        valueMarker9.setValue((double) (byte) -1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot6.setRenderer(2, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint17 = dateAxis16.getTickLabelPaint();
        boolean boolean19 = dateAxis16.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis16.lengthToJava2D((double) 'a', rectangle2D21, rectangleEdge22);
        boolean boolean24 = dateAxis16.isAutoRange();
        dateAxis16.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint28 = dateAxis16.getLabelPaint();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisState axisState30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        java.util.List list33 = dateAxis16.refreshTicks(graphics2D29, axisState30, rectangle2D31, rectangleEdge32);
        org.jfree.data.Range range34 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.util.List list35 = categoryPlot6.getCategories();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setMaximumCategoryLabelLines(2);
        categoryAxis37.setCategoryMargin((double) (byte) 10);
        categoryAxis37.addCategoryLabelToolTip((java.lang.Comparable) 7.0d, "");
        double double46 = categoryAxis37.getCategoryMargin();
        java.util.List list47 = categoryPlot6.getCategoriesForAxis(categoryAxis37);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis49.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape54 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis53.setRightArrow(shape54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis53, categoryItemRenderer56);
        categoryPlot57.clearAnnotations();
        categoryPlot57.setDrawSharedDomainAxis(true);
        dateAxis49.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot57);
        boolean boolean62 = categoryPlot57.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis();
        numberAxis64.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat67 = null;
        numberAxis64.setNumberFormatOverride(numberFormat67);
        categoryPlot57.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis64, true);
        categoryPlot57.setRangeGridlinesVisible(true);
        categoryPlot57.setBackgroundImageAlignment(0);
        java.awt.Color color76 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke79 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis78.setAxisLineStroke(stroke79);
        java.awt.Color color81 = java.awt.Color.BLUE;
        java.awt.Stroke stroke82 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color76, stroke79, (java.awt.Paint) color81, stroke82, (float) (byte) 0);
        valueMarker84.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor87 = valueMarker84.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent88 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker84);
        categoryPlot57.markerChanged(markerChangeEvent88);
        org.jfree.chart.text.TextAnchor textAnchor90 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.JFreeChart jFreeChart91 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType92 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj93 = null;
        boolean boolean94 = chartChangeEventType92.equals(obj93);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent95 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor90, jFreeChart91, chartChangeEventType92);
        markerChangeEvent88.setType(chartChangeEventType92);
        categoryPlot6.markerChanged(markerChangeEvent88);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(list33);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(list35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.0d + "'", double46 == 10.0d);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(rectangleAnchor87);
        org.junit.Assert.assertNotNull(textAnchor90);
        org.junit.Assert.assertNotNull(chartChangeEventType92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        long long5 = day4.getLastMillisecond();
//        java.util.Date date6 = day4.getStart();
//        long long7 = day4.getSerialIndex();
//        int int8 = day4.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint10 = dateAxis9.getTickLabelPaint();
//        int int11 = day4.compareTo((java.lang.Object) dateAxis9);
//        org.jfree.data.time.SerialDate serialDate12 = day4.getSerialDate();
//        boolean boolean13 = day1.equals((java.lang.Object) day4);
//        long long14 = day1.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(paint10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        boolean boolean22 = xYPlot20.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat26 = null;
        numberAxis23.setNumberFormatOverride(numberFormat26);
        java.awt.Color color30 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_RIGHT", 192);
        numberAxis23.setAxisLinePaint((java.awt.Paint) color30);
        xYPlot20.setRangeGridlinePaint((java.awt.Paint) color30);
        int int33 = xYPlot20.getWeight();
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot20.getDataset();
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        xYPlot20.setDomainZeroBaselinePaint((java.awt.Paint) color35);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis18.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setRightArrow(shape23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer25);
        categoryPlot26.clearAnnotations();
        categoryPlot26.setDrawSharedDomainAxis(true);
        dateAxis18.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot26.setFixedDomainAxisSpace(axisSpace31);
        java.awt.Color color34 = java.awt.Color.magenta;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setRightArrow(shape39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer41);
        categoryPlot42.clearDomainMarkers();
        categoryPlot42.zoom((double) (byte) -1);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis49.setAxisLineStroke(stroke50);
        java.awt.Color color52 = java.awt.Color.BLUE;
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color47, stroke50, (java.awt.Paint) color52, stroke53, (float) (byte) 0);
        categoryPlot42.setRangeCrosshairStroke(stroke50);
        boolean boolean57 = day35.equals((java.lang.Object) stroke50);
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color34, stroke50);
        categoryPlot26.setDomainGridlineStroke(stroke50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke65 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis64.setAxisLineStroke(stroke65);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape68 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis67.setRightArrow(shape68);
        dateAxis64.setRightArrow(shape68);
        java.awt.Shape shape71 = dateAxis64.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis();
        numberAxis72.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit75 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis72.setTickUnit(numberTickUnit75);
        java.text.NumberFormat numberFormat77 = numberAxis72.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand78 = numberAxis72.getMarkerBand();
        numberAxis72.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer81 = null;
        org.jfree.chart.plot.XYPlot xYPlot82 = new org.jfree.chart.plot.XYPlot(xYDataset62, (org.jfree.chart.axis.ValueAxis) dateAxis64, (org.jfree.chart.axis.ValueAxis) numberAxis72, xYItemRenderer81);
        java.awt.geom.Point2D point2D83 = xYPlot82.getQuadrantOrigin();
        categoryPlot26.zoomDomainAxes(0.0d, plotRenderingInfo61, point2D83);
        categoryPlot9.zoomDomainAxes(100.0d, (double) 1L, plotRenderingInfo16, point2D83);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(numberTickUnit75);
        org.junit.Assert.assertNull(numberFormat77);
        org.junit.Assert.assertNull(markerAxisBand78);
        org.junit.Assert.assertNotNull(point2D83);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setAxisLineStroke(stroke14);
        java.awt.Color color16 = java.awt.Color.BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color11, stroke14, (java.awt.Paint) color16, stroke17, (float) (byte) 0);
        categoryPlot6.setRangeCrosshairStroke(stroke14);
        categoryPlot6.setRangeCrosshairValue((double) 1560452399999L);
        categoryPlot6.setBackgroundImageAlignment(10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomDomainAxes((double) 9, (double) 1560495599999L, plotRenderingInfo12, point2D13);
        categoryPlot6.zoom(0.0d);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryMarker22.getLabelTextAnchor();
        java.awt.Paint paint24 = categoryMarker22.getOutlinePaint();
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker22);
        boolean boolean26 = xYPlot20.isRangeCrosshairLockedOnData();
        xYPlot20.clearDomainMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis32.setRightArrow(shape33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer35);
        categoryPlot36.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = null;
        categoryPlot36.notifyListeners(plotChangeEvent38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot36.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot36.zoomRangeAxes((double) '4', plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        categoryPlot36.setFixedRangeAxisSpace(axisSpace45, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis52.setAxisLineStroke(stroke53);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape56 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis55.setRightArrow(shape56);
        dateAxis52.setRightArrow(shape56);
        java.awt.Shape shape59 = dateAxis52.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis();
        numberAxis60.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit63 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis60.setTickUnit(numberTickUnit63);
        java.text.NumberFormat numberFormat65 = numberAxis60.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand66 = numberAxis60.getMarkerBand();
        numberAxis60.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset50, (org.jfree.chart.axis.ValueAxis) dateAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis60, xYItemRenderer69);
        java.awt.geom.Point2D point2D71 = xYPlot70.getQuadrantOrigin();
        categoryPlot36.zoomRangeAxes(7.0d, plotRenderingInfo49, point2D71);
        try {
            xYPlot20.zoomRangeAxes((double) 7, plotRenderingInfo29, point2D71, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(numberTickUnit63);
        org.junit.Assert.assertNull(numberFormat65);
        org.junit.Assert.assertNull(markerAxisBand66);
        org.junit.Assert.assertNotNull(point2D71);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType12 = numberAxis9.getRangeType();
        numberAxis4.setRangeType(rangeType12);
        numberAxis0.setRangeType(rangeType12);
        numberAxis0.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(rangeType12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getBottom();
        double double2 = rectangleInsets0.getBottom();
        double double4 = rectangleInsets0.calculateLeftOutset((double) 10L);
        double double6 = rectangleInsets0.trimWidth((double) 6);
        double double8 = rectangleInsets0.calculateTopInset((double) (-12566464));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        java.awt.Paint paint9 = dateAxis1.getTickLabelPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = dateAxis1.getTickMarkPaint();
        boolean boolean13 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint32 = dateAxis31.getTickLabelPaint();
        boolean boolean34 = dateAxis31.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = dateAxis31.lengthToJava2D((double) 'a', rectangle2D36, rectangleEdge37);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis31.setTickLabelPaint((java.awt.Paint) color39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis31.setAxisLinePaint((java.awt.Paint) color41);
        boolean boolean43 = dateAxis31.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange44 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis31.setRange((org.jfree.data.Range) dateRange44, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape51 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis50.setRightArrow(shape51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer53);
        dateAxis31.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot54);
        xYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        xYPlot20.setRangeCrosshairValue(10.0d, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = xYPlot20.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace61 = xYPlot20.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateRange44);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNull(axisSpace61);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        numberAxis1.setAutoTickUnitSelection(true, true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke12);
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        dateAxis11.setLabelPaint(paint14);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis11.getTickUnit();
        dateAxis1.setTickUnit(dateTickUnit18, true, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(dateTickUnit18);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot20.getRangeAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double26 = intervalMarker25.getEndValue();
        java.lang.Object obj27 = intervalMarker25.clone();
        boolean boolean28 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker25);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        java.awt.Color color7 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_RIGHT", 192);
        numberAxis0.setAxisLinePaint((java.awt.Paint) color7);
        org.jfree.data.RangeType rangeType9 = numberAxis0.getRangeType();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rangeType9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        float float12 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.zoomRange((double) 0.0f, (double) (short) 100);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setAxisLineStroke(stroke18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis20.setRightArrow(shape21);
        dateAxis17.setRightArrow(shape21);
        java.awt.Shape shape24 = dateAxis17.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis17.valueToJava2D((double) (short) 100, rectangle2D26, rectangleEdge27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        dateAxis17.setLabelPaint((java.awt.Paint) color29);
        dateAxis0.setTickLabelPaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setRightArrow(shape1);
        java.util.Date date3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str7 = plotOrientation6.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation5, plotOrientation6);
        try {
            double double9 = dateAxis0.dateToJava2D(date3, rectangle2D4, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Date date3 = day1.getStart();
//        long long4 = day1.getMiddleMillisecond();
//        int int5 = day1.getDayOfMonth();
//        boolean boolean7 = day1.equals((java.lang.Object) "AxisLocation.BOTTOM_OR_RIGHT");
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        int int24 = categoryPlot6.getDatasetCount();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getTickLabelPaint();
        boolean boolean28 = dateAxis25.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = dateAxis25.lengthToJava2D((double) 'a', rectangle2D30, rectangleEdge31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis25.setTickLabelPaint((java.awt.Paint) color33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis25.setAxisLinePaint((java.awt.Paint) color35);
        boolean boolean37 = dateAxis25.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis25.setRange((org.jfree.data.Range) dateRange38, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape45 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis44.setRightArrow(shape45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer47);
        dateAxis25.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        double double52 = categoryAxis51.getUpperMargin();
        categoryAxis51.setMaximumCategoryLabelLines(2);
        java.awt.Color color55 = java.awt.Color.DARK_GRAY;
        categoryAxis51.setLabelPaint((java.awt.Paint) color55);
        categoryAxis51.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int60 = categoryPlot48.getDomainAxisIndex(categoryAxis51);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        double double63 = categoryAxis62.getUpperMargin();
        categoryAxis62.setLabelURL("RectangleAnchor.RIGHT");
        int int66 = categoryPlot48.getDomainAxisIndex(categoryAxis62);
        java.awt.Font font68 = categoryAxis62.getTickLabelFont((java.lang.Comparable) (short) 100);
        categoryAxis62.setCategoryLabelPositionOffset(500);
        int int71 = categoryPlot6.getDomainAxisIndex(categoryAxis62);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateRange38);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.05d + "'", double52 == 0.05d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.05d + "'", double63 == 0.05d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType32 = rectangleInsets31.getUnitType();
        xYPlot20.setAxisOffset(rectangleInsets31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat37 = null;
        numberAxis34.setNumberFormatOverride(numberFormat37);
        numberAxis34.setRangeWithMargins((double) (short) -1, (double) 100L);
        boolean boolean42 = numberAxis34.isPositiveArrowVisible();
        numberAxis34.setUpperBound((double) (short) 10);
        boolean boolean45 = rectangleInsets31.equals((java.lang.Object) numberAxis34);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(unitType32);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getTickLabelPaint();
        boolean boolean7 = dateAxis4.isHiddenValue(10L);
        java.lang.Object obj8 = dateAxis4.clone();
        dateAxis4.setTickMarkOutsideLength((float) '4');
        dateAxis4.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        dateAxis4.setTickUnit(dateTickUnit13, false, false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint18 = dateAxis17.getTickLabelPaint();
        boolean boolean19 = dateAxis17.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis17.setRange((org.jfree.data.Range) dateRange20, false, false);
        dateAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange20);
        numberAxis0.setRange((org.jfree.data.Range) dateRange20, true, true);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = numberAxis29.java2DToValue((double) (-16777216), rectangle2D31, rectangleEdge32);
        boolean boolean34 = numberAxis29.getAutoRangeStickyZero();
        boolean boolean35 = numberAxis29.isAxisLineVisible();
        numberAxis29.setInverted(false);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis39.java2DToValue((double) (-16777216), rectangle2D41, rectangleEdge42);
        java.text.NumberFormat numberFormat44 = numberAxis39.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit48 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis45.setTickUnit(numberTickUnit48);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        numberAxis50.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit53 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis50.setTickUnit(numberTickUnit53);
        numberAxis45.setTickUnit(numberTickUnit53);
        numberAxis39.setTickUnit(numberTickUnit53, false, true);
        numberAxis29.setTickUnit(numberTickUnit53);
        numberAxis0.setTickUnit(numberTickUnit53);
        numberAxis0.setTickMarkInsideLength((float) 100);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.NEGATIVE_INFINITY + "'", double33 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNull(numberFormat44);
        org.junit.Assert.assertNotNull(numberTickUnit48);
        org.junit.Assert.assertNotNull(numberTickUnit53);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis2.setUpperMargin((double) 7);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setAxisLineStroke(stroke9);
        java.awt.Color color11 = java.awt.Color.BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color6, stroke9, (java.awt.Paint) color11, stroke12, (float) (byte) 0);
        categoryAxis2.setAxisLineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint17 = dateAxis16.getTickLabelPaint();
        boolean boolean19 = dateAxis16.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis16.lengthToJava2D((double) 'a', rectangle2D21, rectangleEdge22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis16.setAxisLinePaint((java.awt.Paint) color26);
        boolean boolean28 = dateAxis16.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis16.setRange((org.jfree.data.Range) dateRange29, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis35.setRightArrow(shape36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer38);
        dateAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        double double43 = categoryAxis42.getUpperMargin();
        categoryAxis42.setMaximumCategoryLabelLines(2);
        java.awt.Color color46 = java.awt.Color.DARK_GRAY;
        categoryAxis42.setLabelPaint((java.awt.Paint) color46);
        categoryAxis42.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int51 = categoryPlot39.getDomainAxisIndex(categoryAxis42);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("");
        double double54 = categoryAxis53.getUpperMargin();
        categoryAxis53.setLabelURL("RectangleAnchor.RIGHT");
        int int57 = categoryPlot39.getDomainAxisIndex(categoryAxis53);
        org.jfree.data.general.DatasetGroup datasetGroup58 = categoryPlot39.getDatasetGroup();
        boolean boolean59 = categoryPlot39.getDrawSharedDomainAxis();
        categoryAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        boolean boolean61 = layer0.equals((java.lang.Object) categoryAxis2);
        boolean boolean63 = layer0.equals((java.lang.Object) "NO_CHANGE");
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNull(datasetGroup58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        categoryPlot6.clearDomainMarkers((int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint28 = dateAxis27.getTickLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke31);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis33.setRightArrow(shape34);
        dateAxis30.setRightArrow(shape34);
        java.awt.Shape shape37 = dateAxis30.getLeftArrow();
        org.jfree.data.time.DateRange dateRange38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis30.setRange((org.jfree.data.Range) dateRange38);
        dateAxis27.setRange((org.jfree.data.Range) dateRange38);
        valueAxis26.setRange((org.jfree.data.Range) dateRange38, false, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(valueAxis26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(dateRange38);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 1);
        double double4 = rectangleInsets0.calculateBottomOutset((double) (-1.0f));
        double double6 = rectangleInsets0.calculateLeftOutset((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        boolean boolean22 = xYPlot20.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat26 = null;
        numberAxis23.setNumberFormatOverride(numberFormat26);
        java.awt.Color color30 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_RIGHT", 192);
        numberAxis23.setAxisLinePaint((java.awt.Paint) color30);
        xYPlot20.setRangeGridlinePaint((java.awt.Paint) color30);
        xYPlot20.clearAnnotations();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        int int35 = xYPlot20.indexOf(xYDataset34);
        boolean boolean36 = xYPlot20.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis39.setAxisLineStroke(stroke40);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis42.setRightArrow(shape43);
        dateAxis39.setRightArrow(shape43);
        java.awt.Shape shape46 = dateAxis39.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        numberAxis47.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit50 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis47.setTickUnit(numberTickUnit50);
        java.text.NumberFormat numberFormat52 = numberAxis47.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = numberAxis47.getMarkerBand();
        numberAxis47.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis47, xYItemRenderer56);
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent61 = null;
        categoryMarker60.notifyListeners(markerChangeEvent61);
        categoryMarker60.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable65 = categoryMarker60.getKey();
        java.awt.Font font66 = categoryMarker60.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double69 = rectangleInsets67.calculateRightOutset((double) 1);
        categoryMarker60.setLabelOffset(rectangleInsets67);
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape74 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis73.setRightArrow(shape74);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer76 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, (org.jfree.chart.axis.ValueAxis) dateAxis73, categoryItemRenderer76);
        categoryPlot77.clearAnnotations();
        org.jfree.chart.util.Layer layer79 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection80 = categoryPlot77.getDomainMarkers(layer79);
        xYPlot57.addDomainMarker(10, (org.jfree.chart.plot.Marker) categoryMarker60, layer79);
        org.jfree.chart.text.TextAnchor textAnchor82 = categoryMarker60.getLabelTextAnchor();
        boolean boolean83 = xYPlot20.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(numberTickUnit50);
        org.junit.Assert.assertNull(numberFormat52);
        org.junit.Assert.assertNull(markerAxisBand53);
        org.junit.Assert.assertTrue("'" + comparable65 + "' != '" + 0L + "'", comparable65.equals(0L));
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 8.0d + "'", double69 == 8.0d);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(layer79);
        org.junit.Assert.assertNull(collection80);
        org.junit.Assert.assertNotNull(textAnchor82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
//        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
//        dateAxis1.removeChangeListener(axisChangeListener3);
//        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
//        dateAxis1.setAutoRange(false);
//        java.lang.Object obj8 = dateAxis1.clone();
//        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis1.getTickLabelInsets();
//        java.util.Date date10 = null;
//        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
//        java.lang.Class<?> wildcardClass12 = color11.getClass();
//        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class17 = null;
//        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        long long24 = day23.getLastMillisecond();
//        java.util.Date date25 = day23.getStart();
//        long long26 = day23.getSerialIndex();
//        int int27 = day23.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint29 = dateAxis28.getTickLabelPaint();
//        int int30 = day23.compareTo((java.lang.Object) dateAxis28);
//        java.util.TimeZone timeZone31 = dateAxis28.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone31);
//        try {
//            dateAxis1.setRange(date10, date18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(rectangleInsets2);
//        org.junit.Assert.assertNull(dateFormat5);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(rectangleInsets9);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43629L + "'", long26 == 43629L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(paint29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot22.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str29 = axisLocation28.toString();
        categoryPlot22.setRangeAxisLocation(axisLocation28);
        categoryPlot6.setDomainAxisLocation((int) (short) 0, axisLocation28);
        java.lang.String str32 = axisLocation28.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str29.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str32.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        int int23 = color22.getGreen();
        xYPlot20.setRangeGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray26 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer25 };
        xYPlot20.setRenderers(xYItemRendererArray26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot20.setFixedRangeAxisSpace(axisSpace28);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(xYItemRendererArray26);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        java.awt.Paint paint14 = defaultDrawingSupplier11.getNextOutlinePaint();
        java.awt.Paint paint15 = defaultDrawingSupplier11.getNextFillPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis21.setRightArrow(shape22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets();
        double double25 = rectangleInsets24.getBottom();
        double double26 = rectangleInsets24.getBottom();
        double double28 = rectangleInsets24.calculateLeftOutset((double) 10L);
        dateAxis21.setLabelInsets(rectangleInsets24);
        double double30 = dateAxis21.getLowerBound();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape32 = defaultDrawingSupplier31.getNextShape();
        java.awt.Stroke stroke33 = defaultDrawingSupplier31.getNextOutlineStroke();
        java.awt.Shape shape34 = defaultDrawingSupplier31.getNextShape();
        dateAxis21.setRightArrow(shape34);
        boolean boolean36 = dateAxis21.isAutoTickUnitSelection();
        dateAxis21.setLabelAngle((double) (-1.0f));
        int int39 = xYPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        numberAxis0.setTickMarkOutsideLength((float) 7);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis0.setTickLabelFont(font7);
        java.lang.Object obj9 = numberAxis0.clone();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(8);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getTickLabelPaint();
        boolean boolean6 = dateAxis3.isHiddenValue(10L);
        java.lang.Object obj7 = dateAxis3.clone();
        dateAxis3.setTickMarkOutsideLength((float) '4');
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        dateAxis3.addChangeListener(axisChangeListener10);
        objectList1.set(11, (java.lang.Object) dateAxis3);
        java.lang.Object obj13 = objectList1.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setUpperMargin((double) 7);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color5, stroke8, (java.awt.Paint) color10, stroke11, (float) (byte) 0);
        categoryAxis1.setAxisLineStroke(stroke11);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getTickLabelPaint();
        boolean boolean18 = dateAxis15.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = dateAxis15.lengthToJava2D((double) 'a', rectangle2D20, rectangleEdge21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis15.setAxisLinePaint((java.awt.Paint) color25);
        boolean boolean27 = dateAxis15.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis15.setRange((org.jfree.data.Range) dateRange28, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        double double42 = categoryAxis41.getUpperMargin();
        categoryAxis41.setMaximumCategoryLabelLines(2);
        java.awt.Color color45 = java.awt.Color.DARK_GRAY;
        categoryAxis41.setLabelPaint((java.awt.Paint) color45);
        categoryAxis41.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int50 = categoryPlot38.getDomainAxisIndex(categoryAxis41);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        double double53 = categoryAxis52.getUpperMargin();
        categoryAxis52.setLabelURL("RectangleAnchor.RIGHT");
        int int56 = categoryPlot38.getDomainAxisIndex(categoryAxis52);
        org.jfree.data.general.DatasetGroup datasetGroup57 = categoryPlot38.getDatasetGroup();
        boolean boolean58 = categoryPlot38.getDrawSharedDomainAxis();
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        int int60 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNull(datasetGroup57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        java.awt.Font font43 = categoryAxis37.getTickLabelFont((java.lang.Comparable) (short) 100);
        java.awt.Paint paint45 = categoryAxis37.getTickLabelPaint((java.lang.Comparable) (byte) 0);
        double double46 = categoryAxis37.getLowerMargin();
        java.awt.Stroke stroke47 = categoryAxis37.getTickMarkStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot6.getRangeAxisEdge(2019);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis12.setAxisLineStroke(stroke13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        dateAxis12.setRightArrow(shape16);
        java.awt.Shape shape19 = dateAxis12.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis20.setTickUnit(numberTickUnit23);
        java.text.NumberFormat numberFormat25 = numberAxis20.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = numberAxis20.getMarkerBand();
        numberAxis20.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer29);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double34 = intervalMarker33.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer35 = intervalMarker33.getGradientPaintTransformer();
        boolean boolean36 = xYPlot30.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker33);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot30.setDataset(xYDataset37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str40 = axisLocation39.toString();
        xYPlot30.setDomainAxisLocation(axisLocation39, false);
        categoryPlot6.setRangeAxisLocation((int) '#', axisLocation39);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertNull(numberFormat25);
        org.junit.Assert.assertNull(markerAxisBand26);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + (-1.0d) + "'", double34 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str40.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        boolean boolean6 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getTickLabelPaint();
        boolean boolean12 = dateAxis9.isHiddenValue(10L);
        java.lang.Object obj13 = dateAxis9.clone();
        dateAxis9.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setAxisLineStroke(stroke18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis20.setRightArrow(shape21);
        dateAxis17.setRightArrow(shape21);
        boolean boolean24 = dateAxis17.isAxisLineVisible();
        java.awt.Paint paint25 = dateAxis17.getTickLabelPaint();
        org.jfree.data.Range range26 = dateAxis17.getRange();
        dateAxis9.setRange(range26, false, false);
        numberAxis0.setRange(range26, true, true);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str30 = axisLocation29.toString();
        xYPlot20.setDomainAxisLocation(axisLocation29, false);
        java.lang.String str33 = axisLocation29.toString();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str30.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str33.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot6.getRenderer((int) '#');
        float float15 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot6.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(sortOrder16);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean7 = numberAxis1.isAxisLineVisible();
        numberAxis1.setInverted(false);
        numberAxis1.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        boolean boolean9 = dateAxis2.isAxisLineVisible();
        boolean boolean10 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis14.getMarkerBand();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer16);
        java.awt.Paint paint18 = xYPlot17.getRangeCrosshairPaint();
        java.awt.Stroke stroke19 = xYPlot17.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(markerAxisBand15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.extendHeight((double) 0.0f);
        double double6 = rectangleInsets0.trimWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.0d) + "'", double6 == (-2.0d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        dateAxis1.setAxisLineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearDomainMarkers();
        categoryPlot13.zoom((double) (byte) -1);
        categoryPlot13.setAnchorValue((double) (byte) 10, true);
        categoryPlot13.setAnchorValue((double) 1.0f);
        categoryPlot13.setAnchorValue((double) 0);
        boolean boolean24 = dateAxis1.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setAxisLineStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        dateAxis33.setRightArrow(shape37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis33.setStandardTickUnits(tickUnitSource40);
        java.lang.Object obj42 = dateAxis33.clone();
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        dateAxis33.setTickMarkPaint((java.awt.Paint) color43);
        xYPlot20.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape49 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis48.setRightArrow(shape49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer51);
        categoryPlot52.clearAnnotations();
        categoryPlot52.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot52.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str59 = axisLocation58.toString();
        categoryPlot52.setRangeAxisLocation(axisLocation58);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape65 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis64.setRightArrow(shape65);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis64, categoryItemRenderer67);
        categoryPlot68.clearAnnotations();
        categoryPlot68.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis73 = categoryPlot68.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation74 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str75 = axisLocation74.toString();
        categoryPlot68.setRangeAxisLocation(axisLocation74);
        categoryPlot52.setDomainAxisLocation((int) (short) 0, axisLocation74);
        xYPlot20.setDomainAxisLocation(axisLocation74, false);
        boolean boolean80 = xYPlot20.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str59.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str75.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        numberAxis0.setAutoRangeIncludesZero(true);
        numberAxis0.setTickMarkInsideLength((float) 1560409200000L);
        numberAxis0.setAutoTickUnitSelection(true);
        java.lang.String str11 = numberAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        boolean boolean22 = xYPlot20.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot20.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setAxisLineStroke(stroke29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis31.setRightArrow(shape32);
        dateAxis28.setRightArrow(shape32);
        java.awt.Shape shape35 = dateAxis28.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis36.setTickUnit(numberTickUnit39);
        java.text.NumberFormat numberFormat41 = numberAxis36.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = numberAxis36.getMarkerBand();
        numberAxis36.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer45);
        java.awt.geom.Point2D point2D47 = xYPlot46.getQuadrantOrigin();
        xYPlot20.zoomDomainAxes((double) 4, plotRenderingInfo25, point2D47, false);
        boolean boolean50 = xYPlot20.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(numberTickUnit39);
        org.junit.Assert.assertNull(numberFormat41);
        org.junit.Assert.assertNull(markerAxisBand42);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomRangeAxes((double) '4', plotRenderingInfo12, point2D13);
        java.awt.Paint paint15 = categoryPlot6.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryPlot9.clearAnnotations();
        categoryPlot9.setDrawSharedDomainAxis(true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        categoryPlot9.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis16, true);
        java.awt.Paint paint23 = numberAxis16.getLabelPaint();
        java.awt.Shape shape24 = numberAxis16.getDownArrow();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        boolean boolean9 = dateAxis2.isAxisLineVisible();
        boolean boolean10 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis14.getMarkerBand();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer16);
        java.awt.Paint paint18 = xYPlot17.getRangeCrosshairPaint();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            xYPlot17.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(markerAxisBand15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType3);
        categoryMarker1.setKey((java.lang.Comparable) 15);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getTickLabelPaint();
        boolean boolean10 = dateAxis7.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis7.lengthToJava2D((double) 'a', rectangle2D12, rectangleEdge13);
        boolean boolean15 = dateAxis7.isAutoRange();
        dateAxis7.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint19 = dateAxis7.getLabelPaint();
        dateAxis7.resizeRange((double) 11);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int23 = color22.getGreen();
        dateAxis7.setLabelPaint((java.awt.Paint) color22);
        categoryMarker1.setLabelPaint((java.awt.Paint) color22);
        java.awt.color.ColorSpace colorSpace26 = color22.getColorSpace();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 192 + "'", int23 == 192);
        org.junit.Assert.assertNotNull(colorSpace26);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        boolean boolean9 = dateAxis2.isAxisLineVisible();
        boolean boolean10 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis14.getMarkerBand();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer16);
        xYPlot17.mapDatasetToDomainAxis((int) (short) -1, 12);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setRightArrow(shape25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer27);
        categoryPlot28.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot28.zoomDomainAxes(0.0d, plotRenderingInfo31, point2D32, true);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis37.setRightArrow(shape38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer40);
        categoryPlot41.clearAnnotations();
        categoryPlot41.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot41.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str48 = axisLocation47.toString();
        categoryPlot41.setRangeAxisLocation(axisLocation47);
        categoryPlot28.setDomainAxisLocation(axisLocation47, true);
        try {
            xYPlot17.setDomainAxisLocation((-16646144), axisLocation47, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(markerAxisBand15);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str48.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis6.setRightArrow(shape7);
        dateAxis3.setRightArrow(shape7);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit14);
        java.text.NumberFormat numberFormat16 = numberAxis11.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = numberAxis11.getMarkerBand();
        numberAxis11.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer20);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor24 = categoryMarker23.getLabelTextAnchor();
        java.awt.Paint paint25 = categoryMarker23.getOutlinePaint();
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        int int30 = xYPlot21.getIndexOf(xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis35.setRightArrow(shape36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer38);
        categoryPlot39.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = null;
        categoryPlot39.notifyListeners(plotChangeEvent41);
        org.jfree.chart.LegendItemCollection legendItemCollection43 = categoryPlot39.getFixedLegendItems();
        categoryPlot39.setDrawSharedDomainAxis(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot39.setRenderer(2, categoryItemRenderer47);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint50 = dateAxis49.getTickLabelPaint();
        boolean boolean52 = dateAxis49.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = dateAxis49.lengthToJava2D((double) 'a', rectangle2D54, rectangleEdge55);
        boolean boolean57 = dateAxis49.isAutoRange();
        dateAxis49.zoomRange(0.0d, (double) (short) 0);
        java.awt.Paint paint61 = dateAxis49.getLabelPaint();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.axis.AxisState axisState63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
        java.util.List list66 = dateAxis49.refreshTicks(graphics2D62, axisState63, rectangle2D64, rectangleEdge65);
        org.jfree.data.Range range67 = categoryPlot39.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis49);
        java.util.List list68 = categoryPlot39.getCategories();
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        double double71 = categoryAxis70.getUpperMargin();
        categoryAxis70.setMaximumCategoryLabelLines(2);
        categoryAxis70.setCategoryMargin((double) (byte) 10);
        categoryAxis70.addCategoryLabelToolTip((java.lang.Comparable) 7.0d, "");
        double double79 = categoryAxis70.getCategoryMargin();
        java.util.List list80 = categoryPlot39.getCategoriesForAxis(categoryAxis70);
        xYPlot21.drawDomainTickBands(graphics2D31, rectangle2D32, list80);
        boolean boolean82 = day0.equals((java.lang.Object) list80);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNull(numberFormat16);
        org.junit.Assert.assertNull(markerAxisBand17);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(legendItemCollection43);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNull(list66);
        org.junit.Assert.assertNull(range67);
        org.junit.Assert.assertNull(list68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.05d + "'", double71 == 0.05d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 10.0d + "'", double79 == 10.0d);
        org.junit.Assert.assertNotNull(list80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = dateAxis0.draw(graphics2D1, (double) '#', rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean7 = numberAxis1.isAxisLineVisible();
        boolean boolean8 = numberAxis1.getAutoRangeStickyZero();
        java.lang.String str9 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Color color32 = java.awt.Color.getHSBColor((-1.0f), (float) (byte) 10, 1.0f);
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color32);
        java.awt.Paint paint34 = xYPlot20.getDomainTickBandPaint();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setRightArrow(shape39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer41);
        categoryPlot42.clearDomainMarkers();
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean46 = color44.equals((java.lang.Object) false);
        categoryPlot42.setOutlinePaint((java.awt.Paint) color44);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape52 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis51.setRightArrow(shape52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer54);
        categoryPlot55.clearAnnotations();
        categoryPlot55.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot55.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str62 = axisLocation61.toString();
        categoryPlot55.setRangeAxisLocation(axisLocation61);
        org.jfree.chart.plot.CategoryMarker categoryMarker65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent66 = null;
        categoryMarker65.notifyListeners(markerChangeEvent66);
        categoryMarker65.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable70 = categoryMarker65.getKey();
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot55.addDomainMarker(categoryMarker65, layer71);
        java.util.Collection collection73 = categoryPlot42.getDomainMarkers(11, layer71);
        java.util.Collection collection74 = xYPlot20.getDomainMarkers(5, layer71);
        java.awt.Stroke stroke75 = xYPlot20.getDomainZeroBaselineStroke();
        java.awt.Color color76 = java.awt.Color.CYAN;
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color76);
        java.awt.Stroke stroke78 = xYPlot20.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str62.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable70 + "' != '" + 0L + "'", comparable70.equals(0L));
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.Object obj26 = null;
        boolean boolean27 = categoryAnchor25.equals(obj26);
        categoryPlot23.setDomainGridlinePosition(categoryAnchor25);
        categoryPlot23.setRangeCrosshairValue((double) 9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = categoryPlot23.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(drawingSupplier31);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot6.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setRightArrow(shape23);
        dateAxis19.setRightArrow(shape23);
        java.awt.Shape shape26 = dateAxis19.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis27.setTickUnit(numberTickUnit30);
        java.text.NumberFormat numberFormat32 = numberAxis27.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = numberAxis27.getMarkerBand();
        numberAxis27.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer36);
        java.awt.Stroke stroke38 = xYPlot37.getDomainCrosshairStroke();
        categoryPlot6.setDomainGridlineStroke(stroke38);
        java.lang.Object obj40 = categoryPlot6.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertNull(numberFormat32);
        org.junit.Assert.assertNull(markerAxisBand33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(obj40);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1);
        double double4 = rectangleInsets0.calculateRightInset((double) ' ');
        double double6 = rectangleInsets0.calculateTopInset((double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        boolean boolean9 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoTickUnitSelection(true);
        double double12 = dateAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.Stroke stroke21 = xYPlot20.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis27.setRightArrow(shape28);
        dateAxis24.setRightArrow(shape28);
        java.awt.Shape shape31 = dateAxis24.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis32.setTickUnit(numberTickUnit35);
        java.text.NumberFormat numberFormat37 = numberAxis32.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = numberAxis32.getMarkerBand();
        numberAxis32.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer41);
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double46 = intervalMarker45.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer47 = intervalMarker45.getGradientPaintTransformer();
        boolean boolean48 = xYPlot42.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker45);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        xYPlot42.setDataset(xYDataset49);
        java.awt.Color color54 = java.awt.Color.getHSBColor((-1.0f), (float) (byte) 10, 1.0f);
        xYPlot42.setRangeTickBandPaint((java.awt.Paint) color54);
        java.awt.Paint paint56 = xYPlot42.getDomainTickBandPaint();
        boolean boolean57 = xYPlot42.isOutlineVisible();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint59 = dateAxis58.getTickLabelPaint();
        boolean boolean61 = dateAxis58.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis58.lengthToJava2D((double) 'a', rectangle2D63, rectangleEdge64);
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis58.setTickLabelPaint((java.awt.Paint) color66);
        dateAxis58.setFixedDimension(10.0d);
        boolean boolean70 = xYPlot42.equals((java.lang.Object) dateAxis58);
        int int71 = xYPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis58);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(numberTickUnit35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNull(markerAxisBand38);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-1.0d) + "'", double46 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.Stroke stroke21 = xYPlot20.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.util.List list24 = null;
        xYPlot20.drawDomainTickBands(graphics2D22, rectangle2D23, list24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke31);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis33.setRightArrow(shape34);
        dateAxis30.setRightArrow(shape34);
        java.awt.Shape shape37 = dateAxis30.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis38.setTickUnit(numberTickUnit41);
        java.text.NumberFormat numberFormat43 = numberAxis38.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = numberAxis38.getMarkerBand();
        numberAxis38.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis38, xYItemRenderer47);
        java.awt.geom.Point2D point2D49 = xYPlot48.getQuadrantOrigin();
        boolean boolean50 = xYPlot48.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot48.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis56.setAxisLineStroke(stroke57);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape60 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis59.setRightArrow(shape60);
        dateAxis56.setRightArrow(shape60);
        java.awt.Shape shape63 = dateAxis56.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis();
        numberAxis64.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit67 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis64.setTickUnit(numberTickUnit67);
        java.text.NumberFormat numberFormat69 = numberAxis64.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand70 = numberAxis64.getMarkerBand();
        numberAxis64.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset54, (org.jfree.chart.axis.ValueAxis) dateAxis56, (org.jfree.chart.axis.ValueAxis) numberAxis64, xYItemRenderer73);
        java.awt.geom.Point2D point2D75 = xYPlot74.getQuadrantOrigin();
        xYPlot48.zoomDomainAxes((double) 4, plotRenderingInfo53, point2D75, false);
        xYPlot20.zoomRangeAxes((double) 10L, plotRenderingInfo27, point2D75);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(numberTickUnit41);
        org.junit.Assert.assertNull(numberFormat43);
        org.junit.Assert.assertNull(markerAxisBand44);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(numberTickUnit67);
        org.junit.Assert.assertNull(numberFormat69);
        org.junit.Assert.assertNull(markerAxisBand70);
        org.junit.Assert.assertNotNull(point2D75);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) false);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryMarker29.notifyListeners(markerChangeEvent30);
        categoryMarker29.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable34 = categoryMarker29.getKey();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot19.addDomainMarker(categoryMarker29, layer35);
        java.util.Collection collection37 = categoryPlot6.getDomainMarkers(11, layer35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis38.setTickUnit(numberTickUnit41);
        java.text.NumberFormat numberFormat43 = numberAxis38.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit47 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis44.setTickUnit(numberTickUnit47);
        numberAxis38.setTickUnit(numberTickUnit47, false, false);
        int int52 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        java.awt.Paint paint53 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot6.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0L + "'", comparable34.equals(0L));
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(numberTickUnit41);
        org.junit.Assert.assertNull(numberFormat43);
        org.junit.Assert.assertNotNull(numberTickUnit47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(sortOrder54);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double3 = intervalMarker2.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
        double double5 = intervalMarker2.getEndValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType8 = numberAxis5.getRangeType();
        numberAxis0.setRangeType(rangeType8);
        java.lang.Object obj10 = numberAxis0.clone();
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot20.zoomRangeAxes((double) (byte) 10, plotRenderingInfo33, point2D34);
        xYPlot20.clearRangeMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis42.setRightArrow(shape43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer45);
        categoryPlot46.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = null;
        categoryPlot46.notifyListeners(plotChangeEvent48);
        org.jfree.chart.LegendItemCollection legendItemCollection50 = categoryPlot46.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot46.zoomRangeAxes((double) '4', plotRenderingInfo52, point2D53);
        org.jfree.chart.axis.AxisSpace axisSpace55 = null;
        categoryPlot46.setFixedRangeAxisSpace(axisSpace55, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis62.setAxisLineStroke(stroke63);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis65.setRightArrow(shape66);
        dateAxis62.setRightArrow(shape66);
        java.awt.Shape shape69 = dateAxis62.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis();
        numberAxis70.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit73 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis70.setTickUnit(numberTickUnit73);
        java.text.NumberFormat numberFormat75 = numberAxis70.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand76 = numberAxis70.getMarkerBand();
        numberAxis70.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer79 = null;
        org.jfree.chart.plot.XYPlot xYPlot80 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) dateAxis62, (org.jfree.chart.axis.ValueAxis) numberAxis70, xYItemRenderer79);
        java.awt.geom.Point2D point2D81 = xYPlot80.getQuadrantOrigin();
        categoryPlot46.zoomRangeAxes(7.0d, plotRenderingInfo59, point2D81);
        try {
            xYPlot20.zoomDomainAxes((double) 8, plotRenderingInfo39, point2D81, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNull(legendItemCollection50);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(numberTickUnit73);
        org.junit.Assert.assertNull(numberFormat75);
        org.junit.Assert.assertNull(markerAxisBand76);
        org.junit.Assert.assertNotNull(point2D81);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot13.getDomainGridlinePosition();
        boolean boolean19 = categoryPlot13.isDomainGridlinesVisible();
        java.awt.Stroke stroke20 = categoryPlot13.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot6.setRenderer(categoryItemRenderer14, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor20 = categoryMarker19.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker19.setLabelOffsetType(lengthAdjustmentType21);
        java.lang.Comparable comparable23 = categoryMarker19.getKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis26.setRightArrow(shape27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer29);
        categoryPlot30.clearAnnotations();
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection33 = categoryPlot30.getDomainMarkers(layer32);
        boolean boolean35 = categoryPlot6.removeRangeMarker((-65281), (org.jfree.chart.plot.Marker) categoryMarker19, layer32, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 0L + "'", comparable23.equals(0L));
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot11.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot11.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot11.setRenderers(categoryItemRendererArray19);
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) categoryItemRendererArray19);
        double double22 = categoryAxis1.getLowerMargin();
        categoryAxis1.setUpperMargin(0.0d);
        double double25 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLabelAngle(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getUpperMargin();
        categoryAxis2.setMaximumCategoryLabelLines(2);
        java.awt.Color color6 = java.awt.Color.DARK_GRAY;
        categoryAxis2.setLabelPaint((java.awt.Paint) color6);
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) "", "PlotOrientation.HORIZONTAL");
        java.awt.Paint paint12 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) 5);
        categoryAxis2.setUpperMargin((double) 1560452399999L);
        boolean boolean15 = sortOrder0.equals((java.lang.Object) 1560452399999L);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) (-1));
        double double6 = rectangleInsets0.trimWidth((double) (-8388608));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-8388610.0d) + "'", double6 == (-8388610.0d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = dateAxis0.isVerticalTickLabels();
        double double8 = dateAxis0.getUpperMargin();
        java.awt.Font font9 = dateAxis0.getTickLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit3);
        numberAxis0.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(numberTickUnit3);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
//        objectList1.set((int) (byte) 10, (java.lang.Object) 1.0E-8d);
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint6 = dateAxis5.getTickLabelPaint();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        java.util.Date date8 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit7);
//        int int9 = objectList1.indexOf((java.lang.Object) date8);
//        java.lang.Class class10 = null;
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone13);
//        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        long long18 = day17.getLastMillisecond();
//        java.util.Date date19 = day17.getStart();
//        long long20 = day17.getSerialIndex();
//        int int21 = day17.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint23 = dateAxis22.getTickLabelPaint();
//        int int24 = day17.compareTo((java.lang.Object) dateAxis22);
//        java.util.TimeZone timeZone25 = dateAxis22.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date11, timeZone25);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date8, timeZone25);
//        org.junit.Assert.assertNotNull(paint6);
//        org.junit.Assert.assertNotNull(dateTickUnit7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(paint23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(timeZone25);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setAnchorValue(Double.NEGATIVE_INFINITY);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot6.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot6.getFixedLegendItems();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(legendItemCollection14);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color1, stroke4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker6);
        java.lang.String str8 = markerChangeEvent7.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis0.getStandardTickUnits();
        dateAxis0.zoomRange((double) (-8388608), (double) 15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(tickUnitSource16);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        boolean boolean11 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint12 = categoryPlot6.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot19.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        categoryMarker28.notifyListeners(markerChangeEvent29);
        categoryMarker28.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable33 = categoryMarker28.getKey();
        categoryMarker28.setKey((java.lang.Comparable) '4');
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setRightArrow(shape39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer41);
        categoryPlot42.clearDomainMarkers();
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean46 = color44.equals((java.lang.Object) false);
        categoryPlot42.setOutlinePaint((java.awt.Paint) color44);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape52 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis51.setRightArrow(shape52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer54);
        categoryPlot55.clearAnnotations();
        categoryPlot55.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot55.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str62 = axisLocation61.toString();
        categoryPlot55.setRangeAxisLocation(axisLocation61);
        org.jfree.chart.plot.CategoryMarker categoryMarker65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent66 = null;
        categoryMarker65.notifyListeners(markerChangeEvent66);
        categoryMarker65.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable70 = categoryMarker65.getKey();
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot55.addDomainMarker(categoryMarker65, layer71);
        java.util.Collection collection73 = categoryPlot42.getDomainMarkers(11, layer71);
        boolean boolean75 = categoryPlot19.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker28, layer71, true);
        java.util.Collection collection76 = categoryPlot6.getDomainMarkers(layer71);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 0L + "'", comparable33.equals(0L));
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str62.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable70 + "' != '" + 0L + "'", comparable70.equals(0L));
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(collection76);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        categoryMarker1.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable6 = categoryMarker1.getKey();
        java.awt.Font font7 = categoryMarker1.getLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis12.setAxisLineStroke(stroke13);
        java.awt.Color color15 = java.awt.Color.BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color10, stroke13, (java.awt.Paint) color15, stroke16, (float) (byte) 0);
        java.awt.Color color19 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", color10);
        categoryMarker1.setLabelPaint((java.awt.Paint) color19);
        java.awt.Stroke stroke21 = categoryMarker1.getStroke();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0L + "'", comparable6.equals(0L));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        java.lang.String str10 = rectangleInsets8.toString();
        dateAxis0.setLabelInsets(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str10.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        xYPlot20.setDataset(xYDataset22);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        boolean boolean9 = dateAxis1.isAxisLineVisible();
        dateAxis1.setPositiveArrowVisible(false);
        dateAxis1.setRangeWithMargins((double) (-65281), (double) (-1));
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        categoryPlot38.clearAnnotations();
        categoryPlot38.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot38.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str45 = axisLocation44.toString();
        categoryPlot38.setRangeAxisLocation(axisLocation44);
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryMarker48.notifyListeners(markerChangeEvent49);
        categoryMarker48.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable53 = categoryMarker48.getKey();
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot38.addDomainMarker(categoryMarker48, layer54);
        java.util.Collection collection56 = xYPlot20.getRangeMarkers(layer54);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str45.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + 0L + "'", comparable53.equals(0L));
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertNull(collection56);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "PlotOrientation.HORIZONTAL");
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 5);
        java.awt.Color color13 = java.awt.Color.blue;
        java.lang.String str14 = color13.toString();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 1560409200000L, (java.awt.Paint) color13);
        categoryAxis1.setFixedDimension((double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=0,g=0,b=255]" + "'", str14.equals("java.awt.Color[r=0,g=0,b=255]"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke15);
        categoryPlot6.setRangeCrosshairStroke(stroke15);
        float float18 = categoryPlot6.getForegroundAlpha();
        java.awt.Paint paint19 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        boolean boolean12 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange13, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis19.setRightArrow(shape20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer22);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getUpperMargin();
        categoryAxis26.setMaximumCategoryLabelLines(2);
        java.awt.Color color30 = java.awt.Color.DARK_GRAY;
        categoryAxis26.setLabelPaint((java.awt.Paint) color30);
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        int int35 = categoryPlot23.getDomainAxisIndex(categoryAxis26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getUpperMargin();
        categoryAxis37.setLabelURL("RectangleAnchor.RIGHT");
        int int41 = categoryPlot23.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.general.DatasetGroup datasetGroup42 = categoryPlot23.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis45.setRightArrow(shape46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer48);
        categoryPlot49.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot49.zoomDomainAxes(0.0d, plotRenderingInfo52, point2D53, true);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis58.setRightArrow(shape59);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis58, categoryItemRenderer61);
        categoryPlot62.clearAnnotations();
        categoryPlot62.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot62.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation68 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str69 = axisLocation68.toString();
        categoryPlot62.setRangeAxisLocation(axisLocation68);
        categoryPlot49.setDomainAxisLocation(axisLocation68, true);
        java.awt.Paint paint73 = categoryPlot49.getNoDataMessagePaint();
        categoryPlot23.setRangeCrosshairPaint(paint73);
        org.jfree.chart.axis.ValueAxis valueAxis75 = categoryPlot23.getRangeAxis();
        java.awt.Shape shape76 = valueAxis75.getDownArrow();
        org.jfree.data.category.CategoryDataset categoryDataset77 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = null;
        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape80 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis79.setRightArrow(shape80);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset77, categoryAxis78, (org.jfree.chart.axis.ValueAxis) dateAxis79, categoryItemRenderer82);
        categoryPlot83.clearDomainMarkers();
        categoryPlot83.zoom((double) (byte) -1);
        categoryPlot83.setRangeCrosshairLockedOnData(true);
        valueAxis75.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot83);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = null;
        try {
            categoryPlot83.handleClick((int) ' ', 13, plotRenderingInfo92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNull(valueAxis67);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str69.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(valueAxis75);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(shape80);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) false);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryMarker29.notifyListeners(markerChangeEvent30);
        categoryMarker29.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable34 = categoryMarker29.getKey();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot19.addDomainMarker(categoryMarker29, layer35);
        java.util.Collection collection37 = categoryPlot6.getDomainMarkers(11, layer35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis38.setTickUnit(numberTickUnit41);
        java.text.NumberFormat numberFormat43 = numberAxis38.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit47 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis44.setTickUnit(numberTickUnit47);
        numberAxis38.setTickUnit(numberTickUnit47, false, false);
        int int52 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        try {
            numberAxis38.setRangeWithMargins((double) 10, (double) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.6777216E7).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0L + "'", comparable34.equals(0L));
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(numberTickUnit41);
        org.junit.Assert.assertNull(numberFormat43);
        org.junit.Assert.assertNotNull(numberTickUnit47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setAxisLineStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        dateAxis33.setRightArrow(shape37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis33.setStandardTickUnits(tickUnitSource40);
        java.lang.Object obj42 = dateAxis33.clone();
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        dateAxis33.setTickMarkPaint((java.awt.Paint) color43);
        xYPlot20.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape49 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis48.setRightArrow(shape49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer51);
        categoryPlot52.clearAnnotations();
        categoryPlot52.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot52.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str59 = axisLocation58.toString();
        categoryPlot52.setRangeAxisLocation(axisLocation58);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape65 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis64.setRightArrow(shape65);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis64, categoryItemRenderer67);
        categoryPlot68.clearAnnotations();
        categoryPlot68.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis73 = categoryPlot68.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation74 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str75 = axisLocation74.toString();
        categoryPlot68.setRangeAxisLocation(axisLocation74);
        categoryPlot52.setDomainAxisLocation((int) (short) 0, axisLocation74);
        xYPlot20.setDomainAxisLocation(axisLocation74, false);
        org.jfree.chart.axis.AxisSpace axisSpace80 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace80, false);
        int int83 = xYPlot20.getDomainAxisCount();
        java.awt.Color color84 = java.awt.Color.blue;
        xYPlot20.setDomainGridlinePaint((java.awt.Paint) color84);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer87 = null;
        xYPlot20.setRenderer(0, xYItemRenderer87, true);
        org.jfree.chart.axis.AxisSpace axisSpace90 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace90);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str59.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str75.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(color84);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot11.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot11.getDomainAxis((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot11.setRenderers(categoryItemRendererArray19);
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) categoryItemRendererArray19);
        double double22 = categoryAxis1.getLowerMargin();
        java.awt.Paint paint23 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 7, "hi!");
        java.lang.String str10 = categoryAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(dateRange4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot20.zoomRangeAxes((double) (byte) 10, plotRenderingInfo33, point2D34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot20.getDomainAxisLocation(255);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis2.setRightArrow(shape3);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
//        categoryPlot6.clearAnnotations();
//        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
//        categoryPlot6.notifyListeners(plotChangeEvent8);
//        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
//        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
//        categoryPlot6.setRowRenderingOrder(sortOrder11);
//        double double13 = categoryPlot6.getRangeCrosshairValue();
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis17.setRightArrow(shape18);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer20);
//        categoryPlot21.clearAnnotations();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
//        java.awt.geom.Point2D point2D25 = null;
//        categoryPlot21.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25, true);
//        java.awt.Paint paint28 = categoryPlot21.getDomainGridlinePaint();
//        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot21.getRangeAxisLocation();
//        categoryPlot6.setRangeAxisLocation(5, axisLocation29);
//        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
//        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis34.setAxisLineStroke(stroke35);
//        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color32, stroke35);
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker37);
//        categoryPlot6.markerChanged(markerChangeEvent38);
//        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
//        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis42.setRightArrow(shape43);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer45);
//        categoryPlot46.clearAnnotations();
//        categoryPlot46.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.ValueAxis valueAxis51 = categoryPlot46.getRangeAxis((int) (short) 100);
//        org.jfree.chart.axis.CategoryAxis categoryAxis53 = categoryPlot46.getDomainAxis((int) (short) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray54 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot46.setRenderers(categoryItemRendererArray54);
//        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis57.setAxisLineStroke(stroke58);
//        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape61 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis60.setRightArrow(shape61);
//        dateAxis57.setRightArrow(shape61);
//        boolean boolean64 = dateAxis57.isAxisLineVisible();
//        java.awt.Paint paint65 = dateAxis57.getTickLabelPaint();
//        org.jfree.data.Range range66 = dateAxis57.getRange();
//        java.util.Date date68 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
//        long long70 = day69.getLastMillisecond();
//        java.util.Date date71 = day69.getStart();
//        long long72 = day69.getSerialIndex();
//        int int73 = day69.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint75 = dateAxis74.getTickLabelPaint();
//        int int76 = day69.compareTo((java.lang.Object) dateAxis74);
//        java.util.TimeZone timeZone77 = dateAxis74.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone77);
//        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint80 = dateAxis79.getTickLabelPaint();
//        boolean boolean82 = dateAxis79.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D84 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge85 = null;
//        double double86 = dateAxis79.lengthToJava2D((double) 'a', rectangle2D84, rectangleEdge85);
//        boolean boolean87 = dateAxis79.isAutoRange();
//        org.jfree.chart.plot.Plot plot88 = dateAxis79.getPlot();
//        org.jfree.chart.axis.NumberAxis numberAxis89 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis89.setAutoRangeIncludesZero(false);
//        java.text.NumberFormat numberFormat92 = null;
//        numberAxis89.setNumberFormatOverride(numberFormat92);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray94 = new org.jfree.chart.axis.ValueAxis[] { dateAxis57, dateAxis78, dateAxis79, numberAxis89 };
//        categoryPlot46.setRangeAxes(valueAxisArray94);
//        categoryPlot6.setRangeAxes(valueAxisArray94);
//        org.junit.Assert.assertNotNull(shape3);
//        org.junit.Assert.assertNull(legendItemCollection10);
//        org.junit.Assert.assertNotNull(sortOrder11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertNotNull(shape18);
//        org.junit.Assert.assertNotNull(paint28);
//        org.junit.Assert.assertNotNull(axisLocation29);
//        org.junit.Assert.assertNotNull(color32);
//        org.junit.Assert.assertNotNull(stroke35);
//        org.junit.Assert.assertNotNull(shape43);
//        org.junit.Assert.assertNull(valueAxis51);
//        org.junit.Assert.assertNull(categoryAxis53);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray54);
//        org.junit.Assert.assertNotNull(stroke58);
//        org.junit.Assert.assertNotNull(shape61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertNotNull(paint65);
//        org.junit.Assert.assertNotNull(range66);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560495599999L + "'", long70 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 43629L + "'", long72 == 43629L);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertNotNull(paint75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNotNull(paint80);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNull(plot88);
//        org.junit.Assert.assertNotNull(valueAxisArray94);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) false);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryMarker29.notifyListeners(markerChangeEvent30);
        categoryMarker29.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable34 = categoryMarker29.getKey();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot19.addDomainMarker(categoryMarker29, layer35);
        java.util.Collection collection37 = categoryPlot6.getDomainMarkers(11, layer35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis38.setTickUnit(numberTickUnit41);
        java.text.NumberFormat numberFormat43 = numberAxis38.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit47 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis44.setTickUnit(numberTickUnit47);
        numberAxis38.setTickUnit(numberTickUnit47, false, false);
        int int52 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        java.awt.Paint paint53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot6.setRangeCrosshairPaint(paint53);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0L + "'", comparable34.equals(0L));
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(numberTickUnit41);
        org.junit.Assert.assertNull(numberFormat43);
        org.junit.Assert.assertNotNull(numberTickUnit47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1560409200000L, (double) 0L, (double) ' ', (double) 4);
        double double7 = rectangleInsets5.calculateBottomOutset((double) (short) 100);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setAxisLineStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        dateAxis33.setRightArrow(shape37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis33.setStandardTickUnits(tickUnitSource40);
        java.lang.Object obj42 = dateAxis33.clone();
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        dateAxis33.setTickMarkPaint((java.awt.Paint) color43);
        xYPlot20.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = xYPlot20.getOrientation();
        xYPlot20.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(plotOrientation46);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setAxisLineStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        dateAxis33.setRightArrow(shape37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis33.setStandardTickUnits(tickUnitSource40);
        java.lang.Object obj42 = dateAxis33.clone();
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        dateAxis33.setTickMarkPaint((java.awt.Paint) color43);
        xYPlot20.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape49 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis48.setRightArrow(shape49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer51);
        categoryPlot52.clearAnnotations();
        categoryPlot52.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot52.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str59 = axisLocation58.toString();
        categoryPlot52.setRangeAxisLocation(axisLocation58);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape65 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis64.setRightArrow(shape65);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis64, categoryItemRenderer67);
        categoryPlot68.clearAnnotations();
        categoryPlot68.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis73 = categoryPlot68.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation74 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str75 = axisLocation74.toString();
        categoryPlot68.setRangeAxisLocation(axisLocation74);
        categoryPlot52.setDomainAxisLocation((int) (short) 0, axisLocation74);
        xYPlot20.setDomainAxisLocation(axisLocation74, false);
        org.jfree.chart.axis.AxisSpace axisSpace80 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace80, false);
        int int83 = xYPlot20.getDomainAxisCount();
        java.awt.Paint paint84 = xYPlot20.getOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str59.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str75.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(paint84);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        org.jfree.chart.util.Layer layer19 = null;
        categoryPlot6.addRangeMarker(12, (org.jfree.chart.plot.Marker) categoryMarker16, layer19, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double24 = rectangleInsets22.calculateRightOutset((double) 1);
        double double26 = rectangleInsets22.calculateBottomOutset((double) (-1.0f));
        categoryPlot6.setInsets(rectangleInsets22, true);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setRightArrow(shape30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        double double33 = rectangleInsets32.getBottom();
        double double34 = rectangleInsets32.getBottom();
        double double36 = rectangleInsets32.calculateLeftOutset((double) 10L);
        dateAxis29.setLabelInsets(rectangleInsets32);
        double double38 = dateAxis29.getLowerBound();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape40 = defaultDrawingSupplier39.getNextShape();
        java.awt.Stroke stroke41 = defaultDrawingSupplier39.getNextOutlineStroke();
        java.awt.Shape shape42 = defaultDrawingSupplier39.getNextShape();
        dateAxis29.setRightArrow(shape42);
        boolean boolean44 = dateAxis29.isAutoTickUnitSelection();
        double double45 = dateAxis29.getLowerMargin();
        categoryPlot6.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        try {
            categoryPlot6.drawOutline(graphics2D47, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        boolean boolean16 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        double double17 = intervalMarker15.getStartValue();
        org.jfree.chart.util.UnitType unitType18 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean19 = intervalMarker15.equals((java.lang.Object) unitType18);
        double double20 = intervalMarker15.getEndValue();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        intervalMarker15.setLabelTextAnchor(textAnchor21);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.6777216E7d) + "'", double17 == (-1.6777216E7d));
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNotNull(textAnchor21);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D3, rectangleEdge4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setLowerBound((double) ' ');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Shape shape3 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint4 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Shape shape5 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo11, point2D12, false);
        java.awt.Paint paint15 = categoryPlot6.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        categoryPlot13.clearRangeMarkers(192);
        boolean boolean20 = categoryPlot13.isRangeCrosshairVisible();
        java.awt.Paint paint21 = categoryPlot13.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryMarker16.notifyListeners(markerChangeEvent17);
        categoryMarker16.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable21 = categoryMarker16.getKey();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addDomainMarker(categoryMarker16, layer22);
        categoryPlot6.zoom((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        double double28 = categoryAxis27.getUpperMargin();
        categoryAxis27.setLabelURL("RectangleAnchor.RIGHT");
        categoryPlot6.setDomainAxis(categoryAxis27);
        java.awt.Stroke stroke32 = categoryPlot6.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot6.setRenderer(categoryItemRenderer33, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0L + "'", comparable21.equals(0L));
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("UnitType.RELATIVE");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit5);
        numberAxis2.setTickMarkOutsideLength((float) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis2.getStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource9);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setRightArrow(shape5);
        dateAxis1.setRightArrow(shape5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource8);
        java.lang.Object obj10 = dateAxis1.clone();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        int int13 = day12.getYear();
        java.util.Date date14 = day12.getStart();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot22.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str29 = axisLocation28.toString();
        categoryPlot22.setRangeAxisLocation(axisLocation28);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        categoryMarker32.notifyListeners(markerChangeEvent33);
        categoryMarker32.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable37 = categoryMarker32.getKey();
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot22.addDomainMarker(categoryMarker32, layer38);
        categoryPlot22.zoom((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot22.getDomainAxisEdge();
        try {
            double double43 = dateAxis1.dateToJava2D(date14, rectangle2D15, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str29.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 0L + "'", comparable37.equals(0L));
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        categoryAxis1.setCategoryMargin((double) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        double double9 = categoryAxis8.getUpperMargin();
        categoryAxis8.setMaximumCategoryLabelLines(2);
        categoryAxis8.setCategoryMargin((double) (byte) 10);
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 7.0d, "");
        double double17 = categoryAxis8.getCategoryMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis19.setUpperMargin((double) 7);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke26);
        java.awt.Color color28 = java.awt.Color.BLUE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color23, stroke26, (java.awt.Paint) color28, stroke29, (float) (byte) 0);
        categoryAxis19.setAxisLineStroke(stroke29);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions33 = categoryAxis19.getCategoryLabelPositions();
        categoryAxis8.setCategoryLabelPositions(categoryLabelPositions33);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(categoryLabelPositions33);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        boolean boolean22 = xYPlot20.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot20.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot20.setDataset(64, xYDataset25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot20.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation29 = null;
        try {
            xYPlot20.addAnnotation(xYAnnotation29, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        categoryPlot6.zoom((double) (byte) -1);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryMarker14.notifyListeners(markerChangeEvent15);
        categoryMarker14.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable19 = categoryMarker14.getKey();
        categoryMarker14.setKey((java.lang.Comparable) '4');
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setRightArrow(shape25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer27);
        categoryPlot28.clearAnnotations();
        categoryPlot28.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot28.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str35 = axisLocation34.toString();
        categoryPlot28.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent39 = null;
        categoryMarker38.notifyListeners(markerChangeEvent39);
        categoryMarker38.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable43 = categoryMarker38.getKey();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot28.addDomainMarker(categoryMarker38, layer44);
        categoryPlot6.addDomainMarker(13, categoryMarker14, layer44, true);
        boolean boolean48 = categoryPlot6.isOutlineVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 0L + "'", comparable19.equals(0L));
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str35.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 0L + "'", comparable43.equals(0L));
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(1.560495599997E12d, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLabelURL("RectangleAnchor.RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setRightArrow(shape8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer10);
        categoryPlot11.clearAnnotations();
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot11.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str18 = axisLocation17.toString();
        categoryPlot11.setRangeAxisLocation(axisLocation17);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        categoryMarker21.notifyListeners(markerChangeEvent22);
        categoryMarker21.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable26 = categoryMarker21.getKey();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot11.addDomainMarker(categoryMarker21, layer27);
        categoryPlot11.zoom((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        double double33 = categoryAxis32.getUpperMargin();
        categoryAxis32.setLabelURL("RectangleAnchor.RIGHT");
        categoryPlot11.setDomainAxis(categoryAxis32);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis37.setTickUnit(numberTickUnit40);
        categoryAxis32.removeCategoryLabelToolTip((java.lang.Comparable) numberTickUnit40);
        java.lang.String str43 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) numberTickUnit40);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str18.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 0L + "'", comparable26.equals(0L));
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(numberTickUnit40);
        org.junit.Assert.assertNull(str43);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        categoryPlot13.clearRangeMarkers(192);
        categoryPlot13.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setRightArrow(shape25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer27);
        categoryPlot28.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot28.zoomDomainAxes(0.0d, plotRenderingInfo31, point2D32, true);
        java.awt.Paint paint35 = categoryPlot28.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot28.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean39 = plotOrientation37.equals((java.lang.Object) 1.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation36, plotOrientation37);
        xYPlot20.setOrientation(plotOrientation37);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        double double8 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis0.getTickLabelInsets();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder11);
        double double13 = categoryPlot6.getRangeCrosshairValue();
        int int14 = categoryPlot6.getRangeAxisCount();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setAxisLineStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color16, stroke19, (java.awt.Paint) color21, stroke22, (float) (byte) 0);
        categoryPlot6.setOutlineStroke(stroke19);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.lang.Object obj4 = dateAxis0.clone();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot13.getDomainAxisForDataset((int) '4');
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot13.removeDomainMarker((int) '4', marker19, layer20);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis33.setRightArrow(shape34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer36);
        categoryPlot37.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot37.zoomDomainAxes(0.0d, plotRenderingInfo40, point2D41, true);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis46.setRightArrow(shape47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryItemRenderer49);
        categoryPlot50.clearAnnotations();
        categoryPlot50.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot50.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str57 = axisLocation56.toString();
        categoryPlot50.setRangeAxisLocation(axisLocation56);
        categoryPlot37.setDomainAxisLocation(axisLocation56, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation61 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation56, plotOrientation61);
        org.jfree.chart.axis.AxisLocation axisLocation63 = axisLocation56.getOpposite();
        xYPlot20.setRangeAxisLocation(axisLocation63, false);
        java.awt.Color color66 = java.awt.Color.red;
        int int67 = color66.getTransparency();
        xYPlot20.setRangeZeroBaselinePaint((java.awt.Paint) color66);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str57.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        boolean boolean22 = xYPlot20.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat26 = null;
        numberAxis23.setNumberFormatOverride(numberFormat26);
        java.awt.Color color30 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_RIGHT", 192);
        numberAxis23.setAxisLinePaint((java.awt.Paint) color30);
        xYPlot20.setRangeGridlinePaint((java.awt.Paint) color30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot20.setRenderer((int) (short) 10, xYItemRenderer34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot20.getDomainAxis(13);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(valueAxis37);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis11.setRightArrow(shape12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer14);
        categoryPlot15.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot15.zoomDomainAxes(0.0d, plotRenderingInfo18, point2D19, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryMarker24.notifyListeners(markerChangeEvent25);
        categoryMarker24.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable29 = categoryMarker24.getKey();
        categoryMarker24.setKey((java.lang.Comparable) '4');
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        categoryPlot38.clearDomainMarkers();
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean42 = color40.equals((java.lang.Object) false);
        categoryPlot38.setOutlinePaint((java.awt.Paint) color40);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape48 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis47.setRightArrow(shape48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer50);
        categoryPlot51.clearAnnotations();
        categoryPlot51.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis56 = categoryPlot51.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str58 = axisLocation57.toString();
        categoryPlot51.setRangeAxisLocation(axisLocation57);
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent62 = null;
        categoryMarker61.notifyListeners(markerChangeEvent62);
        categoryMarker61.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable66 = categoryMarker61.getKey();
        org.jfree.chart.util.Layer layer67 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot51.addDomainMarker(categoryMarker61, layer67);
        java.util.Collection collection69 = categoryPlot38.getDomainMarkers(11, layer67);
        boolean boolean71 = categoryPlot15.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker24, layer67, true);
        java.util.Collection collection72 = categoryPlot6.getRangeMarkers(0, layer67);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 0L + "'", comparable29.equals(0L));
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str58.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 0L + "'", comparable66.equals(0L));
        org.junit.Assert.assertNotNull(layer67);
        org.junit.Assert.assertNull(collection69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(collection72);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.Object obj1 = null;
        boolean boolean2 = seriesRenderingOrder0.equals(obj1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setAxisLineStroke(stroke6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis8.setRightArrow(shape9);
        dateAxis5.setRightArrow(shape9);
        java.awt.Shape shape12 = dateAxis5.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis13.setTickUnit(numberTickUnit16);
        java.text.NumberFormat numberFormat18 = numberAxis13.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = numberAxis13.getMarkerBand();
        numberAxis13.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer22);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor26 = categoryMarker25.getLabelTextAnchor();
        java.awt.Paint paint27 = categoryMarker25.getOutlinePaint();
        xYPlot23.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker25);
        boolean boolean29 = xYPlot23.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis31.setUpperMargin((double) 7);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setAxisLineStroke(stroke36);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setRightArrow(shape39);
        dateAxis35.setRightArrow(shape39);
        boolean boolean42 = dateAxis35.isAxisLineVisible();
        java.awt.Paint paint43 = dateAxis35.getTickLabelPaint();
        boolean boolean44 = categoryAxis31.equals((java.lang.Object) paint43);
        xYPlot23.setDomainTickBandPaint(paint43);
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        xYPlot23.setDataset(0, xYDataset47);
        boolean boolean49 = seriesRenderingOrder0.equals((java.lang.Object) xYPlot23);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNull(numberFormat18);
        org.junit.Assert.assertNull(markerAxisBand19);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setAxisLineStroke(stroke4);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.05d, (java.awt.Paint) color1, stroke4);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setRightArrow(shape10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer12);
        categoryPlot13.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot13.notifyListeners(plotChangeEvent15);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot13.getFixedLegendItems();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint19 = dateAxis18.getTickLabelPaint();
        boolean boolean21 = dateAxis18.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis18.lengthToJava2D((double) 'a', rectangle2D23, rectangleEdge24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis18.setTickLabelPaint((java.awt.Paint) color26);
        categoryPlot13.setOutlinePaint((java.awt.Paint) color26);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot13.setDataset(categoryDataset29);
        categoryMarker6.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot13);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.lang.Object obj4 = intervalMarker2.clone();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        intervalMarker2.setPaint((java.awt.Paint) color5);
        double double7 = intervalMarker2.getStartValue();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.6777216E7d) + "'", double7 == (-1.6777216E7d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines(2);
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "PlotOrientation.HORIZONTAL");
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 5);
        java.awt.Color color13 = java.awt.Color.blue;
        java.lang.String str14 = color13.toString();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 1560409200000L, (java.awt.Paint) color13);
        java.awt.color.ColorSpace colorSpace16 = color13.getColorSpace();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=0,g=0,b=255]" + "'", str14.equals("java.awt.Color[r=0,g=0,b=255]"));
        org.junit.Assert.assertNotNull(colorSpace16);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getTickLabelPaint();
        boolean boolean7 = dateAxis4.isHiddenValue(10L);
        java.lang.Object obj8 = dateAxis4.clone();
        dateAxis4.setTickMarkOutsideLength((float) '4');
        dateAxis4.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        dateAxis4.setTickUnit(dateTickUnit13, false, false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint18 = dateAxis17.getTickLabelPaint();
        boolean boolean19 = dateAxis17.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis17.setRange((org.jfree.data.Range) dateRange20, false, false);
        dateAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange20);
        numberAxis0.setRange((org.jfree.data.Range) dateRange20, true, true);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = numberAxis29.java2DToValue((double) (-16777216), rectangle2D31, rectangleEdge32);
        boolean boolean34 = numberAxis29.getAutoRangeStickyZero();
        boolean boolean35 = numberAxis29.isAxisLineVisible();
        numberAxis29.setInverted(false);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis39.java2DToValue((double) (-16777216), rectangle2D41, rectangleEdge42);
        java.text.NumberFormat numberFormat44 = numberAxis39.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit48 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis45.setTickUnit(numberTickUnit48);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        numberAxis50.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit53 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis50.setTickUnit(numberTickUnit53);
        numberAxis45.setTickUnit(numberTickUnit53);
        numberAxis39.setTickUnit(numberTickUnit53, false, true);
        numberAxis29.setTickUnit(numberTickUnit53);
        numberAxis0.setTickUnit(numberTickUnit53);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = null;
        numberAxis0.setMarkerBand(markerAxisBand61);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.NEGATIVE_INFINITY + "'", double33 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNull(numberFormat44);
        org.junit.Assert.assertNotNull(numberTickUnit48);
        org.junit.Assert.assertNotNull(numberTickUnit53);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape3 = defaultDrawingSupplier2.getNextShape();
        java.awt.Stroke stroke4 = defaultDrawingSupplier2.getNextOutlineStroke();
        java.awt.Shape shape5 = defaultDrawingSupplier2.getNextShape();
        java.awt.Stroke stroke6 = defaultDrawingSupplier2.getNextOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getTickLabelPaint();
        boolean boolean10 = dateAxis7.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis7.lengthToJava2D((double) 'a', rectangle2D12, rectangleEdge13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setRightArrow(shape23);
        dateAxis19.setRightArrow(shape23);
        java.awt.Shape shape26 = dateAxis19.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis27.setTickUnit(numberTickUnit30);
        java.text.NumberFormat numberFormat32 = numberAxis27.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = numberAxis27.getMarkerBand();
        numberAxis27.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer36);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double41 = intervalMarker40.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer42 = intervalMarker40.getGradientPaintTransformer();
        boolean boolean43 = xYPlot37.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker40);
        java.awt.Stroke stroke44 = xYPlot37.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color1, stroke6, (java.awt.Paint) color15, stroke44, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertNull(numberFormat32);
        org.junit.Assert.assertNull(markerAxisBand33);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-1.0d) + "'", double41 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        java.lang.String str10 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        java.awt.Stroke stroke14 = defaultDrawingSupplier11.getNextOutlineStroke();
        java.awt.Paint paint15 = defaultDrawingSupplier11.getNextOutlinePaint();
        java.awt.Stroke stroke16 = defaultDrawingSupplier11.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        double double7 = categoryPlot6.getRangeCrosshairValue();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint11 = dateAxis10.getTickLabelPaint();
        boolean boolean12 = dateAxis10.isNegativeArrowVisible();
        categoryPlot6.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) dateAxis10, false);
        org.jfree.chart.plot.Plot plot15 = categoryPlot6.getRootPlot();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.Class<?> wildcardClass30 = color29.getClass();
        java.awt.Color color31 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray32 = null;
        float[] floatArray33 = color31.getComponents(floatArray32);
        float[] floatArray34 = color29.getRGBColorComponents(floatArray33);
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color29);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        int int37 = xYPlot20.getDomainAxisIndex(valueAxis36);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder38 = xYPlot20.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(seriesRenderingOrder38);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryMarker1.getLabelTextAnchor();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        java.awt.Paint paint4 = categoryMarker1.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType5);
        java.lang.String str7 = lengthAdjustmentType5.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CONTRACT" + "'", str7.equals("CONTRACT"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double24 = intervalMarker23.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker23.getGradientPaintTransformer();
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot20.drawDomainTickBands(graphics2D27, rectangle2D28, list29);
        int int31 = xYPlot20.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setAxisLineStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setRightArrow(shape37);
        dateAxis33.setRightArrow(shape37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis33.setStandardTickUnits(tickUnitSource40);
        java.lang.Object obj42 = dateAxis33.clone();
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        dateAxis33.setTickMarkPaint((java.awt.Paint) color43);
        xYPlot20.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape49 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis48.setRightArrow(shape49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer51);
        categoryPlot52.clearAnnotations();
        categoryPlot52.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot52.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str59 = axisLocation58.toString();
        categoryPlot52.setRangeAxisLocation(axisLocation58);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape65 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis64.setRightArrow(shape65);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis64, categoryItemRenderer67);
        categoryPlot68.clearAnnotations();
        categoryPlot68.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis73 = categoryPlot68.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation74 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str75 = axisLocation74.toString();
        categoryPlot68.setRangeAxisLocation(axisLocation74);
        categoryPlot52.setDomainAxisLocation((int) (short) 0, axisLocation74);
        xYPlot20.setDomainAxisLocation(axisLocation74, false);
        org.jfree.chart.axis.AxisSpace axisSpace80 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace80, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean85 = plotOrientation83.equals((java.lang.Object) 1.0f);
        xYPlot20.setOrientation(plotOrientation83);
        org.jfree.chart.axis.DateAxis dateAxis87 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint88 = dateAxis87.getTickLabelPaint();
        boolean boolean90 = dateAxis87.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D92 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = null;
        double double94 = dateAxis87.lengthToJava2D((double) 'a', rectangle2D92, rectangleEdge93);
        boolean boolean95 = dateAxis87.isAutoRange();
        xYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis87);
        java.awt.Shape shape97 = dateAxis87.getLeftArrow();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str59.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str75.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertNotNull(shape97);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryMarker22.getLabelTextAnchor();
        java.awt.Paint paint24 = categoryMarker22.getOutlinePaint();
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker22);
        boolean boolean26 = xYPlot20.isRangeCrosshairLockedOnData();
        boolean boolean27 = xYPlot20.isDomainCrosshairLockedOnData();
        int int28 = xYPlot20.getDomainAxisCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryMarker22.getLabelTextAnchor();
        java.awt.Paint paint24 = categoryMarker22.getOutlinePaint();
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker22);
        boolean boolean26 = xYPlot20.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis28.setUpperMargin((double) 7);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis32.setAxisLineStroke(stroke33);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis35.setRightArrow(shape36);
        dateAxis32.setRightArrow(shape36);
        boolean boolean39 = dateAxis32.isAxisLineVisible();
        java.awt.Paint paint40 = dateAxis32.getTickLabelPaint();
        boolean boolean41 = categoryAxis28.equals((java.lang.Object) paint40);
        xYPlot20.setDomainTickBandPaint(paint40);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        xYPlot20.setDataset(0, xYDataset44);
        boolean boolean46 = xYPlot20.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot6.notifyListeners(plotChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot6.getFixedLegendItems();
        categoryPlot6.setDrawSharedDomainAxis(true);
        boolean boolean13 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setRightArrow(shape19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer21);
        categoryPlot22.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = null;
        categoryPlot22.notifyListeners(plotChangeEvent24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot22.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot22.zoomRangeAxes((double) '4', plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot22.setFixedRangeAxisSpace(axisSpace31, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setAxisLineStroke(stroke39);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis41.setRightArrow(shape42);
        dateAxis38.setRightArrow(shape42);
        java.awt.Shape shape45 = dateAxis38.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        numberAxis46.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit49 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis46.setTickUnit(numberTickUnit49);
        java.text.NumberFormat numberFormat51 = numberAxis46.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand52 = numberAxis46.getMarkerBand();
        numberAxis46.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis46, xYItemRenderer55);
        java.awt.geom.Point2D point2D57 = xYPlot56.getQuadrantOrigin();
        categoryPlot22.zoomRangeAxes(7.0d, plotRenderingInfo35, point2D57);
        categoryPlot6.zoomDomainAxes((double) 15, plotRenderingInfo15, point2D57);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(numberTickUnit49);
        org.junit.Assert.assertNull(numberFormat51);
        org.junit.Assert.assertNull(markerAxisBand52);
        org.junit.Assert.assertNotNull(point2D57);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryMarker22.getLabelTextAnchor();
        java.awt.Paint paint24 = categoryMarker22.getOutlinePaint();
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker22);
        boolean boolean26 = xYPlot20.isRangeCrosshairLockedOnData();
        xYPlot20.setRangeCrosshairVisible(false);
        boolean boolean29 = xYPlot20.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot20.setFixedRangeAxisSpace(axisSpace30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace32, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        java.util.Date date3 = day1.getStart();
//        long long4 = day1.getSerialIndex();
//        int int5 = day1.getYear();
//        java.util.Date date6 = day1.getStart();
//        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
//        java.lang.Class<?> wildcardClass8 = color7.getClass();
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date6, timeZone10);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(color7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        boolean boolean9 = dateAxis2.isAxisLineVisible();
        boolean boolean10 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis14.getMarkerBand();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer16);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setAxisLineStroke(stroke23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis25.setRightArrow(shape26);
        dateAxis22.setRightArrow(shape26);
        java.awt.Shape shape29 = dateAxis22.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis30.setTickUnit(numberTickUnit33);
        java.text.NumberFormat numberFormat35 = numberAxis30.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = numberAxis30.getMarkerBand();
        numberAxis30.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis30, xYItemRenderer39);
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) (-16777216), (double) (-1.0f));
        double double44 = intervalMarker43.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer45 = intervalMarker43.getGradientPaintTransformer();
        boolean boolean46 = xYPlot40.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker43);
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        xYPlot40.setDataset(xYDataset47);
        java.awt.Color color52 = java.awt.Color.getHSBColor((-1.0f), (float) (byte) 10, 1.0f);
        xYPlot40.setRangeTickBandPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = xYPlot40.getDomainTickBandPaint();
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis58.setRightArrow(shape59);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis58, categoryItemRenderer61);
        categoryPlot62.clearDomainMarkers();
        java.awt.Color color64 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean66 = color64.equals((java.lang.Object) false);
        categoryPlot62.setOutlinePaint((java.awt.Paint) color64);
        org.jfree.data.category.CategoryDataset categoryDataset69 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape72 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis71.setRightArrow(shape72);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, (org.jfree.chart.axis.ValueAxis) dateAxis71, categoryItemRenderer74);
        categoryPlot75.clearAnnotations();
        categoryPlot75.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis80 = categoryPlot75.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation81 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str82 = axisLocation81.toString();
        categoryPlot75.setRangeAxisLocation(axisLocation81);
        org.jfree.chart.plot.CategoryMarker categoryMarker85 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent86 = null;
        categoryMarker85.notifyListeners(markerChangeEvent86);
        categoryMarker85.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable90 = categoryMarker85.getKey();
        org.jfree.chart.util.Layer layer91 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot75.addDomainMarker(categoryMarker85, layer91);
        java.util.Collection collection93 = categoryPlot62.getDomainMarkers(11, layer91);
        java.util.Collection collection94 = xYPlot40.getDomainMarkers(5, layer91);
        try {
            boolean boolean96 = xYPlot17.removeRangeMarker(13, marker19, layer91, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(markerAxisBand15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNull(numberFormat35);
        org.junit.Assert.assertNull(markerAxisBand36);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-1.0d) + "'", double44 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNull(valueAxis80);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str82.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable90 + "' != '" + 0L + "'", comparable90.equals(0L));
        org.junit.Assert.assertNotNull(layer91);
        org.junit.Assert.assertNull(collection93);
        org.junit.Assert.assertNull(collection94);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis5.setRightArrow(shape6);
        dateAxis2.setRightArrow(shape6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit13);
        java.text.NumberFormat numberFormat15 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis10.getMarkerBand();
        numberAxis10.setAutoRangeIncludesZero(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.geom.Point2D point2D21 = xYPlot20.getQuadrantOrigin();
        boolean boolean22 = xYPlot20.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat26 = null;
        numberAxis23.setNumberFormatOverride(numberFormat26);
        java.awt.Color color30 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_RIGHT", 192);
        numberAxis23.setAxisLinePaint((java.awt.Paint) color30);
        xYPlot20.setRangeGridlinePaint((java.awt.Paint) color30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot20.setRenderer((int) (short) 10, xYItemRenderer34);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = xYPlot20.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis2.setRightArrow(shape3);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
//        categoryPlot6.clearAnnotations();
//        categoryPlot6.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxis((int) (short) 100);
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis((int) (short) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot6.setRenderers(categoryItemRendererArray14);
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis17.setAxisLineStroke(stroke18);
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis20.setRightArrow(shape21);
//        dateAxis17.setRightArrow(shape21);
//        boolean boolean24 = dateAxis17.isAxisLineVisible();
//        java.awt.Paint paint25 = dateAxis17.getTickLabelPaint();
//        org.jfree.data.Range range26 = dateAxis17.getRange();
//        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        long long30 = day29.getLastMillisecond();
//        java.util.Date date31 = day29.getStart();
//        long long32 = day29.getSerialIndex();
//        int int33 = day29.getYear();
//        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint35 = dateAxis34.getTickLabelPaint();
//        int int36 = day29.compareTo((java.lang.Object) dateAxis34);
//        java.util.TimeZone timeZone37 = dateAxis34.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone37);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint40 = dateAxis39.getTickLabelPaint();
//        boolean boolean42 = dateAxis39.isHiddenValue(10L);
//        java.awt.geom.Rectangle2D rectangle2D44 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
//        double double46 = dateAxis39.lengthToJava2D((double) 'a', rectangle2D44, rectangleEdge45);
//        boolean boolean47 = dateAxis39.isAutoRange();
//        org.jfree.chart.plot.Plot plot48 = dateAxis39.getPlot();
//        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis49.setAutoRangeIncludesZero(false);
//        java.text.NumberFormat numberFormat52 = null;
//        numberAxis49.setNumberFormatOverride(numberFormat52);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { dateAxis17, dateAxis38, dateAxis39, numberAxis49 };
//        categoryPlot6.setRangeAxes(valueAxisArray54);
//        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
//        categoryPlot6.setRangeAxis(valueAxis56);
//        org.junit.Assert.assertNotNull(shape3);
//        org.junit.Assert.assertNull(valueAxis11);
//        org.junit.Assert.assertNull(categoryAxis13);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(shape21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertNotNull(range26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(paint40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNull(plot48);
//        org.junit.Assert.assertNotNull(valueAxisArray54);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearDomainMarkers();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) false);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis15.setRightArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer18);
        categoryPlot19.clearAnnotations();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str26 = axisLocation25.toString();
        categoryPlot19.setRangeAxisLocation(axisLocation25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryMarker29.notifyListeners(markerChangeEvent30);
        categoryMarker29.setAlpha((float) (byte) 1);
        java.lang.Comparable comparable34 = categoryMarker29.getKey();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot19.addDomainMarker(categoryMarker29, layer35);
        java.util.Collection collection37 = categoryPlot6.getDomainMarkers(11, layer35);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = dateAxis39.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis43.setRightArrow(shape44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis43, categoryItemRenderer46);
        categoryPlot47.clearAnnotations();
        categoryPlot47.setDrawSharedDomainAxis(true);
        dateAxis39.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot47);
        boolean boolean52 = categoryPlot47.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        numberAxis54.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat57 = null;
        numberAxis54.setNumberFormatOverride(numberFormat57);
        categoryPlot47.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis54, true);
        categoryPlot47.setRangeGridlinesVisible(true);
        categoryPlot47.setBackgroundImageAlignment(0);
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke69 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis68.setAxisLineStroke(stroke69);
        java.awt.Color color71 = java.awt.Color.BLUE;
        java.awt.Stroke stroke72 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker74 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color66, stroke69, (java.awt.Paint) color71, stroke72, (float) (byte) 0);
        valueMarker74.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor77 = valueMarker74.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent78 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker74);
        categoryPlot47.markerChanged(markerChangeEvent78);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent80 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot47);
        categoryPlot6.notifyListeners(plotChangeEvent80);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str26.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0L + "'", comparable34.equals(0L));
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(rectangleAnchor77);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color10);
        float float12 = dateAxis0.getTickMarkOutsideLength();
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis0.setLabelFont(font13);
        dateAxis0.setAutoTickUnitSelection(true);
        boolean boolean17 = dateAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getTickLabelPaint();
        boolean boolean3 = dateAxis0.isHiddenValue(10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis0.lengthToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        double double8 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getTickLabelPaint();
        boolean boolean11 = dateAxis9.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRange((org.jfree.data.Range) dateRange12, false, false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        java.util.TimeZone timeZone17 = dateAxis9.getTimeZone();
        dateAxis0.setTimeZone(timeZone17);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setRightArrow(shape3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke15);
        categoryPlot6.setRangeCrosshairStroke(stroke15);
        float float18 = categoryPlot6.getForegroundAlpha();
        java.awt.Paint paint19 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setAxisLineStroke(stroke23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis25.setRightArrow(shape26);
        dateAxis22.setRightArrow(shape26);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis22.setStandardTickUnits(tickUnitSource29);
        java.lang.Object obj31 = dateAxis22.clone();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setRightArrow(shape35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer37);
        categoryPlot38.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot38.notifyListeners(plotChangeEvent40);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = categoryPlot38.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder43 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot38.setRowRenderingOrder(sortOrder43);
        double double45 = categoryPlot38.getRangeCrosshairValue();
        dateAxis22.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        categoryPlot6.setRangeAxis(8, (org.jfree.chart.axis.ValueAxis) dateAxis22, false);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        boolean boolean53 = categoryPlot6.render(graphics2D49, rectangle2D50, (int) (short) 10, plotRenderingInfo52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        categoryPlot6.setRenderer((int) (byte) 1, categoryItemRenderer55);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(legendItemCollection42);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }
}

