import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setStartAngle((double) (-1L));
        org.jfree.data.general.PieDataset pieDataset4 = piePlot3D1.getDataset();
        piePlot3D1.setLabelGap(0.0d);
        org.junit.Assert.assertNull(pieDataset4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) dateTickUnit8, false);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        legendItem1.setDescription("hi!");
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        piePlot3D7.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        barRenderer3D12.setBaseLegendTextPaint((java.awt.Paint) color13);
        java.awt.Shape shape15 = null;
        barRenderer3D12.setBaseLegendShape(shape15);
        java.awt.Paint paint18 = barRenderer3D12.getSeriesPaint((int) '4');
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D12.setBaseFillPaint((java.awt.Paint) color19, false);
        piePlot3D7.setBaseSectionPaint((java.awt.Paint) color19);
        xYPlot5.setDomainMinorGridlinePaint((java.awt.Paint) color19);
        legendItem1.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.lang.Object obj27 = null;
        boolean boolean28 = standardGradientPaintTransformer25.equals(obj27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        int int5 = day4.getMonth();
//        long long6 = day4.getFirstMillisecond();
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        int int9 = day8.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day8);
//        boolean boolean11 = periodAxis10.isAutoRange();
//        periodAxis10.setMinorTickMarksVisible(true);
//        java.awt.Font font14 = periodAxis10.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font14);
//        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_LEFT", font14);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(font14);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.awt.Paint paint3 = multiplePiePlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.lang.Object obj1 = segmentedTimeline0.clone();
        long long4 = segmentedTimeline0.getExceptionSegmentCount((long) (-9999), 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge(255);
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis(0, categoryAxis10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot8.zoomDomainAxes(0.0d, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean19 = categoryPlot8.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean22 = categoryPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker18, layer20, true);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        jFreeChart2.fireChartChanged();
        int int4 = jFreeChart2.getSubtitleCount();
        boolean boolean5 = multiplePiePlot0.equals((java.lang.Object) int4);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
        combinedDomainXYPlot4.zoom(0.2d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        int int2 = logAxis1.getMinorTickCount();
        java.awt.Shape shape3 = logAxis1.getDownArrow();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.LegendItem legendItem3 = xYLineAndShapeRenderer0.getLegendItem(2958465, (int) (short) 100);
        xYLineAndShapeRenderer0.setBaseShapesVisible(false);
        boolean boolean6 = xYLineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        java.awt.Stroke stroke3 = xYPlot1.getRangeGridlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("12/31/69 4:00 PM", (org.jfree.chart.plot.Plot) xYPlot1);
        java.lang.Object obj5 = jFreeChart4.getTextAntiAlias();
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(obj5);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis8);
//        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
//        try {
//            combinedDomainXYPlot10.addAnnotation(xYAnnotation11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer3D2.getItemLabelGenerator((int) (byte) -1, (int) (byte) -1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = barRenderer3D2.getLegendItemToolTipGenerator();
        int int16 = barRenderer3D2.getPassCount();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        int int2 = day1.getMonth();
//        long long3 = day1.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate6 = serialDate4.getPreviousDayOfWeek((-65281));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        logAxis1.zoomRange((double) (-65281), 100.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D6.setTickMarkStroke(stroke8);
        numberAxis3D6.setLowerBound(0.2d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D2.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer3D2.getBasePositiveItemLabelPosition();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer3D2.getURLGenerator(7, 7, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(categoryURLGenerator15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Stroke stroke2 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(0);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        barRenderer3D6.setBaseLegendTextPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        barRenderer3D6.setBaseLegendShape(shape9);
        java.awt.Paint paint12 = barRenderer3D6.getSeriesPaint((int) '4');
        java.awt.Font font13 = barRenderer3D6.getBaseLegendTextFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        barRenderer3D16.setBaseLegendTextPaint((java.awt.Paint) color17);
        java.awt.Shape shape19 = null;
        barRenderer3D16.setBaseLegendShape(shape19);
        java.awt.Paint paint22 = barRenderer3D16.getSeriesPaint((int) '4');
        java.awt.Color color23 = java.awt.Color.RED;
        barRenderer3D16.setWallPaint((java.awt.Paint) color23);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        barRenderer3D16.notifyListeners(rendererChangeEvent25);
        java.awt.Font font28 = barRenderer3D16.getLegendTextFont(255);
        org.jfree.chart.renderer.category.BarPainter barPainter29 = barRenderer3D16.getBarPainter();
        barRenderer3D6.setBarPainter(barPainter29);
        java.awt.Paint paint34 = barRenderer3D6.getItemOutlinePaint((int) '4', (int) (byte) 1, false);
        xYStepAreaRenderer0.setLegendTextPaint(6, paint34);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(font28);
        org.junit.Assert.assertNotNull(barPainter29);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke16 = combinedDomainXYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = combinedDomainXYPlot4.getOrientation();
        boolean boolean19 = plotOrientation17.equals((java.lang.Object) "13-June-2019");
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        periodAxis8.setRangeWithMargins((double) (-1), (double) 1560409200000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = periodAxis8.getFirst();
//        org.jfree.data.time.TimeSeries timeSeries14 = null;
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14, timeZone15);
//        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, polarItemRenderer19);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) periodAxis8, (org.jfree.data.general.Dataset) timeSeriesCollection16);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(range17);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 6, (double) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, polarItemRenderer10);
        java.awt.Font font12 = polarPlot11.getAngleLabelFont();
        boolean boolean13 = polarPlot11.isRadiusGridlinesVisible();
        org.jfree.chart.axis.TickUnit tickUnit14 = polarPlot11.getAngleTickUnit();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = polarPlot11.getLegendItems();
        boolean boolean16 = verticalAlignment1.equals((java.lang.Object) legendItemCollection15);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(tickUnit14);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot11.configureDomainAxes();
        numberAxis3D6.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot11);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = combinedDomainXYPlot11.getOrientation();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = null;
        xYAreaRenderer15.setLegendItemURLGenerator(xYSeriesLabelGenerator16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYAreaRenderer15.drawRangeMarker(graphics2D18, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot19, valueAxis20, marker21, rectangle2D22);
        java.awt.Font font25 = xYAreaRenderer15.lookupLegendTextFont(6);
        int int26 = xYAreaRenderer15.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = xYAreaRenderer15.getLegendItemLabelGenerator();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape33, (org.jfree.chart.axis.Axis) numberAxis3D34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D34.setTickMarkStroke(stroke36);
        xYAreaRenderer15.setBaseStroke(stroke36);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape41, rectangleAnchor42, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity47 = new org.jfree.chart.entity.AxisEntity(shape45, (org.jfree.chart.axis.Axis) numberAxis3D46);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D46.setTickMarkStroke(stroke48);
        xYAreaRenderer15.setSeriesStroke(0, stroke48, false);
        combinedDomainXYPlot11.setDomainZeroBaselineStroke(stroke48);
        int int53 = combinedDomainXYPlot11.getRangeAxisCount();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(font25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState1 = null;
        timeSeriesCollection0.setSelectionState(xYDatasetSelectionState1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate2 = null;
        try {
            int int3 = spreadsheetDate1.compare(serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        periodAxis8.setMinorTickMarksVisible(true);
//        java.awt.Font font12 = periodAxis8.getLabelFont();
//        double double13 = periodAxis8.getLowerBound();
//        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray14 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
//        periodAxis8.setLabelInfo(periodAxisLabelInfoArray14);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(font12);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray14);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        long long3 = segmentedTimeline0.toTimelineValue(date1);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1099410614137L + "'", long3 == 1099410614137L);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        int int9 = combinedDomainXYPlot4.getWeight();
        java.awt.Paint paint10 = combinedDomainXYPlot4.getDomainTickBandPaint();
        java.awt.Stroke stroke11 = null;
        try {
            combinedDomainXYPlot4.setDomainMinorGridlineStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor16, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape19, (org.jfree.chart.axis.Axis) numberAxis3D20);
        numberAxis3D20.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot25.configureDomainAxes();
        numberAxis3D20.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot25);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = combinedDomainXYPlot25.getOrientation();
        combinedDomainXYPlot4.setOrientation(plotOrientation28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = null;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean40 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape39);
        org.jfree.data.time.TimeSeries timeSeries41 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection(timeSeries41);
        org.jfree.chart.entity.XYItemEntity xYItemEntity47 = new org.jfree.chart.entity.XYItemEntity(shape39, (org.jfree.data.xy.XYDataset) timeSeriesCollection42, 1, 2958465, "", "RectangleEdge.BOTTOM");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState49 = xYLineAndShapeRenderer32.initialise(graphics2D34, rectangle2D35, xYPlot36, (org.jfree.data.xy.XYDataset) timeSeriesCollection42, plotRenderingInfo48);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer50 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.LegendItem legendItem53 = xYLineAndShapeRenderer50.getLegendItem(2958465, (int) (short) 100);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray55 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYLineAndShapeRenderer32, xYLineAndShapeRenderer50, xYStepAreaRenderer54 };
        combinedDomainXYPlot4.setRenderers(xYItemRendererArray55);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState49);
        org.junit.Assert.assertNull(legendItem53);
        org.junit.Assert.assertNotNull(xYItemRendererArray55);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke2 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        int int4 = categoryPlot3.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        barRenderer3D7.setBaseLegendTextPaint((java.awt.Paint) color8);
        java.awt.Shape shape10 = null;
        barRenderer3D7.setBaseLegendShape(shape10);
        java.awt.Paint paint13 = barRenderer3D7.getSeriesPaint((int) '4');
        java.awt.Color color14 = java.awt.Color.RED;
        barRenderer3D7.setWallPaint((java.awt.Paint) color14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer3D7.notifyListeners(rendererChangeEvent16);
        java.awt.Font font19 = barRenderer3D7.getLegendTextFont(255);
        int int20 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        java.awt.Stroke stroke21 = categoryPlot3.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot3.getRangeAxisLocation(4);
        xYPlot0.setDomainAxisLocation(axisLocation23, true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("DomainOrder.ASCENDING", graphics2D1, 0.5f, (float) (-1L), textAnchor4, 0.4d, (float) 1, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.addException(1560409200000L, 1560495599999L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Stroke stroke3 = null;
        legendItem1.setOutlineStroke(stroke3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem1.getFillPaintTransformer();
        boolean boolean6 = legendItem1.isLineVisible();
        legendItem1.setLineVisible(true);
        legendItem1.setSeriesKey((java.lang.Comparable) 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        periodAxis8.setRangeWithMargins((double) (-1), (double) 1560409200000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = periodAxis8.getFirst();
//        float float14 = periodAxis8.getMinorTickMarkOutsideLength();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setSeriesItemLabelGenerator(6, categoryItemLabelGenerator13);
        barRenderer3D2.setBaseSeriesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        try {
            barRenderer3D2.setPlot(categoryPlot17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener3);
        xYSeries2.clear();
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) ' ');
        boolean boolean10 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        barRenderer3D8.setBaseLegendTextPaint((java.awt.Paint) color9);
        java.awt.Shape shape11 = null;
        barRenderer3D8.setBaseLegendShape(shape11);
        java.awt.Paint paint14 = barRenderer3D8.getSeriesPaint((int) '4');
        java.awt.Color color15 = java.awt.Color.RED;
        barRenderer3D8.setWallPaint((java.awt.Paint) color15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        barRenderer3D8.notifyListeners(rendererChangeEvent17);
        java.awt.Font font20 = barRenderer3D8.getLegendTextFont(255);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer3D8.getSeriesURLGenerator(4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNull(categoryURLGenerator23);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.Object obj2 = null;
        boolean boolean3 = rectangleAnchor1.equals(obj2);
        try {
            java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) (short) 0, (double) (-65281));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        legendItem1.setDescription("hi!");
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        piePlot3D7.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        barRenderer3D12.setBaseLegendTextPaint((java.awt.Paint) color13);
        java.awt.Shape shape15 = null;
        barRenderer3D12.setBaseLegendShape(shape15);
        java.awt.Paint paint18 = barRenderer3D12.getSeriesPaint((int) '4');
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D12.setBaseFillPaint((java.awt.Paint) color19, false);
        piePlot3D7.setBaseSectionPaint((java.awt.Paint) color19);
        xYPlot5.setDomainMinorGridlinePaint((java.awt.Paint) color19);
        legendItem1.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.awt.GradientPaint gradientPaint27 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer28 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator29 = null;
        xYAreaRenderer28.setLegendItemURLGenerator(xYSeriesLabelGenerator29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        xYAreaRenderer28.drawRangeMarker(graphics2D31, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot32, valueAxis33, marker34, rectangle2D35);
        java.awt.Shape shape37 = xYAreaRenderer28.getLegendArea();
        try {
            java.awt.GradientPaint gradientPaint38 = standardGradientPaintTransformer25.transform(gradientPaint27, shape37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) '#', (int) (byte) 1);
        boolean boolean12 = xYAreaRenderer0.getItemVisible(15, 3);
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation10.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.Object obj9 = null;
//        boolean boolean10 = day6.equals(obj9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getURLGenerator();
        piePlot3D1.setPieIndex((int) (byte) 100);
        java.awt.Paint paint8 = piePlot3D1.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 64, dateTickUnitType2, 100, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        java.util.List list3 = combinedDomainXYPlot0.getSubplots();
        combinedDomainXYPlot0.configureRangeAxes();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.util.List list7 = null;
        combinedDomainXYPlot0.drawDomainTickBands(graphics2D5, rectangle2D6, list7);
        java.awt.Paint paint9 = combinedDomainXYPlot0.getRangeGridlinePaint();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        java.awt.Font font5 = piePlot3D1.getLabelFont();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        categoryPlot0.clearAnnotations();
        java.awt.Paint paint19 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot21.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = combinedDomainXYPlot21.getDatasetRenderingOrder();
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        double double25 = ringPlot24.getSectionDepth();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = ringPlot24.getLegendItems();
        boolean boolean27 = datasetRenderingOrder23.equals((java.lang.Object) ringPlot24);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder23);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot0.setURLGenerator(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYAreaRenderer0.getSeriesItemLabelGenerator((int) (short) 0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer12.setLegendItemURLGenerator(xYSeriesLabelGenerator13);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYAreaRenderer12.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYAreaRenderer12.getSeriesNegativeItemLabelPosition((int) (short) 1);
        xYAreaRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition20, true);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace24 = xYPlot23.getFixedDomainAxisSpace();
        boolean boolean25 = itemLabelPosition20.equals((java.lang.Object) axisSpace24);
        org.junit.Assert.assertNull(xYItemLabelGenerator10);
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("PlotOrientation.VERTICAL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset9, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeWidth(range11);
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range11, (double) 1099410614137L);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        categoryPlot0.clearAnnotations();
        java.awt.Paint paint19 = categoryPlot0.getDomainCrosshairPaint();
        int int20 = categoryPlot0.getDatasetCount();
        java.awt.Stroke stroke21 = categoryPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(stroke21);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        long long6 = day3.getSerialIndex();
//        try {
//            defaultPieDataset0.insertValue((int) (byte) 100, (java.lang.Comparable) long6, (double) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        barRenderer3D12.setBaseLegendTextPaint((java.awt.Paint) color13);
        java.awt.Shape shape15 = null;
        barRenderer3D12.setBaseLegendShape(shape15);
        java.awt.Paint paint18 = barRenderer3D12.getSeriesPaint((int) '4');
        java.awt.Color color19 = java.awt.Color.RED;
        barRenderer3D12.setWallPaint((java.awt.Paint) color19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        barRenderer3D12.notifyListeners(rendererChangeEvent21);
        java.awt.Font font24 = barRenderer3D12.getLegendTextFont(255);
        org.jfree.chart.renderer.category.BarPainter barPainter25 = barRenderer3D12.getBarPainter();
        barRenderer3D2.setBarPainter(barPainter25);
        boolean boolean27 = barRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(font24);
        org.junit.Assert.assertNotNull(barPainter25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        try {
            double double5 = timeSeriesCollection1.getXValue(6, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = barRenderer3D4.getDrawingSupplier();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer3D4.getURLGenerator(5, 0, false);
        java.awt.Paint paint26 = barRenderer3D4.getItemLabelPaint((int) (short) 10, 2147483647, true);
        boolean boolean27 = barRenderer3D4.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        int int1 = categoryPlot0.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color5 = java.awt.Color.MAGENTA;
//        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
//        java.awt.Shape shape7 = null;
//        barRenderer3D4.setBaseLegendShape(shape7);
//        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
//        java.awt.Color color11 = java.awt.Color.RED;
//        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
//        barRenderer3D4.notifyListeners(rendererChangeEvent13);
//        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
//        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
//        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
//        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        int int22 = day21.getMonth();
//        long long23 = day21.getFirstMillisecond();
//        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        int int26 = day25.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day25);
//        boolean boolean28 = periodAxis27.isAutoRange();
//        periodAxis27.setMinorTickMarksVisible(true);
//        java.awt.Font font31 = periodAxis27.getLabelFont();
//        double double32 = periodAxis27.getLowerBound();
//        int int33 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis27);
//        org.jfree.chart.plot.CategoryMarker categoryMarker35 = null;
//        org.jfree.chart.util.Layer layer36 = null;
//        try {
//            categoryPlot0.addDomainMarker(15, categoryMarker35, layer36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNull(paint10);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNull(font16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = logAxis1.getTickUnit();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = null;
        try {
            logAxis1.setTickUnit(numberTickUnit8, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.lang.Object obj2 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLegendLabelGenerator();
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYAreaRenderer0.getBaseToolTipGenerator();
        boolean boolean8 = xYAreaRenderer0.getPlotArea();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = xYAreaRenderer9.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = xYAreaRenderer9.getBaseToolTipGenerator();
        xYAreaRenderer9.setBaseCreateEntities(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = xYAreaRenderer9.getLegendItemLabelGenerator();
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator19);
        boolean boolean21 = xYAreaRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(xYURLGenerator15);
        org.junit.Assert.assertNull(xYToolTipGenerator16);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        logAxis1.pan((double) 2);
        logAxis1.setTickLabelsVisible(true);
        logAxis1.setLowerMargin(0.4d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        boolean boolean12 = xYAreaRenderer0.removeAnnotation(xYAnnotation11);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            xYAreaRenderer0.addAnnotation(xYAnnotation13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedDomainXYPlot0.getRangeAxisLocation((int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot0.getRangeAxis((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Stroke stroke3 = null;
        legendItem1.setOutlineStroke(stroke3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem1.getFillPaintTransformer();
        java.awt.Paint paint6 = legendItem1.getOutlinePaint();
        java.lang.Comparable comparable7 = legendItem1.getSeriesKey();
        legendItem1.setURLText("Combined_Domain_XYPlot");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(comparable7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 64);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot24.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean35 = categoryPlot24.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker34);
        valueMarker34.setLabel("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = valueMarker34.getLabelAnchor();
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot0.addRangeMarker(13, (org.jfree.chart.plot.Marker) valueMarker34, layer39);
        boolean boolean41 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent43 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color42);
        org.jfree.chart.JFreeChart jFreeChart44 = rendererChangeEvent43.getChart();
        categoryPlot0.rendererChanged(rendererChangeEvent43);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(jFreeChart44);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
//        numberAxis3D0.setAutoRange(false);
//        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D0.setTickLabelFont(font3);
//        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D0);
//        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape13, (org.jfree.chart.axis.Axis) numberAxis3D14);
//        numberAxis3D14.zoomRange(0.0d, 0.0d);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot19.configureDomainAxes();
//        numberAxis3D14.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot19);
//        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
//        int int25 = categoryPlot24.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color29 = java.awt.Color.MAGENTA;
//        barRenderer3D28.setBaseLegendTextPaint((java.awt.Paint) color29);
//        java.awt.Shape shape31 = null;
//        barRenderer3D28.setBaseLegendShape(shape31);
//        java.awt.Paint paint34 = barRenderer3D28.getSeriesPaint((int) '4');
//        java.awt.Color color35 = java.awt.Color.RED;
//        barRenderer3D28.setWallPaint((java.awt.Paint) color35);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
//        barRenderer3D28.notifyListeners(rendererChangeEvent37);
//        java.awt.Font font40 = barRenderer3D28.getLegendTextFont(255);
//        int int41 = categoryPlot24.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
//        java.awt.Stroke stroke42 = categoryPlot24.getRangeCrosshairStroke();
//        java.util.Date date44 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        int int46 = day45.getMonth();
//        long long47 = day45.getFirstMillisecond();
//        java.util.Date date48 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        int int50 = day49.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis51 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day45, (org.jfree.data.time.RegularTimePeriod) day49);
//        boolean boolean52 = periodAxis51.isAutoRange();
//        periodAxis51.setMinorTickMarksVisible(true);
//        java.awt.Font font55 = periodAxis51.getLabelFont();
//        double double56 = periodAxis51.getLowerBound();
//        int int57 = categoryPlot24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis51);
//        int int58 = xYPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis51);
//        xYPlot23.clearDomainMarkers((int) (short) -1);
//        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot23.getRangeAxisLocation((int) (short) 0);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo65 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo65);
//        java.awt.geom.Point2D point2D67 = null;
//        xYPlot23.zoomDomainAxes((double) (-1), 0.0d, plotRenderingInfo66, point2D67);
//        java.awt.geom.Point2D point2D69 = null;
//        combinedDomainXYPlot19.panRangeAxes(4.0d, plotRenderingInfo66, point2D69);
//        combinedRangeXYPlot5.handleClick(4, 100, plotRenderingInfo66);
//        org.junit.Assert.assertNotNull(font3);
//        org.junit.Assert.assertNotNull(shape9);
//        org.junit.Assert.assertNotNull(rectangleAnchor10);
//        org.junit.Assert.assertNotNull(shape13);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(color29);
//        org.junit.Assert.assertNull(paint34);
//        org.junit.Assert.assertNotNull(color35);
//        org.junit.Assert.assertNull(font40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNotNull(stroke42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560409200000L + "'", long47 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(font55);
//        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertNotNull(axisLocation62);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(5);
        xYStepAreaRenderer1.setSeriesVisible(2958465, (java.lang.Boolean) false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color9, false);
        java.awt.Paint paint13 = null;
        barRenderer3D2.setSeriesPaint((int) (byte) 0, paint13);
        boolean boolean15 = barRenderer3D2.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator5, true);
        java.awt.Shape shape9 = barRenderer3D4.lookupSeriesShape((int) '#');
        xYAreaRenderer0.setSeriesShape((int) (byte) 1, shape9, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer12.setLegendItemURLGenerator(xYSeriesLabelGenerator13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYAreaRenderer12.drawRangeMarker(graphics2D15, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot16, valueAxis17, marker18, rectangle2D19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot16.setRangeAxisLocation((int) (byte) 1, axisLocation22, false);
        float float25 = combinedDomainXYPlot16.getBackgroundAlpha();
        combinedDomainXYPlot16.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke28 = combinedDomainXYPlot16.getDomainZeroBaselineStroke();
        xYAreaRenderer0.setBaseStroke(stroke28);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator31 = null;
        xYAreaRenderer30.setLegendItemURLGenerator(xYSeriesLabelGenerator31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.plot.Marker marker36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        xYAreaRenderer30.drawRangeMarker(graphics2D33, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot34, valueAxis35, marker36, rectangle2D37);
        boolean boolean39 = xYAreaRenderer30.getPlotShapes();
        java.awt.Stroke stroke40 = xYAreaRenderer30.getBaseOutlineStroke();
        xYAreaRenderer0.setBaseStroke(stroke40);
        xYAreaRenderer0.setDefaultEntityRadius(0);
        xYAreaRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        boolean boolean48 = xYAreaRenderer0.getPlotArea();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle3 = null;
        jFreeChart1.setTitle(textTitle3);
        org.jfree.chart.title.TextTitle textTitle5 = jFreeChart1.getTitle();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(textTitle5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            combinedDomainXYPlot0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor4 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        boolean boolean6 = timePeriodAnchor4.equals((java.lang.Object) 0L);
        timeSeriesCollection2.setXPosition(timePeriodAnchor4);
        try {
            java.lang.Number number10 = timeSeriesCollection2.getEndY(1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(timePeriodAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.Point point11 = polarPlot6.translateValueThetaRadiusToJava2D((double) 6, (double) 1560409200000L, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(5);
//        java.awt.Graphics2D graphics2D2 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot3.configureDomainAxes();
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot3.getDatasetRenderingOrder();
//        java.util.List list6 = combinedDomainXYPlot3.getSubplots();
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
//        int int8 = categoryPlot7.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color12 = java.awt.Color.MAGENTA;
//        barRenderer3D11.setBaseLegendTextPaint((java.awt.Paint) color12);
//        java.awt.Shape shape14 = null;
//        barRenderer3D11.setBaseLegendShape(shape14);
//        java.awt.Paint paint17 = barRenderer3D11.getSeriesPaint((int) '4');
//        java.awt.Color color18 = java.awt.Color.RED;
//        barRenderer3D11.setWallPaint((java.awt.Paint) color18);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
//        barRenderer3D11.notifyListeners(rendererChangeEvent20);
//        java.awt.Font font23 = barRenderer3D11.getLegendTextFont(255);
//        int int24 = categoryPlot7.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
//        java.awt.Stroke stroke25 = categoryPlot7.getRangeCrosshairStroke();
//        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        int int29 = day28.getMonth();
//        long long30 = day28.getFirstMillisecond();
//        java.util.Date date31 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        int int33 = day32.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) day32);
//        boolean boolean35 = periodAxis34.isAutoRange();
//        periodAxis34.setMinorTickMarksVisible(true);
//        java.awt.Font font38 = periodAxis34.getLabelFont();
//        double double39 = periodAxis34.getLowerBound();
//        int int40 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis34);
//        periodAxis34.setPositiveArrowVisible(false);
//        java.awt.geom.Rectangle2D rectangle2D43 = null;
//        try {
//            xYStepAreaRenderer1.fillRangeGridBand(graphics2D2, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3, (org.jfree.chart.axis.ValueAxis) periodAxis34, rectangle2D43, (double) (-9999), 1.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNull(paint17);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNull(font23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(stroke25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(font38);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYAreaRenderer1.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getSeriesNegativeItemLabelPosition((int) (short) 1);
        xYLineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNull(xYURLGenerator7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(0.2d, 100.0d, (double) 10L, (double) 3600000L, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset9, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeWidth(range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint2.toFixedHeight((double) 6);
        double double15 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot2.getDataset();
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        legendItem1.setDescription("hi!");
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        piePlot3D7.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        barRenderer3D12.setBaseLegendTextPaint((java.awt.Paint) color13);
        java.awt.Shape shape15 = null;
        barRenderer3D12.setBaseLegendShape(shape15);
        java.awt.Paint paint18 = barRenderer3D12.getSeriesPaint((int) '4');
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D12.setBaseFillPaint((java.awt.Paint) color19, false);
        piePlot3D7.setBaseSectionPaint((java.awt.Paint) color19);
        xYPlot5.setDomainMinorGridlinePaint((java.awt.Paint) color19);
        legendItem1.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        org.jfree.data.time.TimeSeries timeSeries27 = null;
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeSeries27, timeZone28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection29, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer32);
        boolean boolean34 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        legendItem1.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection29);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("Monday");
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 1L, 0.4d, 0.2d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = null;
        java.awt.geom.RectangularShape rectangularShape9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = null;
        xYAreaRenderer10.setLegendItemURLGenerator(xYSeriesLabelGenerator11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYAreaRenderer10.drawRangeMarker(graphics2D13, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot14, valueAxis15, marker16, rectangle2D17);
        int int19 = combinedDomainXYPlot14.getWeight();
        java.awt.Paint paint20 = combinedDomainXYPlot14.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = combinedDomainXYPlot14.getDomainAxisEdge((int) (short) 100);
        try {
            gradientXYBarPainter3.paintBar(graphics2D4, xYBarRenderer5, (int) '4', (int) (byte) 10, true, rectangularShape9, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle3 = null;
        jFreeChart1.setTitle(textTitle3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot9.setRangeAxisLocation((int) (byte) 1, axisLocation15, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedDomainXYPlot9.getInsets();
        java.lang.String str19 = rectangleInsets18.toString();
        jFreeChart1.setPadding(rectangleInsets18);
        java.awt.Paint paint21 = jFreeChart1.getBorderPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot22.zoomDomainAxes(0.0d, plotRenderingInfo28, point2D29);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean33 = categoryPlot22.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker32);
        valueMarker32.setLabel("hi!");
        java.awt.Color color36 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = blockBorder37.getInsets();
        valueMarker32.setLabelOffset(rectangleInsets38);
        jFreeChart1.setPadding(rectangleInsets38);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str19.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Stroke stroke2 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(0);
        java.awt.Paint paint4 = xYStepAreaRenderer0.getSeriesItemLabelPaint(12);
        boolean boolean6 = xYStepAreaRenderer0.isSeriesVisible(5);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.lang.String str3 = xYSeries2.getDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        int int8 = xYSeries2.getMaximumItemCount();
        try {
            xYSeries2.update((java.lang.Number) 12, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 12");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color4 = java.awt.Color.MAGENTA;
//        barRenderer3D3.setBaseLegendTextPaint((java.awt.Paint) color4);
//        java.awt.Shape shape6 = null;
//        barRenderer3D3.setBaseLegendShape(shape6);
//        java.awt.Paint paint9 = barRenderer3D3.getSeriesPaint((int) '4');
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        int int13 = day12.getMonth();
//        long long14 = day12.getFirstMillisecond();
//        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day16);
//        boolean boolean19 = periodAxis18.isAutoRange();
//        periodAxis18.setMinorTickMarksVisible(true);
//        java.awt.Font font22 = periodAxis18.getLabelFont();
//        barRenderer3D3.setBaseItemLabelFont(font22);
//        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("Pie 3D Plot", font22);
//        java.awt.Graphics2D graphics2D25 = null;
//        java.awt.geom.Rectangle2D rectangle2D26 = null;
//        try {
//            labelBlock24.draw(graphics2D25, rectangle2D26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNull(paint9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(font22);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = null;
        try {
            legendItem1.setFillPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = barRenderer3D4.getDrawingSupplier();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer3D4.getURLGenerator(5, 0, false);
        java.awt.Paint paint26 = barRenderer3D4.getItemLabelPaint((int) (short) 10, 2147483647, true);
        int int27 = barRenderer3D4.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        java.awt.geom.Rectangle2D rectangle2D15 = null;
//        try {
//            textTitle14.setBounds(rectangle2D15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.lang.Object obj1 = segmentedTimeline0.clone();
        long long4 = segmentedTimeline0.getExceptionSegmentCount((long) 8, 0L);
        long long5 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 86400000L + "'", long5 == 86400000L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        long long13 = day11.getFirstMillisecond();
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day15);
//        periodAxis8.setLast((org.jfree.data.time.RegularTimePeriod) day11);
//        periodAxis8.setFixedAutoRange(1.0E-5d);
//        boolean boolean21 = periodAxis8.isMinorTickMarksVisible();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis8.getLast();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.Marker marker9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        xYAreaRenderer3.drawRangeMarker(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot7, valueAxis8, marker9, rectangle2D10);
        java.awt.Font font13 = xYAreaRenderer3.lookupLegendTextFont(6);
        int int14 = xYAreaRenderer3.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = xYAreaRenderer3.getLegendItemLabelGenerator();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape17, rectangleAnchor18, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity23 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) numberAxis3D22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D22.setTickMarkStroke(stroke24);
        xYAreaRenderer3.setBaseStroke(stroke24);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = xYAreaRenderer3.getGradientTransformer();
        int int28 = year0.compareTo((java.lang.Object) xYAreaRenderer3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(gradientPaintTransformer27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = logAxis1.getTickUnit();
        java.lang.String str8 = numberTickUnit7.toString();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[size=1]" + "'", str8.equals("[size=1]"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer3D2.getItemLabelGenerator((int) (byte) -1, (int) (byte) -1, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = barRenderer3D2.getPlot();
        java.awt.Font font16 = barRenderer3D2.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        barRenderer3D2.setSeriesToolTipGenerator(100, categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryPlot15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        combinedDomainXYPlot0.setRangeGridlinePaint(paint2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        basicProjectInfo5.setCopyright("Pie 3D Plot");
        java.awt.Image image12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("10^4.78", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleAnchor.TOP_RIGHT", image12, "", "Pie 3D Plot", "13-June-2019");
        java.awt.Image image17 = projectInfo16.getLogo();
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo16);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNull(image17);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Object obj1 = defaultPieDataset0.clone();
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYAreaRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYAreaRenderer2.drawRangeMarker(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, valueAxis7, marker8, rectangle2D9);
        java.awt.Font font12 = xYAreaRenderer2.lookupLegendTextFont(6);
        boolean boolean14 = xYAreaRenderer2.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Shape shape15 = xYAreaRenderer2.getLegendArea();
        multiplePiePlot0.setLegendItemShape(shape15);
        java.awt.Shape shape17 = multiplePiePlot0.getLegendItemShape();
        boolean boolean19 = multiplePiePlot0.equals((java.lang.Object) 60000L);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundImageAlpha();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = null;
        xYAreaRenderer14.setLegendItemURLGenerator(xYSeriesLabelGenerator15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        xYAreaRenderer14.drawRangeMarker(graphics2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, valueAxis19, marker20, rectangle2D21);
        boolean boolean23 = xYAreaRenderer14.getPlotShapes();
        java.awt.Stroke stroke24 = xYAreaRenderer14.getBaseOutlineStroke();
        combinedDomainXYPlot4.setDomainGridlineStroke(stroke24);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        try {
            combinedDomainXYPlot4.rendererChanged(rendererChangeEvent26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 12, "index.html", textAnchor3, textAnchor5, (double) 'a');
        org.jfree.chart.axis.TickType tickType8 = numberTick7.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor9 = numberTick7.getTextAnchor();
        java.lang.String str10 = textAnchor9.toString();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str4.equals("TextAnchor.TOP_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(tickType8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str10.equals("TextAnchor.TOP_LEFT"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.LogFormat logFormat1 = new org.jfree.chart.util.LogFormat();
        logFormat1.setMinimumFractionDigits(100);
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat1, (java.text.NumberFormat) logFormat4);
        java.lang.StringBuffer stringBuffer7 = null;
        java.text.FieldPosition fieldPosition8 = null;
        java.lang.StringBuffer stringBuffer9 = logFormat1.format((double) 2.0f, stringBuffer7, fieldPosition8);
        org.junit.Assert.assertNotNull(stringBuffer9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedDomainXYPlot4.setDrawingSupplier(drawingSupplier9);
        boolean boolean11 = combinedDomainXYPlot4.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        java.awt.Paint paint5 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getDomainMarkers(0, layer7);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        logFormat0.setMinimumFractionDigits(100);
        logFormat0.setParseIntegerOnly(true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1560495599999L, (double) (short) 0);
        intervalMarker2.setEndValue((double) 'a');
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(7);
        pieLabelDistributor1.clear();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot2.setDomainAxis(0, categoryAxis4, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot2.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean13 = categoryPlot2.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        valueMarker12.setLabel("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = valueMarker12.getLabelAnchor();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        barRenderer3D19.setBaseLegendTextPaint((java.awt.Paint) color20);
        java.awt.Shape shape22 = null;
        barRenderer3D19.setBaseLegendShape(shape22);
        java.awt.Paint paint25 = barRenderer3D19.getSeriesPaint((int) '4');
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D19.setBaseFillPaint((java.awt.Paint) color26, false);
        int int29 = color26.getTransparency();
        valueMarker12.setPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset32 = combinedDomainXYPlot31.getDataset();
        boolean boolean33 = combinedDomainXYPlot31.isRangeZoomable();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot31.setRangeTickBandPaint(paint34);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator37 = null;
        xYAreaRenderer36.setLegendItemURLGenerator(xYSeriesLabelGenerator37);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.Marker marker42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        xYAreaRenderer36.drawRangeMarker(graphics2D39, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot40, valueAxis41, marker42, rectangle2D43);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot40.setRangeAxisLocation((int) (byte) 1, axisLocation46, false);
        float float49 = combinedDomainXYPlot40.getBackgroundAlpha();
        combinedDomainXYPlot40.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke52 = combinedDomainXYPlot40.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer53 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator54 = null;
        xYAreaRenderer53.setLegendItemURLGenerator(xYSeriesLabelGenerator54);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot57 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.Marker marker59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        xYAreaRenderer53.drawRangeMarker(graphics2D56, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot57, valueAxis58, marker59, rectangle2D60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot57.setRangeAxisLocation((int) (byte) 1, axisLocation63, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = combinedDomainXYPlot57.getInsets();
        double double68 = rectangleInsets66.calculateTopInset((double) (byte) 100);
        org.jfree.chart.block.LineBorder lineBorder69 = new org.jfree.chart.block.LineBorder(paint34, stroke52, rectangleInsets66);
        java.awt.Color color70 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer71 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Stroke stroke73 = xYStepAreaRenderer71.lookupSeriesOutlineStroke(0);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker75 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, 0.0d, (java.awt.Paint) color26, stroke52, (java.awt.Paint) color70, stroke73, (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNull(xYDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 1.0f + "'", float49 == 1.0f);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 4.0d + "'", double68 == 4.0d);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle3 = null;
        jFreeChart1.setTitle(textTitle3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot9.setRangeAxisLocation((int) (byte) 1, axisLocation15, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedDomainXYPlot9.getInsets();
        java.lang.String str19 = rectangleInsets18.toString();
        jFreeChart1.setPadding(rectangleInsets18);
        jFreeChart1.setAntiAlias(true);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str19.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        int int11 = xYAreaRenderer0.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = xYAreaRenderer0.getLegendItemLabelGenerator();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) numberAxis3D19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D19.setTickMarkStroke(stroke21);
        xYAreaRenderer0.setBaseStroke(stroke21);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape26, rectangleAnchor27, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity32 = new org.jfree.chart.entity.AxisEntity(shape30, (org.jfree.chart.axis.Axis) numberAxis3D31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D31.setTickMarkStroke(stroke33);
        xYAreaRenderer0.setSeriesStroke(0, stroke33, false);
        xYAreaRenderer0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator41 = xYAreaRenderer0.getSeriesToolTipGenerator((int) (short) 10);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(xYToolTipGenerator41);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        legendItem1.setLineVisible(false);
        boolean boolean4 = legendItem1.isLineVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.getAutoRangeStickyZero();
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis3D0.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) '#', (int) (byte) 1);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13, timeZone14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, polarItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYAreaRenderer0.initialise(graphics2D10, rectangle2D11, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot12, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo20);
        org.jfree.data.DomainOrder domainOrder22 = timeSeriesCollection15.getDomainOrder();
        java.util.List list23 = null;
        org.jfree.data.Range range24 = null;
        try {
            org.jfree.data.Range range26 = timeSeriesCollection15.getRangeBounds(list23, range24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertNotNull(domainOrder22);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        java.util.List list3 = combinedDomainXYPlot0.getSubplots();
        combinedDomainXYPlot0.configureRangeAxes();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.util.List list7 = null;
        combinedDomainXYPlot0.drawDomainTickBands(graphics2D5, rectangle2D6, list7);
        java.awt.Paint paint9 = combinedDomainXYPlot0.getRangeGridlinePaint();
        java.awt.Paint paint10 = combinedDomainXYPlot0.getRangeGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(paint10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        java.awt.Paint paint11 = barRenderer3D2.getSeriesPaint(3);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        int int15 = categoryPlot14.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color19 = java.awt.Color.MAGENTA;
        barRenderer3D18.setBaseLegendTextPaint((java.awt.Paint) color19);
        java.awt.Shape shape21 = null;
        barRenderer3D18.setBaseLegendShape(shape21);
        java.awt.Paint paint24 = barRenderer3D18.getSeriesPaint((int) '4');
        java.awt.Color color25 = java.awt.Color.RED;
        barRenderer3D18.setWallPaint((java.awt.Paint) color25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        barRenderer3D18.notifyListeners(rendererChangeEvent27);
        java.awt.Font font30 = barRenderer3D18.getLegendTextFont(255);
        int int31 = categoryPlot14.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot14.zoomRangeAxes((double) (short) 100, plotRenderingInfo33, point2D34, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        categoryPlot38.setDomainAxis(0, categoryAxis40, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot38.zoomDomainAxes(0.0d, plotRenderingInfo44, point2D45);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean49 = categoryPlot38.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker48);
        valueMarker48.setLabel("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = valueMarker48.getLabelAnchor();
        org.jfree.chart.util.Layer layer53 = null;
        categoryPlot14.addRangeMarker(13, (org.jfree.chart.plot.Marker) valueMarker48, layer53);
        boolean boolean55 = categoryPlot14.isRangeGridlinesVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo57);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState59 = barRenderer3D2.initialise(graphics2D12, rectangle2D13, categoryPlot14, 5, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.general.PieDataset pieDataset0 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
//        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
//        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D1.getLegendLabelGenerator();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        long long9 = day7.getFirstMillisecond();
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day7, (org.jfree.data.time.RegularTimePeriod) day11);
//        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getMonth();
//        long long18 = day16.getFirstMillisecond();
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        int int21 = day20.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) day20);
//        periodAxis13.setLast((org.jfree.data.time.RegularTimePeriod) day16);
//        int int24 = day16.getDayOfMonth();
//        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_BLUE;
//        int int26 = color25.getTransparency();
//        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) int24, (java.awt.Paint) color25);
//        org.jfree.data.general.PieDataset pieDataset28 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D(pieDataset28);
//        piePlot3D29.setAutoPopulateSectionOutlineStroke(true);
//        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator32 = piePlot3D29.getLegendLabelGenerator();
//        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        int int36 = day35.getMonth();
//        long long37 = day35.getFirstMillisecond();
//        java.util.Date date38 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
//        int int40 = day39.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) day39);
//        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        int int45 = day44.getMonth();
//        long long46 = day44.getFirstMillisecond();
//        java.util.Date date47 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
//        int int49 = day48.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day44, (org.jfree.data.time.RegularTimePeriod) day48);
//        periodAxis41.setLast((org.jfree.data.time.RegularTimePeriod) day44);
//        int int52 = day44.getDayOfMonth();
//        java.awt.Color color53 = org.jfree.chart.ChartColor.LIGHT_BLUE;
//        int int54 = color53.getTransparency();
//        piePlot3D29.setSectionOutlinePaint((java.lang.Comparable) int52, (java.awt.Paint) color53);
//        int int56 = color53.getGreen();
//        piePlot3D1.setLabelOutlinePaint((java.awt.Paint) color53);
//        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertNotNull(color25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(pieSectionLabelGenerator32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560409200000L + "'", long37 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560409200000L + "'", long46 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 13 + "'", int52 == 13);
//        org.junit.Assert.assertNotNull(color53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 64 + "'", int56 == 64);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.lang.String str3 = xYSeries2.getDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        xYSeries2.clear();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator5);
        double double7 = piePlot3D1.getShadowXOffset();
        boolean boolean8 = piePlot3D1.getSimpleLabels();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, rectangleAnchor11, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity16 = new org.jfree.chart.entity.AxisEntity(shape14, (org.jfree.chart.axis.Axis) numberAxis3D15);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        barRenderer3D19.setBaseLegendTextPaint((java.awt.Paint) color20);
        java.awt.Shape shape22 = null;
        barRenderer3D19.setBaseLegendShape(shape22);
        java.awt.Paint paint25 = barRenderer3D19.getSeriesPaint((int) '4');
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D19.setBaseFillPaint((java.awt.Paint) color26, false);
        int int29 = color26.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic30 = new org.jfree.chart.title.LegendGraphic(shape14, (java.awt.Paint) color26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic30.setShapeLocation(rectangleAnchor31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendGraphic30.getPadding();
        double double35 = rectangleInsets33.calculateTopInset(1.0d);
        piePlot3D1.setLabelPadding(rectangleInsets33);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle37 = piePlot3D1.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.0d + "'", double35 == 2.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle37);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke16 = combinedDomainXYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = combinedDomainXYPlot4.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean29 = categoryPlot18.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker28);
        valueMarker28.setLabel("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = valueMarker28.getLabelAnchor();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D35 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color36 = java.awt.Color.MAGENTA;
        barRenderer3D35.setBaseLegendTextPaint((java.awt.Paint) color36);
        java.awt.Shape shape38 = null;
        barRenderer3D35.setBaseLegendShape(shape38);
        java.awt.Paint paint41 = barRenderer3D35.getSeriesPaint((int) '4');
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D35.setBaseFillPaint((java.awt.Paint) color42, false);
        int int45 = color42.getTransparency();
        valueMarker28.setPaint((java.awt.Paint) color42);
        java.awt.Paint paint47 = valueMarker28.getOutlinePaint();
        combinedDomainXYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker28);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        java.lang.String str5 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) date4);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        xYAreaRenderer9.drawRangeMarker(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, valueAxis14, marker15, rectangle2D16);
        int int18 = combinedDomainXYPlot13.getWeight();
        java.awt.Paint paint19 = combinedDomainXYPlot13.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = combinedDomainXYPlot13.getDomainAxisEdge((int) (short) 100);
        try {
            double double22 = categoryAxis1.getCategoryMiddle(2147483647, 0, rectangle2D8, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 2147483647");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        double double24 = legendGraphic21.getContentXOffset();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color22);
        barRenderer3D4.setWallPaint((java.awt.Paint) color22);
        barRenderer3D4.clearSeriesPaints(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis();
        double double20 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxis();
        boolean boolean22 = categoryPlot0.isDomainCrosshairVisible();
        categoryPlot0.setRangePannable(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(13);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            barRenderer3D2.addAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 0.5f, (double) 0L, (double) '#');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = null;
        java.awt.geom.RectangularShape rectangularShape9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            gradientXYBarPainter3.paintBarShadow(graphics2D4, xYBarRenderer5, (int) (short) 100, (int) (short) -1, true, rectangularShape9, rectangleEdge10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.setTickLabelsVisible(false);
        boolean boolean10 = numberAxis3D6.isVerticalTickLabels();
        try {
            numberAxis3D6.zoomRange((double) (byte) 100, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedDomainXYPlot4.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color16 = java.awt.Color.MAGENTA;
        barRenderer3D15.setBaseLegendTextPaint((java.awt.Paint) color16);
        java.awt.Shape shape18 = null;
        barRenderer3D15.setBaseLegendShape(shape18);
        java.awt.Paint paint21 = barRenderer3D15.getSeriesPaint((int) '4');
        java.awt.Color color22 = java.awt.Color.RED;
        barRenderer3D15.setWallPaint((java.awt.Paint) color22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer3D15.notifyListeners(rendererChangeEvent24);
        java.awt.Font font27 = barRenderer3D15.getLegendTextFont(255);
        int int28 = categoryPlot11.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15);
        categoryPlot11.clearAnnotations();
        java.awt.Paint paint30 = categoryPlot11.getDomainCrosshairPaint();
        combinedDomainXYPlot4.setDomainMinorGridlinePaint(paint30);
        combinedDomainXYPlot4.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYAreaRenderer20.setLegendItemURLGenerator(xYSeriesLabelGenerator21);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = xYAreaRenderer20.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem29 = xYAreaRenderer20.getLegendItem((int) '#', (int) (byte) 1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator31 = null;
        xYAreaRenderer20.setSeriesToolTipGenerator(500, xYToolTipGenerator31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYAreaRenderer20.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNull(xYURLGenerator26);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(legendItemCollection33);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color3);
        legendItem1.setFillPaint((java.awt.Paint) color3);
        legendItem1.setSeriesIndex((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        long long9 = day7.getFirstMillisecond();
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day7, (org.jfree.data.time.RegularTimePeriod) day11);
//        boolean boolean14 = periodAxis13.isAutoRange();
//        periodAxis13.setMinorTickMarksVisible(true);
//        java.awt.Font font17 = periodAxis13.getLabelFont();
//        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer21 = null;
//        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, paint18, (float) 1577894400001L, (int) '#', textMeasurer21);
//        java.awt.Graphics2D graphics2D23 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
//        textBlock22.draw(graphics2D23, (float) 10L, (float) 7, textBlockAnchor26);
//        java.awt.Graphics2D graphics2D28 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
//        java.awt.Shape shape35 = textBlock22.calculateBounds(graphics2D28, (float) 2958465, (float) (short) -1, textBlockAnchor31, (float) 2019, (float) ' ', (double) 1);
//        java.awt.Stroke stroke36 = null;
//        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
//        java.awt.image.ColorModel colorModel38 = null;
//        java.awt.Rectangle rectangle39 = null;
//        java.awt.geom.Rectangle2D rectangle2D40 = null;
//        java.awt.geom.AffineTransform affineTransform41 = null;
//        java.awt.RenderingHints renderingHints42 = null;
//        java.awt.PaintContext paintContext43 = color37.createContext(colorModel38, rectangle39, rectangle2D40, affineTransform41, renderingHints42);
//        try {
//            org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "org.jfree.data.general.SeriesException: hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "October", shape35, stroke36, (java.awt.Paint) color37);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(font17);
//        org.junit.Assert.assertNotNull(paint18);
//        org.junit.Assert.assertNotNull(textBlock22);
//        org.junit.Assert.assertNotNull(textBlockAnchor26);
//        org.junit.Assert.assertNotNull(textBlockAnchor31);
//        org.junit.Assert.assertNotNull(shape35);
//        org.junit.Assert.assertNotNull(color37);
//        org.junit.Assert.assertNotNull(paintContext43);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2958465, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) -1, 10.0d);
        boolean boolean3 = xYDataItem2.isSelected();
        java.lang.Number number4 = xYDataItem2.getX();
        java.lang.Number number5 = xYDataItem2.getX();
        java.lang.Object obj6 = null;
        boolean boolean7 = xYDataItem2.equals(obj6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0d) + "'", number5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer3D2.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = null;
        xYAreaRenderer11.setLegendItemURLGenerator(xYSeriesLabelGenerator12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYAreaRenderer11.drawRangeMarker(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, valueAxis16, marker17, rectangle2D18);
        java.awt.Shape shape20 = xYAreaRenderer11.getLegendArea();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator23 = null;
        xYAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator23);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYAreaRenderer22.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYAreaRenderer22.getSeriesNegativeItemLabelPosition((int) (short) 1);
        xYAreaRenderer11.setSeriesNegativeItemLabelPosition((int) (byte) 10, itemLabelPosition30);
        barRenderer3D2.setSeriesNegativeItemLabelPosition(7, itemLabelPosition30);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(xYURLGenerator28);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        int int2 = logAxis1.getMinorTickCount();
        double double3 = logAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        int int20 = categoryPlot19.getCrosshairDatasetIndex();
        java.awt.Paint paint21 = categoryPlot19.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = combinedDomainXYPlot22.getDataset();
        boolean boolean24 = combinedDomainXYPlot22.isRangeZoomable();
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot22.setRangeTickBandPaint(paint25);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator28 = null;
        xYAreaRenderer27.setLegendItemURLGenerator(xYSeriesLabelGenerator28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.Marker marker33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYAreaRenderer27.drawRangeMarker(graphics2D30, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot31, valueAxis32, marker33, rectangle2D34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot31.setRangeAxisLocation((int) (byte) 1, axisLocation37, false);
        float float40 = combinedDomainXYPlot31.getBackgroundAlpha();
        combinedDomainXYPlot31.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke43 = combinedDomainXYPlot31.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer44 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator45 = null;
        xYAreaRenderer44.setLegendItemURLGenerator(xYSeriesLabelGenerator45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot48 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.plot.Marker marker50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        xYAreaRenderer44.drawRangeMarker(graphics2D47, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot48, valueAxis49, marker50, rectangle2D51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot48.setRangeAxisLocation((int) (byte) 1, axisLocation54, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = combinedDomainXYPlot48.getInsets();
        double double59 = rectangleInsets57.calculateTopInset((double) (byte) 100);
        org.jfree.chart.block.LineBorder lineBorder60 = new org.jfree.chart.block.LineBorder(paint25, stroke43, rectangleInsets57);
        categoryPlot19.setRangeMinorGridlineStroke(stroke43);
        categoryPlot0.setRangeGridlineStroke(stroke43);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 4.0d + "'", double59 == 4.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        float[] floatArray6 = new float[] { 432000000L };
        try {
            float[] floatArray7 = color3.getColorComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "[size=1]", "Pie 3D Plot", "hi!", "Combined_Domain_XYPlot");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) ' ');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setAutoRange(false);
        org.jfree.data.Range range6 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D3);
        boolean boolean7 = numberAxis3D3.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains(0.0d);
        numberAxis3D3.setRange(range8, true, true);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        java.awt.Paint paint11 = barRenderer3D2.getSeriesPaint(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer3D2.getSeriesItemLabelGenerator((int) (short) 10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        float[] floatArray9 = new float[] { 0L, 60000L, (-65281), 2958465, 0.5f, 1560409200000L };
        float[] floatArray10 = color0.getColorComponents(colorSpace2, floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRange(false);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D0.setTickLabelFont(font3);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D0);
        double double6 = combinedRangeXYPlot5.getGap();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean10 = xYLineAndShapeRenderer9.getDrawSeriesLineAsPath();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator12 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_LEFT");
        xYLineAndShapeRenderer9.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator12);
        combinedRangeXYPlot5.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        double double22 = legendGraphic21.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendGraphic21.setShapeAnchor(rectangleAnchor23);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2, timeZone3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer7);
        timeSeriesCollection4.seriesChanged(seriesChangeEvent8);
        legendItem1.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection4);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate12 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection4, true);
        try {
            double double15 = intervalXYDelegate12.getEndXValue(500, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        java.awt.Font font13 = barRenderer3D2.getItemLabelFont(10, 9, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = null;
        try {
            logAxis1.setTickUnit(numberTickUnit2, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color4 = java.awt.Color.MAGENTA;
//        barRenderer3D3.setBaseLegendTextPaint((java.awt.Paint) color4);
//        java.awt.Shape shape6 = null;
//        barRenderer3D3.setBaseLegendShape(shape6);
//        java.awt.Paint paint9 = barRenderer3D3.getSeriesPaint((int) '4');
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        int int13 = day12.getMonth();
//        long long14 = day12.getFirstMillisecond();
//        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day16);
//        boolean boolean19 = periodAxis18.isAutoRange();
//        periodAxis18.setMinorTickMarksVisible(true);
//        java.awt.Font font22 = periodAxis18.getLabelFont();
//        barRenderer3D3.setBaseItemLabelFont(font22);
//        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("Pie 3D Plot", font22);
//        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        int int29 = day28.getMonth();
//        long long30 = day28.getFirstMillisecond();
//        java.util.Date date31 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        int int33 = day32.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) day32);
//        boolean boolean35 = periodAxis34.isAutoRange();
//        periodAxis34.setMinorTickMarksVisible(true);
//        java.awt.Font font38 = periodAxis34.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font38);
//        labelBlock24.setFont(font38);
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNull(paint9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(font22);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(font38);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color22);
        barRenderer3D4.setWallPaint((java.awt.Paint) color22);
        boolean boolean26 = barRenderer3D4.isSeriesVisibleInLegend((int) '#');
        barRenderer3D4.clearSeriesPaints(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        org.jfree.data.general.PieDataset pieDataset15 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D(pieDataset15);
//        piePlot3D16.setAutoPopulateSectionOutlineStroke(true);
//        java.awt.Stroke stroke19 = piePlot3D16.getBaseSectionOutlineStroke();
//        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = null;
//        piePlot3D16.setURLGenerator(pieURLGenerator20);
//        double double22 = piePlot3D16.getShadowXOffset();
//        boolean boolean23 = piePlot3D16.getSimpleLabels();
//        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape29, (org.jfree.chart.axis.Axis) numberAxis3D30);
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D34 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color35 = java.awt.Color.MAGENTA;
//        barRenderer3D34.setBaseLegendTextPaint((java.awt.Paint) color35);
//        java.awt.Shape shape37 = null;
//        barRenderer3D34.setBaseLegendShape(shape37);
//        java.awt.Paint paint40 = barRenderer3D34.getSeriesPaint((int) '4');
//        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        barRenderer3D34.setBaseFillPaint((java.awt.Paint) color41, false);
//        int int44 = color41.getTransparency();
//        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape29, (java.awt.Paint) color41);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        legendGraphic45.setShapeLocation(rectangleAnchor46);
//        org.jfree.chart.util.RectangleInsets rectangleInsets48 = legendGraphic45.getPadding();
//        double double50 = rectangleInsets48.calculateTopInset(1.0d);
//        piePlot3D16.setLabelPadding(rectangleInsets48);
//        org.jfree.chart.util.LogFormat logFormat54 = new org.jfree.chart.util.LogFormat();
//        logFormat54.setMinimumFractionDigits(100);
//        org.jfree.chart.util.LogFormat logFormat57 = new org.jfree.chart.util.LogFormat();
//        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator58 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat54, (java.text.NumberFormat) logFormat57);
//        org.jfree.chart.util.LogFormat logFormat59 = new org.jfree.chart.util.LogFormat();
//        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator60 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie 3D Plot", (java.text.NumberFormat) logFormat54, (java.text.NumberFormat) logFormat59);
//        java.text.AttributedString attributedString62 = null;
//        standardPieSectionLabelGenerator60.setAttributedLabel(255, attributedString62);
//        piePlot3D16.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator60);
//        boolean boolean65 = textTitle14.equals((java.lang.Object) standardPieSectionLabelGenerator60);
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer66 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator67 = null;
//        xYAreaRenderer66.setLegendItemURLGenerator(xYSeriesLabelGenerator67);
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator72 = xYAreaRenderer66.getURLGenerator(0, 100, true);
//        org.jfree.chart.LegendItem legendItem75 = xYAreaRenderer66.getLegendItem((int) '#', (int) (byte) 1);
//        java.awt.Graphics2D graphics2D76 = null;
//        java.awt.geom.Rectangle2D rectangle2D77 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot78 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.data.time.TimeSeries timeSeries79 = null;
//        java.util.TimeZone timeZone80 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection81 = new org.jfree.data.time.TimeSeriesCollection(timeSeries79, timeZone80);
//        org.jfree.data.Range range82 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection81);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D83 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer84 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot85 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection81, (org.jfree.chart.axis.ValueAxis) numberAxis3D83, polarItemRenderer84);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState87 = xYAreaRenderer66.initialise(graphics2D76, rectangle2D77, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot78, (org.jfree.data.xy.XYDataset) timeSeriesCollection81, plotRenderingInfo86);
//        org.jfree.data.DomainOrder domainOrder88 = timeSeriesCollection81.getDomainOrder();
//        boolean boolean89 = textTitle14.equals((java.lang.Object) domainOrder88);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(shape25);
//        org.junit.Assert.assertNotNull(rectangleAnchor26);
//        org.junit.Assert.assertNotNull(shape29);
//        org.junit.Assert.assertNotNull(color35);
//        org.junit.Assert.assertNull(paint40);
//        org.junit.Assert.assertNotNull(color41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(rectangleAnchor46);
//        org.junit.Assert.assertNotNull(rectangleInsets48);
//        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNull(xYURLGenerator72);
//        org.junit.Assert.assertNull(legendItem75);
//        org.junit.Assert.assertNull(range82);
//        org.junit.Assert.assertNotNull(xYItemRendererState87);
//        org.junit.Assert.assertNotNull(domainOrder88);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        int int5 = day4.getMonth();
//        long long6 = day4.getFirstMillisecond();
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        int int9 = day8.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day8);
//        boolean boolean11 = periodAxis10.isAutoRange();
//        periodAxis10.setMinorTickMarksVisible(true);
//        java.awt.Font font14 = periodAxis10.getLabelFont();
//        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
//        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, paint15, (float) 1577894400001L, (int) '#', textMeasurer18);
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color23 = java.awt.Color.MAGENTA;
//        barRenderer3D22.setBaseLegendTextPaint((java.awt.Paint) color23);
//        java.awt.Shape shape25 = null;
//        barRenderer3D22.setBaseLegendShape(shape25);
//        java.awt.Paint paint28 = barRenderer3D22.getSeriesPaint((int) '4');
//        java.awt.Color color29 = java.awt.Color.RED;
//        barRenderer3D22.setWallPaint((java.awt.Paint) color29);
//        org.jfree.chart.text.TextMeasurer textMeasurer32 = null;
//        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, (java.awt.Paint) color29, (float) (byte) 100, textMeasurer32);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(font14);
//        org.junit.Assert.assertNotNull(paint15);
//        org.junit.Assert.assertNotNull(textBlock19);
//        org.junit.Assert.assertNotNull(color23);
//        org.junit.Assert.assertNull(paint28);
//        org.junit.Assert.assertNotNull(color29);
//        org.junit.Assert.assertNotNull(textBlock33);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color3 = java.awt.Color.MAGENTA;
//        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
//        java.awt.Shape shape5 = null;
//        barRenderer3D2.setBaseLegendShape(shape5);
//        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
//        java.awt.Color color9 = java.awt.Color.RED;
//        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer3D2.getItemLabelGenerator((int) (byte) -1, (int) (byte) -1, false);
//        org.jfree.chart.plot.CategoryPlot categoryPlot15 = barRenderer3D2.getPlot();
//        barRenderer3D2.setBase((double) (short) 0);
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        int int21 = day20.getMonth();
//        long long22 = day20.getFirstMillisecond();
//        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        int int25 = day24.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day24);
//        boolean boolean27 = periodAxis26.isAutoRange();
//        periodAxis26.setMinorTickMarksVisible(true);
//        java.awt.Font font30 = periodAxis26.getLabelFont();
//        barRenderer3D2.setBaseItemLabelFont(font30, true);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNull(paint8);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
//        org.junit.Assert.assertNull(categoryPlot15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(font30);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRange(false);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D0.setTickLabelFont(font3);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D0);
        double double6 = combinedRangeXYPlot5.getGap();
        java.lang.Object obj7 = null;
        boolean boolean8 = combinedRangeXYPlot5.equals(obj7);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font12 = barRenderer3D2.getItemLabelFont(9, (int) (short) 10, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        float float2 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("DomainOrder.ASCENDING", (java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendGraphic21.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic21.setShapeAnchor(rectangleAnchor25);
        java.awt.Shape shape27 = legendGraphic21.getLine();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNull(shape27);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day1, (double) 5);
//        long long5 = day1.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.setDatasetIndex((int) '4');
        xYCrosshairState0.setCrosshairDistance((double) 1.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 1, 1.0f);
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.lang.Object obj27 = legendItemEntity26.clone();
        org.jfree.data.general.Dataset dataset28 = null;
        legendItemEntity26.setDataset(dataset28);
        legendItemEntity26.setSeriesKey((java.lang.Comparable) 9);
        java.lang.Comparable comparable32 = legendItemEntity26.getSeriesKey();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 9 + "'", comparable32.equals(9));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = rendererChangeEvent1.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.lang.String str3 = xYSeries2.getDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        int int8 = xYSeries2.getMaximumItemCount();
        xYSeries2.add(0.0d, (java.lang.Number) 1099410614137L);
        xYSeries2.add((double) 10.0f, (double) 10L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Stroke stroke2 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(0);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        combinedDomainXYPlot9.setDrawingSupplier(drawingSupplier14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYStepAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, xYDataset16, plotRenderingInfo17);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) xYStepAreaRenderer0, false);
        boolean boolean21 = rendererChangeEvent20.getSeriesVisibilityChanged();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        java.lang.String str5 = categoryPlot0.getPlotType();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(7, layer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(8);
        categoryPlot0.setRangeGridlinesVisible(false);
        java.awt.Paint paint13 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint13);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
//        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 1577894400001L, (int) '#', textMeasurer17);
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        int int21 = day20.getMonth();
//        long long22 = day20.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        boolean boolean24 = textBlock18.equals((java.lang.Object) day20);
//        org.jfree.chart.text.TextLine textLine25 = textBlock18.getLastLine();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(textBlock18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNull(textLine25);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((double) 7, plotRenderingInfo6, point2D7, true);
        double[] doubleArray15 = new double[] { (short) 100, 6 };
        double[][] doubleArray16 = new double[][] { doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset17, true);
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset17);
        categoryPlot0.setDataset(500, categoryDataset17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        try {
            org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset17, (java.lang.Comparable) date24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color22);
        barRenderer3D4.setWallPaint((java.awt.Paint) color22);
        boolean boolean26 = barRenderer3D4.isSeriesVisibleInLegend((int) '#');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = barRenderer3D4.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(drawingSupplier27);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int3 = java.awt.Color.HSBtoRGB((float) 5, (float) (byte) 100, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        logAxis1.pan((double) 1.0f);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        piePlot3D12.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D17 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        barRenderer3D17.setBaseLegendTextPaint((java.awt.Paint) color18);
        java.awt.Shape shape20 = null;
        barRenderer3D17.setBaseLegendShape(shape20);
        java.awt.Paint paint23 = barRenderer3D17.getSeriesPaint((int) '4');
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D17.setBaseFillPaint((java.awt.Paint) color24, false);
        piePlot3D12.setBaseSectionPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        int int29 = categoryPlot28.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D32 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color33 = java.awt.Color.MAGENTA;
        barRenderer3D32.setBaseLegendTextPaint((java.awt.Paint) color33);
        java.awt.Shape shape35 = null;
        barRenderer3D32.setBaseLegendShape(shape35);
        java.awt.Paint paint38 = barRenderer3D32.getSeriesPaint((int) '4');
        java.awt.Color color39 = java.awt.Color.RED;
        barRenderer3D32.setWallPaint((java.awt.Paint) color39);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        barRenderer3D32.notifyListeners(rendererChangeEvent41);
        java.awt.Font font44 = barRenderer3D32.getLegendTextFont(255);
        int int45 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D32);
        categoryPlot28.clearAnnotations();
        java.awt.Paint paint47 = categoryPlot28.getDomainCrosshairPaint();
        int int48 = categoryPlot28.getDatasetCount();
        boolean boolean49 = categoryPlot28.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot28.getDomainAxisEdge(2019);
        boolean boolean52 = color24.equals((java.lang.Object) rectangleEdge51);
        try {
            double double53 = logAxis1.exponentLengthToJava2D(1.5051499783199058d, rectangle2D10, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(font44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        jFreeChart2.fireChartChanged();
        boolean boolean4 = timePeriodAnchor0.equals((java.lang.Object) jFreeChart2);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat1, dateFormat2);
        java.text.NumberFormat numberFormat4 = standardXYToolTipGenerator3.getXFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setAutoRange(false);
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setTickLabelFont(font4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_LEFT", font4);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        int int6 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
        org.jfree.chart.event.ChartProgressListener chartProgressListener8 = null;
        jFreeChart4.addProgressListener(chartProgressListener8);
        java.lang.Object obj10 = jFreeChart4.getTextAntiAlias();
        float float11 = jFreeChart4.getBackgroundImageAlpha();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = null;
        try {
            jFreeChart4.titleChanged(titleChangeEvent12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        org.jfree.chart.event.TitleChangeListener titleChangeListener15 = null;
//        textTitle14.removeChangeListener(titleChangeListener15);
//        java.awt.Paint paint17 = textTitle14.getBackgroundPaint();
//        java.awt.Color color22 = java.awt.Color.MAGENTA;
//        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color22);
//        textTitle14.setFrame((org.jfree.chart.block.BlockFrame) blockBorder23);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNull(paint17);
//        org.junit.Assert.assertNotNull(color22);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        int int1 = shapeList0.size();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot2.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedDomainXYPlot2.getDataset((int) (byte) 100);
        boolean boolean6 = shapeList0.equals((java.lang.Object) xYDataset5);
        shapeList0.clear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Paint paint8 = polarPlot6.getRadiusGridlinePaint();
        polarPlot6.clearCornerTextItems();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.Point point13 = polarPlot6.translateValueThetaRadiusToJava2D((double) 86400000L, (double) 3600000L, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = null;
        shapeList0.setShape((int) '#', shape2);
        shapeList0.clear();
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) -1, 10.0d);
        boolean boolean3 = xYDataItem2.isSelected();
        java.lang.Number number4 = xYDataItem2.getX();
        xYDataItem2.setY((double) (short) 1);
        xYDataItem2.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) '#', (int) (byte) 1);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13, timeZone14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, polarItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYAreaRenderer0.initialise(graphics2D10, rectangle2D11, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot12, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = xYItemRendererState21.getInfo();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState23 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState23.setDatasetIndex((int) '4');
        xYItemRendererState21.setCrosshairState(xYCrosshairState23);
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertNull(plotRenderingInfo22);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
//        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 1577894400001L, (int) '#', textMeasurer17);
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        int int21 = day20.getMonth();
//        long long22 = day20.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        boolean boolean24 = textBlock18.equals((java.lang.Object) day20);
//        java.awt.Graphics2D graphics2D25 = null;
//        org.jfree.chart.util.Size2D size2D26 = textBlock18.calculateDimensions(graphics2D25);
//        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape33, (org.jfree.chart.axis.Axis) numberAxis3D34);
//        numberAxis3D34.zoomRange(0.0d, 0.0d);
//        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        int int43 = day42.getMonth();
//        long long44 = day42.getFirstMillisecond();
//        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        int int47 = day46.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day46);
//        boolean boolean49 = periodAxis48.isAutoRange();
//        periodAxis48.setMinorTickMarksVisible(true);
//        java.awt.Font font52 = periodAxis48.getLabelFont();
//        java.awt.Paint paint53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer56 = null;
//        org.jfree.chart.text.TextBlock textBlock57 = org.jfree.chart.text.TextUtilities.createTextBlock("", font52, paint53, (float) 1577894400001L, (int) '#', textMeasurer56);
//        numberAxis3D34.setTickLabelFont(font52);
//        java.awt.Color color59 = java.awt.Color.cyan;
//        textBlock18.addLine("", font52, (java.awt.Paint) color59);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(textBlock18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(size2D26);
//        org.junit.Assert.assertNotNull(shape29);
//        org.junit.Assert.assertNotNull(rectangleAnchor30);
//        org.junit.Assert.assertNotNull(shape33);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560409200000L + "'", long44 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(font52);
//        org.junit.Assert.assertNotNull(paint53);
//        org.junit.Assert.assertNotNull(textBlock57);
//        org.junit.Assert.assertNotNull(color59);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = logAxis1.getTickUnit();
        java.lang.String str9 = numberTickUnit7.valueToString((double) 255);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "255" + "'", str9.equals("255"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Paint paint8 = polarPlot6.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        polarPlot6.zoomDomainAxes((double) 0, (double) 100.0f, plotRenderingInfo11, point2D12);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor16, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape19, (org.jfree.chart.axis.Axis) numberAxis3D20);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color25 = java.awt.Color.MAGENTA;
        barRenderer3D24.setBaseLegendTextPaint((java.awt.Paint) color25);
        java.awt.Shape shape27 = null;
        barRenderer3D24.setBaseLegendShape(shape27);
        java.awt.Paint paint30 = barRenderer3D24.getSeriesPaint((int) '4');
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D24.setBaseFillPaint((java.awt.Paint) color31, false);
        int int34 = color31.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic35 = new org.jfree.chart.title.LegendGraphic(shape19, (java.awt.Paint) color31);
        polarPlot6.setAngleLabelPaint((java.awt.Paint) color31);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean4 = combinedDomainXYPlot0.removeAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(64, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("[size=1]", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        combinedDomainXYPlot4.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedDomainXYPlot4.getLegendItems();
        java.lang.Object obj14 = legendItemCollection13.clone();
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getSimpleLabelOffset();
        boolean boolean3 = ringPlot0.getAutoPopulateSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        xYAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        java.awt.Paint paint11 = barRenderer3D2.getSeriesPaint(3);
        barRenderer3D2.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer3D2.getSeriesToolTipGenerator(255);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator15);
        boolean boolean17 = barRenderer3D2.getIncludeBaseInRange();
        barRenderer3D2.setShadowXOffset((double) 0.5f);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        int int24 = categoryPlot23.getCrosshairDatasetIndex();
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot23.getDomainMarkers(layer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator30 = null;
        xYAreaRenderer29.setLegendItemURLGenerator(xYSeriesLabelGenerator30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        xYAreaRenderer29.drawRangeMarker(graphics2D32, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot33, valueAxis34, marker35, rectangle2D36);
        java.awt.Shape shape38 = xYAreaRenderer29.getLegendArea();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis28, shape38, "SerialDate.weekInMonthToString(): invalid code.", "");
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[][] numberArray63 = new java.lang.Number[][] { numberArray50, numberArray56, numberArray62 };
        org.jfree.data.category.CategoryDataset categoryDataset64 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-10,1,0,-19,-20,-19,-20,-19", "hi!", numberArray63);
        try {
            barRenderer3D2.drawItem(graphics2D20, categoryItemRendererState21, rectangle2D22, categoryPlot23, categoryAxis28, valueAxis42, categoryDataset64, 0, 1, false, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(categoryDataset64);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        barRenderer3D6.setBaseLegendTextPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        barRenderer3D6.setBaseLegendShape(shape9);
        java.awt.Paint paint12 = barRenderer3D6.getSeriesPaint((int) '4');
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D6.setBaseFillPaint((java.awt.Paint) color13, false);
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.Rotation rotation17 = piePlot3D1.getDirection();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = null;
        xYAreaRenderer18.setLegendItemURLGenerator(xYSeriesLabelGenerator19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYAreaRenderer18.drawRangeMarker(graphics2D21, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot22, valueAxis23, marker24, rectangle2D25);
        java.awt.Font font28 = xYAreaRenderer18.lookupLegendTextFont(6);
        int int29 = xYAreaRenderer18.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator30 = xYAreaRenderer18.getLegendItemLabelGenerator();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape32, rectangleAnchor33, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity38 = new org.jfree.chart.entity.AxisEntity(shape36, (org.jfree.chart.axis.Axis) numberAxis3D37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D37.setTickMarkStroke(stroke39);
        xYAreaRenderer18.setBaseStroke(stroke39);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape44, rectangleAnchor45, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity50 = new org.jfree.chart.entity.AxisEntity(shape48, (org.jfree.chart.axis.Axis) numberAxis3D49);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D49.setTickMarkStroke(stroke51);
        xYAreaRenderer18.setSeriesStroke(0, stroke51, false);
        java.awt.Paint paint58 = xYAreaRenderer18.getItemOutlinePaint(6, 0, false);
        piePlot3D1.setBaseSectionPaint(paint58);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertNull(font28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator30);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        barRenderer3D2.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition();
        barRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        double double10 = ringPlot9.getSectionDepth();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = ringPlot9.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis(0, categoryAxis15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot13.zoomDomainAxes(0.0d, plotRenderingInfo19, point2D20);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean24 = categoryPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker23);
        valueMarker23.setLabel("hi!");
        java.lang.Object obj27 = valueMarker23.clone();
        boolean boolean28 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker23);
        org.jfree.chart.text.TextAnchor textAnchor29 = valueMarker23.getLabelTextAnchor();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(textAnchor29);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Stroke stroke1 = xYStepAreaRenderer0.getBaseOutlineStroke();
        xYStepAreaRenderer0.setShapesVisible(true);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        java.awt.Stroke stroke7 = categoryPlot0.getDomainCrosshairStroke();
        java.awt.Paint paint8 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Font font2 = legendTitle1.getItemFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection7);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        xYSeries11.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14, timeZone15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, polarItemRenderer19);
        xYSeries11.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection16);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection16);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RectangleAnchor.TOP_RIGHT", numberFormat1, dateFormat2);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        int int5 = day4.getMonth();
//        long long6 = day4.getFirstMillisecond();
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        int int9 = day8.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day8);
//        boolean boolean11 = periodAxis10.isAutoRange();
//        periodAxis10.setMinorTickMarksVisible(true);
//        java.awt.Font font14 = periodAxis10.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font14);
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot16.getPieChart();
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = null;
//        xYAreaRenderer18.setLegendItemURLGenerator(xYSeriesLabelGenerator19);
//        java.awt.Graphics2D graphics2D21 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
//        org.jfree.chart.plot.Marker marker24 = null;
//        java.awt.geom.Rectangle2D rectangle2D25 = null;
//        xYAreaRenderer18.drawRangeMarker(graphics2D21, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot22, valueAxis23, marker24, rectangle2D25);
//        java.awt.Font font28 = xYAreaRenderer18.lookupLegendTextFont(6);
//        boolean boolean30 = xYAreaRenderer18.equals((java.lang.Object) "DomainOrder.ASCENDING");
//        java.awt.Shape shape31 = xYAreaRenderer18.getLegendArea();
//        multiplePiePlot16.setLegendItemShape(shape31);
//        org.jfree.data.xy.XYDataItem xYDataItem35 = new org.jfree.data.xy.XYDataItem((double) (short) -1, 10.0d);
//        boolean boolean36 = xYDataItem35.isSelected();
//        java.lang.Number number37 = xYDataItem35.getX();
//        xYDataItem35.setY((double) (short) 1);
//        multiplePiePlot16.setAggregatedItemsKey((java.lang.Comparable) xYDataItem35);
//        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
//        java.awt.image.ColorModel colorModel42 = null;
//        java.awt.Rectangle rectangle43 = null;
//        java.awt.geom.Rectangle2D rectangle2D44 = null;
//        java.awt.geom.AffineTransform affineTransform45 = null;
//        java.awt.RenderingHints renderingHints46 = null;
//        java.awt.PaintContext paintContext47 = color41.createContext(colorModel42, rectangle43, rectangle2D44, affineTransform45, renderingHints46);
//        multiplePiePlot16.setAggregatedItemsPaint((java.awt.Paint) color41);
//        org.jfree.chart.text.TextMeasurer textMeasurer51 = null;
//        try {
//            org.jfree.chart.text.TextBlock textBlock52 = org.jfree.chart.text.TextUtilities.createTextBlock("TimePeriodAnchor.MIDDLE", font14, (java.awt.Paint) color41, (float) 0, 6, textMeasurer51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(font14);
//        org.junit.Assert.assertNotNull(jFreeChart17);
//        org.junit.Assert.assertNull(font28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(shape31);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1.0d) + "'", number37.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(color41);
//        org.junit.Assert.assertNotNull(paintContext47);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle3 = null;
        jFreeChart1.setTitle(textTitle3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot9.setRangeAxisLocation((int) (byte) 1, axisLocation15, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedDomainXYPlot9.getInsets();
        java.lang.String str19 = rectangleInsets18.toString();
        jFreeChart1.setPadding(rectangleInsets18);
        java.awt.Paint paint21 = jFreeChart1.getBorderPaint();
        java.awt.Image image22 = null;
        jFreeChart1.setBackgroundImage(image22);
        jFreeChart1.setBackgroundImageAlpha((float) (short) 100);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str19.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        java.lang.Boolean boolean12 = xYAreaRenderer0.getSeriesVisible(0);
        java.awt.Stroke stroke13 = xYAreaRenderer0.getBaseOutlineStroke();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator18 = null;
        xYAreaRenderer17.setLegendItemURLGenerator(xYSeriesLabelGenerator18);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYAreaRenderer17.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem26 = xYAreaRenderer17.getLegendItem((int) '#', (int) (byte) 1);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.time.TimeSeries timeSeries30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeSeries30, timeZone31);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection32);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection32, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, polarItemRenderer35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState38 = xYAreaRenderer17.initialise(graphics2D27, rectangle2D28, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot29, (org.jfree.data.xy.XYDataset) timeSeriesCollection32, plotRenderingInfo37);
        int int39 = xYItemRendererState38.getLastItemIndex();
        java.awt.geom.Line2D line2D40 = null;
        xYItemRendererState38.workingLine = line2D40;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot43.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation46 = combinedDomainXYPlot43.getRangeAxisLocation((int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis48 = combinedDomainXYPlot43.getRangeAxis((int) (short) 0);
        combinedDomainXYPlot43.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        java.awt.Shape shape53 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape53, rectangleAnchor54, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity59 = new org.jfree.chart.entity.AxisEntity(shape57, (org.jfree.chart.axis.Axis) numberAxis3D58);
        java.awt.Stroke stroke60 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D58.setTickMarkStroke(stroke60);
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("");
        org.jfree.data.time.TimeSeries timeSeries64 = null;
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection66 = new org.jfree.data.time.TimeSeriesCollection(timeSeries64, timeZone65);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer69 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent70 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer69);
        timeSeriesCollection66.seriesChanged(seriesChangeEvent70);
        legendItem63.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection66);
        try {
            xYAreaRenderer0.drawItem(graphics2D16, xYItemRendererState38, rectangle2D42, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot43, valueAxis51, (org.jfree.chart.axis.ValueAxis) numberAxis3D58, (org.jfree.data.xy.XYDataset) timeSeriesCollection66, 0, 64, true, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYURLGenerator23);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(xYItemRendererState38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator5);
        double double7 = piePlot3D1.getShadowYOffset();
        org.jfree.chart.util.Rotation rotation8 = piePlot3D1.getDirection();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        xYAreaRenderer9.drawRangeMarker(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, valueAxis14, marker15, rectangle2D16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot13.setRangeAxisLocation((int) (byte) 1, axisLocation19, false);
        float float22 = combinedDomainXYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace23 = combinedDomainXYPlot13.getFixedDomainAxisSpace();
        boolean boolean24 = rotation8.equals((java.lang.Object) combinedDomainXYPlot13);
        double double25 = rotation8.getFactor();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendGraphic21.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic21.setShapeAnchor(rectangleAnchor25);
        org.jfree.data.DomainOrder domainOrder27 = org.jfree.data.DomainOrder.ASCENDING;
        boolean boolean28 = rectangleAnchor25.equals((java.lang.Object) domainOrder27);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(domainOrder27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator5, true);
        java.awt.Shape shape9 = barRenderer3D4.lookupSeriesShape((int) '#');
        xYAreaRenderer0.setSeriesShape((int) (byte) 1, shape9, true);
        xYAreaRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = null;
        xYAreaRenderer4.setLegendItemURLGenerator(xYSeriesLabelGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        xYAreaRenderer4.drawRangeMarker(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, valueAxis9, marker10, rectangle2D11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot8.setRangeAxisLocation((int) (byte) 1, axisLocation14, false);
        float float17 = combinedDomainXYPlot8.getBackgroundAlpha();
        boolean boolean18 = combinedDomainXYPlot8.isDomainCrosshairVisible();
        combinedDomainXYPlot8.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        multiplePiePlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        combinedDomainXYPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22, true);
        java.awt.Shape shape26 = defaultDrawingSupplier22.getNextShape();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle27 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape33, (org.jfree.chart.axis.Axis) numberAxis3D34);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D38 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color39 = java.awt.Color.MAGENTA;
        barRenderer3D38.setBaseLegendTextPaint((java.awt.Paint) color39);
        java.awt.Shape shape41 = null;
        barRenderer3D38.setBaseLegendShape(shape41);
        java.awt.Paint paint44 = barRenderer3D38.getSeriesPaint((int) '4');
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D38.setBaseFillPaint((java.awt.Paint) color45, false);
        int int48 = color45.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic49 = new org.jfree.chart.title.LegendGraphic(shape33, (java.awt.Paint) color45);
        boolean boolean50 = pieLabelLinkStyle27.equals((java.lang.Object) color45);
        try {
            org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem(attributedString0, "12/31/69 4:00 PM", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "ERROR : Relative To String", shape26, (java.awt.Paint) color45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        boolean boolean8 = polarPlot6.isRadiusGridlinesVisible();
        boolean boolean9 = polarPlot6.isDomainZoomable();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        double[] doubleArray25 = new double[] { (short) 100, 6 };
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("12/31/69 4:00 PM", "DomainOrder.ASCENDING", doubleArray26);
        categoryPlot0.setDataset(5, categoryDataset28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("RectangleEdge.BOTTOM");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleEdge.BOTTOM");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot11.configureDomainAxes();
        numberAxis3D6.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot11);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = combinedDomainXYPlot11.getOrientation();
        combinedDomainXYPlot11.clearAnnotations();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            combinedDomainXYPlot11.drawBackground(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        boolean boolean12 = xYAreaRenderer0.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Font font16 = xYAreaRenderer0.getItemLabelFont(0, (int) (byte) -1, false);
        xYAreaRenderer0.removeAnnotations();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, polarItemRenderer8);
        java.awt.Font font10 = polarPlot9.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit11);
        polarPlot9.setAngleGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        polarPlot9.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo18, point2D19);
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomRangeAxes((double) (-1.0f), 0.0d, plotRenderingInfo18, point2D21);
        xYPlot0.clearDomainMarkers(5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(dateTickUnit11);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        java.lang.String str5 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getParent();
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        int int9 = logAxis8.getMinorTickCount();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis8);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.general.PieDataset pieDataset0 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
//        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
//        boolean boolean4 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
//        java.awt.Graphics2D graphics2D5 = null;
//        java.awt.geom.Rectangle2D rectangle2D6 = null;
//        java.awt.geom.Point2D point2D7 = null;
//        org.jfree.chart.plot.PlotState plotState8 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = null;
//        xYAreaRenderer11.setLegendItemURLGenerator(xYSeriesLabelGenerator12);
//        java.awt.Graphics2D graphics2D14 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
//        org.jfree.chart.plot.Marker marker17 = null;
//        java.awt.geom.Rectangle2D rectangle2D18 = null;
//        xYAreaRenderer11.drawRangeMarker(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, valueAxis16, marker17, rectangle2D18);
//        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        combinedDomainXYPlot15.setRangeAxisLocation((int) (byte) 1, axisLocation21, false);
//        float float24 = combinedDomainXYPlot15.getBackgroundImageAlpha();
//        org.jfree.chart.axis.AxisSpace axisSpace25 = combinedDomainXYPlot15.getFixedDomainAxisSpace();
//        boolean boolean26 = combinedDomainXYPlot15.canSelectByPoint();
//        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape33, (org.jfree.chart.axis.Axis) numberAxis3D34);
//        numberAxis3D34.zoomRange(0.0d, 0.0d);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot39.configureDomainAxes();
//        numberAxis3D34.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot39);
//        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
//        int int45 = categoryPlot44.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D48 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color49 = java.awt.Color.MAGENTA;
//        barRenderer3D48.setBaseLegendTextPaint((java.awt.Paint) color49);
//        java.awt.Shape shape51 = null;
//        barRenderer3D48.setBaseLegendShape(shape51);
//        java.awt.Paint paint54 = barRenderer3D48.getSeriesPaint((int) '4');
//        java.awt.Color color55 = java.awt.Color.RED;
//        barRenderer3D48.setWallPaint((java.awt.Paint) color55);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent57 = null;
//        barRenderer3D48.notifyListeners(rendererChangeEvent57);
//        java.awt.Font font60 = barRenderer3D48.getLegendTextFont(255);
//        int int61 = categoryPlot44.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D48);
//        java.awt.Stroke stroke62 = categoryPlot44.getRangeCrosshairStroke();
//        java.util.Date date64 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
//        int int66 = day65.getMonth();
//        long long67 = day65.getFirstMillisecond();
//        java.util.Date date68 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
//        int int70 = day69.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis71 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day65, (org.jfree.data.time.RegularTimePeriod) day69);
//        boolean boolean72 = periodAxis71.isAutoRange();
//        periodAxis71.setMinorTickMarksVisible(true);
//        java.awt.Font font75 = periodAxis71.getLabelFont();
//        double double76 = periodAxis71.getLowerBound();
//        int int77 = categoryPlot44.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis71);
//        int int78 = xYPlot43.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis71);
//        xYPlot43.clearDomainMarkers((int) (short) -1);
//        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot43.getRangeAxisLocation((int) (short) 0);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo85 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo85);
//        java.awt.geom.Point2D point2D87 = null;
//        xYPlot43.zoomDomainAxes((double) (-1), 0.0d, plotRenderingInfo86, point2D87);
//        java.awt.geom.Point2D point2D89 = null;
//        combinedDomainXYPlot39.panRangeAxes(4.0d, plotRenderingInfo86, point2D89);
//        java.awt.geom.Point2D point2D91 = null;
//        combinedDomainXYPlot15.zoomDomainAxes((double) 1560495599999L, plotRenderingInfo86, point2D91);
//        java.awt.geom.Point2D point2D93 = null;
//        categoryPlot9.panDomainAxes((double) 10L, plotRenderingInfo86, point2D93);
//        try {
//            piePlot3D1.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo86);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(axisLocation21);
//        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.5f + "'", float24 == 0.5f);
//        org.junit.Assert.assertNull(axisSpace25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(shape29);
//        org.junit.Assert.assertNotNull(rectangleAnchor30);
//        org.junit.Assert.assertNotNull(shape33);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(color49);
//        org.junit.Assert.assertNull(paint54);
//        org.junit.Assert.assertNotNull(color55);
//        org.junit.Assert.assertNull(font60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNotNull(stroke62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560409200000L + "'", long67 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertNotNull(font75);
//        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
//        org.junit.Assert.assertNotNull(axisLocation82);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis8);
//        boolean boolean11 = combinedDomainXYPlot10.canSelectByRegion();
//        combinedDomainXYPlot10.setRangePannable(true);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeCrosshairValue((double) 500, false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        int int6 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
        jFreeChart4.setTitle("ERROR : Relative To String");
        boolean boolean10 = jFreeChart4.isNotify();
        org.jfree.chart.plot.Plot plot11 = jFreeChart4.getPlot();
        java.lang.Object obj12 = null;
        boolean boolean13 = jFreeChart4.equals(obj12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYAreaRenderer0.getBaseToolTipGenerator();
        xYAreaRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = xYAreaRenderer0.getLegendItemLabelGenerator();
        boolean boolean11 = xYAreaRenderer0.getPlotLines();
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = barRenderer3D4.getDrawingSupplier();
        java.awt.Stroke stroke20 = barRenderer3D4.lookupSeriesOutlineStroke((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(stroke20);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
//        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.plot.Marker marker6 = null;
//        java.awt.geom.Rectangle2D rectangle2D7 = null;
//        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
//        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot4.getLegendItems();
//        combinedDomainXYPlot4.clearSelection();
//        java.awt.Stroke stroke11 = combinedDomainXYPlot4.getDomainMinorGridlineStroke();
//        java.util.List list12 = combinedDomainXYPlot4.getSubplots();
//        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, rectangleAnchor17, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity22 = new org.jfree.chart.entity.AxisEntity(shape20, (org.jfree.chart.axis.Axis) numberAxis3D21);
//        numberAxis3D21.zoomRange(0.0d, 0.0d);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot26.configureDomainAxes();
//        numberAxis3D21.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot26);
//        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
//        int int32 = categoryPlot31.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D35 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color36 = java.awt.Color.MAGENTA;
//        barRenderer3D35.setBaseLegendTextPaint((java.awt.Paint) color36);
//        java.awt.Shape shape38 = null;
//        barRenderer3D35.setBaseLegendShape(shape38);
//        java.awt.Paint paint41 = barRenderer3D35.getSeriesPaint((int) '4');
//        java.awt.Color color42 = java.awt.Color.RED;
//        barRenderer3D35.setWallPaint((java.awt.Paint) color42);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent44 = null;
//        barRenderer3D35.notifyListeners(rendererChangeEvent44);
//        java.awt.Font font47 = barRenderer3D35.getLegendTextFont(255);
//        int int48 = categoryPlot31.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D35);
//        java.awt.Stroke stroke49 = categoryPlot31.getRangeCrosshairStroke();
//        java.util.Date date51 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
//        int int53 = day52.getMonth();
//        long long54 = day52.getFirstMillisecond();
//        java.util.Date date55 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
//        int int57 = day56.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis58 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day52, (org.jfree.data.time.RegularTimePeriod) day56);
//        boolean boolean59 = periodAxis58.isAutoRange();
//        periodAxis58.setMinorTickMarksVisible(true);
//        java.awt.Font font62 = periodAxis58.getLabelFont();
//        double double63 = periodAxis58.getLowerBound();
//        int int64 = categoryPlot31.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis58);
//        int int65 = xYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis58);
//        xYPlot30.clearDomainMarkers((int) (short) -1);
//        org.jfree.chart.axis.AxisLocation axisLocation69 = xYPlot30.getRangeAxisLocation((int) (short) 0);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo72 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo72);
//        java.awt.geom.Point2D point2D74 = null;
//        xYPlot30.zoomDomainAxes((double) (-1), 0.0d, plotRenderingInfo73, point2D74);
//        java.awt.geom.Point2D point2D76 = null;
//        combinedDomainXYPlot26.panRangeAxes(4.0d, plotRenderingInfo73, point2D76);
//        combinedDomainXYPlot4.handleClick(0, 0, plotRenderingInfo73);
//        org.jfree.chart.plot.Marker marker80 = null;
//        org.jfree.chart.util.Layer layer81 = null;
//        boolean boolean82 = combinedDomainXYPlot4.removeDomainMarker(2958465, marker80, layer81);
//        org.junit.Assert.assertNotNull(legendItemCollection9);
//        org.junit.Assert.assertNotNull(stroke11);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertNotNull(shape16);
//        org.junit.Assert.assertNotNull(rectangleAnchor17);
//        org.junit.Assert.assertNotNull(shape20);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(color36);
//        org.junit.Assert.assertNull(paint41);
//        org.junit.Assert.assertNotNull(color42);
//        org.junit.Assert.assertNull(font47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(stroke49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560409200000L + "'", long54 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(font62);
//        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertNotNull(axisLocation69);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        int int1 = xYStepAreaRenderer0.getDefaultEntityRadius();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke2);
        xYStepAreaRenderer0.setSeriesItemLabelsVisible(2, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 1, 1.0f);
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        long long8 = day6.getFirstMillisecond();
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        int int11 = day10.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) day10);
//        boolean boolean13 = periodAxis12.isAutoRange();
//        periodAxis12.setMinorTickMarksVisible(true);
//        java.awt.Font font16 = periodAxis12.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font16);
//        boolean boolean19 = textTitle17.equals((java.lang.Object) "TimePeriodAnchor.MIDDLE");
//        textTitle17.visible = false;
//        org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) textTitle17, "");
//        java.awt.Paint paint24 = textTitle17.getPaint();
//        org.junit.Assert.assertNotNull(shape2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(font16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(paint24);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot5.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = combinedDomainXYPlot5.getDatasetRenderingOrder();
        java.util.List list8 = combinedDomainXYPlot5.getSubplots();
        combinedDomainXYPlot5.configureRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        combinedDomainXYPlot5.drawDomainTickBands(graphics2D10, rectangle2D11, list12);
        java.awt.Paint paint14 = combinedDomainXYPlot5.getRangeGridlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        combinedDomainXYPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15, false);
        java.awt.Paint paint18 = defaultDrawingSupplier15.getNextPaint();
        barRenderer3D2.setBasePaint(paint18);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint18);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
//        int int2 = categoryPlot1.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color6 = java.awt.Color.MAGENTA;
//        barRenderer3D5.setBaseLegendTextPaint((java.awt.Paint) color6);
//        java.awt.Shape shape8 = null;
//        barRenderer3D5.setBaseLegendShape(shape8);
//        java.awt.Paint paint11 = barRenderer3D5.getSeriesPaint((int) '4');
//        java.awt.Color color12 = java.awt.Color.RED;
//        barRenderer3D5.setWallPaint((java.awt.Paint) color12);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
//        barRenderer3D5.notifyListeners(rendererChangeEvent14);
//        java.awt.Font font17 = barRenderer3D5.getLegendTextFont(255);
//        int int18 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
//        java.awt.Stroke stroke19 = categoryPlot1.getRangeCrosshairStroke();
//        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        int int23 = day22.getMonth();
//        long long24 = day22.getFirstMillisecond();
//        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        int int27 = day26.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day26);
//        boolean boolean29 = periodAxis28.isAutoRange();
//        periodAxis28.setMinorTickMarksVisible(true);
//        java.awt.Font font32 = periodAxis28.getLabelFont();
//        double double33 = periodAxis28.getLowerBound();
//        int int34 = categoryPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis28);
//        int int35 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis28);
//        xYPlot0.clearDomainMarkers((int) (short) -1);
//        org.jfree.data.time.TimeSeries timeSeries40 = null;
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection(timeSeries40, timeZone41);
//        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection42);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection42, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, polarItemRenderer45);
//        java.awt.Font font47 = polarPlot46.getAngleLabelFont();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        polarPlot46.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit48);
//        polarPlot46.setAngleGridlinesVisible(false);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo54);
//        java.awt.geom.Point2D point2D56 = null;
//        polarPlot46.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo55, point2D56);
//        java.awt.geom.Point2D point2D58 = null;
//        xYPlot0.zoomRangeAxes(0.2d, (double) 100.0f, plotRenderingInfo55, point2D58);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNull(paint11);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNull(font17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(font32);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNull(range43);
//        org.junit.Assert.assertNotNull(font47);
//        org.junit.Assert.assertNotNull(dateTickUnit48);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean11 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        valueMarker10.setLabel("hi!");
        java.lang.Object obj14 = valueMarker10.clone();
        java.awt.Stroke stroke15 = valueMarker10.getOutlineStroke();
        java.lang.Object obj16 = valueMarker10.clone();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator5);
        java.lang.String str7 = piePlot3D1.getPlotType();
        java.awt.Paint paint8 = piePlot3D1.getLabelPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie 3D Plot" + "'", str7.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(paint8);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color4 = java.awt.Color.MAGENTA;
//        barRenderer3D3.setBaseLegendTextPaint((java.awt.Paint) color4);
//        java.awt.Shape shape6 = null;
//        barRenderer3D3.setBaseLegendShape(shape6);
//        java.awt.Paint paint9 = barRenderer3D3.getSeriesPaint((int) '4');
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        int int13 = day12.getMonth();
//        long long14 = day12.getFirstMillisecond();
//        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day16);
//        boolean boolean19 = periodAxis18.isAutoRange();
//        periodAxis18.setMinorTickMarksVisible(true);
//        java.awt.Font font22 = periodAxis18.getLabelFont();
//        barRenderer3D3.setBaseItemLabelFont(font22);
//        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("Pie 3D Plot", font22);
//        java.lang.String str25 = labelBlock24.getToolTipText();
//        labelBlock24.setHeight((double) (short) 1);
//        labelBlock24.setURLText("DomainOrder.ASCENDING");
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNull(paint9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(font22);
//        org.junit.Assert.assertNull(str25);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 6);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 60000L, 1.5051499783199058d, (double) 3600000L, 90.0d);
        double double10 = rectangleInsets8.calculateBottomInset((double) 1560495599999L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3600000.0d + "'", double10 == 3600000.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Pie 3D Plot");
        java.lang.String str2 = textFragment1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        polarPlot6.setRenderer(polarItemRenderer10);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = combinedDomainXYPlot4.getInsets();
        try {
            combinedDomainXYPlot4.mapDatasetToDomainAxis((int) (byte) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 86400000L, numberFormat1, 0);
        java.util.Currency currency4 = numberFormat1.getCurrency();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(currency4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("10^4.78", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleAnchor.TOP_RIGHT", image3, "", "Pie 3D Plot", "13-June-2019");
        java.lang.String str8 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10^4.78 version RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0].\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.TOP_RIGHT\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY 10^4.78:None\n10^4.78 LICENCE TERMS:\n13-June-2019" + "'", str8.equals("10^4.78 version RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0].\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.TOP_RIGHT\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY 10^4.78:None\n10^4.78 LICENCE TERMS:\n13-June-2019"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape2);
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4);
        org.jfree.chart.entity.XYItemEntity xYItemEntity10 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) timeSeriesCollection5, 1, 2958465, "", "RectangleEdge.BOTTOM");
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = logAxis13.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        org.jfree.data.Range range20 = timeSeriesCollection5.getDomainBounds(list18, true);
        org.jfree.data.time.TimeSeries timeSeries21 = null;
        try {
            timeSeriesCollection5.removeSeries(timeSeries21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, rectangleAnchor9, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) numberAxis3D13);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D17 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        barRenderer3D17.setBaseLegendTextPaint((java.awt.Paint) color18);
        java.awt.Shape shape20 = null;
        barRenderer3D17.setBaseLegendShape(shape20);
        java.awt.Paint paint23 = barRenderer3D17.getSeriesPaint((int) '4');
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D17.setBaseFillPaint((java.awt.Paint) color24, false);
        int int27 = color24.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color24);
        numberAxis3D4.setRightArrow(shape12);
        double double30 = numberAxis3D4.getFixedAutoRange();
        numberAxis3D4.setPositiveArrowVisible(true);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getAxisOffset();
        double double7 = rectangleInsets5.calculateBottomOutset((double) 1);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets5.createAdjustedRectangle(rectangle2D8, lengthAdjustmentType9, lengthAdjustmentType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        int int6 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        jFreeChart4.handleClick((int) (short) 0, 9, chartRenderingInfo11);
        try {
            org.jfree.chart.title.Title title14 = jFreeChart4.getSubtitle(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Font font14 = barRenderer3D2.getLegendTextFont(255);
        org.jfree.chart.renderer.category.BarPainter barPainter15 = barRenderer3D2.getBarPainter();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = barRenderer3D2.getPlot();
        int int17 = barRenderer3D2.getRowCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertNotNull(barPainter15);
        org.junit.Assert.assertNull(categoryPlot16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit0.valueToString((double) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        java.util.TimeZone timeZone6 = null;
        try {
            java.util.Date date7 = dateTickUnit0.addToDate(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = barRenderer3D4.getDrawingSupplier();
        java.awt.Stroke stroke20 = null;
        barRenderer3D4.setSeriesOutlineStroke(0, stroke20, false);
        double[] doubleArray29 = new double[] { (short) 100, 6 };
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset31, true);
        boolean boolean34 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset31);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset31);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        categoryAxis37.setUpperMargin((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double42 = barRenderer3D4.getItemMiddle((java.lang.Comparable) (-1), (java.lang.Comparable) "ERROR : Relative To String", categoryDataset31, categoryAxis37, rectangle2D40, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0.0d + "'", number35.equals(0.0d));
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 9, (float) (byte) 10, textAnchor5, (double) 13, textAnchor8);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNull(shape9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font10 = barRenderer3D2.getLegendTextFont((int) (short) 100);
        barRenderer3D2.setIncludeBaseInRange(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer3D2.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
        xYAreaRenderer16.setLegendItemURLGenerator(xYSeriesLabelGenerator17);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYAreaRenderer16.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem25 = xYAreaRenderer16.getLegendItem((int) '#', (int) (byte) 1);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.time.TimeSeries timeSeries29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeSeries29, timeZone30);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection31, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, polarItemRenderer34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState37 = xYAreaRenderer16.initialise(graphics2D26, rectangle2D27, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot28, (org.jfree.data.xy.XYDataset) timeSeriesCollection31, plotRenderingInfo36);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = xYAreaRenderer16.getBaseNegativeItemLabelPosition();
        barRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition38);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(xYItemRendererState37);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRange(false);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D0.setTickLabelFont(font3);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 0.0f, 0.0d, (double) 10, 0.2d, font9);
        numberAxis3D0.setUpperMargin((double) 432000000L);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.BOTTOM", graphics2D1, (float) 3600000L, (float) 2019, 1.0d, (float) 1560409200000L, (float) (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.lang.String str7 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) date6);
        try {
            java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) str7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("10^4.78", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleAnchor.TOP_RIGHT", image3, "", "Pie 3D Plot", "13-June-2019");
        java.awt.Image image8 = projectInfo7.getLogo();
        projectInfo7.setName("");
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        double double7 = barRenderer3D2.getMinimumBarLength();
        java.awt.Shape shape11 = barRenderer3D2.getItemShape((int) (byte) 1, (int) 'a', false);
        java.awt.Paint paint13 = barRenderer3D2.getSeriesFillPaint(500);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.data.Range range16 = barRenderer3D2.findRangeBounds(categoryDataset14, true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("");
        boolean boolean7 = legendItem6.isShapeFilled();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color8);
        legendItem6.setFillPaint((java.awt.Paint) color8);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("-10,1,0,-19,-20,-19,-20,-19", font4, (java.awt.Paint) color8);
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        java.lang.Comparable comparable13 = categoryPlot0.getDomainCrosshairColumnKey();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(comparable13);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset9, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeWidth(range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint2.toFixedHeight((double) 6);
        double double15 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleConstraint2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint2.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(7);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        java.awt.Stroke stroke7 = categoryPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot8.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getRangeAxisEdge(255);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        categoryPlot0.setRenderers(categoryItemRendererArray13);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape1 = xYStepRenderer0.getLegendLine();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        barRenderer3D6.setBaseLegendTextPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        barRenderer3D6.setBaseLegendShape(shape9);
        java.awt.Paint paint12 = barRenderer3D6.getSeriesPaint((int) '4');
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D6.setBaseFillPaint((java.awt.Paint) color13, false);
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.Rotation rotation17 = piePlot3D1.getDirection();
        piePlot3D1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rotation17);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Shape shape9 = xYAreaRenderer0.getLegendArea();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = xYAreaRenderer0.getToolTipGenerator((int) (short) 1, (int) (byte) 0, true);
        java.awt.Font font17 = xYAreaRenderer0.getItemLabelFont(12, 500, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = xYAreaRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(xYToolTipGenerator13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(xYToolTipGenerator18);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getURLGenerator();
        java.lang.Object obj6 = piePlot3D1.clone();
        java.awt.Paint paint7 = piePlot3D1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2, timeZone3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer7);
        timeSeriesCollection4.seriesChanged(seriesChangeEvent8);
        legendItem1.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection4);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate12 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection4, true);
        double double14 = intervalXYDelegate12.getDomainLowerBound(false);
        try {
            intervalXYDelegate12.setIntervalPositionFactor((double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        logAxis1.setLabelURL("ERROR : Relative To String");
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getURLGenerator();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(7);
        pieLabelDistributor7.clear();
        piePlot3D1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord11 = pieLabelDistributor7.getPieLabelRecord(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.getAutoRangeStickyZero();
        numberAxis3D0.setAutoRangeMinimumSize(1.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot4.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace7, true);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer12.setLegendItemURLGenerator(xYSeriesLabelGenerator13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYAreaRenderer12.drawRangeMarker(graphics2D15, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot16, valueAxis17, marker18, rectangle2D19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot16.setRangeAxisLocation((int) (byte) 1, axisLocation22, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = combinedDomainXYPlot16.getInsets();
        java.lang.String str26 = rectangleInsets25.toString();
        categoryPlot4.setInsets(rectangleInsets25);
        numberAxis3D0.setLabelInsets(rectangleInsets25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = numberAxis3D0.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str26.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(tickUnitSource29);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        combinedDomainXYPlot0.setRangeGridlinePaint(paint2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(0.0d, plotRenderingInfo11, point2D12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean16 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        valueMarker15.setLabel("hi!");
        java.awt.Color color19 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        valueMarker15.setLabelOffset(rectangleInsets21);
        org.jfree.chart.util.Layer layer23 = null;
        try {
            combinedDomainXYPlot0.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker15, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) '#', (int) (byte) 1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYAreaRenderer0.setSeriesToolTipGenerator(500, xYToolTipGenerator11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = xYAreaRenderer0.getGradientTransformer();
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot4.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = combinedDomainXYPlot4.getDatasetRenderingOrder();
        java.util.List list7 = combinedDomainXYPlot4.getSubplots();
        combinedDomainXYPlot0.drawRangeTickBands(graphics2D2, rectangle2D3, list7);
        combinedDomainXYPlot0.setGap((double) 86400000L);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D(pieDataset22);
        piePlot3D23.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke26 = piePlot3D23.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator27 = piePlot3D23.getURLGenerator();
        piePlot3D23.setLabelLinksVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator30 = piePlot3D23.getLegendLabelURLGenerator();
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) piePlot3D23, "12/31/69 4:00 PM", "[size=1]");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(pieURLGenerator27);
        org.junit.Assert.assertNull(pieURLGenerator30);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape9);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11);
        org.jfree.chart.entity.XYItemEntity xYItemEntity17 = new org.jfree.chart.entity.XYItemEntity(shape9, (org.jfree.data.xy.XYDataset) timeSeriesCollection12, 1, 2958465, "", "RectangleEdge.BOTTOM");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = xYLineAndShapeRenderer2.initialise(graphics2D4, rectangle2D5, xYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection12, plotRenderingInfo18);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20, timeZone21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor24 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        boolean boolean26 = timePeriodAnchor24.equals((java.lang.Object) 0L);
        timeSeriesCollection22.setXPosition(timePeriodAnchor24);
        xYItemRendererState19.endSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection22, (int) '#', 9, 0, 15, 255);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState19);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(timePeriodAnchor24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot12.getRenderer((int) ' ');
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "10^4.78", numberArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot12.getRendererForDataset(categoryDataset18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            barRenderer3D2.drawBackground(graphics2D11, categoryPlot12, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        java.awt.Paint paint11 = barRenderer3D2.getSeriesPaint(3);
        barRenderer3D2.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer3D2.getSeriesToolTipGenerator(255);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator15);
        boolean boolean17 = barRenderer3D2.getIncludeBaseInRange();
        barRenderer3D2.setShadowXOffset((double) 0.5f);
        boolean boolean21 = barRenderer3D2.isSeriesItemLabelsVisible(12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Stroke stroke6 = xYAreaRenderer0.getItemStroke((-65281), 15, false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.updateCrosshairY((double) (short) 10);
        java.awt.geom.Point2D point2D3 = xYCrosshairState0.getAnchor();
        org.junit.Assert.assertNull(point2D3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator5);
        double double7 = piePlot3D1.getShadowYOffset();
        java.awt.Stroke stroke9 = piePlot3D1.getSectionOutlineStroke((java.lang.Comparable) Double.NaN);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("");
        boolean boolean5 = legendItem4.isShapeFilled();
        java.awt.Stroke stroke6 = null;
        legendItem4.setOutlineStroke(stroke6);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendItem4.getFillPaintTransformer();
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        boolean boolean10 = legendItemCollection2.equals((java.lang.Object) legendItem4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendGraphic21.getPadding();
        java.lang.Object obj25 = legendGraphic21.clone();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str27 = org.jfree.chart.util.PaintUtilities.colorToString(color26);
        int int28 = color26.getGreen();
        legendGraphic21.setFillPaint((java.awt.Paint) color26);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        try {
            legendGraphic21.setBounds(rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "#000080" + "'", str27.equals("#000080"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor4, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity9 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) numberAxis3D8);
        numberAxis3D8.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot13.configureDomainAxes();
        numberAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot13);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot13, "index.html");
        java.lang.Object obj18 = plotEntity17.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        int int20 = categoryPlot19.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D23 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        barRenderer3D23.setBaseLegendTextPaint((java.awt.Paint) color24);
        java.awt.Shape shape26 = null;
        barRenderer3D23.setBaseLegendShape(shape26);
        java.awt.Paint paint29 = barRenderer3D23.getSeriesPaint((int) '4');
        java.awt.Color color30 = java.awt.Color.RED;
        barRenderer3D23.setWallPaint((java.awt.Paint) color30);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        barRenderer3D23.notifyListeners(rendererChangeEvent32);
        java.awt.Font font35 = barRenderer3D23.getLegendTextFont(255);
        int int36 = categoryPlot19.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D23);
        java.awt.Color color41 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color41);
        barRenderer3D23.setWallPaint((java.awt.Paint) color41);
        boolean boolean45 = barRenderer3D23.isSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = null;
        barRenderer3D23.setSeriesNegativeItemLabelPosition(500, itemLabelPosition47);
        barRenderer3D23.setItemMargin((double) (byte) 100);
        boolean boolean51 = plotEntity17.equals((java.lang.Object) barRenderer3D23);
        org.jfree.chart.plot.Plot plot52 = plotEntity17.getPlot();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(font35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(plot52);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
//        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 1577894400001L, (int) '#', textMeasurer17);
//        java.awt.Graphics2D graphics2D19 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
//        textBlock18.draw(graphics2D19, (float) 10L, (float) 7, textBlockAnchor22);
//        java.awt.Graphics2D graphics2D24 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
//        java.awt.Shape shape31 = textBlock18.calculateBounds(graphics2D24, (float) 2958465, (float) (short) -1, textBlockAnchor27, (float) 2019, (float) ' ', (double) 1);
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator33 = null;
//        xYAreaRenderer32.setLegendItemURLGenerator(xYSeriesLabelGenerator33);
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = xYAreaRenderer32.getURLGenerator(0, 100, true);
//        org.jfree.chart.LegendItem legendItem41 = xYAreaRenderer32.getLegendItem((int) '#', (int) (byte) 1);
//        boolean boolean42 = textBlockAnchor27.equals((java.lang.Object) xYAreaRenderer32);
//        java.text.DateFormat dateFormat44 = null;
//        java.text.DateFormat dateFormat45 = null;
//        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator46 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat44, dateFormat45);
//        xYAreaRenderer32.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator46, false);
//        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape50, rectangleAnchor51, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity56 = new org.jfree.chart.entity.AxisEntity(shape54, (org.jfree.chart.axis.Axis) numberAxis3D55);
//        boolean boolean57 = standardXYToolTipGenerator46.equals((java.lang.Object) numberAxis3D55);
//        java.lang.Object obj58 = standardXYToolTipGenerator46.clone();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(textBlock18);
//        org.junit.Assert.assertNotNull(textBlockAnchor22);
//        org.junit.Assert.assertNotNull(textBlockAnchor27);
//        org.junit.Assert.assertNotNull(shape31);
//        org.junit.Assert.assertNull(xYURLGenerator38);
//        org.junit.Assert.assertNull(legendItem41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(shape50);
//        org.junit.Assert.assertNotNull(rectangleAnchor51);
//        org.junit.Assert.assertNotNull(shape54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(obj58);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.general.PieDataset pieDataset9 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
//        piePlot3D10.setStartAngle((double) (-1L));
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color16 = java.awt.Color.MAGENTA;
//        barRenderer3D15.setBaseLegendTextPaint((java.awt.Paint) color16);
//        java.awt.Shape shape18 = null;
//        barRenderer3D15.setBaseLegendShape(shape18);
//        java.awt.Paint paint21 = barRenderer3D15.getSeriesPaint((int) '4');
//        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        barRenderer3D15.setBaseFillPaint((java.awt.Paint) color22, false);
//        piePlot3D10.setLabelBackgroundPaint((java.awt.Paint) color22);
//        org.jfree.chart.util.Rotation rotation26 = piePlot3D10.getDirection();
//        int int27 = day2.compareTo((java.lang.Object) piePlot3D10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(color16);
//        org.junit.Assert.assertNull(paint21);
//        org.junit.Assert.assertNotNull(color22);
//        org.junit.Assert.assertNotNull(rotation26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0);
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        try {
            timeSeriesCollection2.removeSeries((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        polarPlot6.setAngleGridlinesVisible(false);
        polarPlot6.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesShapesVisible(6, (java.lang.Boolean) false);
        java.awt.Shape shape4 = xYLineAndShapeRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator8 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_LEFT");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2019, xYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator8);
        xYLineAndShapeRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator8);
        java.lang.Boolean boolean12 = xYLineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYAreaRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYAreaRenderer2.drawRangeMarker(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, valueAxis7, marker8, rectangle2D9);
        java.awt.Font font12 = xYAreaRenderer2.lookupLegendTextFont(6);
        boolean boolean14 = xYAreaRenderer2.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Shape shape15 = xYAreaRenderer2.getLegendArea();
        multiplePiePlot0.setLegendItemShape(shape15);
        java.lang.String str17 = multiplePiePlot0.getPlotType();
        java.lang.String str18 = multiplePiePlot0.getPlotType();
        java.awt.Paint paint19 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Multiple Pie Plot" + "'", str17.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Multiple Pie Plot" + "'", str18.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRange(false);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D0.setTickLabelFont(font3);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D0);
        java.lang.String str6 = combinedRangeXYPlot5.getPlotType();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Combined Range XYPlot" + "'", str6.equals("Combined Range XYPlot"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (byte) 0, (double) 1.0f);
        legendGraphic21.setShape(shape29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = null;
        try {
            org.jfree.chart.util.Size2D size2D33 = legendGraphic21.arrange(graphics2D31, rectangleConstraint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(stroke6);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) -1, 10.0d);
//        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter3 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
//        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter3);
//        boolean boolean5 = xYDataItem2.equals((java.lang.Object) xYBarPainter3);
//        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("");
//        boolean boolean8 = legendItem7.isShapeFilled();
//        int int9 = xYDataItem2.compareTo((java.lang.Object) legendItem7);
//        java.text.AttributedString attributedString10 = legendItem7.getAttributedLabel();
//        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        int int14 = day13.getMonth();
//        long long15 = day13.getFirstMillisecond();
//        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        int int18 = day17.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day13, (org.jfree.data.time.RegularTimePeriod) day17);
//        boolean boolean20 = periodAxis19.isAutoRange();
//        periodAxis19.setRangeWithMargins((double) (-1), (double) 1560409200000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = periodAxis19.getFirst();
//        org.jfree.data.Range range25 = periodAxis19.getDefaultAutoRange();
//        boolean boolean26 = legendItem7.equals((java.lang.Object) periodAxis19);
//        org.junit.Assert.assertNotNull(xYBarPainter3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(attributedString10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(range25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        double double10 = intervalXYDelegate9.getIntervalWidth();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) ' ');
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "10^4.78", numberArray5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation(2147483647);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        barRenderer3D6.setBaseLegendTextPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        barRenderer3D6.setBaseLegendShape(shape9);
        java.awt.Paint paint12 = barRenderer3D6.getSeriesPaint((int) '4');
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D6.setBaseFillPaint((java.awt.Paint) color13, false);
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.jfree.data.general.PieDataset pieDataset17 = piePlot3D1.getDataset();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(pieDataset17);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        java.lang.String str5 = categoryPlot0.getPlotType();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(7, layer7);
        int int9 = categoryPlot0.getCrosshairDatasetIndex();
        categoryPlot0.setRangePannable(false);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        int int1 = categoryPlot0.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color5 = java.awt.Color.MAGENTA;
//        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
//        java.awt.Shape shape7 = null;
//        barRenderer3D4.setBaseLegendShape(shape7);
//        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
//        java.awt.Color color11 = java.awt.Color.RED;
//        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
//        barRenderer3D4.notifyListeners(rendererChangeEvent13);
//        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
//        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
//        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
//        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        int int22 = day21.getMonth();
//        long long23 = day21.getFirstMillisecond();
//        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        int int26 = day25.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day25);
//        boolean boolean28 = periodAxis27.isAutoRange();
//        periodAxis27.setMinorTickMarksVisible(true);
//        java.awt.Font font31 = periodAxis27.getLabelFont();
//        double double32 = periodAxis27.getLowerBound();
//        int int33 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis27);
//        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        java.util.Date date39 = spreadsheetDate38.toDate();
//        java.lang.String str40 = categoryAxis36.getCategoryLabelToolTip((java.lang.Comparable) date39);
//        categoryPlot0.setDomainAxis((int) '#', categoryAxis36, true);
//        categoryAxis36.setUpperMargin((double) 86400000L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNull(paint10);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNull(font16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(str40);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        int int1 = categoryPlot0.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color5 = java.awt.Color.MAGENTA;
//        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
//        java.awt.Shape shape7 = null;
//        barRenderer3D4.setBaseLegendShape(shape7);
//        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
//        java.awt.Color color11 = java.awt.Color.RED;
//        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
//        barRenderer3D4.notifyListeners(rendererChangeEvent13);
//        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
//        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
//        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
//        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        int int22 = day21.getMonth();
//        long long23 = day21.getFirstMillisecond();
//        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        int int26 = day25.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day25);
//        boolean boolean28 = periodAxis27.isAutoRange();
//        periodAxis27.setMinorTickMarksVisible(true);
//        java.awt.Font font31 = periodAxis27.getLabelFont();
//        double double32 = periodAxis27.getLowerBound();
//        int int33 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis27);
//        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot0.getRangeAxisEdge(1);
//        java.awt.Stroke stroke36 = categoryPlot0.getDomainGridlineStroke();
//        categoryPlot0.setDrawSharedDomainAxis(true);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNull(paint10);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNull(font16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(rectangleEdge35);
//        org.junit.Assert.assertNotNull(stroke36);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Paint paint8 = polarPlot6.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        polarPlot6.zoomDomainAxes((double) 0, (double) 100.0f, plotRenderingInfo11, point2D12);
        polarPlot6.setRadiusGridlinesVisible(true);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange0, (double) (-9999));
        double double4 = dateRange0.getCentralValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer7.setLegendItemURLGenerator(xYSeriesLabelGenerator8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYAreaRenderer7.drawRangeMarker(graphics2D10, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot11, valueAxis12, marker13, rectangle2D14);
        java.awt.Font font17 = xYAreaRenderer7.lookupLegendTextFont(6);
        boolean boolean19 = xYAreaRenderer7.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Shape shape20 = xYAreaRenderer7.getLegendArea();
        boolean boolean21 = xYAreaRenderer7.isOutline();
        boolean boolean22 = barRenderer3D2.equals((java.lang.Object) boolean21);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = null;
        try {
            barRenderer3D2.setLegendItemLabelGenerator(categorySeriesLabelGenerator23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.toTimelineValue(100L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 644288400000L + "'", long2 == 644288400000L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) '#', (int) (byte) 1);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13, timeZone14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, polarItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYAreaRenderer0.initialise(graphics2D10, rectangle2D11, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot12, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo20);
        try {
            int int23 = timeSeriesCollection15.getItemCount((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        boolean boolean16 = textTitle14.equals((java.lang.Object) "TimePeriodAnchor.MIDDLE");
//        java.awt.Color color17 = java.awt.Color.WHITE;
//        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
//        java.awt.Paint paint19 = blockBorder18.getPaint();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot20.getPieChart();
//        jFreeChart21.fireChartChanged();
//        int int23 = jFreeChart21.getSubtitleCount();
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint19, jFreeChart21);
//        org.jfree.chart.event.ChartProgressListener chartProgressListener25 = null;
//        jFreeChart21.addProgressListener(chartProgressListener25);
//        java.lang.Object obj27 = jFreeChart21.getTextAntiAlias();
//        textTitle14.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart21);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNotNull(jFreeChart21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNull(obj27);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test371");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        long long13 = day11.getFirstMillisecond();
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day15);
//        periodAxis8.setLast((org.jfree.data.time.RegularTimePeriod) day11);
//        periodAxis8.setFixedAutoRange(1.0E-5d);
//        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        int int24 = day23.getMonth();
//        long long25 = day23.getFirstMillisecond();
//        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        int int28 = day27.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.general.PieDataset pieDataset30 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D31 = new org.jfree.chart.plot.PiePlot3D(pieDataset30);
//        piePlot3D31.setStartAngle((double) (-1L));
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D36 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color37 = java.awt.Color.MAGENTA;
//        barRenderer3D36.setBaseLegendTextPaint((java.awt.Paint) color37);
//        java.awt.Shape shape39 = null;
//        barRenderer3D36.setBaseLegendShape(shape39);
//        java.awt.Paint paint42 = barRenderer3D36.getSeriesPaint((int) '4');
//        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        barRenderer3D36.setBaseFillPaint((java.awt.Paint) color43, false);
//        piePlot3D31.setBaseSectionPaint((java.awt.Paint) color43);
//        boolean boolean47 = day27.equals((java.lang.Object) color43);
//        periodAxis8.setFirst((org.jfree.data.time.RegularTimePeriod) day27);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(color37);
//        org.junit.Assert.assertNull(paint42);
//        org.junit.Assert.assertNotNull(color43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Paint paint14 = barRenderer3D2.getSeriesItemLabelPaint((int) 'a');
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, rectangleAnchor17, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity22 = new org.jfree.chart.entity.AxisEntity(shape20, (org.jfree.chart.axis.Axis) numberAxis3D21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D21.setTickMarkStroke(stroke23);
        barRenderer3D2.setBaseOutlineStroke(stroke23);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2, timeZone3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer7);
        timeSeriesCollection4.seriesChanged(seriesChangeEvent8);
        legendItem1.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection4);
        java.awt.Paint paint11 = legendItem1.getLabelPaint();
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer4 = null;
        categoryPlot0.addRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker3, layer4, false);
        categoryPlot0.setRangeGridlinesVisible(false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 13, (double) 5, (double) 1560452399999L, (double) 7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot3.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot3.getRangeGridlinePaint();
        boolean boolean9 = combinedDomainXYPlot0.equals((java.lang.Object) categoryPlot3);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer12 = null;
        combinedDomainXYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker11, layer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = new org.jfree.chart.axis.AxisSpace();
        java.lang.Object obj15 = axisSpace14.clone();
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace14, true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.getAutoRangeStickyZero();
        numberAxis3D0.setAutoRangeMinimumSize(1.0d);
        boolean boolean4 = numberAxis3D0.getAutoRangeStickyZero();
        numberAxis3D0.setFixedAutoRange((double) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.awt.Color color3 = java.awt.Color.getHSBColor(100.0f, (float) (byte) -1, (float) 0L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        double double9 = timeSeriesCollection2.getDomainUpperBound(false);
        try {
            double double12 = timeSeriesCollection2.getXValue(2147483647, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor4, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity9 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) numberAxis3D8);
        numberAxis3D8.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot13.configureDomainAxes();
        numberAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot13);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot13, "index.html");
        java.lang.Object obj18 = plotEntity17.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        int int20 = categoryPlot19.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D23 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        barRenderer3D23.setBaseLegendTextPaint((java.awt.Paint) color24);
        java.awt.Shape shape26 = null;
        barRenderer3D23.setBaseLegendShape(shape26);
        java.awt.Paint paint29 = barRenderer3D23.getSeriesPaint((int) '4');
        java.awt.Color color30 = java.awt.Color.RED;
        barRenderer3D23.setWallPaint((java.awt.Paint) color30);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        barRenderer3D23.notifyListeners(rendererChangeEvent32);
        java.awt.Font font35 = barRenderer3D23.getLegendTextFont(255);
        int int36 = categoryPlot19.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D23);
        java.awt.Color color41 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color41);
        barRenderer3D23.setWallPaint((java.awt.Paint) color41);
        boolean boolean45 = barRenderer3D23.isSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = null;
        barRenderer3D23.setSeriesNegativeItemLabelPosition(500, itemLabelPosition47);
        barRenderer3D23.setItemMargin((double) (byte) 100);
        boolean boolean51 = plotEntity17.equals((java.lang.Object) barRenderer3D23);
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 255, (float) ' ');
        barRenderer3D23.setSeriesShape(5, shape55, true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(font35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape55);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D(pieDataset14);
        piePlot3D15.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D20 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color21 = java.awt.Color.MAGENTA;
        barRenderer3D20.setBaseLegendTextPaint((java.awt.Paint) color21);
        java.awt.Shape shape23 = null;
        barRenderer3D20.setBaseLegendShape(shape23);
        java.awt.Paint paint26 = barRenderer3D20.getSeriesPaint((int) '4');
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D20.setBaseFillPaint((java.awt.Paint) color27, false);
        piePlot3D15.setBaseSectionPaint((java.awt.Paint) color27);
        xYPlot13.setDomainMinorGridlinePaint((java.awt.Paint) color27);
        combinedDomainXYPlot4.add(xYPlot13);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis();
        double double20 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator25 = null;
        xYAreaRenderer24.setLegendItemURLGenerator(xYSeriesLabelGenerator25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        xYAreaRenderer24.drawRangeMarker(graphics2D27, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot28, valueAxis29, marker30, rectangle2D31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot28.setRangeAxisLocation((int) (byte) 1, axisLocation34, false);
        float float37 = combinedDomainXYPlot28.getBackgroundAlpha();
        boolean boolean38 = combinedDomainXYPlot28.isDomainCrosshairVisible();
        combinedDomainXYPlot28.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot41 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        multiplePiePlot41.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier42);
        combinedDomainXYPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier42, true);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier42);
        java.lang.Object obj47 = defaultDrawingSupplier42.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((double) 7, plotRenderingInfo6, point2D7, true);
        java.awt.Paint paint10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = null;
        try {
            categoryPlot0.setInsets(rectangleInsets12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        basicProjectInfo5.setCopyright("Pie 3D Plot");
        java.lang.String str9 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie 3D Plot" + "'", str9.equals("Pie 3D Plot"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = xYSeries2.equals((java.lang.Object) categoryPlot3);
        java.lang.String str5 = xYSeries2.getDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYAreaRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYAreaRenderer2.drawRangeMarker(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, valueAxis7, marker8, rectangle2D9);
        java.awt.Shape shape11 = xYAreaRenderer2.getLegendArea();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape11, "SerialDate.weekInMonthToString(): invalid code.", "");
        org.jfree.chart.axis.Axis axis15 = axisLabelEntity14.getAxis();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axis15);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray9, numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-10,1,0,-19,-20,-19,-20,-19", "hi!", numberArray22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("10^-∞", "hi!", numberArray22);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(categoryDataset24);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setSeriesItemLabelGenerator(6, categoryItemLabelGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer3D2.setSeriesItemLabelGenerator(15, categoryItemLabelGenerator16, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("TextAnchor.TOP_LEFT");
        numberAxis3D1.setAutoRangeMinimumSize((double) 7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setStartAngle((double) (-1L));
        double double4 = piePlot3D1.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        java.util.Iterator iterator3 = legendItemCollection2.iterator();
        int int4 = legendItemCollection2.getItemCount();
        org.jfree.chart.LegendItem legendItem5 = null;
        legendItemCollection2.add(legendItem5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        java.lang.Boolean boolean12 = xYAreaRenderer0.getSeriesVisible(0);
        xYAreaRenderer0.setOutline(true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendGraphic21.getPadding();
        double double26 = rectangleInsets24.calculateTopInset(10.0d);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity34 = new org.jfree.chart.entity.AxisEntity(shape32, (org.jfree.chart.axis.Axis) numberAxis3D33);
        numberAxis3D33.setTickLabelsVisible(false);
        java.awt.Color color37 = java.awt.Color.MAGENTA;
        numberAxis3D33.setTickLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder(rectangleInsets24, (java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit0.valueToString((double) (short) 0);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit0.getRollUnitType();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(dateTickUnitType3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot0.getDomainAxis();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 100, 0);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot0.getDomainMarkers((int) (byte) 10, layer23);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNull(collection24);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test402");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, rectangleAnchor13, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape16, (org.jfree.chart.axis.Axis) numberAxis3D17);
//        numberAxis3D17.setTickLabelsVisible(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = numberAxis3D17.getStandardTickUnits();
//        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) periodAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer24);
//        periodAxis9.setPositiveArrowVisible(false);
//        org.jfree.data.Range range28 = periodAxis9.getRange();
//        periodAxis9.resizeRange((double) 0.0f, (double) 60000L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(shape12);
//        org.junit.Assert.assertNotNull(rectangleAnchor13);
//        org.junit.Assert.assertNotNull(shape16);
//        org.junit.Assert.assertNotNull(tickUnitSource21);
//        org.junit.Assert.assertNotNull(range28);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 12, "index.html", textAnchor3, textAnchor5, (double) 'a');
        org.jfree.chart.axis.TickType tickType8 = numberTick7.getTickType();
        java.lang.String str9 = numberTick7.toString();
        java.lang.Object obj10 = numberTick7.clone();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str4.equals("TextAnchor.TOP_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(tickType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "index.html" + "'", str9.equals("index.html"));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.TOP_RIGHT");
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape9);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11);
        org.jfree.chart.entity.XYItemEntity xYItemEntity17 = new org.jfree.chart.entity.XYItemEntity(shape9, (org.jfree.data.xy.XYDataset) timeSeriesCollection12, 1, 2958465, "", "RectangleEdge.BOTTOM");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = xYLineAndShapeRenderer2.initialise(graphics2D4, rectangle2D5, xYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection12, plotRenderingInfo18);
        xYLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState19);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str2 = verticalAlignment1.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (-65281), (double) 1577894400001L);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.CENTER" + "'", str2.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D1.getLegendLabelGenerator();
        piePlot3D1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(Double.NaN, 0.4d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        org.jfree.data.general.PieDataset pieDataset3 = ringPlot0.getDataset();
        ringPlot0.setShadowXOffset((double) 100L);
        java.awt.Paint paint6 = ringPlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNull(pieDataset3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        double double10 = intervalXYDelegate9.getFixedIntervalWidth();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        int int6 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        jFreeChart4.handleClick((int) (short) 0, 9, chartRenderingInfo11);
        org.jfree.chart.RenderingSource renderingSource13 = chartRenderingInfo11.getRenderingSource();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            chartRenderingInfo11.setChartArea(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(renderingSource13);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_LEFT");
        xYLineAndShapeRenderer2.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        boolean boolean7 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        xYLineAndShapeRenderer2.setSeriesShapesFilled((int) 'a', false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 12, "index.html", textAnchor3, textAnchor5, (double) 'a');
        org.jfree.chart.axis.TickType tickType8 = numberTick7.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor9 = numberTick7.getTextAnchor();
        double double10 = numberTick7.getAngle();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str4.equals("TextAnchor.TOP_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(tickType8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D1.getLegendLabelGenerator();
        piePlot3D1.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        int int9 = combinedDomainXYPlot4.getWeight();
        java.awt.Paint paint10 = combinedDomainXYPlot4.getDomainTickBandPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color16 = java.awt.Color.MAGENTA;
        barRenderer3D15.setBaseLegendTextPaint((java.awt.Paint) color16);
        java.awt.Shape shape18 = null;
        barRenderer3D15.setBaseLegendShape(shape18);
        java.awt.Paint paint21 = barRenderer3D15.getSeriesPaint((int) '4');
        java.awt.Color color22 = java.awt.Color.RED;
        barRenderer3D15.setWallPaint((java.awt.Paint) color22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer3D15.notifyListeners(rendererChangeEvent24);
        java.awt.Font font27 = barRenderer3D15.getLegendTextFont(255);
        int int28 = categoryPlot11.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15);
        java.awt.Color color33 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color33);
        barRenderer3D15.setWallPaint((java.awt.Paint) color33);
        combinedDomainXYPlot4.setDomainZeroBaselinePaint((java.awt.Paint) color33);
        org.jfree.chart.axis.ValueAxis valueAxis38 = combinedDomainXYPlot4.getDomainAxisForDataset(0);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) valueAxis38);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(valueAxis38);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("10^4.78", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleAnchor.TOP_RIGHT", image3, "", "Pie 3D Plot", "13-June-2019");
        java.awt.Image image8 = projectInfo7.getLogo();
        projectInfo7.setLicenceText("10^4.78 version RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0].\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.TOP_RIGHT\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY 10^4.78:None\n10^4.78 LICENCE TERMS:\n13-June-2019");
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        java.awt.Stroke stroke3 = xYPlot1.getRangeGridlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("12/31/69 4:00 PM", (org.jfree.chart.plot.Plot) xYPlot1);
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        try {
            java.awt.image.BufferedImage bufferedImage9 = jFreeChart4.createBufferedImage((int) (short) 0, (int) (byte) 10, chartRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer8.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        xYAreaRenderer8.drawRangeMarker(graphics2D11, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot12, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot12.setRangeAxisLocation((int) (byte) 1, axisLocation18, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = combinedDomainXYPlot12.getInsets();
        java.lang.String str22 = rectangleInsets21.toString();
        categoryPlot0.setInsets(rectangleInsets21);
        double double24 = rectangleInsets21.getRight();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str22.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape13, (org.jfree.chart.axis.Axis) numberAxis3D14);
        numberAxis3D14.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range19 = polarPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D14.getTickLabelInsets();
        numberAxis3D14.setLabel("Pie 3D Plot");
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis3D14.setTickLabelFont(font23);
        numberAxis3D14.configure();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 1, 1.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) 1560495599999L, (double) 12);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test424");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
//        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 1577894400001L, (int) '#', textMeasurer17);
//        java.awt.Graphics2D graphics2D19 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
//        textBlock18.draw(graphics2D19, (float) 10L, (float) 7, textBlockAnchor22);
//        java.awt.Graphics2D graphics2D24 = null;
//        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
//        int int31 = day30.getMonth();
//        long long32 = day30.getFirstMillisecond();
//        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        int int35 = day34.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) day34);
//        boolean boolean37 = periodAxis36.isAutoRange();
//        periodAxis36.setMinorTickMarksVisible(true);
//        java.awt.Font font40 = periodAxis36.getLabelFont();
//        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer44 = null;
//        org.jfree.chart.text.TextBlock textBlock45 = org.jfree.chart.text.TextUtilities.createTextBlock("", font40, paint41, (float) 1577894400001L, (int) '#', textMeasurer44);
//        java.awt.Graphics2D graphics2D46 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor49 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
//        textBlock45.draw(graphics2D46, (float) 10L, (float) 7, textBlockAnchor49);
//        java.awt.Graphics2D graphics2D51 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor54 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
//        java.awt.Shape shape58 = textBlock45.calculateBounds(graphics2D51, (float) 2958465, (float) (short) -1, textBlockAnchor54, (float) 2019, (float) ' ', (double) 1);
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer59 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator60 = null;
//        xYAreaRenderer59.setLegendItemURLGenerator(xYSeriesLabelGenerator60);
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator65 = xYAreaRenderer59.getURLGenerator(0, 100, true);
//        org.jfree.chart.LegendItem legendItem68 = xYAreaRenderer59.getLegendItem((int) '#', (int) (byte) 1);
//        boolean boolean69 = textBlockAnchor54.equals((java.lang.Object) xYAreaRenderer59);
//        java.awt.Shape shape73 = textBlock18.calculateBounds(graphics2D24, 10.0f, (float) (-9999), textBlockAnchor54, (float) (byte) 10, (float) 1099410614137L, (double) 1099410614137L);
//        org.jfree.chart.util.HorizontalAlignment horizontalAlignment74 = null;
//        try {
//            textBlock18.setLineAlignment(horizontalAlignment74);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(textBlock18);
//        org.junit.Assert.assertNotNull(textBlockAnchor22);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(font40);
//        org.junit.Assert.assertNotNull(paint41);
//        org.junit.Assert.assertNotNull(textBlock45);
//        org.junit.Assert.assertNotNull(textBlockAnchor49);
//        org.junit.Assert.assertNotNull(textBlockAnchor54);
//        org.junit.Assert.assertNotNull(shape58);
//        org.junit.Assert.assertNull(xYURLGenerator65);
//        org.junit.Assert.assertNull(legendItem68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(shape73);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Stroke stroke3 = null;
        legendItem1.setOutlineStroke(stroke3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem1.getFillPaintTransformer();
        java.awt.Paint paint6 = legendItem1.getOutlinePaint();
        legendItem1.setToolTipText("RectangleEdge.BOTTOM");
        legendItem1.setDescription("RectangleEdge.BOTTOM");
        int int11 = legendItem1.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        java.awt.Stroke stroke7 = categoryPlot0.getDomainCrosshairStroke();
        double[] doubleArray12 = new double[] { (short) 100, 6 };
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset14, true);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset14);
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset14);
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        java.util.List list25 = logAxis20.refreshTicks(graphics2D21, axisState22, rectangle2D23, rectangleEdge24);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, list25, true);
        categoryPlot0.setDataset(categoryDataset14);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot3.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot3.getRangeGridlinePaint();
        boolean boolean9 = combinedDomainXYPlot0.equals((java.lang.Object) categoryPlot3);
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10, timeZone11);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer15);
        java.awt.Paint paint17 = polarPlot16.getAngleLabelPaint();
        java.awt.Paint paint18 = polarPlot16.getRadiusGridlinePaint();
        java.awt.Paint paint19 = polarPlot16.getAngleLabelPaint();
        java.awt.Font font20 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        polarPlot16.setAngleLabelFont(font20);
        categoryPlot3.setNoDataMessageFont(font20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        categoryPlot3.notifyListeners(plotChangeEvent23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        int int26 = categoryPlot25.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D29 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color30 = java.awt.Color.MAGENTA;
        barRenderer3D29.setBaseLegendTextPaint((java.awt.Paint) color30);
        java.awt.Shape shape32 = null;
        barRenderer3D29.setBaseLegendShape(shape32);
        java.awt.Paint paint35 = barRenderer3D29.getSeriesPaint((int) '4');
        java.awt.Color color36 = java.awt.Color.RED;
        barRenderer3D29.setWallPaint((java.awt.Paint) color36);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        barRenderer3D29.notifyListeners(rendererChangeEvent38);
        java.awt.Font font41 = barRenderer3D29.getLegendTextFont(255);
        int int42 = categoryPlot25.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D29);
        java.awt.Stroke stroke43 = categoryPlot25.getRangeCrosshairStroke();
        categoryPlot3.setRangeGridlineStroke(stroke43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(font41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setSeriesItemLabelGenerator(6, categoryItemLabelGenerator13);
        barRenderer3D2.setBaseSeriesVisible(true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) true, (java.lang.Object) stroke17);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        categoryPlot0.clearAnnotations();
        java.awt.Paint paint19 = categoryPlot0.getDomainCrosshairPaint();
        int int20 = categoryPlot0.getDatasetCount();
        java.util.List list21 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        int int24 = categoryPlot23.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D27 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color28 = java.awt.Color.MAGENTA;
        barRenderer3D27.setBaseLegendTextPaint((java.awt.Paint) color28);
        java.awt.Shape shape30 = null;
        barRenderer3D27.setBaseLegendShape(shape30);
        java.awt.Paint paint33 = barRenderer3D27.getSeriesPaint((int) '4');
        java.awt.Color color34 = java.awt.Color.RED;
        barRenderer3D27.setWallPaint((java.awt.Paint) color34);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent36 = null;
        barRenderer3D27.notifyListeners(rendererChangeEvent36);
        java.awt.Font font39 = barRenderer3D27.getLegendTextFont(255);
        int int40 = categoryPlot23.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D27);
        categoryPlot23.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        categoryAxis43.setUpperMargin((double) (short) 0);
        categoryPlot23.setDomainAxis(categoryAxis43);
        categoryPlot0.setDomainAxis((int) (byte) 10, categoryAxis43);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(font39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Object obj1 = defaultPieDataset0.clone();
        java.lang.Object obj2 = defaultPieDataset0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot3.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot3.getRangeAxisEdge(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot3.zoomRangeAxes((double) 7, plotRenderingInfo9, point2D10, true);
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot3.setRangeZeroBaselinePaint(paint13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot3.getRowRenderingOrder();
        defaultPieDataset0.sortByKeys(sortOrder15);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        java.lang.String str8 = axisEntity7.getShapeCoords();
        java.lang.String str9 = axisEntity7.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-10,1,0,-19,-20,-19,-20,-19" + "'", str8.equals("-10,1,0,-19,-20,-19,-20,-19"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AxisEntity: tooltip = null" + "'", str9.equals("AxisEntity: tooltip = null"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYAreaRenderer0.getBaseToolTipGenerator();
        boolean boolean8 = xYAreaRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        double double7 = barRenderer3D2.getMinimumBarLength();
        java.awt.Shape shape11 = barRenderer3D2.getItemShape((int) (byte) 1, (int) 'a', false);
        double double12 = barRenderer3D2.getYOffset();
        double double13 = barRenderer3D2.getShadowYOffset();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        legendGraphic21.setWidth((double) (short) 100);
        java.lang.String str26 = legendGraphic21.getID();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = legendGraphic21.getShapeLocation();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        int int15 = categoryPlot14.getCrosshairDatasetIndex();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getDomainMarkers(layer16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        logAxis19.pan((double) 2);
        logAxis19.setTickLabelsVisible(true);
        logAxis19.zoomRange((double) (byte) 0, (double) 2);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer3D2.drawRangeLine(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) logAxis19, rectangle2D27, 0.0d, (java.awt.Paint) color29, stroke30);
        java.text.NumberFormat numberFormat32 = java.text.NumberFormat.getNumberInstance();
        java.math.RoundingMode roundingMode33 = numberFormat32.getRoundingMode();
        logAxis19.setNumberFormatOverride(numberFormat32);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(numberFormat32);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode33.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle3 = null;
        jFreeChart1.setTitle(textTitle3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot9.setRangeAxisLocation((int) (byte) 1, axisLocation15, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedDomainXYPlot9.getInsets();
        java.lang.String str19 = rectangleInsets18.toString();
        jFreeChart1.setPadding(rectangleInsets18);
        java.awt.Paint paint21 = null;
        jFreeChart1.setBorderPaint(paint21);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str19.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color3);
        legendItem1.setFillPaint((java.awt.Paint) color3);
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer11);
        java.awt.Paint paint13 = polarPlot12.getAngleLabelPaint();
        legendItem1.setFillPaint(paint13);
        java.awt.Paint paint15 = legendItem1.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("Category Plot", regularTimePeriod3, (org.jfree.data.time.RegularTimePeriod) day6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test443");
//        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 1, 1.0f);
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        int int9 = day8.getMonth();
//        long long10 = day8.getFirstMillisecond();
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        int int13 = day12.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day12);
//        boolean boolean15 = periodAxis14.isAutoRange();
//        periodAxis14.setMinorTickMarksVisible(true);
//        java.awt.Font font18 = periodAxis14.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font18);
//        boolean boolean21 = textTitle19.equals((java.lang.Object) "TimePeriodAnchor.MIDDLE");
//        textTitle19.visible = false;
//        org.jfree.chart.entity.TitleEntity titleEntity25 = new org.jfree.chart.entity.TitleEntity(shape4, (org.jfree.chart.title.Title) textTitle19, "");
//        org.jfree.chart.entity.TitleEntity titleEntity27 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle19, "DomainOrder.ASCENDING");
//        java.awt.Graphics2D graphics2D28 = null;
//        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.data.time.TimeSeries timeSeries32 = null;
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection(timeSeries32, timeZone33);
//        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection34);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection34, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, polarItemRenderer37);
//        java.awt.Font font39 = polarPlot38.getAngleLabelFont();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        polarPlot38.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit40);
//        polarPlot38.setAngleGridlinesVisible(false);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
//        java.awt.geom.Point2D point2D48 = null;
//        polarPlot38.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo47, point2D48);
//        java.awt.geom.Point2D point2D50 = null;
//        xYPlot29.zoomRangeAxes((double) (-1.0f), 0.0d, plotRenderingInfo47, point2D50);
//        java.awt.geom.Rectangle2D rectangle2D52 = plotRenderingInfo47.getDataArea();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D55 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color56 = java.awt.Color.MAGENTA;
//        barRenderer3D55.setBaseLegendTextPaint((java.awt.Paint) color56);
//        java.awt.Shape shape58 = null;
//        barRenderer3D55.setBaseLegendShape(shape58);
//        java.awt.Paint paint61 = barRenderer3D55.getSeriesPaint((int) '4');
//        java.awt.Font font62 = barRenderer3D55.getBaseLegendTextFont();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition63 = barRenderer3D55.getPositiveItemLabelPositionFallback();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition64 = barRenderer3D55.getBasePositiveItemLabelPosition();
//        java.lang.Object obj65 = textTitle19.draw(graphics2D28, rectangle2D52, (java.lang.Object) itemLabelPosition64);
//        org.junit.Assert.assertNotNull(shape1);
//        org.junit.Assert.assertNotNull(shape4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(font18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(range35);
//        org.junit.Assert.assertNotNull(font39);
//        org.junit.Assert.assertNotNull(dateTickUnit40);
//        org.junit.Assert.assertNotNull(rectangle2D52);
//        org.junit.Assert.assertNotNull(color56);
//        org.junit.Assert.assertNull(paint61);
//        org.junit.Assert.assertNull(font62);
//        org.junit.Assert.assertNull(itemLabelPosition63);
//        org.junit.Assert.assertNotNull(itemLabelPosition64);
//        org.junit.Assert.assertNull(obj65);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test444");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        periodAxis8.setNegativeArrowVisible(false);
//        periodAxis8.setPositiveArrowVisible(false);
//        float float13 = periodAxis8.getMinorTickMarkInsideLength();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.setFixedAutoRange((double) (byte) 100);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat();
        logFormat10.setMinimumFractionDigits(100);
        numberAxis3D6.setNumberFormatOverride((java.text.NumberFormat) logFormat10);
        logFormat10.setMinimumIntegerDigits((int) (short) -1);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test446");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        periodAxis8.setMinorTickMarksVisible(true);
//        java.awt.Font font12 = periodAxis8.getLabelFont();
//        double double13 = periodAxis8.getLowerBound();
//        java.awt.Stroke stroke14 = periodAxis8.getAxisLineStroke();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(font12);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertNotNull(stroke14);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
        java.lang.String str16 = combinedDomainXYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = null;
        xYAreaRenderer18.setLegendItemURLGenerator(xYSeriesLabelGenerator19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYAreaRenderer18.drawRangeMarker(graphics2D21, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot22, valueAxis23, marker24, rectangle2D25);
        xYAreaRenderer18.setBaseCreateEntities(false);
        combinedDomainXYPlot4.setRenderer(500, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot4.setRangeAxisLocation(13, axisLocation31);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Combined_Domain_XYPlot" + "'", str16.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation31);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test448");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        boolean boolean16 = textTitle14.equals((java.lang.Object) "TimePeriodAnchor.MIDDLE");
//        textTitle14.visible = false;
//        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
//        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
//        java.lang.String str21 = verticalAlignment20.toString();
//        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment19, verticalAlignment20, (double) 1577894400001L, (double) 1099410614137L);
//        textTitle14.setTextAlignment(horizontalAlignment19);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(horizontalAlignment19);
//        org.junit.Assert.assertNotNull(verticalAlignment20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "VerticalAlignment.CENTER" + "'", str21.equals("VerticalAlignment.CENTER"));
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        double double1 = xYStepAreaRenderer0.getRangeBase();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean5 = xYLineAndShapeRenderer4.getDrawSeriesLineAsPath();
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("");
        boolean boolean8 = legendItem7.isShapeFilled();
        java.awt.Stroke stroke9 = null;
        legendItem7.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = null;
        legendItem7.setOutlineStroke(stroke11);
        boolean boolean13 = xYLineAndShapeRenderer4.equals((java.lang.Object) stroke11);
        xYLineAndShapeRenderer4.setSeriesLinesVisible(9, false);
        boolean boolean17 = xYStepAreaRenderer0.equals((java.lang.Object) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Paint paint14 = barRenderer3D2.getSeriesItemLabelPaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = barRenderer3D2.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            month0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day1, (double) 5);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("Category Plot");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor4, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity9 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) numberAxis3D8);
        numberAxis3D8.setFixedAutoRange((double) (byte) 100);
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat();
        logFormat12.setMinimumFractionDigits(100);
        numberAxis3D8.setNumberFormatOverride((java.text.NumberFormat) logFormat12);
        boolean boolean16 = datasetGroup1.equals((java.lang.Object) numberAxis3D8);
        java.lang.Object obj17 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.updateCrosshairY((double) (short) 10, 64);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.data.time.TimeSeries timeSeries22 = null;
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeSeries22, timeZone23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, polarItemRenderer27);
        java.awt.Paint paint29 = polarPlot28.getAngleLabelPaint();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape31, rectangleAnchor32, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity37 = new org.jfree.chart.entity.AxisEntity(shape35, (org.jfree.chart.axis.Axis) numberAxis3D36);
        numberAxis3D36.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range41 = polarPlot28.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D36);
        org.jfree.chart.entity.AxisEntity axisEntity43 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D36, "Pie 3D Plot");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = numberAxis3D36.getMarkerBand();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNull(markerAxisBand44);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) '#', (int) (byte) 1);
        boolean boolean10 = xYAreaRenderer0.getUseFillPaint();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYAreaRenderer0.setBaseItemLabelFont(font11);
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        java.awt.Color color2 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        java.awt.Paint paint4 = blockBorder3.getPaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint4);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot0.setRangeTickBandPaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = combinedDomainXYPlot0.getRangeAxisEdge();
        boolean boolean7 = combinedDomainXYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 60000L);
        double double3 = dateRange2.getLowerBound();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, (double) 100.0f, true);
        java.util.Date date8 = dateRange4.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) 1099410614137L);
        boolean boolean16 = dateRange4.intersects(8.64E7d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        int int6 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
        jFreeChart4.setTitle("ERROR : Relative To String");
        boolean boolean10 = jFreeChart4.isNotify();
        org.jfree.chart.plot.Plot plot11 = jFreeChart4.getPlot();
        java.awt.Stroke stroke12 = jFreeChart4.getBorderStroke();
        jFreeChart4.setBackgroundImageAlignment(12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        categoryAxis1.setMaximumCategoryLabelLines(9);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test464");
//        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//        java.awt.Stroke stroke2 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(0);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.XYPlot xYPlot4 = null;
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        long long9 = day7.getFirstMillisecond();
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day7, (org.jfree.data.time.RegularTimePeriod) day11);
//        periodAxis13.configure();
//        java.awt.geom.Rectangle2D rectangle2D15 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot17.getDomainAxis(10);
//        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
//        categoryPlot17.setFixedRangeAxisSpace(axisSpace20);
//        java.awt.Paint paint22 = categoryPlot17.getRangeGridlinePaint();
//        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, rectangleAnchor25, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape28, (org.jfree.chart.axis.Axis) numberAxis3D29);
//        numberAxis3D29.zoomRange(0.0d, 0.0d);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot34.configureDomainAxes();
//        numberAxis3D29.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot34);
//        org.jfree.chart.plot.PlotOrientation plotOrientation37 = combinedDomainXYPlot34.getOrientation();
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer38 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator39 = null;
//        xYAreaRenderer38.setLegendItemURLGenerator(xYSeriesLabelGenerator39);
//        java.awt.Graphics2D graphics2D41 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
//        org.jfree.chart.plot.Marker marker44 = null;
//        java.awt.geom.Rectangle2D rectangle2D45 = null;
//        xYAreaRenderer38.drawRangeMarker(graphics2D41, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot42, valueAxis43, marker44, rectangle2D45);
//        java.awt.Font font48 = xYAreaRenderer38.lookupLegendTextFont(6);
//        int int49 = xYAreaRenderer38.getPassCount();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator50 = xYAreaRenderer38.getLegendItemLabelGenerator();
//        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape52, rectangleAnchor53, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity58 = new org.jfree.chart.entity.AxisEntity(shape56, (org.jfree.chart.axis.Axis) numberAxis3D57);
//        java.awt.Stroke stroke59 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis3D57.setTickMarkStroke(stroke59);
//        xYAreaRenderer38.setBaseStroke(stroke59);
//        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape64, rectangleAnchor65, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D69 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity70 = new org.jfree.chart.entity.AxisEntity(shape68, (org.jfree.chart.axis.Axis) numberAxis3D69);
//        java.awt.Stroke stroke71 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis3D69.setTickMarkStroke(stroke71);
//        xYAreaRenderer38.setSeriesStroke(0, stroke71, false);
//        combinedDomainXYPlot34.setDomainZeroBaselineStroke(stroke71);
//        xYStepAreaRenderer0.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis13, rectangle2D15, (double) 35L, paint22, stroke71);
//        periodAxis13.setVerticalTickLabels(true);
//        java.awt.Paint paint79 = periodAxis13.getTickLabelPaint();
//        java.lang.String str80 = periodAxis13.getLabel();
//        org.junit.Assert.assertNotNull(stroke2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNull(categoryAxis19);
//        org.junit.Assert.assertNotNull(paint22);
//        org.junit.Assert.assertNotNull(shape24);
//        org.junit.Assert.assertNotNull(rectangleAnchor25);
//        org.junit.Assert.assertNotNull(shape28);
//        org.junit.Assert.assertNotNull(plotOrientation37);
//        org.junit.Assert.assertNull(font48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator50);
//        org.junit.Assert.assertNotNull(shape52);
//        org.junit.Assert.assertNotNull(rectangleAnchor53);
//        org.junit.Assert.assertNotNull(shape56);
//        org.junit.Assert.assertNotNull(stroke59);
//        org.junit.Assert.assertNotNull(shape64);
//        org.junit.Assert.assertNotNull(rectangleAnchor65);
//        org.junit.Assert.assertNotNull(shape68);
//        org.junit.Assert.assertNotNull(stroke71);
//        org.junit.Assert.assertNotNull(paint79);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "" + "'", str80.equals(""));
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (byte) -1, (double) (byte) 100);
        java.lang.Object obj3 = size2D2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test466");
//        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
//        java.lang.Object obj1 = defaultPieDataset0.clone();
//        java.lang.Object obj2 = defaultPieDataset0.clone();
//        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        int int6 = day5.getMonth();
//        long long7 = day5.getFirstMillisecond();
//        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        int int10 = day9.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day9);
//        try {
//            defaultPieDataset0.remove((java.lang.Comparable) day9);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (13-June-2019) is not recognised.");
//        } catch (org.jfree.data.UnknownKeyException e) {
//        }
//        org.junit.Assert.assertNotNull(obj1);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedDomainXYPlot0.getRangeAxisLocation((int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot0.getRangeAxis((int) (short) 0);
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        piePlot3D11.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke14 = piePlot3D11.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        piePlot3D11.setURLGenerator(pieURLGenerator15);
        boolean boolean17 = piePlot3D11.getAutoPopulateSectionOutlineStroke();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int19 = color18.getBlue();
        piePlot3D11.setLabelOutlinePaint((java.awt.Paint) color18);
        boolean boolean21 = textFragment9.equals((java.lang.Object) color18);
        combinedDomainXYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        try {
            double double10 = timeSeriesCollection2.getXValue(6, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Font font14 = barRenderer3D2.getLegendTextFont(255);
        org.jfree.chart.renderer.category.BarPainter barPainter15 = barRenderer3D2.getBarPainter();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = barRenderer3D2.getPlot();
        barRenderer3D2.setShadowVisible(true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertNotNull(barPainter15);
        org.junit.Assert.assertNull(categoryPlot16);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        double double4 = ringPlot3.getSectionDepth();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9, timeZone10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, polarItemRenderer14);
        java.awt.Font font16 = polarPlot15.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot15.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit17);
        polarPlot15.setAngleGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Point2D point2D25 = null;
        polarPlot15.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo24, point2D25);
        java.awt.geom.Point2D point2D27 = null;
        xYPlot6.zoomRangeAxes((double) (-1.0f), 0.0d, plotRenderingInfo24, point2D27);
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo24.getDataArea();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D31 = new org.jfree.chart.plot.PiePlot3D(pieDataset30);
        piePlot3D31.setStartAngle((double) (-1L));
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        boolean boolean35 = piePlot3D31.equals((java.lang.Object) ringPlot34);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer37 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator38 = null;
        xYAreaRenderer37.setLegendItemURLGenerator(xYSeriesLabelGenerator38);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot41 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.Marker marker43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        xYAreaRenderer37.drawRangeMarker(graphics2D40, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot41, valueAxis42, marker43, rectangle2D44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = combinedDomainXYPlot41.getLegendItems();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        java.awt.geom.Point2D point2D50 = null;
        combinedDomainXYPlot41.zoomDomainAxes((double) 432000000L, plotRenderingInfo49, point2D50);
        org.jfree.chart.plot.PiePlotState piePlotState52 = ringPlot3.initialise(graphics2D5, rectangle2D29, (org.jfree.chart.plot.PiePlot) ringPlot34, (java.lang.Integer) 10, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer53 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator54 = null;
        xYAreaRenderer53.setLegendItemURLGenerator(xYSeriesLabelGenerator54);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot57 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.Marker marker59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        xYAreaRenderer53.drawRangeMarker(graphics2D56, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot57, valueAxis58, marker59, rectangle2D60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot57.setRangeAxisLocation((int) (byte) 1, axisLocation63, false);
        float float66 = combinedDomainXYPlot57.getBackgroundAlpha();
        combinedDomainXYPlot57.setDomainMinorGridlinesVisible(true);
        java.lang.String str69 = combinedDomainXYPlot57.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection70 = combinedDomainXYPlot57.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = combinedDomainXYPlot57.getRangeAxisEdge(0);
        try {
            java.util.List list73 = dateAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D29, rectangleEdge72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(piePlotState52);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 1.0f + "'", float66 == 1.0f);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Combined_Domain_XYPlot" + "'", str69.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(legendItemCollection70);
        org.junit.Assert.assertNotNull(rectangleEdge72);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        int int6 = spreadsheetDate4.toSerial();
        boolean boolean7 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean8 = axisSpace0.equals((java.lang.Object) spreadsheetDate4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test472");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        periodAxis8.setNegativeArrowVisible(false);
//        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        int int14 = day13.getMonth();
//        long long15 = day13.getFirstMillisecond();
//        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        int int18 = day17.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day13, (org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.general.PieDataset pieDataset20 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
//        piePlot3D21.setStartAngle((double) (-1L));
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D26 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color27 = java.awt.Color.MAGENTA;
//        barRenderer3D26.setBaseLegendTextPaint((java.awt.Paint) color27);
//        java.awt.Shape shape29 = null;
//        barRenderer3D26.setBaseLegendShape(shape29);
//        java.awt.Paint paint32 = barRenderer3D26.getSeriesPaint((int) '4');
//        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        barRenderer3D26.setBaseFillPaint((java.awt.Paint) color33, false);
//        piePlot3D21.setBaseSectionPaint((java.awt.Paint) color33);
//        boolean boolean37 = day17.equals((java.lang.Object) color33);
//        periodAxis8.setMinorTickMarkPaint((java.awt.Paint) color33);
//        boolean boolean39 = periodAxis8.isPositiveArrowVisible();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(color27);
//        org.junit.Assert.assertNull(paint32);
//        org.junit.Assert.assertNotNull(color33);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = null;
        xYAreaRenderer4.setLegendItemURLGenerator(xYSeriesLabelGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        xYAreaRenderer4.drawRangeMarker(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, valueAxis9, marker10, rectangle2D11);
        java.awt.Shape shape13 = xYAreaRenderer4.getLegendArea();
        xYLineAndShapeRenderer2.setLegendLine(shape13);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape13);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test474");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
//        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.plot.Marker marker6 = null;
//        java.awt.geom.Rectangle2D rectangle2D7 = null;
//        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
//        java.awt.Graphics2D graphics2D9 = null;
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        java.util.List list11 = null;
//        combinedDomainXYPlot4.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
//        org.jfree.chart.util.Layer layer14 = null;
//        java.util.Collection collection15 = combinedDomainXYPlot4.getDomainMarkers((int) (short) 1, layer14);
//        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, rectangleAnchor19, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity24 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) numberAxis3D23);
//        numberAxis3D23.zoomRange(0.0d, 0.0d);
//        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        int int32 = day31.getMonth();
//        long long33 = day31.getFirstMillisecond();
//        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        int int36 = day35.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) day35);
//        boolean boolean38 = periodAxis37.isAutoRange();
//        periodAxis37.setMinorTickMarksVisible(true);
//        java.awt.Font font41 = periodAxis37.getLabelFont();
//        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer45 = null;
//        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("", font41, paint42, (float) 1577894400001L, (int) '#', textMeasurer45);
//        numberAxis3D23.setTickLabelFont(font41);
//        combinedDomainXYPlot4.setRangeAxis(64, (org.jfree.chart.axis.ValueAxis) numberAxis3D23);
//        java.awt.Paint paint49 = combinedDomainXYPlot4.getRangeZeroBaselinePaint();
//        org.junit.Assert.assertNull(collection15);
//        org.junit.Assert.assertNotNull(shape18);
//        org.junit.Assert.assertNotNull(rectangleAnchor19);
//        org.junit.Assert.assertNotNull(shape22);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(font41);
//        org.junit.Assert.assertNotNull(paint42);
//        org.junit.Assert.assertNotNull(textBlock46);
//        org.junit.Assert.assertNotNull(paint49);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D4.setBaseFillPaint((java.awt.Paint) color11, false);
        int int14 = color11.getTransparency();
        org.jfree.chart.axis.AxisCollection axisCollection15 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot16.getRenderer((int) ' ');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D19.setAutoRange(false);
        org.jfree.data.Range range22 = categoryPlot16.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D19);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset24 = combinedDomainXYPlot23.getDataset();
        boolean boolean25 = combinedDomainXYPlot23.isRangeZoomable();
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot23.setRangeTickBandPaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = combinedDomainXYPlot23.getRangeAxisEdge();
        axisCollection15.add((org.jfree.chart.axis.Axis) numberAxis3D19, rectangleEdge29);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str33 = verticalAlignment32.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement36 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment31, verticalAlignment32, (double) 1577894400001L, (double) 1099410614137L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        categoryPlot38.setDomainAxis(0, categoryAxis40, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryPlot38.getAxisOffset();
        try {
            org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Combined Range XYPlot", font1, (java.awt.Paint) color11, rectangleEdge29, horizontalAlignment31, verticalAlignment37, rectangleInsets43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "VerticalAlignment.CENTER" + "'", str33.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets43);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYAreaRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYAreaRenderer2.drawRangeMarker(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, valueAxis7, marker8, rectangle2D9);
        java.awt.Font font12 = xYAreaRenderer2.lookupLegendTextFont(6);
        boolean boolean14 = xYAreaRenderer2.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Shape shape15 = xYAreaRenderer2.getLegendArea();
        multiplePiePlot0.setLegendItemShape(shape15);
        java.awt.Shape shape17 = multiplePiePlot0.getLegendItemShape();
        java.lang.Object obj18 = multiplePiePlot0.clone();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 1560495599999L);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection7);
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            int int10 = timeSeriesCollection7.indexOf(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        org.jfree.data.Range range11 = intervalXYDelegate9.getDomainBounds(false);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = legendTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke2 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        int int4 = categoryPlot3.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        barRenderer3D7.setBaseLegendTextPaint((java.awt.Paint) color8);
        java.awt.Shape shape10 = null;
        barRenderer3D7.setBaseLegendShape(shape10);
        java.awt.Paint paint13 = barRenderer3D7.getSeriesPaint((int) '4');
        java.awt.Color color14 = java.awt.Color.RED;
        barRenderer3D7.setWallPaint((java.awt.Paint) color14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer3D7.notifyListeners(rendererChangeEvent16);
        java.awt.Font font19 = barRenderer3D7.getLegendTextFont(255);
        int int20 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        java.awt.Stroke stroke21 = categoryPlot3.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot3.getDomainAxis();
        double double23 = categoryPlot3.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot3.getRangeAxis();
        boolean boolean25 = xYPlot0.equals((java.lang.Object) valueAxis24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeries timeSeries30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeSeries30, timeZone31);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection32);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection32, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, polarItemRenderer35);
        java.awt.Font font37 = polarPlot36.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot36.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit38);
        polarPlot36.setAngleGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
        java.awt.geom.Point2D point2D46 = null;
        polarPlot36.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo45, point2D46);
        java.awt.geom.Point2D point2D48 = null;
        xYPlot27.zoomRangeAxes((double) (-1.0f), 0.0d, plotRenderingInfo45, point2D48);
        java.awt.geom.Rectangle2D rectangle2D50 = plotRenderingInfo45.getDataArea();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot51 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot51.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder53 = combinedDomainXYPlot51.getDatasetRenderingOrder();
        java.util.List list54 = combinedDomainXYPlot51.getSubplots();
        combinedDomainXYPlot51.configureRangeAxes();
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        java.util.List list58 = null;
        combinedDomainXYPlot51.drawDomainTickBands(graphics2D56, rectangle2D57, list58);
        java.awt.geom.Point2D point2D60 = combinedDomainXYPlot51.getQuadrantOrigin();
        xYPlot0.panDomainAxes((double) 60000L, plotRenderingInfo45, point2D60);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(dateTickUnit38);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(datasetRenderingOrder53);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        legendItem1.setLineVisible(false);
        java.lang.String str4 = legendItem1.getLabel();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(255, (int) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test485");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
//        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.plot.Marker marker6 = null;
//        java.awt.geom.Rectangle2D rectangle2D7 = null;
//        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
//        java.awt.Graphics2D graphics2D9 = null;
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        java.util.List list11 = null;
//        combinedDomainXYPlot4.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
//        org.jfree.chart.axis.ValueAxis valueAxis14 = combinedDomainXYPlot4.getRangeAxisForDataset(0);
//        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        int int19 = day18.getMonth();
//        long long20 = day18.getFirstMillisecond();
//        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        int int23 = day22.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day18, (org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = periodAxis24.isAutoRange();
//        periodAxis24.setMinorTickMarksVisible(true);
//        combinedDomainXYPlot4.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) periodAxis24);
//        org.junit.Assert.assertNull(valueAxis14);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = barRenderer3D4.getDrawingSupplier();
        java.awt.Stroke stroke20 = null;
        barRenderer3D4.setSeriesOutlineStroke(0, stroke20, false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D25 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        barRenderer3D25.setBaseItemLabelGenerator(categoryItemLabelGenerator26, true);
        java.awt.Shape shape30 = barRenderer3D25.lookupSeriesShape((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer3D25.getSeriesNegativeItemLabelPosition(3);
        barRenderer3D4.setBaseNegativeItemLabelPosition(itemLabelPosition32, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test488");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        org.jfree.chart.event.TitleChangeListener titleChangeListener15 = null;
//        textTitle14.removeChangeListener(titleChangeListener15);
//        java.awt.Paint paint17 = textTitle14.getBackgroundPaint();
//        textTitle14.setMaximumLinesToDisplay(64);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNull(paint17);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) ' ');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setAutoRange(false);
        org.jfree.data.Range range6 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("12/31/69 4:00 PM");
        int int9 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D8);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        boolean boolean14 = combinedDomainXYPlot4.isDomainCrosshairVisible();
        java.lang.String str15 = combinedDomainXYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
        xYAreaRenderer16.setLegendItemURLGenerator(xYSeriesLabelGenerator17);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYAreaRenderer16.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem25 = xYAreaRenderer16.getLegendItem((int) '#', (int) (byte) 1);
        int int26 = combinedDomainXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer16);
        java.awt.Paint paint27 = combinedDomainXYPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        int int30 = categoryPlot29.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D33 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color34 = java.awt.Color.MAGENTA;
        barRenderer3D33.setBaseLegendTextPaint((java.awt.Paint) color34);
        java.awt.Shape shape36 = null;
        barRenderer3D33.setBaseLegendShape(shape36);
        java.awt.Paint paint39 = barRenderer3D33.getSeriesPaint((int) '4');
        java.awt.Color color40 = java.awt.Color.RED;
        barRenderer3D33.setWallPaint((java.awt.Paint) color40);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        barRenderer3D33.notifyListeners(rendererChangeEvent42);
        java.awt.Font font45 = barRenderer3D33.getLegendTextFont(255);
        int int46 = categoryPlot29.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D33);
        java.awt.Stroke stroke47 = categoryPlot29.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot29.getRangeAxisLocation(4);
        combinedDomainXYPlot4.setRangeAxisLocation(0, axisLocation49, false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Combined_Domain_XYPlot" + "'", str15.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(font45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset4 = combinedDomainXYPlot0.getDataset((int) ' ');
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) numberAxis3D11);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color16 = java.awt.Color.MAGENTA;
        barRenderer3D15.setBaseLegendTextPaint((java.awt.Paint) color16);
        java.awt.Shape shape18 = null;
        barRenderer3D15.setBaseLegendShape(shape18);
        java.awt.Paint paint21 = barRenderer3D15.getSeriesPaint((int) '4');
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D15.setBaseFillPaint((java.awt.Paint) color22, false);
        int int25 = color22.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic26.setShapeLocation(rectangleAnchor27);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator30 = null;
        xYAreaRenderer29.setLegendItemURLGenerator(xYSeriesLabelGenerator30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        xYAreaRenderer29.drawRangeMarker(graphics2D32, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot33, valueAxis34, marker35, rectangle2D36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot33.setRangeAxisLocation((int) (byte) 1, axisLocation39, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = combinedDomainXYPlot33.getInsets();
        double double44 = rectangleInsets42.calculateTopInset((double) (byte) 100);
        legendGraphic26.setMargin(rectangleInsets42);
        boolean boolean46 = combinedDomainXYPlot0.equals((java.lang.Object) rectangleInsets42);
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot11.configureDomainAxes();
        numberAxis3D6.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis3D6.setStandardTickUnits(tickUnitSource14);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(tickUnitSource14);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str3 = org.jfree.chart.util.PaintUtilities.colorToString(color2);
        boolean boolean4 = year0.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#000080" + "'", str3.equals("#000080"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("org.jfree.data.general.SeriesException: hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot0.setRangeTickBandPaint(paint3);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10, timeZone11);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer15);
        java.awt.Font font17 = polarPlot16.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot16.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit18);
        polarPlot16.setAngleGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Point2D point2D26 = null;
        polarPlot16.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo25, point2D26);
        java.awt.geom.Point2D point2D28 = null;
        xYPlot7.zoomRangeAxes((double) (-1.0f), 0.0d, plotRenderingInfo25, point2D28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo25.getDataArea();
        combinedDomainXYPlot0.handleClick((-16777216), (int) (byte) 0, plotRenderingInfo25);
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Stroke stroke2 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(0);
        xYStepAreaRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        org.jfree.data.general.PieDataset pieDataset3 = ringPlot0.getDataset();
        boolean boolean4 = ringPlot0.getLabelLinksVisible();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, polarItemRenderer10);
        org.jfree.data.DomainOrder domainOrder12 = timeSeriesCollection7.getDomainOrder();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(domainOrder12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        int int6 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
        org.jfree.chart.JFreeChart jFreeChart8 = chartChangeEvent7.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent7.setType(chartChangeEventType9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jFreeChart8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Font font14 = barRenderer3D2.getLegendTextFont(255);
        org.jfree.chart.renderer.category.BarPainter barPainter15 = barRenderer3D2.getBarPainter();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = barRenderer3D2.getPlot();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = barRenderer3D2.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertNotNull(barPainter15);
        org.junit.Assert.assertNull(categoryPlot16);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator17);
    }
}

