import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity2 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 1L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 100.0d, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        try {
            barRenderer3D2.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot8, categoryAxis9, valueAxis10, categoryDataset11, (int) (byte) 100, 100, true, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        paintMap0.put((java.lang.Comparable) 100.0f, (java.awt.Paint) color2);
        java.awt.color.ColorSpace colorSpace4 = null;
        float[] floatArray11 = new float[] { (-1L), 0L, (short) -1, ' ', 100, (short) 100 };
        try {
            float[] floatArray12 = color2.getColorComponents(colorSpace4, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound(xYDataset0, (int) (byte) 1, 0.0d, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = barRenderer3D2.initialise(graphics2D5, rectangle2D6, categoryPlot7, (int) (byte) 0, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { (byte) 0, (short) -1, 0.0f, 'a' };
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray5, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        try {
            combinedDomainXYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo3, point2D4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        try {
            legendItem1.setFillPaintTransformer(gradientPaintTransformer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        java.awt.Paint paint4 = blockBorder3.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font1, paint4, rectangleEdge5, horizontalAlignment6, verticalAlignment7, rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        try {
            combinedDomainXYPlot0.handleClick(4, (int) '#', plotRenderingInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.BOTTOM" + "'", str1.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "", "", "RectangleEdge.BOTTOM");
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            combinedDomainXYPlot0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        basicProjectInfo5.setVersion("RectangleEdge.BOTTOM");
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            barRenderer3D2.drawOutline(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer3D2.getItemLabelGenerator((int) (byte) -1, (int) (byte) -1, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        try {
            double double21 = barRenderer3D2.getItemMiddle((java.lang.Comparable) (-1.0f), (java.lang.Comparable) (-1L), categoryDataset17, categoryAxis18, rectangle2D19, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
        org.junit.Assert.assertNotNull(uRL2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        paintMap0.put((java.lang.Comparable) 100.0f, (java.awt.Paint) color2);
        int int4 = color2.getRed();
        boolean boolean6 = color2.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            boolean boolean5 = combinedDomainXYPlot0.removeRangeMarker((int) (short) 100, marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 255, (float) 255, (double) 'a', (float) 0L, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font9 = null;
        try {
            xYAreaRenderer0.setBaseItemLabelFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 1, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        try {
            boolean boolean2 = categoryPlot0.removeAnnotation(categoryAnnotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = null;
        xYAreaRenderer4.setLegendItemURLGenerator(xYSeriesLabelGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        xYAreaRenderer4.drawRangeMarker(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, valueAxis9, marker10, rectangle2D11);
        java.awt.Shape shape13 = xYAreaRenderer4.getLegendArea();
        java.awt.Paint paint14 = null;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "hi!", shape13, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleEdge.BOTTOM", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setAutoRange(false);
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            barRenderer3D2.drawRangeMarker(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, marker14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setAutoRange(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.Layer layer9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYAreaRenderer0.drawAnnotations(graphics2D3, rectangle2D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, layer9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        try {
            combinedDomainXYPlot0.setDataset((int) (byte) -1, (org.jfree.data.xy.XYDataset) timeSeriesCollection6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            java.lang.Comparable comparable4 = timeSeriesCollection2.getSeriesKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) -1, 10.0d);
        boolean boolean3 = xYDataItem2.isSelected();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        int int5 = xYDataItem2.compareTo((java.lang.Object) itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedDomainXYPlot4.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = null;
        try {
            combinedDomainXYPlot4.setOrientation(plotOrientation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.lang.Boolean boolean9 = xYAreaRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Stroke stroke3 = null;
        legendItem1.setOutlineStroke(stroke3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem1.getFillPaintTransformer();
        legendItem1.setToolTipText("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D6.setTickMarkStroke(stroke8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            org.jfree.chart.axis.AxisState axisState16 = numberAxis3D6.draw(graphics2D10, (double) 10, rectangle2D12, rectangle2D13, rectangleEdge14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot0.setRangeTickBandPaint(paint3);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = combinedDomainXYPlot0.removeDomainMarker(marker5);
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRange(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = numberAxis3D0.draw(graphics2D3, (double) 1L, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date0, timeZone2, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.zoomRange(0.0d, 0.0d);
        try {
            numberAxis3D6.setRangeWithMargins((double) 100.0f, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedDomainXYPlot4.setDrawingSupplier(drawingSupplier9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot4.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = null;
        try {
            combinedDomainXYPlot4.setOrientation(plotOrientation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        try {
            categoryPlot0.setDataset((int) (byte) -1, categoryDataset9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) (byte) 1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        java.util.List list2 = null;
        try {
            combinedDomainXYPlot0.mapDatasetToRangeAxes((int) (byte) 10, list2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            combinedDomainXYPlot4.draw(graphics2D9, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 0, (float) 0L, (-1.0d), (float) 1560409200000L, (float) (short) 1);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("-10,1,0,-19,-20,-19,-20,-19", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setAutoRange(false);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setTickLabelFont(font6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            xYLineAndShapeRenderer0.fillRangeGridBand(graphics2D1, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, rectangle2D8, (double) 1577894400001L, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("index.html", graphics2D1, (float) (byte) 1, (float) 1, 0.0d, (float) 2, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = '#';
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        java.lang.String str1 = domainOrder0.toString();
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DomainOrder.ASCENDING" + "'", str1.equals("DomainOrder.ASCENDING"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.lang.Comparable comparable7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeriesCollection2.getSeries(comparable7);
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            int int10 = timeSeriesCollection2.indexOf(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(timeSeries8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        int int2 = day1.getYear();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-10,1,0,-19,-20,-19,-20,-19", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Comparable comparable1 = null;
        try {
            int int2 = defaultPieDataset0.getIndex(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.util.Calendar calendar9 = null;
//        try {
//            day6.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TextAnchor.TOP_LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TextAnchor.TOP_LEFT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 4, 100.0d, (double) 1, (double) (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            java.lang.Comparable comparable2 = defaultPieDataset0.getKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.setTickLabelsVisible(false);
        try {
            numberAxis3D6.setAutoRangeMinimumSize((double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 35L + "'", long0 == 35L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) ' ');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            categoryPlot0.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        try {
            java.math.RoundingMode roundingMode1 = logFormat0.getRoundingMode();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        java.util.List list8 = null;
        org.jfree.data.Range range9 = null;
        try {
            org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list8, range9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor4, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity9 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) numberAxis3D8);
        numberAxis3D8.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot13.configureDomainAxes();
        numberAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot13);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot13, "index.html");
        org.jfree.chart.title.Title title18 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape1, title18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.lang.Object obj1 = null;
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator2 = logFormat0.formatToCharacterIterator(obj1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Font font14 = barRenderer3D2.getLegendTextFont(255);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot16.getRangeAxis((int) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            barRenderer3D2.drawDomainGridline(graphics2D15, categoryPlot16, rectangle2D19, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        boolean boolean2 = timePeriodAnchor0.equals((java.lang.Object) 0L);
        java.lang.String str3 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TimePeriodAnchor.MIDDLE" + "'", str3.equals("TimePeriodAnchor.MIDDLE"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = null;
        xYAreaRenderer10.setLegendItemURLGenerator(xYSeriesLabelGenerator11);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYAreaRenderer10.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYAreaRenderer10.getSeriesNegativeItemLabelPosition((int) (short) 1);
        xYAreaRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition18, false);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            combinedDomainXYPlot0.addDomainMarker((int) '#', marker4, layer5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.util.List list7 = null;
        try {
            org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        java.awt.Image image2 = combinedDomainXYPlot0.getBackgroundImage();
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1.0f, 100, 0.0d, 90.0d, (-1.0d) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray7, numberArray13, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-10,1,0,-19,-20,-19,-20,-19", "hi!", numberArray20);
        try {
            org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset21, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { ' ' };
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { year2, 7, "DomainOrder.ASCENDING", 5 };
        double[] doubleArray11 = new double[] { (short) 100, 6 };
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray12);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray6, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of column keys does not match the number of columns in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset9, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeWidth(range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint2.toFixedHeight((double) 6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint14.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
//        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.plot.Marker marker6 = null;
//        java.awt.geom.Rectangle2D rectangle2D7 = null;
//        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
//        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYAreaRenderer0.getSeriesItemLabelGenerator((int) (short) 0);
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
//        xYAreaRenderer12.setLegendItemURLGenerator(xYSeriesLabelGenerator13);
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYAreaRenderer12.getURLGenerator(0, 100, true);
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYAreaRenderer12.getSeriesNegativeItemLabelPosition((int) (short) 1);
//        xYAreaRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition20, true);
//        java.awt.Graphics2D graphics2D23 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = null;
//        java.awt.geom.Rectangle2D rectangle2D25 = null;
//        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape27, rectangleAnchor28, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity33 = new org.jfree.chart.entity.AxisEntity(shape31, (org.jfree.chart.axis.Axis) numberAxis3D32);
//        numberAxis3D32.zoomRange(0.0d, 0.0d);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot37.configureDomainAxes();
//        numberAxis3D32.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot37);
//        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape41, rectangleAnchor42, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity47 = new org.jfree.chart.entity.AxisEntity(shape45, (org.jfree.chart.axis.Axis) numberAxis3D46);
//        java.util.Date date49 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
//        int int51 = day50.getMonth();
//        long long52 = day50.getFirstMillisecond();
//        java.util.Date date53 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
//        int int55 = day54.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis56 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day50, (org.jfree.data.time.RegularTimePeriod) day54);
//        boolean boolean57 = periodAxis56.isAutoRange();
//        org.jfree.data.time.TimeSeries timeSeries58 = null;
//        java.util.TimeZone timeZone59 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeSeries58, timeZone59);
//        org.jfree.data.Range range61 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection60, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, polarItemRenderer63);
//        org.jfree.data.DomainOrder domainOrder65 = timeSeriesCollection60.getDomainOrder();
//        try {
//            xYAreaRenderer0.drawItem(graphics2D23, xYItemRendererState24, rectangle2D25, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot37, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, (org.jfree.chart.axis.ValueAxis) periodAxis56, (org.jfree.data.xy.XYDataset) timeSeriesCollection60, 0, 0, false, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(xYItemLabelGenerator10);
//        org.junit.Assert.assertNull(xYURLGenerator18);
//        org.junit.Assert.assertNotNull(itemLabelPosition20);
//        org.junit.Assert.assertNotNull(shape27);
//        org.junit.Assert.assertNotNull(rectangleAnchor28);
//        org.junit.Assert.assertNotNull(shape31);
//        org.junit.Assert.assertNotNull(shape41);
//        org.junit.Assert.assertNotNull(rectangleAnchor42);
//        org.junit.Assert.assertNotNull(shape45);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560409200000L + "'", long52 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNull(range61);
//        org.junit.Assert.assertNotNull(domainOrder65);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        long long13 = day11.getFirstMillisecond();
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day15);
//        periodAxis8.setLast((org.jfree.data.time.RegularTimePeriod) day11);
//        java.util.Calendar calendar19 = null;
//        try {
//            day11.peg(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape6);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8, timeZone9);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, polarItemRenderer13);
        java.awt.Paint paint15 = polarPlot14.getAngleLabelPaint();
        java.awt.Paint paint16 = polarPlot14.getRadiusGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        java.awt.Stroke stroke19 = xYPlot17.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color23 = java.awt.Color.MAGENTA;
        barRenderer3D22.setBaseLegendTextPaint((java.awt.Paint) color23);
        java.awt.Shape shape25 = null;
        barRenderer3D22.setBaseLegendShape(shape25);
        java.awt.Paint paint28 = barRenderer3D22.getSeriesPaint((int) '4');
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D22.setBaseFillPaint((java.awt.Paint) color29, false);
        try {
            org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem(attributedString0, "Pie 3D Plot", "RectangleEdge.BOTTOM", "index.html", shape6, paint16, stroke19, (java.awt.Paint) color29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4, 7, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        logFormat0.setMinimumFractionDigits(100);
        java.math.RoundingMode roundingMode3 = null;
        try {
            logFormat0.setRoundingMode(roundingMode3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = java.awt.Color.white;
        float[] floatArray3 = new float[] { '4', 1 };
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.math.RoundingMode roundingMode1 = numberFormat0.getRoundingMode();
        numberFormat0.setParseIntegerOnly(true);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + roundingMode1 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode1.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getLength();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator3, true);
        java.awt.Paint paint6 = null;
        try {
            barRenderer3D2.setWallPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        barRenderer3D6.setBaseLegendTextPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        barRenderer3D6.setBaseLegendShape(shape9);
        java.awt.Paint paint12 = barRenderer3D6.getSeriesPaint((int) '4');
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D6.setBaseFillPaint((java.awt.Paint) color13, false);
        piePlot3D1.setBaseSectionPaint((java.awt.Paint) color13);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.Point2D point2D19 = null;
        org.jfree.chart.plot.PlotState plotState20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            piePlot3D1.draw(graphics2D17, rectangle2D18, point2D19, plotState20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            boolean boolean5 = xYPlot0.removeRangeMarker((int) (byte) -1, marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        basicProjectInfo5.setCopyright("TimePeriodAnchor.MIDDLE");
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("Polar Plot");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        periodAxis8.setRangeWithMargins((double) (-1), (double) 1560409200000L);
//        float float13 = periodAxis8.getMinorTickMarkInsideLength();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("DomainOrder.ASCENDING", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font10 = barRenderer3D2.getLegendTextFont((int) (short) 100);
        barRenderer3D2.setIncludeBaseInRange(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        boolean boolean15 = barRenderer3D2.getIncludeBaseInRange();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        try {
            java.awt.image.BufferedImage bufferedImage6 = jFreeChart1.createBufferedImage(3, (int) 'a', 0, chartRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = null;
        try {
            piePlot3D1.setLabelLinkStyle(pieLabelLinkStyle5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        boolean boolean9 = xYAreaRenderer0.getPlotShapes();
        java.awt.Stroke stroke10 = xYAreaRenderer0.getBaseOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer12.setLegendItemURLGenerator(xYSeriesLabelGenerator13);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYAreaRenderer12.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYAreaRenderer12.getSeriesNegativeItemLabelPosition((int) (short) 1);
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition(6, itemLabelPosition20, true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        try {
            double double10 = timeSeriesCollection2.getEndXValue(255, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.lang.Comparable comparable7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeriesCollection2.getSeries(comparable7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        try {
            timeSeriesCollection2.removeSeries(timeSeries10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(timeSeries8);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendGraphic21.getPadding();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets24.createInsetRectangle(rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        try {
            polarPlot6.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            combinedDomainXYPlot0.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(5);
        boolean boolean2 = xYStepAreaRenderer1.getPlotArea();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment4, (double) 6, (double) 0);
        columnArrangement7.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) 6, (double) 0);
        columnArrangement13.clear();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1, (org.jfree.chart.block.Arrangement) columnArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement13);
        columnArrangement13.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot4.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        try {
            legendItemCollection9.addAll(legendItemCollection10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        boolean boolean24 = legendGraphic21.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font10 = barRenderer3D2.getLegendTextFont((int) (short) 100);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) numberAxis3D19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            barRenderer3D2.drawRangeMarker(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, marker21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) 35L, 2.0d, (int) (byte) 10, (java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        try {
            jFreeChart1.handleClick(0, 100, chartRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor4, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity9 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) numberAxis3D8);
        numberAxis3D8.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot13.configureDomainAxes();
        numberAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot13);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot13, "index.html");
        java.lang.Object obj18 = null;
        boolean boolean19 = plotEntity17.equals(obj18);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("TimePeriodAnchor.MIDDLE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RectangleEdge.BOTTOM");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str6 = textAnchor5.toString();
        try {
            textLine1.draw(graphics2D2, (float) 2019, (float) (short) -1, textAnchor5, (float) 100, (float) (short) 10, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str6.equals("TextAnchor.TOP_LEFT"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.lang.Object obj1 = segmentedTimeline0.clone();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge(255);
        boolean boolean5 = categoryPlot0.isDomainPannable();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedDomainXYPlot0.getRangeAxisLocation((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        try {
            combinedDomainXYPlot0.zoomRangeAxes(0.0d, (double) 10L, plotRenderingInfo6, point2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset9, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeWidth(range11);
        double double13 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Stroke stroke3 = null;
        legendItem1.setOutlineStroke(stroke3);
        java.lang.Object obj5 = legendItem1.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        java.awt.Shape shape8 = null;
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape7, shape8);
        try {
            legendItem1.setShape(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsIncludedSize();
        int int2 = segmentedTimeline0.getSegmentsExcluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 432000000L + "'", long1 == 432000000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) '#', (int) (byte) 1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYAreaRenderer0.setSeriesToolTipGenerator(500, xYToolTipGenerator11);
        double double13 = xYAreaRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            int int7 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (int) (byte) 0, (double) (byte) 0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Paint paint0 = null;
        java.awt.Paint paint1 = null;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font10 = barRenderer3D2.getLegendTextFont((int) (short) 100);
        barRenderer3D2.setIncludeBaseInRange(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer3D2.setSeriesItemLabelGenerator(2958465, categoryItemLabelGenerator16);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot11.configureDomainAxes();
        numberAxis3D6.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot11);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = combinedDomainXYPlot11.getOrientation();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = null;
        xYAreaRenderer15.setLegendItemURLGenerator(xYSeriesLabelGenerator16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYAreaRenderer15.drawRangeMarker(graphics2D18, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot19, valueAxis20, marker21, rectangle2D22);
        java.awt.Font font25 = xYAreaRenderer15.lookupLegendTextFont(6);
        int int26 = xYAreaRenderer15.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = xYAreaRenderer15.getLegendItemLabelGenerator();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape33, (org.jfree.chart.axis.Axis) numberAxis3D34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D34.setTickMarkStroke(stroke36);
        xYAreaRenderer15.setBaseStroke(stroke36);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape41, rectangleAnchor42, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity47 = new org.jfree.chart.entity.AxisEntity(shape45, (org.jfree.chart.axis.Axis) numberAxis3D46);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D46.setTickMarkStroke(stroke48);
        xYAreaRenderer15.setSeriesStroke(0, stroke48, false);
        combinedDomainXYPlot11.setDomainZeroBaselineStroke(stroke48);
        org.jfree.chart.axis.ValueAxis valueAxis54 = combinedDomainXYPlot11.getRangeAxis(0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(font25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(valueAxis54);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 100, (float) '4', (double) 1L, (float) 35L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        categoryPlot0.clearAnnotations();
        java.awt.Paint paint19 = categoryPlot0.getDomainCrosshairPaint();
        int int20 = categoryPlot0.getDatasetCount();
        boolean boolean21 = categoryPlot0.isOutlineVisible();
        java.awt.Stroke stroke22 = null;
        try {
            categoryPlot0.setRangeZeroBaselineStroke(stroke22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = null;
        try {
            jFreeChart1.titleChanged(titleChangeEvent3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = null;
        try {
            timeSeriesCollection2.setGroup(datasetGroup7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        java.awt.Paint paint11 = barRenderer3D2.getSeriesPaint(0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        categoryPlot0.clearAnnotations();
        java.awt.Paint paint19 = categoryPlot0.getDomainCrosshairPaint();
        int int20 = categoryPlot0.getDatasetCount();
        boolean boolean21 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot0.getDomainAxisEdge(2019);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            categoryPlot0.addDomainMarker(12, categoryMarker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("DomainOrder.ASCENDING");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo12);
        basicProjectInfo12.setInfo("-10,1,0,-19,-20,-19,-20,-19");
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font10 = barRenderer3D2.getLegendTextFont((int) (short) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        int int15 = categoryPlot14.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color19 = java.awt.Color.MAGENTA;
        barRenderer3D18.setBaseLegendTextPaint((java.awt.Paint) color19);
        java.awt.Shape shape21 = null;
        barRenderer3D18.setBaseLegendShape(shape21);
        java.awt.Paint paint24 = barRenderer3D18.getSeriesPaint((int) '4');
        java.awt.Color color25 = java.awt.Color.RED;
        barRenderer3D18.setWallPaint((java.awt.Paint) color25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        barRenderer3D18.notifyListeners(rendererChangeEvent27);
        java.awt.Font font30 = barRenderer3D18.getLegendTextFont(255);
        int int31 = categoryPlot14.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D18);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            barRenderer3D2.drawBackground(graphics2D13, categoryPlot14, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("");
        boolean boolean7 = legendItem6.isShapeFilled();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color8);
        legendItem6.setFillPaint((java.awt.Paint) color8);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("-10,1,0,-19,-20,-19,-20,-19", font4, (java.awt.Paint) color8);
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.Marker marker13 = null;
        try {
            categoryPlot0.addRangeMarker(marker13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape13, (org.jfree.chart.axis.Axis) numberAxis3D14);
        numberAxis3D14.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range19 = polarPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D14.getTickLabelInsets();
        numberAxis3D14.setLabel("Pie 3D Plot");
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot25.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot25.getRangeAxisEdge(255);
        try {
            double double30 = numberAxis3D14.java2DToValue((double) 0.5f, rectangle2D24, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2, (float) 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color22);
        barRenderer3D4.setWallPaint((java.awt.Paint) color22);
        java.awt.Shape shape26 = null;
        try {
            barRenderer3D4.setLegendShape((int) (byte) -1, shape26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.lang.Comparable comparable7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeriesCollection2.getSeries(comparable7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            timeSeriesCollection2.removeSeries((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(timeSeries8);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray4 = new double[] { (short) 100, 6 };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray5);
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries7, timeZone8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, polarItemRenderer12);
        java.awt.Font font14 = polarPlot13.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot13.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit15);
        try {
            org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset6, (java.lang.Comparable) dateTickUnit15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYAreaRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 1);
        java.awt.Paint paint9 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke16 = combinedDomainXYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            boolean boolean19 = combinedDomainXYPlot4.removeRangeMarker(marker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendGraphic21.getPadding();
        legendGraphic21.setShapeFilled(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("index.html", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font10 = barRenderer3D2.getLegendTextFont((int) (short) 100);
        barRenderer3D2.setIncludeBaseInRange(false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        int int15 = categoryPlot14.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color19 = java.awt.Color.MAGENTA;
        barRenderer3D18.setBaseLegendTextPaint((java.awt.Paint) color19);
        java.awt.Shape shape21 = null;
        barRenderer3D18.setBaseLegendShape(shape21);
        java.awt.Paint paint24 = barRenderer3D18.getSeriesPaint((int) '4');
        java.awt.Color color25 = java.awt.Color.RED;
        barRenderer3D18.setWallPaint((java.awt.Paint) color25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        barRenderer3D18.notifyListeners(rendererChangeEvent27);
        java.awt.Font font30 = barRenderer3D18.getLegendTextFont(255);
        int int31 = categoryPlot14.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D18);
        java.awt.Stroke stroke32 = categoryPlot14.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot14.getDomainAxis();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        try {
            barRenderer3D2.drawBackground(graphics2D13, categoryPlot14, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(categoryAxis33);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (short) 10, 1.0f, (double) 1, 0.0f, (float) (short) 100);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color0 = java.awt.Color.GRAY;
        float[] floatArray4 = new float[] { (short) 0, 7, (-1.0f) };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(5);
        boolean boolean2 = xYStepAreaRenderer1.getPlotArea();
        try {
            xYStepAreaRenderer1.setSeriesCreateEntities((int) (short) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color3);
        waferMapPlot2.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo12);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo19 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray20 = basicProjectInfo19.getOptionalLibraries();
        basicProjectInfo12.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo19);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        combinedDomainXYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(xYDataset1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getURLGenerator();
        piePlot3D1.setPieIndex(0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.Object obj1 = null;
        boolean boolean2 = axisLocation0.equals(obj1);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        double double22 = legendGraphic21.getHeight();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = legendGraphic21.arrange(graphics2D23);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(size2D24);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Stroke stroke3 = null;
        legendItem1.setOutlineStroke(stroke3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem1.getFillPaintTransformer();
        java.text.AttributedString attributedString6 = legendItem1.getAttributedLabel();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNull(attributedString6);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        boolean boolean16 = textTitle14.equals((java.lang.Object) "TimePeriodAnchor.MIDDLE");
//        textTitle14.visible = false;
//        org.jfree.chart.event.TitleChangeListener titleChangeListener19 = null;
//        textTitle14.removeChangeListener(titleChangeListener19);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        boolean boolean14 = combinedDomainXYPlot4.isDomainCrosshairVisible();
        java.lang.String str15 = combinedDomainXYPlot4.getPlotType();
        int int16 = combinedDomainXYPlot4.getSeriesCount();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Combined_Domain_XYPlot" + "'", str15.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        int int11 = xYAreaRenderer0.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = xYAreaRenderer0.getLegendItemLabelGenerator();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) numberAxis3D19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D19.setTickMarkStroke(stroke21);
        xYAreaRenderer0.setBaseStroke(stroke21);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = xYAreaRenderer0.getGradientTransformer();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = xYAreaRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(gradientPaintTransformer24);
        org.junit.Assert.assertNull(xYToolTipGenerator25);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis8);
//        java.awt.Font font11 = periodAxis8.getLabelFont();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(font11);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedDomainXYPlot4.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color16 = java.awt.Color.MAGENTA;
        barRenderer3D15.setBaseLegendTextPaint((java.awt.Paint) color16);
        java.awt.Shape shape18 = null;
        barRenderer3D15.setBaseLegendShape(shape18);
        java.awt.Paint paint21 = barRenderer3D15.getSeriesPaint((int) '4');
        java.awt.Color color22 = java.awt.Color.RED;
        barRenderer3D15.setWallPaint((java.awt.Paint) color22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer3D15.notifyListeners(rendererChangeEvent24);
        java.awt.Font font27 = barRenderer3D15.getLegendTextFont(255);
        int int28 = categoryPlot11.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15);
        categoryPlot11.clearAnnotations();
        java.awt.Paint paint30 = categoryPlot11.getDomainCrosshairPaint();
        combinedDomainXYPlot4.setDomainMinorGridlinePaint(paint30);
        org.jfree.chart.axis.ValueAxis valueAxis33 = combinedDomainXYPlot4.getDomainAxis(5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(valueAxis33);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("hi!");
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        try {
            java.lang.String[] strArray5 = jFreeChartResources0.getStringArray("PlotOrientation.VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key PlotOrientation.VERTICAL");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        boolean boolean12 = xYAreaRenderer0.removeAnnotation(xYAnnotation11);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        try {
            xYAreaRenderer0.setLegendItemLabelGenerator(xYSeriesLabelGenerator13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        org.jfree.data.general.PieDataset pieDataset3 = ringPlot0.getDataset();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState9 = ringPlot0.initialise(graphics2D4, rectangle2D5, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNull(pieDataset3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = combinedDomainXYPlot4.getInsets();
        java.lang.String str14 = rectangleInsets13.toString();
        double double15 = rectangleInsets13.getRight();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str14.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        legendItem1.setDescription("hi!");
        java.lang.String str5 = legendItem1.getURLText();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 500, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleEdge.BOTTOM", "hi!", "");
        basicProjectInfo5.setInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) -1, 10.0d);
        java.lang.Number number3 = xYDataItem2.getX();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.LogFormat logFormat2 = new org.jfree.chart.util.LogFormat();
        logFormat2.setMinimumFractionDigits(100);
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator6 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat2, (java.text.NumberFormat) logFormat5);
        org.jfree.chart.util.LogFormat logFormat7 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie 3D Plot", (java.text.NumberFormat) logFormat2, (java.text.NumberFormat) logFormat7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.lang.String str10 = logFormat7.format((java.lang.Object) rectangleAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot0.setRangeTickBandPaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        double[] doubleArray12 = new double[] { (short) 100, 6 };
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset14, true);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset14);
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset14);
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        java.util.List list25 = logAxis20.refreshTicks(graphics2D21, axisState22, rectangle2D23, rectangleEdge24);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, list25, true);
        try {
            combinedDomainXYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(range27);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        java.lang.String str10 = periodAxis8.getLabelToolTip();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNull(str10);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        piePlot3D2.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        barRenderer3D7.setBaseLegendTextPaint((java.awt.Paint) color8);
        java.awt.Shape shape10 = null;
        barRenderer3D7.setBaseLegendShape(shape10);
        java.awt.Paint paint13 = barRenderer3D7.getSeriesPaint((int) '4');
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D7.setBaseFillPaint((java.awt.Paint) color14, false);
        piePlot3D2.setBaseSectionPaint((java.awt.Paint) color14);
        combinedDomainXYPlot0.setRangeTickBandPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        categoryPlot0.clearAnnotations();
        java.awt.Paint paint19 = categoryPlot0.getDomainCrosshairPaint();
        int int20 = categoryPlot0.getDatasetCount();
        double double21 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Paint paint14 = barRenderer3D2.getSeriesItemLabelPaint((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = barRenderer3D2.getSeriesURLGenerator(4);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(categoryURLGenerator16);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'multiple' > 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("");
        boolean boolean4 = legendItem3.isShapeFilled();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color5);
        legendItem3.setFillPaint((java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("-10,1,0,-19,-20,-19,-20,-19", font1, (java.awt.Paint) color5);
        org.jfree.chart.text.TextFragment textFragment9 = null;
        textLine8.addFragment(textFragment9);
        org.jfree.chart.text.TextFragment textFragment11 = textLine8.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textFragment11);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        int int2 = day1.getMonth();
//        long long3 = day1.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        java.lang.String str5 = serialDate4.toString();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
//        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 1577894400001L, (int) '#', textMeasurer17);
//        java.awt.Graphics2D graphics2D19 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
//        textBlock18.draw(graphics2D19, (float) 10L, (float) 7, textBlockAnchor22);
//        org.jfree.data.time.TimeSeries timeSeries24 = null;
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection(timeSeries24, timeZone25);
//        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection26);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection26, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, polarItemRenderer29);
//        java.awt.Font font31 = polarPlot30.getAngleLabelFont();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        polarPlot30.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit32);
//        int int34 = dateTickUnit32.getCalendarField();
//        boolean boolean35 = textBlockAnchor22.equals((java.lang.Object) int34);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(textBlock18);
//        org.junit.Assert.assertNotNull(textBlockAnchor22);
//        org.junit.Assert.assertNull(range27);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertNotNull(dateTickUnit32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Combined_Domain_XYPlot", font13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator5);
        double double7 = piePlot3D1.getShadowXOffset();
        java.awt.Stroke stroke8 = piePlot3D1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot3.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot3.getRangeGridlinePaint();
        boolean boolean9 = combinedDomainXYPlot0.equals((java.lang.Object) categoryPlot3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = combinedDomainXYPlot0.getRenderer(13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYItemRenderer11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape2);
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4);
        org.jfree.chart.entity.XYItemEntity xYItemEntity10 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) timeSeriesCollection5, 1, 2958465, "", "RectangleEdge.BOTTOM");
        org.jfree.data.xy.XYDataset xYDataset11 = xYItemEntity10.getDataset();
        int int12 = xYItemEntity10.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects((double) (short) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("");
        boolean boolean7 = legendItem6.isShapeFilled();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color8);
        legendItem6.setFillPaint((java.awt.Paint) color8);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("-10,1,0,-19,-20,-19,-20,-19", font4, (java.awt.Paint) color8);
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        double[] doubleArray18 = new double[] { (short) 100, 6 };
        double[][] doubleArray19 = new double[][] { doubleArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset20);
        try {
            categoryPlot0.setDataset((-65281), categoryDataset20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 6.0d + "'", number21.equals(6.0d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        java.awt.Shape shape22 = legendGraphic21.getLine();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(shape22);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYAreaRenderer0.getSeriesItemLabelGenerator((int) (short) 0);
        xYAreaRenderer0.setDefaultEntityRadius((int) (short) -1);
        org.junit.Assert.assertNull(xYItemLabelGenerator10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("PlotOrientation.VERTICAL", "13-June-2019", "DomainOrder.ASCENDING", "Polar Plot", "Polar Plot");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot4.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        try {
            combinedDomainXYPlot4.zoomRangeAxes((double) 5, (double) 1L, plotRenderingInfo12, point2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray4 = new double[] { (short) 100, 6 };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray5);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset6, true);
        try {
            org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset6, (java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getDomainMarkers(layer2);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.BOTTOM", "TimePeriodAnchor.MIDDLE", "", "");
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 10.0f, (double) 7, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendGraphic21.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic21.setShapeAnchor(rectangleAnchor25);
        java.lang.String str27 = rectangleAnchor25.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str27.equals("RectangleAnchor.TOP_RIGHT"));
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis9);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal(paint0, (java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getAxisOffset();
        try {
            categoryPlot0.setBackgroundImageAlpha((float) 1560409200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Font font14 = barRenderer3D2.getLegendTextFont(255);
        barRenderer3D2.setShadowXOffset((double) 100.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(font14);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Paint paint8 = polarPlot6.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot6.zoomRangeAxes((double) (short) 1, plotRenderingInfo10, point2D11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Stroke stroke3 = null;
        legendItem1.setOutlineStroke(stroke3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem1.getFillPaintTransformer();
        java.awt.Paint paint6 = legendItem1.getOutlinePaint();
        legendItem1.setToolTipText("RectangleEdge.BOTTOM");
        java.awt.Stroke stroke9 = legendItem1.getLineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("DomainOrder.ASCENDING", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Multiple Pie Plot", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.util.LogFormat logFormat1 = new org.jfree.chart.util.LogFormat();
        logFormat1.setMinimumFractionDigits(100);
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat1, (java.text.NumberFormat) logFormat4);
        java.text.ParsePosition parsePosition7 = null;
        java.lang.Object obj8 = logFormat1.parseObject("TimePeriodAnchor.MIDDLE", parsePosition7);
        int int9 = logFormat1.getMinimumFractionDigits();
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        int int9 = combinedDomainXYPlot4.getWeight();
        java.awt.Paint paint10 = combinedDomainXYPlot4.getDomainTickBandPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color16 = java.awt.Color.MAGENTA;
        barRenderer3D15.setBaseLegendTextPaint((java.awt.Paint) color16);
        java.awt.Shape shape18 = null;
        barRenderer3D15.setBaseLegendShape(shape18);
        java.awt.Paint paint21 = barRenderer3D15.getSeriesPaint((int) '4');
        java.awt.Color color22 = java.awt.Color.RED;
        barRenderer3D15.setWallPaint((java.awt.Paint) color22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer3D15.notifyListeners(rendererChangeEvent24);
        java.awt.Font font27 = barRenderer3D15.getLegendTextFont(255);
        int int28 = categoryPlot11.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15);
        java.awt.Color color33 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color33);
        barRenderer3D15.setWallPaint((java.awt.Paint) color33);
        combinedDomainXYPlot4.setDomainZeroBaselinePaint((java.awt.Paint) color33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        try {
            combinedDomainXYPlot4.zoomRangeAxes((double) 12, plotRenderingInfo38, point2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) -1, 10.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color6 = java.awt.Color.MAGENTA;
        barRenderer3D5.setBaseLegendTextPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = null;
        barRenderer3D5.setBaseLegendShape(shape8);
        java.awt.Paint paint11 = barRenderer3D5.getSeriesPaint((int) '4');
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D5.setBaseFillPaint((java.awt.Paint) color12, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer3D5.setSeriesItemLabelGenerator(6, categoryItemLabelGenerator16);
        boolean boolean18 = xYDataItem2.equals((java.lang.Object) categoryItemLabelGenerator16);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Stroke stroke2 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(0);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        combinedDomainXYPlot9.setDrawingSupplier(drawingSupplier14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYStepAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, xYDataset16, plotRenderingInfo17);
        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYStepAreaRenderer0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot0.setRangeTickBandPaint(paint3);
        combinedDomainXYPlot0.clearDomainMarkers((-65281));
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
//        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
//        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) '#', (int) (byte) 1);
//        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        int int15 = day14.getMonth();
//        long long16 = day14.getFirstMillisecond();
//        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        int int19 = day18.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day14, (org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = periodAxis20.isAutoRange();
//        periodAxis20.setMinorTickMarksVisible(true);
//        java.awt.Font font24 = periodAxis20.getLabelFont();
//        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer28 = null;
//        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("", font24, paint25, (float) 1577894400001L, (int) '#', textMeasurer28);
//        xYAreaRenderer0.setSeriesPaint(500, paint25, true);
//        org.junit.Assert.assertNull(xYURLGenerator6);
//        org.junit.Assert.assertNull(legendItem9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(font24);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertNotNull(textBlock29);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Paint paint8 = polarPlot6.getRadiusGridlinePaint();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot6.getRenderer();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(polarItemRenderer9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        axisEntity7.setURLText("RectangleEdge.BOTTOM");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.TableOrder tableOrder3 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor4 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        boolean boolean6 = timePeriodAnchor4.equals((java.lang.Object) 0L);
        timeSeriesCollection2.setXPosition(timePeriodAnchor4);
        try {
            java.lang.Comparable comparable9 = timeSeriesCollection2.getSeriesKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(timePeriodAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        logAxis1.pan((double) 2);
        double double5 = logAxis1.calculateLog((double) ' ');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.5051499783199058d + "'", double5 == 1.5051499783199058d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.LogFormat logFormat2 = new org.jfree.chart.util.LogFormat();
        logFormat2.setMinimumFractionDigits(100);
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator6 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat2, (java.text.NumberFormat) logFormat5);
        org.jfree.chart.util.LogFormat logFormat7 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie 3D Plot", (java.text.NumberFormat) logFormat2, (java.text.NumberFormat) logFormat7);
        java.text.AttributedString attributedString10 = standardPieSectionLabelGenerator8.getAttributedLabel((int) (byte) -1);
        org.junit.Assert.assertNull(attributedString10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor4, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity9 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) numberAxis3D8);
        numberAxis3D8.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot13.configureDomainAxes();
        numberAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot13);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot13, "index.html");
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        try {
            combinedDomainXYPlot13.draw(graphics2D18, rectangle2D19, point2D20, plotState21, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYAreaRenderer1.drawRangeMarker(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot5, valueAxis6, marker7, rectangle2D8);
        java.awt.Font font11 = xYAreaRenderer1.lookupLegendTextFont(6);
        int int12 = xYAreaRenderer1.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = xYAreaRenderer1.getLegendItemLabelGenerator();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor16, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape19, (org.jfree.chart.axis.Axis) numberAxis3D20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D20.setTickMarkStroke(stroke22);
        xYAreaRenderer1.setBaseStroke(stroke22);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape27, rectangleAnchor28, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity33 = new org.jfree.chart.entity.AxisEntity(shape31, (org.jfree.chart.axis.Axis) numberAxis3D32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D32.setTickMarkStroke(stroke34);
        xYAreaRenderer1.setSeriesStroke(0, stroke34, false);
        java.awt.Paint paint41 = xYAreaRenderer1.getItemOutlinePaint(6, 0, false);
        boolean boolean42 = domainOrder0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            java.lang.Number number2 = defaultPieDataset0.getValue((java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found:  ");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer5);
        timeSeriesCollection2.seriesChanged(seriesChangeEvent6);
        org.jfree.data.Range range9 = timeSeriesCollection2.getDomainBounds(true);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        polarPlot6.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot6.getOrientation();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        logFormat0.setMinimumFractionDigits(100);
        java.lang.String str4 = logFormat0.format((double) 60000L);
        try {
            java.lang.Number number6 = logFormat0.parse("RectangleAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"RectangleAnchor.TOP_RIGHT\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10^4.78" + "'", str4.equals("10^4.78"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis();
        categoryPlot0.setWeight((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryAxis19);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.TickType tickType6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str10 = textAnchor9.toString();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick(tickType6, (double) 12, "index.html", textAnchor9, textAnchor11, (double) 'a');
        try {
            java.awt.Shape shape14 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("12/31/69 4:00 PM", graphics2D1, (float) (byte) 0, (float) 100L, textAnchor4, (double) 255, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str10.equals("TextAnchor.TOP_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        barRenderer3D6.setBaseLegendTextPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        barRenderer3D6.setBaseLegendShape(shape9);
        java.awt.Paint paint12 = barRenderer3D6.getSeriesPaint((int) '4');
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D6.setBaseFillPaint((java.awt.Paint) color13, false);
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis8);
//        boolean boolean11 = combinedDomainXYPlot10.canSelectByRegion();
//        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//        java.awt.Stroke stroke14 = xYStepAreaRenderer12.lookupSeriesOutlineStroke(0);
//        java.awt.Graphics2D graphics2D15 = null;
//        org.jfree.chart.plot.XYPlot xYPlot16 = null;
//        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        int int20 = day19.getMonth();
//        long long21 = day19.getFirstMillisecond();
//        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        int int24 = day23.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) day23);
//        periodAxis25.configure();
//        java.awt.geom.Rectangle2D rectangle2D27 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot29.getDomainAxis(10);
//        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
//        categoryPlot29.setFixedRangeAxisSpace(axisSpace32);
//        java.awt.Paint paint34 = categoryPlot29.getRangeGridlinePaint();
//        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape36, rectangleAnchor37, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity42 = new org.jfree.chart.entity.AxisEntity(shape40, (org.jfree.chart.axis.Axis) numberAxis3D41);
//        numberAxis3D41.zoomRange(0.0d, 0.0d);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot46.configureDomainAxes();
//        numberAxis3D41.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot46);
//        org.jfree.chart.plot.PlotOrientation plotOrientation49 = combinedDomainXYPlot46.getOrientation();
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer50 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator51 = null;
//        xYAreaRenderer50.setLegendItemURLGenerator(xYSeriesLabelGenerator51);
//        java.awt.Graphics2D graphics2D53 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot54 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
//        org.jfree.chart.plot.Marker marker56 = null;
//        java.awt.geom.Rectangle2D rectangle2D57 = null;
//        xYAreaRenderer50.drawRangeMarker(graphics2D53, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot54, valueAxis55, marker56, rectangle2D57);
//        java.awt.Font font60 = xYAreaRenderer50.lookupLegendTextFont(6);
//        int int61 = xYAreaRenderer50.getPassCount();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator62 = xYAreaRenderer50.getLegendItemLabelGenerator();
//        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape64, rectangleAnchor65, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D69 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity70 = new org.jfree.chart.entity.AxisEntity(shape68, (org.jfree.chart.axis.Axis) numberAxis3D69);
//        java.awt.Stroke stroke71 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis3D69.setTickMarkStroke(stroke71);
//        xYAreaRenderer50.setBaseStroke(stroke71);
//        java.awt.Shape shape76 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor77 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape80 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape76, rectangleAnchor77, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D81 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity82 = new org.jfree.chart.entity.AxisEntity(shape80, (org.jfree.chart.axis.Axis) numberAxis3D81);
//        java.awt.Stroke stroke83 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis3D81.setTickMarkStroke(stroke83);
//        xYAreaRenderer50.setSeriesStroke(0, stroke83, false);
//        combinedDomainXYPlot46.setDomainZeroBaselineStroke(stroke83);
//        xYStepAreaRenderer12.drawDomainLine(graphics2D15, xYPlot16, (org.jfree.chart.axis.ValueAxis) periodAxis25, rectangle2D27, (double) 35L, paint34, stroke83);
//        combinedDomainXYPlot10.setRangeMinorGridlineStroke(stroke83);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(stroke14);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNull(categoryAxis31);
//        org.junit.Assert.assertNotNull(paint34);
//        org.junit.Assert.assertNotNull(shape36);
//        org.junit.Assert.assertNotNull(rectangleAnchor37);
//        org.junit.Assert.assertNotNull(shape40);
//        org.junit.Assert.assertNotNull(plotOrientation49);
//        org.junit.Assert.assertNull(font60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator62);
//        org.junit.Assert.assertNotNull(shape64);
//        org.junit.Assert.assertNotNull(rectangleAnchor65);
//        org.junit.Assert.assertNotNull(shape68);
//        org.junit.Assert.assertNotNull(stroke71);
//        org.junit.Assert.assertNotNull(shape76);
//        org.junit.Assert.assertNotNull(rectangleAnchor77);
//        org.junit.Assert.assertNotNull(shape80);
//        org.junit.Assert.assertNotNull(stroke83);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        categoryPlot0.clearAnnotations();
        java.awt.Stroke stroke19 = null;
        try {
            categoryPlot0.setRangeZeroBaselineStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape2);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "Category Plot");
        chartEntity5.setURLText("");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot3 = jFreeChart1.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint2 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.Marker marker9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        xYAreaRenderer3.drawRangeMarker(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot7, valueAxis8, marker9, rectangle2D10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot7.setRangeAxisLocation((int) (byte) 1, axisLocation13, false);
        float float16 = combinedDomainXYPlot7.getBackgroundAlpha();
        combinedDomainXYPlot7.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke19 = combinedDomainXYPlot7.getDomainZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        int int1 = color0.getTransparency();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        legendItem1.setDescription("hi!");
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        piePlot3D7.setStartAngle((double) (-1L));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        barRenderer3D12.setBaseLegendTextPaint((java.awt.Paint) color13);
        java.awt.Shape shape15 = null;
        barRenderer3D12.setBaseLegendShape(shape15);
        java.awt.Paint paint18 = barRenderer3D12.getSeriesPaint((int) '4');
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D12.setBaseFillPaint((java.awt.Paint) color19, false);
        piePlot3D7.setBaseSectionPaint((java.awt.Paint) color19);
        xYPlot5.setDomainMinorGridlinePaint((java.awt.Paint) color19);
        legendItem1.setLabelPaint((java.awt.Paint) color19);
        org.jfree.data.time.TimeSeries timeSeries25 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection(timeSeries25);
        legendItem1.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color3 = java.awt.Color.MAGENTA;
//        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
//        java.awt.Shape shape5 = null;
//        barRenderer3D2.setBaseLegendShape(shape5);
//        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        long long13 = day11.getFirstMillisecond();
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day15);
//        boolean boolean18 = periodAxis17.isAutoRange();
//        periodAxis17.setMinorTickMarksVisible(true);
//        java.awt.Font font21 = periodAxis17.getLabelFont();
//        barRenderer3D2.setBaseItemLabelFont(font21);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
//        barRenderer3D2.setSeriesItemLabelGenerator(4, categoryItemLabelGenerator24);
//        boolean boolean26 = barRenderer3D2.getShadowsVisible();
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNull(paint8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(font21);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYAreaRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYAreaRenderer2.drawRangeMarker(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, valueAxis7, marker8, rectangle2D9);
        java.awt.Font font12 = xYAreaRenderer2.lookupLegendTextFont(6);
        boolean boolean14 = xYAreaRenderer2.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Shape shape15 = xYAreaRenderer2.getLegendArea();
        multiplePiePlot0.setLegendItemShape(shape15);
        java.lang.String str17 = multiplePiePlot0.getPlotType();
        multiplePiePlot0.setLimit((double) 500);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Multiple Pie Plot" + "'", str17.equals("Multiple Pie Plot"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.setTickLabelsVisible(false);
        double double10 = numberAxis3D6.getLabelAngle();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double3 = rectangleInsets2.getLeft();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        boolean boolean16 = textTitle14.equals((java.lang.Object) "TimePeriodAnchor.MIDDLE");
//        textTitle14.visible = false;
//        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle14.getPosition();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge19);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.LegendItem legendItem3 = xYLineAndShapeRenderer0.getLegendItem(2958465, (int) (short) 100);
        xYLineAndShapeRenderer0.setUseOutlinePaint(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer6.setLegendItemURLGenerator(xYSeriesLabelGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        xYAreaRenderer6.drawRangeMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, valueAxis11, marker12, rectangle2D13);
        java.awt.Font font16 = xYAreaRenderer6.lookupLegendTextFont(6);
        int int17 = xYAreaRenderer6.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator18 = xYAreaRenderer6.getLegendItemLabelGenerator();
        xYLineAndShapeRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator18);
        boolean boolean20 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean5 = xYLineAndShapeRenderer4.getDrawSeriesLineAsPath();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator7 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_LEFT");
        xYLineAndShapeRenderer4.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer(2019, xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape13, (org.jfree.chart.axis.Axis) numberAxis3D14);
        numberAxis3D14.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range19 = polarPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D14.getTickLabelInsets();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset26 = combinedDomainXYPlot25.getDataset();
        boolean boolean27 = combinedDomainXYPlot25.isRangeZoomable();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot25.setRangeTickBandPaint(paint28);
        boolean boolean30 = combinedDomainXYPlot25.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = combinedDomainXYPlot25.getRangeAxisEdge();
        org.jfree.data.time.TimeSeries timeSeries32 = null;
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection(timeSeries32, timeZone33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection34, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, polarItemRenderer37);
        java.awt.Font font39 = polarPlot38.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot38.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit40);
        polarPlot38.setAngleGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        java.awt.geom.Point2D point2D48 = null;
        polarPlot38.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo47, point2D48);
        try {
            org.jfree.chart.axis.AxisState axisState50 = numberAxis3D14.draw(graphics2D21, 4.0d, rectangle2D23, rectangle2D24, rectangleEdge31, plotRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(dateTickUnit40);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        java.lang.Object obj1 = null;
        boolean boolean2 = standardXYSeriesLabelGenerator0.equals(obj1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape5);
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries7);
        org.jfree.chart.entity.XYItemEntity xYItemEntity13 = new org.jfree.chart.entity.XYItemEntity(shape5, (org.jfree.data.xy.XYDataset) timeSeriesCollection8, 1, 2958465, "", "RectangleEdge.BOTTOM");
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        try {
            java.lang.String str16 = standardXYSeriesLabelGenerator0.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection8, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (7).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator5);
        double double7 = piePlot3D1.getShadowYOffset();
        piePlot3D1.setMaximumLabelWidth((double) 1577894400001L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset9, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeWidth(range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toFixedWidth(0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("hi!");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("PlotOrientation.VERTICAL");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.util.LogFormat logFormat1 = new org.jfree.chart.util.LogFormat();
        logFormat1.setMinimumFractionDigits(100);
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat1, (java.text.NumberFormat) logFormat4);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator7 = logFormat1.formatToCharacterIterator((java.lang.Object) tickUnitSource6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity8 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) numberAxis3D7);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape6, 0.0d, (float) (byte) 0, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13, timeZone14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState17 = timeSeriesCollection15.getSelectionState();
        combinedDomainXYPlot4.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState17);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.data.time.TimeSeries timeSeries22 = null;
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeSeries22, timeZone23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, polarItemRenderer27);
        java.awt.Paint paint29 = polarPlot28.getAngleLabelPaint();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape31, rectangleAnchor32, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity37 = new org.jfree.chart.entity.AxisEntity(shape35, (org.jfree.chart.axis.Axis) numberAxis3D36);
        numberAxis3D36.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range41 = polarPlot28.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D36);
        org.jfree.chart.entity.AxisEntity axisEntity43 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D36, "Pie 3D Plot");
        java.lang.String str44 = axisEntity43.getToolTipText();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Pie 3D Plot" + "'", str44.equals("Pie 3D Plot"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer3D2.getItemLabelGenerator((int) (byte) -1, (int) (byte) -1, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = barRenderer3D2.getPlot();
        java.awt.Paint paint19 = barRenderer3D2.getItemPaint(13, 0, false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator22 = null;
        xYAreaRenderer21.setLegendItemURLGenerator(xYSeriesLabelGenerator22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        xYAreaRenderer21.drawRangeMarker(graphics2D24, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot25, valueAxis26, marker27, rectangle2D28);
        java.awt.Shape shape30 = xYAreaRenderer21.getLegendArea();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator33 = null;
        xYAreaRenderer32.setLegendItemURLGenerator(xYSeriesLabelGenerator33);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = xYAreaRenderer32.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = xYAreaRenderer32.getSeriesNegativeItemLabelPosition((int) (short) 1);
        xYAreaRenderer21.setSeriesNegativeItemLabelPosition((int) (byte) 10, itemLabelPosition40);
        try {
            barRenderer3D2.setSeriesNegativeItemLabelPosition((int) (short) -1, itemLabelPosition40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryPlot15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(xYURLGenerator38);
        org.junit.Assert.assertNotNull(itemLabelPosition40);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        double double7 = barRenderer3D2.getMinimumBarLength();
        java.awt.Shape shape11 = barRenderer3D2.getItemShape((int) (byte) 1, (int) 'a', false);
        double double12 = barRenderer3D2.getYOffset();
        boolean boolean13 = barRenderer3D2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        barRenderer3D8.setBaseLegendTextPaint((java.awt.Paint) color9);
        java.awt.Shape shape11 = null;
        barRenderer3D8.setBaseLegendShape(shape11);
        java.awt.Paint paint14 = barRenderer3D8.getSeriesPaint((int) '4');
        java.awt.Color color15 = java.awt.Color.RED;
        barRenderer3D8.setWallPaint((java.awt.Paint) color15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        barRenderer3D8.notifyListeners(rendererChangeEvent17);
        java.awt.Font font20 = barRenderer3D8.getLegendTextFont(255);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D8);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(font20);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        int int9 = combinedDomainXYPlot4.getWeight();
        int int10 = combinedDomainXYPlot4.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleAnchor.TOP_RIGHT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        long long13 = day11.getFirstMillisecond();
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day15);
//        periodAxis8.setLast((org.jfree.data.time.RegularTimePeriod) day11);
//        periodAxis8.setFixedAutoRange(1.0E-5d);
//        org.jfree.data.Range range21 = periodAxis8.getRange();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(range21);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNull(xYDataset1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        paintMap0.put((java.lang.Comparable) 100.0f, (java.awt.Paint) color2);
        java.lang.Comparable comparable4 = null;
        try {
            java.awt.Paint paint5 = paintMap0.getPaint(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYAreaRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYAreaRenderer2.drawRangeMarker(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, valueAxis7, marker8, rectangle2D9);
        java.awt.Font font12 = xYAreaRenderer2.lookupLegendTextFont(6);
        boolean boolean14 = xYAreaRenderer2.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Shape shape15 = xYAreaRenderer2.getLegendArea();
        multiplePiePlot0.setLegendItemShape(shape15);
        org.jfree.data.xy.XYDataItem xYDataItem19 = new org.jfree.data.xy.XYDataItem((double) (short) -1, 10.0d);
        boolean boolean20 = xYDataItem19.isSelected();
        java.lang.Number number21 = xYDataItem19.getX();
        xYDataItem19.setY((double) (short) 1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) xYDataItem19);
        java.lang.String str25 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Multiple Pie Plot" + "'", str25.equals("Multiple Pie Plot"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            double double10 = timeSeriesCollection2.getXValue((int) '#', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        int int10 = dateTickUnit8.getCalendarField();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color16 = java.awt.Color.MAGENTA;
        barRenderer3D15.setBaseLegendTextPaint((java.awt.Paint) color16);
        java.awt.Shape shape18 = null;
        barRenderer3D15.setBaseLegendShape(shape18);
        java.awt.Paint paint21 = barRenderer3D15.getSeriesPaint((int) '4');
        java.awt.Color color22 = java.awt.Color.RED;
        barRenderer3D15.setWallPaint((java.awt.Paint) color22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer3D15.notifyListeners(rendererChangeEvent24);
        java.awt.Font font27 = barRenderer3D15.getLegendTextFont(255);
        int int28 = categoryPlot11.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15);
        categoryPlot11.clearAnnotations();
        java.awt.Paint paint30 = categoryPlot11.getDomainCrosshairPaint();
        int int31 = categoryPlot11.getDatasetCount();
        boolean boolean32 = categoryPlot11.isOutlineVisible();
        boolean boolean33 = dateTickUnit8.equals((java.lang.Object) boolean32);
        double double34 = dateTickUnit8.getSize();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 8.64E7d + "'", double34 == 8.64E7d);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        java.awt.Color color17 = java.awt.Color.MAGENTA;
//        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color17);
//        int int19 = day11.compareTo((java.lang.Object) blockBorder18);
//        java.util.TimeZone timeZone20 = null;
//        java.util.Locale locale21 = null;
//        try {
//            org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day7, (org.jfree.data.time.RegularTimePeriod) day11, timeZone20, locale21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
//        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.plot.Marker marker6 = null;
//        java.awt.geom.Rectangle2D rectangle2D7 = null;
//        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
//        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
//        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
//        boolean boolean14 = combinedDomainXYPlot4.isDomainCrosshairVisible();
//        java.lang.String str15 = combinedDomainXYPlot4.getPlotType();
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
//        xYAreaRenderer16.setLegendItemURLGenerator(xYSeriesLabelGenerator17);
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYAreaRenderer16.getURLGenerator(0, 100, true);
//        org.jfree.chart.LegendItem legendItem25 = xYAreaRenderer16.getLegendItem((int) '#', (int) (byte) 1);
//        int int26 = combinedDomainXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer16);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer28 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator29 = null;
//        xYAreaRenderer28.setLegendItemURLGenerator(xYSeriesLabelGenerator29);
//        java.awt.Graphics2D graphics2D31 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
//        org.jfree.chart.plot.Marker marker34 = null;
//        java.awt.geom.Rectangle2D rectangle2D35 = null;
//        xYAreaRenderer28.drawRangeMarker(graphics2D31, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot32, valueAxis33, marker34, rectangle2D35);
//        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        combinedDomainXYPlot32.setRangeAxisLocation((int) (byte) 1, axisLocation38, false);
//        float float41 = combinedDomainXYPlot32.getBackgroundImageAlpha();
//        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        int int45 = day44.getMonth();
//        long long46 = day44.getFirstMillisecond();
//        java.util.Date date47 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
//        int int49 = day48.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day44, (org.jfree.data.time.RegularTimePeriod) day48);
//        boolean boolean51 = periodAxis50.isAutoRange();
//        periodAxis50.setRangeWithMargins((double) (-1), (double) 1560409200000L);
//        periodAxis50.configure();
//        java.awt.geom.Rectangle2D rectangle2D56 = null;
//        try {
//            xYAreaRenderer16.drawDomainGridLine(graphics2D27, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot32, (org.jfree.chart.axis.ValueAxis) periodAxis50, rectangle2D56, (double) 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(axisLocation10);
//        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Combined_Domain_XYPlot" + "'", str15.equals("Combined_Domain_XYPlot"));
//        org.junit.Assert.assertNull(xYURLGenerator22);
//        org.junit.Assert.assertNull(legendItem25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(axisLocation38);
//        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.5f + "'", float41 == 0.5f);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560409200000L + "'", long46 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = java.awt.Color.RED;
        barRenderer3D2.setWallPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = barRenderer3D2.getPlot();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryPlot11);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color4 = java.awt.Color.MAGENTA;
//        barRenderer3D3.setBaseLegendTextPaint((java.awt.Paint) color4);
//        java.awt.Shape shape6 = null;
//        barRenderer3D3.setBaseLegendShape(shape6);
//        java.awt.Paint paint9 = barRenderer3D3.getSeriesPaint((int) '4');
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        int int13 = day12.getMonth();
//        long long14 = day12.getFirstMillisecond();
//        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day16);
//        boolean boolean19 = periodAxis18.isAutoRange();
//        periodAxis18.setMinorTickMarksVisible(true);
//        java.awt.Font font22 = periodAxis18.getLabelFont();
//        barRenderer3D3.setBaseItemLabelFont(font22);
//        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("Pie 3D Plot", font22);
//        labelBlock24.setToolTipText("Pie 3D Plot");
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNull(paint9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(font22);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        int int6 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
        org.jfree.chart.event.ChartProgressListener chartProgressListener8 = null;
        jFreeChart4.addProgressListener(chartProgressListener8);
        java.lang.Object obj10 = jFreeChart4.getTextAntiAlias();
        jFreeChart4.clearSubtitles();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator3, true);
        java.awt.Shape shape7 = barRenderer3D2.lookupSeriesShape((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer3D2.getSeriesNegativeItemLabelPosition(3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = null;
        xYAreaRenderer11.setLegendItemURLGenerator(xYSeriesLabelGenerator12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYAreaRenderer11.drawRangeMarker(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator21 = xYAreaRenderer11.getSeriesItemLabelGenerator((int) (short) 0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator24 = null;
        xYAreaRenderer23.setLegendItemURLGenerator(xYSeriesLabelGenerator24);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = xYAreaRenderer23.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYAreaRenderer23.getSeriesNegativeItemLabelPosition((int) (short) 1);
        xYAreaRenderer11.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition31, true);
        barRenderer3D2.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition31);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(xYItemLabelGenerator21);
        org.junit.Assert.assertNull(xYURLGenerator29);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Stroke stroke3 = null;
        legendItem1.setOutlineStroke(stroke3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem1.getFillPaintTransformer();
        java.awt.Paint paint6 = legendItem1.getOutlinePaint();
        legendItem1.setToolTipText("RectangleEdge.BOTTOM");
        legendItem1.setToolTipText("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle3 = null;
        jFreeChart1.setTitle(textTitle3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot9.setRangeAxisLocation((int) (byte) 1, axisLocation15, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedDomainXYPlot9.getInsets();
        java.lang.String str19 = rectangleInsets18.toString();
        jFreeChart1.setPadding(rectangleInsets18);
        java.awt.Paint paint21 = jFreeChart1.getBorderPaint();
        java.awt.Paint paint22 = jFreeChart1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str19.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        boolean boolean8 = polarPlot6.isRadiusGridlinesVisible();
        org.jfree.chart.axis.TickUnit tickUnit9 = polarPlot6.getAngleTickUnit();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot6.getAxis();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 255, (float) ' ');
        valueAxis10.setRightArrow(shape13);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(tickUnit9);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { 1 };
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray0, comparableArray2, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(5);
        boolean boolean2 = xYStepAreaRenderer1.getPlotArea();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment4, (double) 6, (double) 0);
        columnArrangement7.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) 6, (double) 0);
        columnArrangement13.clear();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1, (org.jfree.chart.block.Arrangement) columnArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = null;
        xYAreaRenderer18.setLegendItemURLGenerator(xYSeriesLabelGenerator19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYAreaRenderer18.drawRangeMarker(graphics2D21, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot22, valueAxis23, marker24, rectangle2D25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = null;
        combinedDomainXYPlot22.setDrawingSupplier(drawingSupplier27);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = null;
        combinedDomainXYPlot22.datasetChanged(datasetChangeEvent29);
        combinedDomainXYPlot22.setNoDataMessage("-10,1,0,-19,-20,-19,-20,-19");
        try {
            java.lang.Object obj33 = legendTitle15.draw(graphics2D16, rectangle2D17, (java.lang.Object) combinedDomainXYPlot22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        barRenderer3D8.setBaseItemLabelGenerator(categoryItemLabelGenerator9, true);
        java.awt.Shape shape13 = barRenderer3D8.lookupSeriesShape((int) '#');
        xYAreaRenderer4.setSeriesShape((int) (byte) 1, shape13, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
        xYAreaRenderer16.setLegendItemURLGenerator(xYSeriesLabelGenerator17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYAreaRenderer16.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, valueAxis21, marker22, rectangle2D23);
        java.awt.Font font26 = xYAreaRenderer16.lookupLegendTextFont(6);
        int int27 = xYAreaRenderer16.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator28 = xYAreaRenderer16.getLegendItemLabelGenerator();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape30, rectangleAnchor31, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity36 = new org.jfree.chart.entity.AxisEntity(shape34, (org.jfree.chart.axis.Axis) numberAxis3D35);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D35.setTickMarkStroke(stroke37);
        xYAreaRenderer16.setBaseStroke(stroke37);
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape42, rectangleAnchor43, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity48 = new org.jfree.chart.entity.AxisEntity(shape46, (org.jfree.chart.axis.Axis) numberAxis3D47);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D47.setTickMarkStroke(stroke49);
        xYAreaRenderer16.setSeriesStroke(0, stroke49, false);
        java.awt.Paint paint56 = xYAreaRenderer16.getItemOutlinePaint(6, 0, false);
        try {
            org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem(attributedString0, "VerticalAlignment.CENTER", "Polar Plot", "DomainOrder.ASCENDING", shape13, paint56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(font26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean11 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        valueMarker10.setLabel("hi!");
        java.lang.Object obj14 = valueMarker10.clone();
        java.lang.Class class15 = null;
        try {
            java.util.EventListener[] eventListenerArray16 = valueMarker10.getListeners(class15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Font font1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2, timeZone3);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, polarItemRenderer7);
        java.awt.Paint paint9 = polarPlot8.getAngleLabelPaint();
        java.awt.Paint paint10 = polarPlot8.getRadiusGridlinePaint();
        java.awt.Paint paint11 = polarPlot8.getAngleLabelPaint();
        try {
            org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("index.html", font1, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        java.lang.String str2 = numberFormat0.format(0L);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "$0.00" + "'", str2.equals("$0.00"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.LogFormat logFormat2 = new org.jfree.chart.util.LogFormat();
        logFormat2.setMinimumFractionDigits(100);
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator6 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat2, (java.text.NumberFormat) logFormat5);
        org.jfree.chart.util.LogFormat logFormat7 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie 3D Plot", (java.text.NumberFormat) logFormat2, (java.text.NumberFormat) logFormat7);
        java.text.AttributedString attributedString10 = null;
        standardPieSectionLabelGenerator8.setAttributedLabel(255, attributedString10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.String str14 = standardPieSectionLabelGenerator8.generateSectionLabel(pieDataset12, (java.lang.Comparable) 8.0d);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNull(valueAxis2);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        periodAxis8.setRangeWithMargins((double) (-1), (double) 1560409200000L);
//        periodAxis8.configure();
//        org.jfree.data.Range range14 = periodAxis8.getDefaultAutoRange();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(range14);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot0.setRangeTickBandPaint(paint3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot9.setRangeAxisLocation((int) (byte) 1, axisLocation15, false);
        float float18 = combinedDomainXYPlot9.getBackgroundAlpha();
        combinedDomainXYPlot9.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke21 = combinedDomainXYPlot9.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator23 = null;
        xYAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.Marker marker28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        xYAreaRenderer22.drawRangeMarker(graphics2D25, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot26, valueAxis27, marker28, rectangle2D29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot26.setRangeAxisLocation((int) (byte) 1, axisLocation32, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = combinedDomainXYPlot26.getInsets();
        double double37 = rectangleInsets35.calculateTopInset((double) (byte) 100);
        org.jfree.chart.block.LineBorder lineBorder38 = new org.jfree.chart.block.LineBorder(paint3, stroke21, rectangleInsets35);
        java.awt.Paint paint39 = lineBorder38.getPaint();
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        polarPlot6.setAngleGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Point2D point2D16 = null;
        polarPlot6.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo15, point2D16);
        java.awt.geom.Point2D point2D18 = null;
        try {
            int int19 = plotRenderingInfo15.getSubplotIndex(point2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.lang.String str3 = xYSeries2.getDescription();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.remove((java.lang.Number) 64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setSeriesItemLabelGenerator(6, categoryItemLabelGenerator13);
        barRenderer3D2.setBaseSeriesVisible(true);
        java.awt.Shape shape18 = barRenderer3D2.lookupSeriesShape(13);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.LegendItem legendItem3 = xYLineAndShapeRenderer0.getLegendItem(2958465, (int) (short) 100);
        boolean boolean4 = xYLineAndShapeRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = barRenderer3D4.getDrawingSupplier();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        int int21 = categoryPlot20.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color25 = java.awt.Color.MAGENTA;
        barRenderer3D24.setBaseLegendTextPaint((java.awt.Paint) color25);
        java.awt.Shape shape27 = null;
        barRenderer3D24.setBaseLegendShape(shape27);
        java.awt.Paint paint30 = barRenderer3D24.getSeriesPaint((int) '4');
        java.awt.Color color31 = java.awt.Color.RED;
        barRenderer3D24.setWallPaint((java.awt.Paint) color31);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        barRenderer3D24.notifyListeners(rendererChangeEvent33);
        java.awt.Font font36 = barRenderer3D24.getLegendTextFont(255);
        int int37 = categoryPlot20.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D24);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot20.getDomainAxis();
        categoryPlot20.mapDatasetToRangeAxis((int) (byte) 100, 0);
        java.util.List list42 = categoryPlot20.getCategories();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int46 = color45.getBlue();
        java.awt.Stroke stroke47 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            barRenderer3D4.drawDomainLine(graphics2D19, categoryPlot20, rectangle2D43, (double) 100.0f, (java.awt.Paint) color45, stroke47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(font36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNull(list42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(stroke47);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//        java.awt.Stroke stroke2 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(0);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.XYPlot xYPlot4 = null;
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        long long9 = day7.getFirstMillisecond();
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day7, (org.jfree.data.time.RegularTimePeriod) day11);
//        periodAxis13.configure();
//        java.awt.geom.Rectangle2D rectangle2D15 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot17.getDomainAxis(10);
//        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
//        categoryPlot17.setFixedRangeAxisSpace(axisSpace20);
//        java.awt.Paint paint22 = categoryPlot17.getRangeGridlinePaint();
//        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, rectangleAnchor25, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape28, (org.jfree.chart.axis.Axis) numberAxis3D29);
//        numberAxis3D29.zoomRange(0.0d, 0.0d);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot34.configureDomainAxes();
//        numberAxis3D29.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot34);
//        org.jfree.chart.plot.PlotOrientation plotOrientation37 = combinedDomainXYPlot34.getOrientation();
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer38 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator39 = null;
//        xYAreaRenderer38.setLegendItemURLGenerator(xYSeriesLabelGenerator39);
//        java.awt.Graphics2D graphics2D41 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
//        org.jfree.chart.plot.Marker marker44 = null;
//        java.awt.geom.Rectangle2D rectangle2D45 = null;
//        xYAreaRenderer38.drawRangeMarker(graphics2D41, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot42, valueAxis43, marker44, rectangle2D45);
//        java.awt.Font font48 = xYAreaRenderer38.lookupLegendTextFont(6);
//        int int49 = xYAreaRenderer38.getPassCount();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator50 = xYAreaRenderer38.getLegendItemLabelGenerator();
//        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape52, rectangleAnchor53, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity58 = new org.jfree.chart.entity.AxisEntity(shape56, (org.jfree.chart.axis.Axis) numberAxis3D57);
//        java.awt.Stroke stroke59 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis3D57.setTickMarkStroke(stroke59);
//        xYAreaRenderer38.setBaseStroke(stroke59);
//        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape64, rectangleAnchor65, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D69 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity70 = new org.jfree.chart.entity.AxisEntity(shape68, (org.jfree.chart.axis.Axis) numberAxis3D69);
//        java.awt.Stroke stroke71 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis3D69.setTickMarkStroke(stroke71);
//        xYAreaRenderer38.setSeriesStroke(0, stroke71, false);
//        combinedDomainXYPlot34.setDomainZeroBaselineStroke(stroke71);
//        xYStepAreaRenderer0.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis13, rectangle2D15, (double) 35L, paint22, stroke71);
//        periodAxis13.setVerticalTickLabels(true);
//        java.util.Date date79 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date79);
//        int int81 = day80.getMonth();
//        java.awt.Color color86 = java.awt.Color.MAGENTA;
//        org.jfree.chart.block.BlockBorder blockBorder87 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color86);
//        int int88 = day80.compareTo((java.lang.Object) blockBorder87);
//        periodAxis13.setLast((org.jfree.data.time.RegularTimePeriod) day80);
//        org.junit.Assert.assertNotNull(stroke2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNull(categoryAxis19);
//        org.junit.Assert.assertNotNull(paint22);
//        org.junit.Assert.assertNotNull(shape24);
//        org.junit.Assert.assertNotNull(rectangleAnchor25);
//        org.junit.Assert.assertNotNull(shape28);
//        org.junit.Assert.assertNotNull(plotOrientation37);
//        org.junit.Assert.assertNull(font48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator50);
//        org.junit.Assert.assertNotNull(shape52);
//        org.junit.Assert.assertNotNull(rectangleAnchor53);
//        org.junit.Assert.assertNotNull(shape56);
//        org.junit.Assert.assertNotNull(stroke59);
//        org.junit.Assert.assertNotNull(shape64);
//        org.junit.Assert.assertNotNull(rectangleAnchor65);
//        org.junit.Assert.assertNotNull(shape68);
//        org.junit.Assert.assertNotNull(stroke71);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 6 + "'", int81 == 6);
//        org.junit.Assert.assertNotNull(color86);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3D4.getLegendLabelGenerator();
        boolean boolean6 = datasetRenderingOrder2.equals((java.lang.Object) pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(500);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color3 = java.awt.Color.MAGENTA;
//        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
//        java.awt.Shape shape5 = null;
//        barRenderer3D2.setBaseLegendShape(shape5);
//        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        long long13 = day11.getFirstMillisecond();
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day15);
//        boolean boolean18 = periodAxis17.isAutoRange();
//        periodAxis17.setMinorTickMarksVisible(true);
//        java.awt.Font font21 = periodAxis17.getLabelFont();
//        barRenderer3D2.setBaseItemLabelFont(font21);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
//        barRenderer3D2.setSeriesItemLabelGenerator(4, categoryItemLabelGenerator24);
//        boolean boolean28 = barRenderer3D2.getItemVisible(2019, (int) (byte) -1);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNull(paint8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(font21);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        periodAxis8.setRangeWithMargins((double) (-1), (double) 1560409200000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = periodAxis8.getFirst();
//        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray14 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
//        periodAxis8.setLabelInfo(periodAxisLabelInfoArray14);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray14);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Shape shape9 = xYAreaRenderer0.getLegendArea();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = xYAreaRenderer0.getToolTipGenerator((int) (short) 1, (int) (byte) 0, true);
        java.awt.Stroke stroke15 = xYAreaRenderer0.getSeriesStroke(0);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(xYToolTipGenerator13);
        org.junit.Assert.assertNull(stroke15);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.zoomRange(0.0d, 0.0d);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot11.configureDomainAxes();
        numberAxis3D6.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot11);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = combinedDomainXYPlot11.getOrientation();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = null;
        xYAreaRenderer15.setLegendItemURLGenerator(xYSeriesLabelGenerator16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYAreaRenderer15.drawRangeMarker(graphics2D18, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot19, valueAxis20, marker21, rectangle2D22);
        java.awt.Font font25 = xYAreaRenderer15.lookupLegendTextFont(6);
        int int26 = xYAreaRenderer15.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = xYAreaRenderer15.getLegendItemLabelGenerator();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape33, (org.jfree.chart.axis.Axis) numberAxis3D34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D34.setTickMarkStroke(stroke36);
        xYAreaRenderer15.setBaseStroke(stroke36);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape41, rectangleAnchor42, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity47 = new org.jfree.chart.entity.AxisEntity(shape45, (org.jfree.chart.axis.Axis) numberAxis3D46);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D46.setTickMarkStroke(stroke48);
        xYAreaRenderer15.setSeriesStroke(0, stroke48, false);
        combinedDomainXYPlot11.setDomainZeroBaselineStroke(stroke48);
        combinedDomainXYPlot11.setDomainCrosshairValue((double) '4');
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(font25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = combinedDomainXYPlot1.getDataset();
        boolean boolean3 = combinedDomainXYPlot1.isRangeZoomable();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot1.setRangeTickBandPaint(paint4);
        boolean boolean6 = combinedDomainXYPlot1.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = combinedDomainXYPlot1.getRangeAxisEdge();
        try {
            double double8 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color22);
        barRenderer3D4.setWallPaint((java.awt.Paint) color22);
        java.awt.Font font28 = barRenderer3D4.getItemLabelFont(2, 7, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("");
        boolean boolean5 = legendItem4.isShapeFilled();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color6);
        legendItem4.setFillPaint((java.awt.Paint) color6);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("-10,1,0,-19,-20,-19,-20,-19", font2, (java.awt.Paint) color6);
        java.awt.Color color10 = java.awt.Color.getColor("Pie 3D Plot", color6);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
//        numberAxis3D0.setAutoRange(false);
//        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D0.setTickLabelFont(font3);
//        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D0);
//        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
//        int int8 = categoryPlot7.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color12 = java.awt.Color.MAGENTA;
//        barRenderer3D11.setBaseLegendTextPaint((java.awt.Paint) color12);
//        java.awt.Shape shape14 = null;
//        barRenderer3D11.setBaseLegendShape(shape14);
//        java.awt.Paint paint17 = barRenderer3D11.getSeriesPaint((int) '4');
//        java.awt.Color color18 = java.awt.Color.RED;
//        barRenderer3D11.setWallPaint((java.awt.Paint) color18);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
//        barRenderer3D11.notifyListeners(rendererChangeEvent20);
//        java.awt.Font font23 = barRenderer3D11.getLegendTextFont(255);
//        int int24 = categoryPlot7.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
//        java.awt.Stroke stroke25 = categoryPlot7.getRangeCrosshairStroke();
//        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        int int29 = day28.getMonth();
//        long long30 = day28.getFirstMillisecond();
//        java.util.Date date31 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        int int33 = day32.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) day32);
//        boolean boolean35 = periodAxis34.isAutoRange();
//        periodAxis34.setMinorTickMarksVisible(true);
//        java.awt.Font font38 = periodAxis34.getLabelFont();
//        double double39 = periodAxis34.getLowerBound();
//        int int40 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis34);
//        int int41 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis34);
//        xYPlot6.clearDomainMarkers((int) (short) -1);
//        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot6.getRangeAxisLocation((int) (short) 0);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
//        java.awt.geom.Point2D point2D50 = null;
//        xYPlot6.zoomDomainAxes((double) (-1), 0.0d, plotRenderingInfo49, point2D50);
//        java.awt.geom.Point2D point2D52 = null;
//        try {
//            org.jfree.chart.plot.XYPlot xYPlot53 = combinedRangeXYPlot5.findSubplot(plotRenderingInfo49, point2D52);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(font3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNull(paint17);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNull(font23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(stroke25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(font38);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNotNull(axisLocation45);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        java.lang.String str5 = categoryPlot0.getPlotType();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(7, layer7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot9.getDomainGridlinePosition();
        categoryPlot0.setDomainGridlinePosition(categoryAnchor14);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot16.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedDomainXYPlot16.getRangeAxisLocation((int) 'a');
        categoryPlot0.setDomainAxisLocation(axisLocation19);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
//        int int2 = categoryPlot1.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color6 = java.awt.Color.MAGENTA;
//        barRenderer3D5.setBaseLegendTextPaint((java.awt.Paint) color6);
//        java.awt.Shape shape8 = null;
//        barRenderer3D5.setBaseLegendShape(shape8);
//        java.awt.Paint paint11 = barRenderer3D5.getSeriesPaint((int) '4');
//        java.awt.Color color12 = java.awt.Color.RED;
//        barRenderer3D5.setWallPaint((java.awt.Paint) color12);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
//        barRenderer3D5.notifyListeners(rendererChangeEvent14);
//        java.awt.Font font17 = barRenderer3D5.getLegendTextFont(255);
//        int int18 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
//        java.awt.Stroke stroke19 = categoryPlot1.getRangeCrosshairStroke();
//        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        int int23 = day22.getMonth();
//        long long24 = day22.getFirstMillisecond();
//        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        int int27 = day26.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day26);
//        boolean boolean29 = periodAxis28.isAutoRange();
//        periodAxis28.setMinorTickMarksVisible(true);
//        java.awt.Font font32 = periodAxis28.getLabelFont();
//        double double33 = periodAxis28.getLowerBound();
//        int int34 = categoryPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis28);
//        int int35 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis28);
//        boolean boolean36 = periodAxis28.isAxisLineVisible();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNull(paint11);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNull(font17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(font32);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font10 = barRenderer3D2.getLegendTextFont((int) (short) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        int int15 = categoryPlot14.getCrosshairDatasetIndex();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getDomainMarkers(layer16);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, rectangleAnchor20, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape23, (org.jfree.chart.axis.Axis) numberAxis3D24);
        numberAxis3D24.setTickLabelsVisible(false);
        java.awt.Color color28 = java.awt.Color.MAGENTA;
        numberAxis3D24.setTickLabelPaint((java.awt.Paint) color28);
        numberAxis3D24.configure();
        boolean boolean31 = numberAxis3D24.getAutoRangeStickyZero();
        java.lang.Object obj32 = numberAxis3D24.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        categoryPlot33.setDomainAxis(0, categoryAxis35, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot33.zoomDomainAxes(0.0d, plotRenderingInfo39, point2D40);
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean44 = categoryPlot33.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker43);
        valueMarker43.setLabel("hi!");
        java.lang.Object obj47 = valueMarker43.clone();
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        try {
            barRenderer3D2.drawRangeMarker(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.plot.Marker) valueMarker43, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = barRenderer3D4.getDrawingSupplier();
        barRenderer3D4.setShadowVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(drawingSupplier18);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("#000080", "-10,1,0,-19,-20,-19,-20,-19", "TextAnchor.TOP_LEFT", "SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape13, (org.jfree.chart.axis.Axis) numberAxis3D14);
        numberAxis3D14.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range19 = polarPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D14.getTickLabelInsets();
        numberAxis3D14.setLabel("Pie 3D Plot");
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis3D14.setTickLabelFont(font23);
        org.jfree.chart.plot.Plot plot25 = numberAxis3D14.getPlot();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(plot25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 100.0f, true);
        java.util.Date date4 = dateRange0.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 100.0d);
        double double7 = dateRange0.getLowerBound();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color4 = java.awt.Color.MAGENTA;
//        barRenderer3D3.setBaseLegendTextPaint((java.awt.Paint) color4);
//        java.awt.Shape shape6 = null;
//        barRenderer3D3.setBaseLegendShape(shape6);
//        java.awt.Paint paint9 = barRenderer3D3.getSeriesPaint((int) '4');
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        int int13 = day12.getMonth();
//        long long14 = day12.getFirstMillisecond();
//        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day16);
//        boolean boolean19 = periodAxis18.isAutoRange();
//        periodAxis18.setMinorTickMarksVisible(true);
//        java.awt.Font font22 = periodAxis18.getLabelFont();
//        barRenderer3D3.setBaseItemLabelFont(font22);
//        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("Pie 3D Plot", font22);
//        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        boolean boolean26 = labelBlock24.equals((java.lang.Object) axisLocation25);
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNull(paint9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(font22);
//        org.junit.Assert.assertNotNull(axisLocation25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double[] doubleArray7 = new double[] { (short) 100, 6 };
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset9, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeWidth(range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint2.toFixedHeight((double) 6);
        double double15 = rectangleConstraint2.getWidth();
        org.jfree.data.Range range16 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "October" + "'", str2.equals("October"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYAreaRenderer0.getSeriesItemLabelGenerator((int) (short) 0);
        java.awt.Paint paint11 = null;
        try {
            xYAreaRenderer0.setBaseFillPaint(paint11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator10);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        boolean boolean12 = xYAreaRenderer0.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Shape shape13 = xYAreaRenderer0.getLegendArea();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = xYAreaRenderer0.getGradientTransformer();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer7.setLegendItemURLGenerator(xYSeriesLabelGenerator8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYAreaRenderer7.drawRangeMarker(graphics2D10, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot11, valueAxis12, marker13, rectangle2D14);
        int int16 = combinedDomainXYPlot11.getWeight();
        java.awt.Paint paint17 = combinedDomainXYPlot11.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = combinedDomainXYPlot11.getDomainAxisEdge((int) (short) 100);
        try {
            gradientXYBarPainter0.paintBar(graphics2D1, xYBarRenderer2, (int) (byte) 100, 12, true, rectangularShape6, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot1.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        combinedDomainXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = combinedDomainXYPlot0.getOrientation();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(plotOrientation5);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis8);
//        java.lang.String str11 = combinedDomainXYPlot10.getPlotType();
//        boolean boolean12 = combinedDomainXYPlot10.isDomainPannable();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Combined_Domain_XYPlot" + "'", str11.equals("Combined_Domain_XYPlot"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) ' ');
        java.util.List list10 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.LegendItem legendItem3 = xYLineAndShapeRenderer0.getLegendItem(2958465, (int) (short) 100);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = xYLineAndShapeRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        java.awt.Font font15 = xYAreaRenderer5.lookupLegendTextFont(6);
        boolean boolean17 = xYAreaRenderer5.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Shape shape18 = xYAreaRenderer5.getLegendArea();
        xYLineAndShapeRenderer0.setBaseShape(shape18, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator4);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray4 = new double[] { (short) 100, 6 };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "hi!", doubleArray5);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset6, true);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset6);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset6);
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.util.List list17 = logAxis12.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset6, list17, true);
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset6);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double[] doubleArray7 = new double[] { 0.0f, (-1), 100, (short) 0, 0.0f };
        double[] doubleArray13 = new double[] { 0.0f, (-1), 100, (short) 0, 0.0f };
        double[] doubleArray19 = new double[] { 0.0f, (-1), 100, (short) 0, 0.0f };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-10,1,0,-19,-20,-19,-20,-19", "GradientPaintTransformType.HORIZONTAL", doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
        int int19 = categoryPlot0.getCrosshairDatasetIndex();
        categoryPlot0.setAnchorValue((double) 255, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        boolean boolean8 = polarPlot6.isRadiusGridlinesVisible();
        org.jfree.chart.axis.TickUnit tickUnit9 = polarPlot6.getAngleTickUnit();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot6.getAxis();
        java.lang.Object obj11 = valueAxis10.clone();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(tickUnit9);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = periodAxis8.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis8);
//        boolean boolean11 = combinedDomainXYPlot10.canSelectByRegion();
//        java.awt.Graphics2D graphics2D12 = null;
//        java.awt.geom.Rectangle2D rectangle2D13 = null;
//        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
//        java.awt.Graphics2D graphics2D16 = null;
//        org.jfree.chart.axis.AxisState axisState17 = null;
//        java.awt.geom.Rectangle2D rectangle2D18 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
//        java.util.List list20 = logAxis15.refreshTicks(graphics2D16, axisState17, rectangle2D18, rectangleEdge19);
//        combinedDomainXYPlot10.drawRangeTickBands(graphics2D12, rectangle2D13, list20);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list20);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle3 = null;
        jFreeChart1.setTitle(textTitle3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot9.setRangeAxisLocation((int) (byte) 1, axisLocation15, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedDomainXYPlot9.getInsets();
        java.lang.String str19 = rectangleInsets18.toString();
        jFreeChart1.setPadding(rectangleInsets18);
        int int21 = jFreeChart1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str19.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100L, (double) 2958465, (double) (-1.0f), (double) 3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        java.lang.String str2 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str2.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Stroke stroke2 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(0);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYAreaRenderer5.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        combinedDomainXYPlot9.setDrawingSupplier(drawingSupplier14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYStepAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, xYDataset16, plotRenderingInfo17);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        barRenderer3D21.setBaseLegendTextPaint((java.awt.Paint) color22);
        java.awt.Shape shape24 = null;
        barRenderer3D21.setBaseLegendShape(shape24);
        java.awt.Paint paint27 = barRenderer3D21.getSeriesPaint((int) '4');
        java.awt.Font font28 = barRenderer3D21.getBaseLegendTextFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D31 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color32 = java.awt.Color.MAGENTA;
        barRenderer3D31.setBaseLegendTextPaint((java.awt.Paint) color32);
        java.awt.Shape shape34 = null;
        barRenderer3D31.setBaseLegendShape(shape34);
        java.awt.Paint paint37 = barRenderer3D31.getSeriesPaint((int) '4');
        java.awt.Color color38 = java.awt.Color.RED;
        barRenderer3D31.setWallPaint((java.awt.Paint) color38);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        barRenderer3D31.notifyListeners(rendererChangeEvent40);
        java.awt.Font font43 = barRenderer3D31.getLegendTextFont(255);
        org.jfree.chart.renderer.category.BarPainter barPainter44 = barRenderer3D31.getBarPainter();
        barRenderer3D21.setBarPainter(barPainter44);
        java.awt.Paint paint49 = barRenderer3D21.getItemOutlinePaint((int) '4', (int) (byte) 1, false);
        combinedDomainXYPlot9.setRangeCrosshairPaint(paint49);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(font28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(font43);
        org.junit.Assert.assertNotNull(barPainter44);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection2.getDomainOrder();
        java.lang.String str8 = domainOrder7.toString();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DomainOrder.ASCENDING" + "'", str8.equals("DomainOrder.ASCENDING"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        java.lang.String str8 = axisEntity7.getURLText();
        java.lang.Object obj9 = axisEntity7.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Monday" + "'", str1.equals("Monday"));
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//        boolean boolean3 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
//        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 1, 1.0f);
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        int int12 = day11.getMonth();
//        long long13 = day11.getFirstMillisecond();
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day15);
//        boolean boolean18 = periodAxis17.isAutoRange();
//        periodAxis17.setMinorTickMarksVisible(true);
//        java.awt.Font font21 = periodAxis17.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font21);
//        boolean boolean24 = textTitle22.equals((java.lang.Object) "TimePeriodAnchor.MIDDLE");
//        textTitle22.visible = false;
//        org.jfree.chart.entity.TitleEntity titleEntity28 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle22, "");
//        xYLineAndShapeRenderer2.setSeriesShape((int) (short) 0, shape7);
//        boolean boolean30 = xYLineAndShapeRenderer2.getBaseItemLabelsVisible();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(shape7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(font21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator5);
        double double7 = piePlot3D1.getShadowXOffset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator8);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer2);
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("");
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer11);
        timeSeriesCollection8.seriesChanged(seriesChangeEvent12);
        legendItem5.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection8);
        boolean boolean15 = xYLineAndShapeRenderer2.equals((java.lang.Object) legendItem5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.data.time.TimeSeries timeSeries22 = null;
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeSeries22, timeZone23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, polarItemRenderer27);
        java.awt.Paint paint29 = polarPlot28.getAngleLabelPaint();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape31, rectangleAnchor32, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity37 = new org.jfree.chart.entity.AxisEntity(shape35, (org.jfree.chart.axis.Axis) numberAxis3D36);
        numberAxis3D36.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range41 = polarPlot28.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D36);
        org.jfree.chart.entity.AxisEntity axisEntity43 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D36, "Pie 3D Plot");
        double double44 = numberAxis3D36.getUpperMargin();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2, timeZone3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer7);
        timeSeriesCollection4.seriesChanged(seriesChangeEvent8);
        legendItem1.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection4);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate12 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection4, true);
        intervalXYDelegate12.setAutoWidth(true);
        boolean boolean15 = intervalXYDelegate12.isAutoWidth();
        try {
            java.lang.Number number18 = intervalXYDelegate12.getStartX(15, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer5);
        timeSeriesCollection2.seriesChanged(seriesChangeEvent6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }
}

