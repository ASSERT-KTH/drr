import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        java.lang.String str5 = categoryPlot0.getPlotType();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        barRenderer3D8.setBaseLegendTextPaint((java.awt.Paint) color9);
        java.awt.Shape shape11 = null;
        barRenderer3D8.setBaseLegendShape(shape11);
        java.awt.Paint paint14 = barRenderer3D8.getSeriesPaint((int) '4');
        java.awt.Font font15 = barRenderer3D8.getBaseLegendTextFont();
        java.awt.Paint paint17 = barRenderer3D8.getSeriesPaint(3);
        barRenderer3D8.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer3D8.getSeriesToolTipGenerator(255);
        int int21 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D8);
        java.awt.Stroke stroke22 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.setBackgroundImageAlignment(1);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace14 = combinedDomainXYPlot4.getFixedDomainAxisSpace();
        java.awt.Paint paint15 = combinedDomainXYPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        logAxis17.setMinorTickMarkInsideLength((float) 6);
        logAxis17.setTickMarksVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setAutoRange(false);
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D22.setTickLabelFont(font25);
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D22, (double) 0.0f, 0.0d, (double) 10, 0.2d, font31);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D33.setAutoRange(false);
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D33.setTickLabelFont(font36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        java.awt.Font font39 = numberAxis3D33.getTickLabelFont();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { logAxis17, numberAxis3D22, numberAxis3D33 };
        combinedDomainXYPlot4.setRangeAxes(valueAxisArray40);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(valueAxisArray40);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        boolean boolean4 = lineBorder0.equals((java.lang.Object) multiplePiePlot1);
        java.awt.Paint paint5 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        boolean boolean14 = combinedDomainXYPlot4.isDomainCrosshairVisible();
        java.lang.String str15 = combinedDomainXYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
        xYAreaRenderer16.setLegendItemURLGenerator(xYSeriesLabelGenerator17);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYAreaRenderer16.getURLGenerator(0, 100, true);
        org.jfree.chart.LegendItem legendItem25 = xYAreaRenderer16.getLegendItem((int) '#', (int) (byte) 1);
        int int26 = combinedDomainXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = combinedDomainXYPlot4.getRangeAxisEdge(0);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Combined_Domain_XYPlot" + "'", str15.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 1560495599999L;
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font13);
//        boolean boolean16 = textTitle14.equals((java.lang.Object) "TimePeriodAnchor.MIDDLE");
//        textTitle14.visible = false;
//        java.awt.geom.Rectangle2D rectangle2D19 = textTitle14.getBounds();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(rectangle2D19);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYAreaRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 1);
        java.awt.Shape shape9 = xYAreaRenderer0.getLegendArea();
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 60000L);
        double double3 = dateRange2.getLowerBound();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, (double) 100.0f, true);
        java.util.Date date8 = dateRange4.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint11.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Font font10 = xYAreaRenderer0.lookupLegendTextFont(6);
        java.lang.Boolean boolean12 = xYAreaRenderer0.getSeriesVisible(0);
        java.awt.Stroke stroke13 = xYAreaRenderer0.getBaseOutlineStroke();
        java.lang.Object obj14 = xYAreaRenderer0.clone();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor16);
        xYAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        java.lang.String str8 = axisEntity7.getURLText();
        java.lang.String str9 = axisEntity7.getShapeCoords();
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10, timeZone11);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer15);
        boolean boolean17 = axisEntity7.equals((java.lang.Object) timeSeriesCollection12);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-10,1,0,-19,-20,-19,-20,-19" + "'", str9.equals("-10,1,0,-19,-20,-19,-20,-19"));
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2, timeZone3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer7);
        timeSeriesCollection4.seriesChanged(seriesChangeEvent8);
        legendItem1.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection4);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate12 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection4, true);
        double double14 = intervalXYDelegate12.getDomainLowerBound(false);
        try {
            java.lang.Number number17 = intervalXYDelegate12.getEndX(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        double double5 = barRenderer3D2.getMinimumBarLength();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = barRenderer3D2.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(drawingSupplier6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator5);
        piePlot3D1.setForegroundAlpha((float) 255);
        piePlot3D1.clearSectionPaints(false);
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat();
        logFormat12.setMinimumFractionDigits(100);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator16 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat12, (java.text.NumberFormat) logFormat15);
        java.lang.Object obj17 = standardPieToolTipGenerator16.clone();
        piePlot3D1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator16);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = combinedDomainXYPlot0.getDataset();
        boolean boolean2 = combinedDomainXYPlot0.isRangeZoomable();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot0.setRangeTickBandPaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.isRangeZoomable();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot6.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = combinedDomainXYPlot6.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedDomainXYPlot6.getRangeAxisLocation();
        combinedDomainXYPlot0.setDomainAxisLocation(axisLocation9);
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        logAxis1.setMinorTickMarkInsideLength((float) 6);
        logAxis1.setTickMarksVisible(true);
        logAxis1.setLabelURL("");
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        double double7 = barRenderer3D2.getMinimumBarLength();
        barRenderer3D2.setItemMargin((double) 1560452399999L);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str1 = dateTickUnit0.toString();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = dateTickUnit0.getRollUnitType();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str1.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.DomainOrder domainOrder4 = timeSeriesCollection2.getDomainOrder();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(domainOrder4);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
//        long long4 = segmentedTimeline0.getExceptionSegmentCount(1560409200000L, 60000L);
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        boolean boolean6 = segmentedTimeline0.containsDomainValue(date5);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(segmentedTimeline1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.data.time.TimeSeries timeSeries22 = null;
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeSeries22, timeZone23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, polarItemRenderer27);
        java.awt.Font font29 = polarPlot28.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot28.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit30);
        polarPlot28.setAngleGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Point2D point2D38 = null;
        polarPlot28.zoomDomainAxes((double) (short) 100, (double) '4', plotRenderingInfo37, point2D38);
        categoryPlot0.handleClick((-65281), (int) '4', plotRenderingInfo37);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(dateTickUnit30);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str2 = verticalAlignment1.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 1577894400001L, (double) 1099410614137L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 6, (double) 0);
        java.lang.String str11 = verticalAlignment7.toString();
        java.lang.Object obj12 = null;
        boolean boolean13 = verticalAlignment7.equals(obj12);
        boolean boolean14 = horizontalAlignment0.equals((java.lang.Object) boolean13);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.CENTER" + "'", str2.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "VerticalAlignment.CENTER" + "'", str11.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot4.getLegendItems();
        boolean boolean10 = combinedDomainXYPlot4.isRangeMinorGridlinesVisible();
        boolean boolean11 = combinedDomainXYPlot4.isRangeMinorGridlinesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.LegendItem legendItem15 = xYLineAndShapeRenderer12.getLegendItem(2958465, (int) (short) 100);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = xYLineAndShapeRenderer12.getLegendItemToolTipGenerator();
        combinedDomainXYPlot4.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        combinedDomainXYPlot4.setRangeTickBandPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Paint paint8 = polarPlot6.getRadiusGridlinePaint();
        polarPlot6.removeCornerTextItem("10^4.78");
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 1, 1.0f);
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.lang.Object obj27 = legendItemEntity26.clone();
        org.jfree.data.general.Dataset dataset28 = null;
        legendItemEntity26.setDataset(dataset28);
        java.lang.String str30 = legendItemEntity26.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str30.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("");
        boolean boolean6 = legendItem5.isShapeFilled();
        java.awt.Stroke stroke7 = null;
        legendItem5.setOutlineStroke(stroke7);
        java.awt.Stroke stroke9 = null;
        legendItem5.setOutlineStroke(stroke9);
        boolean boolean11 = xYLineAndShapeRenderer2.equals((java.lang.Object) stroke9);
        xYLineAndShapeRenderer2.setSeriesLinesVisible(9, false);
        boolean boolean17 = xYLineAndShapeRenderer2.getItemLineVisible(64, 9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYAreaRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYAreaRenderer2.drawRangeMarker(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, valueAxis7, marker8, rectangle2D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot6.setRangeAxisLocation((int) (byte) 1, axisLocation12, false);
        float float15 = combinedDomainXYPlot6.getBackgroundAlpha();
        combinedDomainXYPlot6.setDomainMinorGridlinesVisible(true);
        java.lang.String str18 = combinedDomainXYPlot6.getPlotType();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYAreaRenderer20.setLegendItemURLGenerator(xYSeriesLabelGenerator21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYAreaRenderer20.drawRangeMarker(graphics2D23, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24, valueAxis25, marker26, rectangle2D27);
        xYAreaRenderer20.setBaseCreateEntities(false);
        combinedDomainXYPlot6.setRenderer(500, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer20);
        boolean boolean32 = textFragment1.equals((java.lang.Object) 500);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Combined_Domain_XYPlot" + "'", str18.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 4, (double) ' ', (double) (short) 100, (double) 100, (java.awt.Paint) color22);
        barRenderer3D4.setWallPaint((java.awt.Paint) color22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer3D4.getPositiveItemLabelPositionFallback();
        barRenderer3D4.setSeriesItemLabelsVisible(2, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(itemLabelPosition25);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        categoryAxis1.setTickMarkInsideLength(0.0f);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, rectangleAnchor13, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape16, (org.jfree.chart.axis.Axis) numberAxis3D17);
//        numberAxis3D17.setTickLabelsVisible(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = numberAxis3D17.getStandardTickUnits();
//        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) periodAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer24);
//        periodAxis9.setPositiveArrowVisible(false);
//        org.jfree.data.Range range28 = periodAxis9.getRange();
//        periodAxis9.setAxisLineVisible(true);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(shape12);
//        org.junit.Assert.assertNotNull(rectangleAnchor13);
//        org.junit.Assert.assertNotNull(shape16);
//        org.junit.Assert.assertNotNull(tickUnitSource21);
//        org.junit.Assert.assertNotNull(range28);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.awt.Color color2 = java.awt.Color.getColor("#000080", 4);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        combinedDomainXYPlot4.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedDomainXYPlot4.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot4.getRenderer((int) (byte) -1);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer3D2.getLegendItemToolTipGenerator();
        java.awt.Stroke stroke11 = barRenderer3D2.getSeriesStroke((int) '4');
        double double12 = barRenderer3D2.getBase();
        java.awt.Paint paint14 = barRenderer3D2.lookupLegendTextPaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day1, (double) 5);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) numberAxis3D11);
        numberAxis3D11.setTickLabelsVisible(false);
        java.awt.Color color15 = java.awt.Color.MAGENTA;
        numberAxis3D11.setTickLabelPaint((java.awt.Paint) color15);
        numberAxis3D11.configure();
        boolean boolean18 = numberAxis3D11.getAutoRangeStickyZero();
        numberAxis3D11.zoomRange((double) (-1L), 100.0d);
        int int22 = timeSeriesDataItem4.compareTo((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor3 = new org.jfree.chart.plot.PieLabelDistributor(7);
        pieLabelDistributor3.clear();
        int int5 = month0.compareTo((java.lang.Object) pieLabelDistributor3);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_LEFT");
        xYLineAndShapeRenderer2.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        java.awt.Paint paint8 = xYLineAndShapeRenderer2.getSeriesItemLabelPaint(8);
        boolean boolean9 = xYLineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getSimpleLabelOffset();
        ringPlot0.setInnerSeparatorExtension(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.LegendItem legendItem3 = xYLineAndShapeRenderer0.getLegendItem(2958465, (int) (short) 100);
        xYLineAndShapeRenderer0.setUseOutlinePaint(true);
        boolean boolean8 = xYLineAndShapeRenderer0.getItemShapeFilled((int) (short) 1, 13);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = null;
        xYAreaRenderer10.setLegendItemURLGenerator(xYSeriesLabelGenerator11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYAreaRenderer10.drawRangeMarker(graphics2D13, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot14, valueAxis15, marker16, rectangle2D17);
        java.awt.Font font20 = xYAreaRenderer10.lookupLegendTextFont(6);
        boolean boolean22 = xYAreaRenderer10.equals((java.lang.Object) "DomainOrder.ASCENDING");
        java.awt.Font font26 = xYAreaRenderer10.getItemLabelFont(0, (int) (byte) -1, false);
        xYLineAndShapeRenderer0.setLegendTextFont((int) (short) 1, font26);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape2);
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4);
        org.jfree.chart.entity.XYItemEntity xYItemEntity10 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) timeSeriesCollection5, 1, 2958465, "", "RectangleEdge.BOTTOM");
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11, timeZone12);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYLineAndShapeRenderer16);
        timeSeriesCollection13.seriesChanged(seriesChangeEvent17);
        xYItemEntity10.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.time.TimeSeries timeSeries21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeSeries21, timeZone22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, polarItemRenderer26);
        java.lang.Comparable comparable28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeriesCollection23.getSeries(comparable28);
        timeSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection23);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(timeSeries29);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        int int9 = combinedDomainXYPlot4.getWeight();
        java.awt.Paint paint10 = combinedDomainXYPlot4.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedDomainXYPlot4.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = combinedDomainXYPlot4.getOrientation();
        java.awt.Paint paint14 = combinedDomainXYPlot4.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot18.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = combinedDomainXYPlot18.getDatasetRenderingOrder();
        java.util.List list21 = combinedDomainXYPlot18.getSubplots();
        combinedDomainXYPlot18.configureRangeAxes();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        combinedDomainXYPlot18.drawDomainTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.geom.Point2D point2D27 = combinedDomainXYPlot18.getQuadrantOrigin();
        try {
            combinedDomainXYPlot4.zoomDomainAxes((double) (short) 100, 0.0d, plotRenderingInfo17, point2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (105.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = xYPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(drawingSupplier1);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test047");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
//        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 1577894400001L, (int) '#', textMeasurer17);
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        int int21 = day20.getMonth();
//        long long22 = day20.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        boolean boolean24 = textBlock18.equals((java.lang.Object) day20);
//        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textBlock18.getLineAlignment();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(textBlock18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(horizontalAlignment25);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator5, true);
        java.awt.Shape shape9 = barRenderer3D4.lookupSeriesShape((int) '#');
        xYAreaRenderer0.setSeriesShape((int) (byte) 1, shape9, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer12.setLegendItemURLGenerator(xYSeriesLabelGenerator13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYAreaRenderer12.drawRangeMarker(graphics2D15, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot16, valueAxis17, marker18, rectangle2D19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot16.setRangeAxisLocation((int) (byte) 1, axisLocation22, false);
        float float25 = combinedDomainXYPlot16.getBackgroundAlpha();
        combinedDomainXYPlot16.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke28 = combinedDomainXYPlot16.getDomainZeroBaselineStroke();
        xYAreaRenderer0.setBaseStroke(stroke28);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator31 = null;
        xYAreaRenderer30.setLegendItemURLGenerator(xYSeriesLabelGenerator31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.plot.Marker marker36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        xYAreaRenderer30.drawRangeMarker(graphics2D33, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot34, valueAxis35, marker36, rectangle2D37);
        boolean boolean39 = xYAreaRenderer30.getPlotShapes();
        java.awt.Stroke stroke40 = xYAreaRenderer30.getBaseOutlineStroke();
        xYAreaRenderer0.setBaseStroke(stroke40);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer43.setSeriesShapesVisible(6, (java.lang.Boolean) false);
        java.awt.Shape shape47 = xYLineAndShapeRenderer43.getBaseLegendShape();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator49 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator51 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_LEFT");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2019, xYToolTipGenerator49, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator51);
        xYLineAndShapeRenderer43.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator51);
        xYAreaRenderer0.setSeriesURLGenerator(15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator51);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(shape47);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        java.awt.Shape shape2 = null;
        boolean boolean3 = org.jfree.chart.util.ShapeUtilities.equal(shape1, shape2);
        try {
            org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.lang.String str3 = xYSeries2.getDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        int int8 = xYSeries2.getMaximumItemCount();
        xYSeries2.add(0.0d, (java.lang.Number) 1099410614137L);
        boolean boolean12 = xYSeries2.getNotify();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.setTickLabelsVisible(false);
        boolean boolean10 = numberAxis3D6.isVerticalTickLabels();
        boolean boolean11 = numberAxis3D6.isMinorTickMarksVisible();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean14 = range12.contains(0.0d);
        numberAxis3D6.setRangeWithMargins(range12, false, true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.RenderingSource renderingSource2 = null;
        chartRenderingInfo1.setRenderingSource(renderingSource2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
        java.lang.String str16 = combinedDomainXYPlot4.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = combinedDomainXYPlot4.getRangeAxisEdge(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = combinedDomainXYPlot4.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Combined_Domain_XYPlot" + "'", str16.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TextAnchor.TOP_LEFT");
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test056");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        int int1 = categoryPlot0.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color5 = java.awt.Color.MAGENTA;
//        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
//        java.awt.Shape shape7 = null;
//        barRenderer3D4.setBaseLegendShape(shape7);
//        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
//        java.awt.Color color11 = java.awt.Color.RED;
//        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
//        barRenderer3D4.notifyListeners(rendererChangeEvent13);
//        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
//        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
//        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
//        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        int int22 = day21.getMonth();
//        long long23 = day21.getFirstMillisecond();
//        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        int int26 = day25.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day25);
//        boolean boolean28 = periodAxis27.isAutoRange();
//        periodAxis27.setMinorTickMarksVisible(true);
//        java.awt.Font font31 = periodAxis27.getLabelFont();
//        double double32 = periodAxis27.getLowerBound();
//        int int33 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis27);
//        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot0.getRangeAxisEdge(1);
//        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryPlot0.getDataset();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNull(paint10);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNull(font16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(rectangleEdge35);
//        org.junit.Assert.assertNull(categoryDataset36);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        org.jfree.chart.util.LogFormat logFormat1 = new org.jfree.chart.util.LogFormat();
        boolean boolean2 = paintMap0.equals((java.lang.Object) logFormat1);
        java.lang.Comparable comparable3 = null;
        boolean boolean4 = paintMap0.containsKey(comparable3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleLabelPaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape13, (org.jfree.chart.axis.Axis) numberAxis3D14);
        numberAxis3D14.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range19 = polarPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D14.getTickLabelInsets();
        org.jfree.data.RangeType rangeType21 = numberAxis3D14.getRangeType();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color25 = java.awt.Color.MAGENTA;
        barRenderer3D24.setBaseLegendTextPaint((java.awt.Paint) color25);
        java.awt.Shape shape27 = null;
        barRenderer3D24.setBaseLegendShape(shape27);
        double double29 = barRenderer3D24.getMinimumBarLength();
        java.awt.Shape shape33 = barRenderer3D24.getItemShape((int) (byte) 1, (int) 'a', false);
        boolean boolean34 = rangeType21.equals((java.lang.Object) barRenderer3D24);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rangeType21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        categoryPlot0.clearAnnotations();
        java.awt.Paint paint19 = categoryPlot0.getDomainCrosshairPaint();
        int int20 = categoryPlot0.getDatasetCount();
        boolean boolean21 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot0.getDomainAxisEdge(2019);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot24.getDomainAxis(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot24.getRangeAxisEdge(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot24.zoomRangeAxes((double) 7, plotRenderingInfo30, point2D31, true);
        java.awt.Paint paint34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot24.setRangeZeroBaselinePaint(paint34);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot24.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder36);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(sortOrder36);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.END" + "'", str1.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TextAnchor.TOP_LEFT");
//        periodAxis1.setInverted(false);
//        java.lang.Class class4 = periodAxis1.getMajorTickTimePeriodClass();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        int int6 = categoryPlot5.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color10 = java.awt.Color.MAGENTA;
//        barRenderer3D9.setBaseLegendTextPaint((java.awt.Paint) color10);
//        java.awt.Shape shape12 = null;
//        barRenderer3D9.setBaseLegendShape(shape12);
//        java.awt.Paint paint15 = barRenderer3D9.getSeriesPaint((int) '4');
//        java.awt.Color color16 = java.awt.Color.RED;
//        barRenderer3D9.setWallPaint((java.awt.Paint) color16);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
//        barRenderer3D9.notifyListeners(rendererChangeEvent18);
//        java.awt.Font font21 = barRenderer3D9.getLegendTextFont(255);
//        int int22 = categoryPlot5.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
//        java.awt.Stroke stroke23 = categoryPlot5.getRangeCrosshairStroke();
//        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        int int27 = day26.getMonth();
//        long long28 = day26.getFirstMillisecond();
//        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
//        int int31 = day30.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day30);
//        boolean boolean33 = periodAxis32.isAutoRange();
//        periodAxis32.setMinorTickMarksVisible(true);
//        java.awt.Font font36 = periodAxis32.getLabelFont();
//        double double37 = periodAxis32.getLowerBound();
//        int int38 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis32);
//        java.lang.Class class39 = periodAxis32.getMinorTickTimePeriodClass();
//        periodAxis1.setMinorTickTimePeriodClass(class39);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(color10);
//        org.junit.Assert.assertNull(paint15);
//        org.junit.Assert.assertNotNull(color16);
//        org.junit.Assert.assertNull(font21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(stroke23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560409200000L + "'", long28 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(font36);
//        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertNotNull(class39);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.util.LogFormat logFormat1 = new org.jfree.chart.util.LogFormat();
        logFormat1.setMinimumFractionDigits(100);
        java.lang.String str5 = logFormat1.format((double) 60000L);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat();
        logFormat8.setMinimumFractionDigits(100);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat8, (java.text.NumberFormat) logFormat11);
        org.jfree.chart.util.LogFormat logFormat13 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator14 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie 3D Plot", (java.text.NumberFormat) logFormat8, (java.text.NumberFormat) logFormat13);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("DomainOrder.ASCENDING", (java.text.NumberFormat) logFormat1, (java.text.NumberFormat) logFormat13);
        try {
            java.lang.Number number17 = logFormat13.parse("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"Category Plot\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10^4.78" + "'", str5.equals("10^4.78"));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
//        int int2 = categoryPlot1.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color6 = java.awt.Color.MAGENTA;
//        barRenderer3D5.setBaseLegendTextPaint((java.awt.Paint) color6);
//        java.awt.Shape shape8 = null;
//        barRenderer3D5.setBaseLegendShape(shape8);
//        java.awt.Paint paint11 = barRenderer3D5.getSeriesPaint((int) '4');
//        java.awt.Color color12 = java.awt.Color.RED;
//        barRenderer3D5.setWallPaint((java.awt.Paint) color12);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
//        barRenderer3D5.notifyListeners(rendererChangeEvent14);
//        java.awt.Font font17 = barRenderer3D5.getLegendTextFont(255);
//        int int18 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
//        java.awt.Stroke stroke19 = categoryPlot1.getRangeCrosshairStroke();
//        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        int int23 = day22.getMonth();
//        long long24 = day22.getFirstMillisecond();
//        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        int int27 = day26.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day26);
//        boolean boolean29 = periodAxis28.isAutoRange();
//        periodAxis28.setMinorTickMarksVisible(true);
//        java.awt.Font font32 = periodAxis28.getLabelFont();
//        double double33 = periodAxis28.getLowerBound();
//        int int34 = categoryPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis28);
//        int int35 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis28);
//        periodAxis28.setAutoTickUnitSelection(true);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNull(paint11);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNull(font17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(font32);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        barRenderer3D3.setBaseLegendTextPaint((java.awt.Paint) color4);
        java.awt.Shape shape6 = null;
        barRenderer3D3.setBaseLegendShape(shape6);
        java.awt.Paint paint9 = barRenderer3D3.getSeriesPaint((int) '4');
        java.awt.Color color10 = java.awt.Color.RED;
        barRenderer3D3.setWallPaint((java.awt.Paint) color10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer3D3.notifyListeners(rendererChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        int int16 = categoryPlot15.getCrosshairDatasetIndex();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getDomainMarkers(layer17);
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("Pie 3D Plot");
        logAxis20.pan((double) 2);
        logAxis20.setTickLabelsVisible(true);
        logAxis20.zoomRange((double) (byte) 0, (double) 2);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.Color color30 = java.awt.Color.green;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer3D3.drawRangeLine(graphics2D14, categoryPlot15, (org.jfree.chart.axis.ValueAxis) logAxis20, rectangle2D28, 0.0d, (java.awt.Paint) color30, stroke31);
        boolean boolean33 = rangeType0.equals((java.lang.Object) stroke31);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        int int5 = spreadsheetDate3.toSerial();
        boolean boolean6 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate1.getPreviousDayOfWeek((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.Marker marker23 = null;
        try {
            categoryPlot0.addRangeMarker(marker23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 2019, (double) 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        java.awt.Paint paint11 = barRenderer3D2.getSeriesPaint(3);
        barRenderer3D2.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer3D2.getSeriesToolTipGenerator(255);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator15);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        barRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator17, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Shape shape9 = xYAreaRenderer0.getLegendArea();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = xYAreaRenderer0.getToolTipGenerator((int) (short) 1, (int) (byte) 0, true);
        xYAreaRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(xYToolTipGenerator13);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1560495599999L, (double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean2 = textTitle1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle1.getBounds();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        boolean boolean14 = combinedDomainXYPlot4.isDomainCrosshairVisible();
        java.awt.Stroke stroke15 = combinedDomainXYPlot4.getDomainGridlineStroke();
        combinedDomainXYPlot4.configureDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test078");
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color4 = java.awt.Color.MAGENTA;
//        barRenderer3D3.setBaseLegendTextPaint((java.awt.Paint) color4);
//        java.awt.Shape shape6 = null;
//        barRenderer3D3.setBaseLegendShape(shape6);
//        java.awt.Paint paint9 = barRenderer3D3.getSeriesPaint((int) '4');
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        int int13 = day12.getMonth();
//        long long14 = day12.getFirstMillisecond();
//        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day16);
//        boolean boolean19 = periodAxis18.isAutoRange();
//        periodAxis18.setMinorTickMarksVisible(true);
//        java.awt.Font font22 = periodAxis18.getLabelFont();
//        barRenderer3D3.setBaseItemLabelFont(font22);
//        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("Pie 3D Plot", font22);
//        java.lang.String str25 = labelBlock24.getToolTipText();
//        labelBlock24.setHeight((double) (short) 1);
//        java.lang.Object obj28 = labelBlock24.clone();
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNull(paint9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(font22);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertNotNull(obj28);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        numberAxis3D6.setFixedAutoRange((double) (byte) 100);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat();
        logFormat10.setMinimumFractionDigits(100);
        numberAxis3D6.setNumberFormatOverride((java.text.NumberFormat) logFormat10);
        java.text.NumberFormat numberFormat14 = java.text.NumberFormat.getNumberInstance();
        int int15 = numberFormat14.getMaximumFractionDigits();
        java.util.Currency currency16 = numberFormat14.getCurrency();
        logFormat10.setExponentFormat(numberFormat14);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(numberFormat14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(currency16);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 100, (double) 13);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYAreaRenderer1.getURLGenerator(0, 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getSeriesNegativeItemLabelPosition((int) (short) 1);
        xYLineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition9);
        xYLineAndShapeRenderer0.setSeriesLinesVisible(4, false);
        xYLineAndShapeRenderer0.setSeriesShapesFilled(255, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(xYURLGenerator7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("");
        boolean boolean4 = legendItem3.isShapeFilled();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color5);
        legendItem3.setFillPaint((java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("-10,1,0,-19,-20,-19,-20,-19", font1, (java.awt.Paint) color5);
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment10 = textLine8.getFirstTextFragment();
        java.lang.Object obj11 = null;
        boolean boolean12 = textFragment10.equals(obj11);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TextAnchor.TOP_LEFT");
        boolean boolean2 = periodAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit0.valueToString((double) (short) 0);
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 0, false);
        boolean boolean5 = xYSeries4.isEmpty();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day6.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getURLGenerator();
        java.lang.Object obj6 = piePlot3D1.clone();
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        piePlot3D1.setLabelFont(font7);
        double double9 = piePlot3D1.getLabelGap();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        java.lang.String str8 = axisEntity7.getURLText();
        java.lang.String str9 = axisEntity7.getShapeCoords();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = axisEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-10,1,0,-19,-20,-19,-20,-19" + "'", str9.equals("-10,1,0,-19,-20,-19,-20,-19"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = null;
        barRenderer3D4.setBaseLegendShape(shape7);
        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer3D4.notifyListeners(rendererChangeEvent13);
        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = barRenderer3D4.getDrawingSupplier();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer3D4.getURLGenerator(5, 0, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer3D4.getNegativeItemLabelPositionFallback();
        org.jfree.chart.util.PaintMap paintMap24 = new org.jfree.chart.util.PaintMap();
        java.awt.Color color26 = java.awt.Color.MAGENTA;
        paintMap24.put((java.lang.Comparable) 100.0f, (java.awt.Paint) color26);
        int int28 = color26.getRGB();
        barRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color26);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-65281) + "'", int28 == (-65281));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        logFormat0.setMinimumFractionDigits(100);
        java.lang.String str4 = logFormat0.format((double) 60000L);
        logFormat0.setParseIntegerOnly(false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10^4.78" + "'", str4.equals("10^4.78"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint2 = categoryPlot0.getRangeMinorGridlinePaint();
        categoryPlot0.setCrosshairDatasetIndex(13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
//        int int2 = categoryPlot1.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color6 = java.awt.Color.MAGENTA;
//        barRenderer3D5.setBaseLegendTextPaint((java.awt.Paint) color6);
//        java.awt.Shape shape8 = null;
//        barRenderer3D5.setBaseLegendShape(shape8);
//        java.awt.Paint paint11 = barRenderer3D5.getSeriesPaint((int) '4');
//        java.awt.Color color12 = java.awt.Color.RED;
//        barRenderer3D5.setWallPaint((java.awt.Paint) color12);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
//        barRenderer3D5.notifyListeners(rendererChangeEvent14);
//        java.awt.Font font17 = barRenderer3D5.getLegendTextFont(255);
//        int int18 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
//        java.awt.Stroke stroke19 = categoryPlot1.getRangeCrosshairStroke();
//        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        int int23 = day22.getMonth();
//        long long24 = day22.getFirstMillisecond();
//        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        int int27 = day26.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day26);
//        boolean boolean29 = periodAxis28.isAutoRange();
//        periodAxis28.setMinorTickMarksVisible(true);
//        java.awt.Font font32 = periodAxis28.getLabelFont();
//        double double33 = periodAxis28.getLowerBound();
//        int int34 = categoryPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis28);
//        int int35 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis28);
//        org.jfree.data.general.DatasetGroup datasetGroup36 = xYPlot0.getDatasetGroup();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNull(paint11);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNull(font17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(font32);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNull(datasetGroup36);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot0.configureDomainAxes();
//        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedDomainXYPlot0.getRangeAxisLocation((int) 'a');
//        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot0.getRangeAxis((int) (short) 0);
//        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
//        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//        java.awt.Stroke stroke10 = xYStepAreaRenderer8.lookupSeriesOutlineStroke(0);
//        java.awt.Graphics2D graphics2D11 = null;
//        org.jfree.chart.plot.XYPlot xYPlot12 = null;
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        long long17 = day15.getFirstMillisecond();
//        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        int int20 = day19.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) day19);
//        periodAxis21.configure();
//        java.awt.geom.Rectangle2D rectangle2D23 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot25.getDomainAxis(10);
//        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
//        categoryPlot25.setFixedRangeAxisSpace(axisSpace28);
//        java.awt.Paint paint30 = categoryPlot25.getRangeGridlinePaint();
//        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape32, rectangleAnchor33, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity38 = new org.jfree.chart.entity.AxisEntity(shape36, (org.jfree.chart.axis.Axis) numberAxis3D37);
//        numberAxis3D37.zoomRange(0.0d, 0.0d);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        combinedDomainXYPlot42.configureDomainAxes();
//        numberAxis3D37.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot42);
//        org.jfree.chart.plot.PlotOrientation plotOrientation45 = combinedDomainXYPlot42.getOrientation();
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer46 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator47 = null;
//        xYAreaRenderer46.setLegendItemURLGenerator(xYSeriesLabelGenerator47);
//        java.awt.Graphics2D graphics2D49 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
//        org.jfree.chart.plot.Marker marker52 = null;
//        java.awt.geom.Rectangle2D rectangle2D53 = null;
//        xYAreaRenderer46.drawRangeMarker(graphics2D49, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot50, valueAxis51, marker52, rectangle2D53);
//        java.awt.Font font56 = xYAreaRenderer46.lookupLegendTextFont(6);
//        int int57 = xYAreaRenderer46.getPassCount();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator58 = xYAreaRenderer46.getLegendItemLabelGenerator();
//        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape60, rectangleAnchor61, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D65 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity66 = new org.jfree.chart.entity.AxisEntity(shape64, (org.jfree.chart.axis.Axis) numberAxis3D65);
//        java.awt.Stroke stroke67 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis3D65.setTickMarkStroke(stroke67);
//        xYAreaRenderer46.setBaseStroke(stroke67);
//        java.awt.Shape shape72 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape76 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape72, rectangleAnchor73, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D77 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity78 = new org.jfree.chart.entity.AxisEntity(shape76, (org.jfree.chart.axis.Axis) numberAxis3D77);
//        java.awt.Stroke stroke79 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis3D77.setTickMarkStroke(stroke79);
//        xYAreaRenderer46.setSeriesStroke(0, stroke79, false);
//        combinedDomainXYPlot42.setDomainZeroBaselineStroke(stroke79);
//        xYStepAreaRenderer8.drawDomainLine(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) periodAxis21, rectangle2D23, (double) 35L, paint30, stroke79);
//        combinedDomainXYPlot0.setRangeGridlinePaint(paint30);
//        org.junit.Assert.assertNotNull(axisLocation3);
//        org.junit.Assert.assertNull(valueAxis5);
//        org.junit.Assert.assertNotNull(stroke10);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNull(categoryAxis27);
//        org.junit.Assert.assertNotNull(paint30);
//        org.junit.Assert.assertNotNull(shape32);
//        org.junit.Assert.assertNotNull(rectangleAnchor33);
//        org.junit.Assert.assertNotNull(shape36);
//        org.junit.Assert.assertNotNull(plotOrientation45);
//        org.junit.Assert.assertNull(font56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator58);
//        org.junit.Assert.assertNotNull(shape60);
//        org.junit.Assert.assertNotNull(rectangleAnchor61);
//        org.junit.Assert.assertNotNull(shape64);
//        org.junit.Assert.assertNotNull(stroke67);
//        org.junit.Assert.assertNotNull(shape72);
//        org.junit.Assert.assertNotNull(rectangleAnchor73);
//        org.junit.Assert.assertNotNull(shape76);
//        org.junit.Assert.assertNotNull(stroke79);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("");
        boolean boolean4 = legendItem3.isShapeFilled();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color5);
        legendItem3.setFillPaint((java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("-10,1,0,-19,-20,-19,-20,-19", font1, (java.awt.Paint) color5);
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment10 = textLine8.getFirstTextFragment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            float float13 = textFragment10.calculateBaselineOffset(graphics2D11, textAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font9 = barRenderer3D2.getBaseLegendTextFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        barRenderer3D12.setBaseLegendTextPaint((java.awt.Paint) color13);
        java.awt.Shape shape15 = null;
        barRenderer3D12.setBaseLegendShape(shape15);
        java.awt.Paint paint18 = barRenderer3D12.getSeriesPaint((int) '4');
        java.awt.Color color19 = java.awt.Color.RED;
        barRenderer3D12.setWallPaint((java.awt.Paint) color19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        barRenderer3D12.notifyListeners(rendererChangeEvent21);
        java.awt.Font font24 = barRenderer3D12.getLegendTextFont(255);
        org.jfree.chart.renderer.category.BarPainter barPainter25 = barRenderer3D12.getBarPainter();
        barRenderer3D2.setBarPainter(barPainter25);
        java.awt.Paint paint30 = barRenderer3D2.getItemOutlinePaint((int) '4', (int) (byte) 1, false);
        boolean boolean32 = barRenderer3D2.isSeriesVisible(0);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "", (java.lang.Object) shape36);
        org.jfree.data.time.TimeSeries timeSeries38 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeSeries38);
        org.jfree.chart.entity.XYItemEntity xYItemEntity44 = new org.jfree.chart.entity.XYItemEntity(shape36, (org.jfree.data.xy.XYDataset) timeSeriesCollection39, 1, 2958465, "", "RectangleEdge.BOTTOM");
        org.jfree.data.xy.XYDataset xYDataset45 = xYItemEntity44.getDataset();
        java.awt.Shape shape46 = xYItemEntity44.getArea();
        java.awt.Shape shape47 = xYItemEntity44.getArea();
        barRenderer3D2.setSeriesShape(0, shape47);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(font24);
        org.junit.Assert.assertNotNull(barPainter25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(xYDataset45);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
        java.lang.String str16 = combinedDomainXYPlot4.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis(0, categoryAxis19, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot17.zoomDomainAxes(0.0d, plotRenderingInfo23, point2D24);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean28 = categoryPlot17.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker27);
        valueMarker27.setLabel("hi!");
        combinedDomainXYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker27);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Combined_Domain_XYPlot" + "'", str16.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Object obj1 = defaultPieDataset0.clone();
        java.lang.Object obj2 = defaultPieDataset0.clone();
        java.lang.Object obj3 = defaultPieDataset0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        int int6 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        jFreeChart4.handleClick((int) (short) 0, 9, chartRenderingInfo11);
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        chartRenderingInfo11.setEntityCollection(entityCollection13);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot1.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        combinedDomainXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
        combinedDomainXYPlot0.setRangePannable(true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.getAutoRangeStickyZero();
        boolean boolean2 = numberAxis3D0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        polarPlot6.setAngleGridlinesVisible(false);
        java.awt.Font font12 = polarPlot6.getAngleLabelFont();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 100.0f, true);
        java.util.Date date4 = dateRange0.getUpperDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek((int) (byte) 1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setStartAngle((double) (-1L));
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = piePlot3D1.equals((java.lang.Object) ringPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot3D1.getLabelPadding();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        piePlot3D1.setLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator(64, xYItemLabelGenerator2);
        java.lang.Object obj4 = xYStepRenderer0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, (double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape5, (org.jfree.chart.axis.Axis) numberAxis3D6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        barRenderer3D10.setBaseLegendTextPaint((java.awt.Paint) color11);
        java.awt.Shape shape13 = null;
        barRenderer3D10.setBaseLegendShape(shape13);
        java.awt.Paint paint16 = barRenderer3D10.getSeriesPaint((int) '4');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D10.setBaseFillPaint((java.awt.Paint) color17, false);
        int int20 = color17.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic21.setShapeLocation(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendGraphic21.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic21.setShapeAnchor(rectangleAnchor25);
        legendGraphic21.setPadding((double) (-1), (double) (byte) -1, 0.0d, 0.0d);
        legendGraphic21.setMargin((double) (short) 0, (double) 15, 0.0d, Double.NaN);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test117");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        int int1 = categoryPlot0.getCrosshairDatasetIndex();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color5 = java.awt.Color.MAGENTA;
//        barRenderer3D4.setBaseLegendTextPaint((java.awt.Paint) color5);
//        java.awt.Shape shape7 = null;
//        barRenderer3D4.setBaseLegendShape(shape7);
//        java.awt.Paint paint10 = barRenderer3D4.getSeriesPaint((int) '4');
//        java.awt.Color color11 = java.awt.Color.RED;
//        barRenderer3D4.setWallPaint((java.awt.Paint) color11);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
//        barRenderer3D4.notifyListeners(rendererChangeEvent13);
//        java.awt.Font font16 = barRenderer3D4.getLegendTextFont(255);
//        int int17 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
//        java.awt.Stroke stroke18 = categoryPlot0.getRangeCrosshairStroke();
//        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        int int22 = day21.getMonth();
//        long long23 = day21.getFirstMillisecond();
//        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        int int26 = day25.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day25);
//        boolean boolean28 = periodAxis27.isAutoRange();
//        periodAxis27.setMinorTickMarksVisible(true);
//        java.awt.Font font31 = periodAxis27.getLabelFont();
//        double double32 = periodAxis27.getLowerBound();
//        int int33 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis27);
//        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        java.util.Date date39 = spreadsheetDate38.toDate();
//        java.lang.String str40 = categoryAxis36.getCategoryLabelToolTip((java.lang.Comparable) date39);
//        categoryPlot0.setDomainAxis((int) '#', categoryAxis36, true);
//        categoryAxis36.setCategoryMargin((double) 'a');
//        java.util.EventListener eventListener45 = null;
//        boolean boolean46 = categoryAxis36.hasListener(eventListener45);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNull(paint10);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNull(font16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, true);
        java.lang.String str3 = xYSeries2.getDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        int int8 = xYSeries2.getMaximumItemCount();
        xYSeries2.add(0.0d, (java.lang.Number) 1099410614137L);
        org.jfree.data.xy.XYSeries xYSeries14 = xYSeries2.createCopy((int) 'a', (int) (byte) 10);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNotNull(xYSeries14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 10.0f, (java.lang.Number) (-1.0f));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getURLGenerator();
        piePlot3D1.setLabelLinksVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getLegendLabelURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        xYAreaRenderer9.drawRangeMarker(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, valueAxis14, marker15, rectangle2D16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot13.setRangeAxisLocation((int) (byte) 1, axisLocation19, false);
        float float22 = combinedDomainXYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator24 = null;
        xYAreaRenderer23.setLegendItemURLGenerator(xYSeriesLabelGenerator24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYAreaRenderer23.drawRangeMarker(graphics2D26, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot27, valueAxis28, marker29, rectangle2D30);
        boolean boolean32 = xYAreaRenderer23.getPlotShapes();
        java.awt.Stroke stroke33 = xYAreaRenderer23.getBaseOutlineStroke();
        combinedDomainXYPlot13.setDomainGridlineStroke(stroke33);
        boolean boolean35 = piePlot3D1.equals((java.lang.Object) combinedDomainXYPlot13);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(5);
        xYPlot36.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer39);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = xYPlot36.getRangeMarkers((int) (byte) 1, layer42);
        java.awt.Paint paint44 = xYPlot36.getDomainCrosshairPaint();
        piePlot3D1.setLabelBackgroundPaint(paint44);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(paint44);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test123");
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.String str9 = day6.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle1.getFrame();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 100.0f, true);
        java.util.Date date4 = dateRange0.getUpperDate();
        java.util.Date date5 = dateRange0.getLowerDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date5, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test126");
//        java.awt.Color color0 = java.awt.Color.WHITE;
//        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
//        java.awt.Paint paint2 = blockBorder1.getPaint();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
//        jFreeChart4.fireChartChanged();
//        int int6 = jFreeChart4.getSubtitleCount();
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint2, jFreeChart4);
//        org.jfree.chart.event.ChartProgressListener chartProgressListener8 = null;
//        jFreeChart4.addProgressListener(chartProgressListener8);
//        jFreeChart4.setBackgroundImageAlignment((int) '#');
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        int int16 = day15.getMonth();
//        long long17 = day15.getFirstMillisecond();
//        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        int int20 = day19.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) day19);
//        boolean boolean22 = periodAxis21.isAutoRange();
//        periodAxis21.setMinorTickMarksVisible(true);
//        java.awt.Font font25 = periodAxis21.getLabelFont();
//        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font25);
//        org.jfree.data.general.PieDataset pieDataset27 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D(pieDataset27);
//        piePlot3D28.setAutoPopulateSectionOutlineStroke(true);
//        java.awt.Stroke stroke31 = piePlot3D28.getBaseSectionOutlineStroke();
//        org.jfree.chart.urls.PieURLGenerator pieURLGenerator32 = null;
//        piePlot3D28.setURLGenerator(pieURLGenerator32);
//        double double34 = piePlot3D28.getShadowXOffset();
//        boolean boolean35 = piePlot3D28.getSimpleLabels();
//        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 10);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape37, rectangleAnchor38, (double) (byte) 0, (double) 1.0f);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.entity.AxisEntity axisEntity43 = new org.jfree.chart.entity.AxisEntity(shape41, (org.jfree.chart.axis.Axis) numberAxis3D42);
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D46 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
//        java.awt.Color color47 = java.awt.Color.MAGENTA;
//        barRenderer3D46.setBaseLegendTextPaint((java.awt.Paint) color47);
//        java.awt.Shape shape49 = null;
//        barRenderer3D46.setBaseLegendShape(shape49);
//        java.awt.Paint paint52 = barRenderer3D46.getSeriesPaint((int) '4');
//        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        barRenderer3D46.setBaseFillPaint((java.awt.Paint) color53, false);
//        int int56 = color53.getTransparency();
//        org.jfree.chart.title.LegendGraphic legendGraphic57 = new org.jfree.chart.title.LegendGraphic(shape41, (java.awt.Paint) color53);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
//        legendGraphic57.setShapeLocation(rectangleAnchor58);
//        org.jfree.chart.util.RectangleInsets rectangleInsets60 = legendGraphic57.getPadding();
//        double double62 = rectangleInsets60.calculateTopInset(1.0d);
//        piePlot3D28.setLabelPadding(rectangleInsets60);
//        org.jfree.chart.util.LogFormat logFormat66 = new org.jfree.chart.util.LogFormat();
//        logFormat66.setMinimumFractionDigits(100);
//        org.jfree.chart.util.LogFormat logFormat69 = new org.jfree.chart.util.LogFormat();
//        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator70 = new org.jfree.chart.labels.StandardPieToolTipGenerator("GradientPaintTransformType.HORIZONTAL", (java.text.NumberFormat) logFormat66, (java.text.NumberFormat) logFormat69);
//        org.jfree.chart.util.LogFormat logFormat71 = new org.jfree.chart.util.LogFormat();
//        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator72 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie 3D Plot", (java.text.NumberFormat) logFormat66, (java.text.NumberFormat) logFormat71);
//        java.text.AttributedString attributedString74 = null;
//        standardPieSectionLabelGenerator72.setAttributedLabel(255, attributedString74);
//        piePlot3D28.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator72);
//        boolean boolean77 = textTitle26.equals((java.lang.Object) standardPieSectionLabelGenerator72);
//        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle26);
//        org.junit.Assert.assertNotNull(color0);
//        org.junit.Assert.assertNotNull(paint2);
//        org.junit.Assert.assertNotNull(jFreeChart4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(font25);
//        org.junit.Assert.assertNotNull(stroke31);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(shape37);
//        org.junit.Assert.assertNotNull(rectangleAnchor38);
//        org.junit.Assert.assertNotNull(shape41);
//        org.junit.Assert.assertNotNull(color47);
//        org.junit.Assert.assertNull(paint52);
//        org.junit.Assert.assertNotNull(color53);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(rectangleAnchor58);
//        org.junit.Assert.assertNotNull(rectangleInsets60);
//        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.0d + "'", double62 == 2.0d);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(10);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        java.lang.String str5 = categoryPlot0.getPlotType();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        barRenderer3D8.setBaseLegendTextPaint((java.awt.Paint) color9);
        java.awt.Shape shape11 = null;
        barRenderer3D8.setBaseLegendShape(shape11);
        java.awt.Paint paint14 = barRenderer3D8.getSeriesPaint((int) '4');
        java.awt.Font font15 = barRenderer3D8.getBaseLegendTextFont();
        java.awt.Paint paint17 = barRenderer3D8.getSeriesPaint(3);
        barRenderer3D8.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer3D8.getSeriesToolTipGenerator(255);
        int int21 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D8);
        java.awt.Stroke stroke22 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot0.getDomainAxisForDataset((int) (short) 100);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(categoryAxis24);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle1.getFrame();
        double double3 = textTitle1.getHeight();
        java.lang.Object obj4 = textTitle1.clone();
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1), (double) 10.0f);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        barRenderer3D2.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = null;
        barRenderer3D2.setBaseLegendShape(shape5);
        java.awt.Paint paint8 = barRenderer3D2.getSeriesPaint((int) '4');
        java.awt.Font font10 = barRenderer3D2.getLegendTextFont((int) (short) 100);
        barRenderer3D2.setIncludeBaseInRange(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        double double15 = barRenderer3D2.getShadowXOffset();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        java.lang.Object obj1 = null;
        boolean boolean2 = standardXYSeriesLabelGenerator0.equals(obj1);
        java.lang.Object obj3 = standardXYSeriesLabelGenerator0.clone();
        java.lang.Object obj4 = standardXYSeriesLabelGenerator0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test131");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        int int4 = day3.getMonth();
//        long long5 = day3.getFirstMillisecond();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        int int8 = day7.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) day7);
//        boolean boolean10 = periodAxis9.isAutoRange();
//        periodAxis9.setMinorTickMarksVisible(true);
//        java.awt.Font font13 = periodAxis9.getLabelFont();
//        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
//        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
//        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 1577894400001L, (int) '#', textMeasurer17);
//        java.awt.Graphics2D graphics2D19 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
//        textBlock18.draw(graphics2D19, (float) 10L, (float) 7, textBlockAnchor22);
//        java.awt.Graphics2D graphics2D24 = null;
//        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
//        java.awt.Shape shape31 = textBlock18.calculateBounds(graphics2D24, (float) 2958465, (float) (short) -1, textBlockAnchor27, (float) 2019, (float) ' ', (double) 1);
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator33 = null;
//        xYAreaRenderer32.setLegendItemURLGenerator(xYSeriesLabelGenerator33);
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = xYAreaRenderer32.getURLGenerator(0, 100, true);
//        org.jfree.chart.LegendItem legendItem41 = xYAreaRenderer32.getLegendItem((int) '#', (int) (byte) 1);
//        boolean boolean42 = textBlockAnchor27.equals((java.lang.Object) xYAreaRenderer32);
//        java.text.DateFormat dateFormat44 = null;
//        java.text.DateFormat dateFormat45 = null;
//        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator46 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat44, dateFormat45);
//        xYAreaRenderer32.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator46, false);
//        java.text.DateFormat dateFormat49 = standardXYToolTipGenerator46.getXDateFormat();
//        java.lang.Object obj50 = standardXYToolTipGenerator46.clone();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(textBlock18);
//        org.junit.Assert.assertNotNull(textBlockAnchor22);
//        org.junit.Assert.assertNotNull(textBlockAnchor27);
//        org.junit.Assert.assertNotNull(shape31);
//        org.junit.Assert.assertNull(xYURLGenerator38);
//        org.junit.Assert.assertNull(legendItem41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNull(dateFormat49);
//        org.junit.Assert.assertNotNull(obj50);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.scale(range0, (double) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
//        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.plot.Marker marker6 = null;
//        java.awt.geom.Rectangle2D rectangle2D7 = null;
//        xYAreaRenderer0.drawRangeMarker(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4, valueAxis5, marker6, rectangle2D7);
//        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        combinedDomainXYPlot4.setRangeAxisLocation((int) (byte) 1, axisLocation10, false);
//        float float13 = combinedDomainXYPlot4.getBackgroundAlpha();
//        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
//        java.awt.Stroke stroke16 = combinedDomainXYPlot4.getDomainZeroBaselineStroke();
//        org.jfree.chart.plot.PlotOrientation plotOrientation17 = combinedDomainXYPlot4.getOrientation();
//        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot18.getRangeAxis((int) (byte) -1);
//        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
//        categoryPlot18.setFixedDomainAxisSpace(axisSpace21, true);
//        categoryPlot18.setRangeGridlinesVisible(true);
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
//        xYAreaRenderer26.setLegendItemURLGenerator(xYSeriesLabelGenerator27);
//        java.awt.Graphics2D graphics2D29 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
//        org.jfree.chart.plot.Marker marker32 = null;
//        java.awt.geom.Rectangle2D rectangle2D33 = null;
//        xYAreaRenderer26.drawRangeMarker(graphics2D29, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30, valueAxis31, marker32, rectangle2D33);
//        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        combinedDomainXYPlot30.setRangeAxisLocation((int) (byte) 1, axisLocation36, false);
//        org.jfree.chart.util.RectangleInsets rectangleInsets39 = combinedDomainXYPlot30.getInsets();
//        java.lang.String str40 = rectangleInsets39.toString();
//        categoryPlot18.setInsets(rectangleInsets39);
//        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        int int45 = day44.getMonth();
//        long long46 = day44.getFirstMillisecond();
//        java.util.Date date47 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
//        int int49 = day48.getMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day44, (org.jfree.data.time.RegularTimePeriod) day48);
//        boolean boolean51 = periodAxis50.isAutoRange();
//        periodAxis50.setMinorTickMarksVisible(true);
//        org.jfree.data.time.TimeSeries timeSeries54 = null;
//        java.util.TimeZone timeZone55 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection56 = new org.jfree.data.time.TimeSeriesCollection(timeSeries54, timeZone55);
//        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection56);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer59 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot60 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection56, (org.jfree.chart.axis.ValueAxis) numberAxis3D58, polarItemRenderer59);
//        java.lang.Comparable comparable61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeriesCollection56.getSeries(comparable61);
//        org.jfree.chart.text.TextAnchor textAnchor63 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
//        boolean boolean64 = timeSeriesCollection56.equals((java.lang.Object) textAnchor63);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent65 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) true, (org.jfree.data.general.Dataset) timeSeriesCollection56);
//        categoryPlot18.datasetChanged(datasetChangeEvent65);
//        combinedDomainXYPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot18);
//        org.junit.Assert.assertNotNull(axisLocation10);
//        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(plotOrientation17);
//        org.junit.Assert.assertNull(valueAxis20);
//        org.junit.Assert.assertNotNull(axisLocation36);
//        org.junit.Assert.assertNotNull(rectangleInsets39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str40.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560409200000L + "'", long46 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNull(range57);
//        org.junit.Assert.assertNull(timeSeries62);
//        org.junit.Assert.assertNotNull(textAnchor63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }
//}

